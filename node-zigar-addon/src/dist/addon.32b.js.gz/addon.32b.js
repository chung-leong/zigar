(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, i = 3, s = 4, o = 5, a = 6, c = 7, l = Object.keys(e), u = 1, f = 2, h = 4, d = 8, g = 16, p = {
        IsSize: 32
    }, y = 32, m = 64, b = 128, w = 256, v = {
        IsExtern: 32,
        IsPacked: 64,
        IsTuple: 128,
        IsOptional: 256
    }, S = 32, I = 64, A = 128, x = 32, E = 32, M = 32, U = 64, k = 128, O = 256, V = 512, B = 32, T = 64, $ = 128, z = 256, _ = 512, C = {
        IsGlobal: 32
    }, j = 32, L = 64, F = 32, R = 64, N = 128, P = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, D = Object.keys(P), W = 1, Z = 2, G = 4, q = 16, J = 32, H = 128, Y = 256, X = 512, K = 1024, Q = 2048, tt = {
        Pointer: 1,
        Slice: 2,
        Const: 4,
        ReadOnly: 8
    }, et = 1, nt = 2, rt = 4, it = 8, st = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, ot = 0, at = 2, ct = 6, lt = 8, ut = 16, ft = 20, ht = 21, dt = 28, gt = 29, pt = 34, yt = 44, mt = 51, bt = 58, wt = 63, vt = 70, St = 76, It = {
        unknown: 0,
        blockDevice: 1,
        characterDevice: 2,
        directory: 3,
        file: 4,
        socketDgram: 5,
        socketStream: 6,
        symbolicLink: 7
    }, At = {
        create: 1,
        directory: 2,
        exclusive: 4,
        truncate: 8
    }, xt = {
        symlinkFollow: 1
    }, Et = {
        fd_datasync: 1,
        fd_read: 2,
        fd_seek: 4,
        fd_fdstat_set_flags: 8,
        fd_sync: 16,
        fd_tell: 32,
        fd_write: 64,
        fd_advise: 128,
        fd_allocate: 256,
        path_create_directory: 512,
        path_create_file: 1024,
        path_link_source: 2048,
        path_link_target: 4096,
        path_open: 8192,
        fd_readdir: 16384,
        path_readlink: 32768,
        path_rename_source: 65536,
        path_rename_target: 1 << 17,
        path_filestat_get: 1 << 18,
        path_filestat_set_size: 1 << 19,
        path_filestat_set_times: 1 << 20,
        fd_filestat_get: 1 << 21,
        fd_filestat_set_size: 1 << 22,
        fd_filestat_set_times: 1 << 23,
        path_symlink: 1 << 24,
        path_remove_directory: 1 << 25,
        path_unlink_file: 1 << 26,
        poll_fd_readwrite: 1 << 27,
        sock_shutdown: 1 << 28,
        sock_accept: 1 << 29
    }, Mt = {
        append: 1,
        dsync: 2,
        nonblock: 4,
        rsync: 8,
        sync: 16
    }, Ut = {
        stdin: 0,
        stdout: 1,
        stderr: 2,
        root: -1,
        min: 15728640,
        max: 16777215
    }, kt = 0, Ot = 1, Vt = 2, Bt = globalThis[Symbol.for("ZIGAR")] ??= {};
    function Tt(t) {
        return Bt[t] ??= Symbol(t);
    }
    function $t(t) {
        return Tt(t);
    }
    const zt = $t("memory"), _t = $t("slots"), Ct = $t("parent"), jt = $t("zig"), Lt = $t("name"), Ft = $t("type"), Rt = $t("flags"), Nt = $t("class"), Pt = $t("tag"), Dt = $t("props"), Wt = $t("sentinel"), Zt = $t("target"), Gt = $t("entries"), qt = $t("max length"), Jt = $t("keys"), Ht = $t("address"), Yt = $t("length"), Xt = $t("last address"), Kt = $t("last length"), Qt = $t("cache"), te = $t("size"), ee = $t("bit size"), ne = $t("align"), re = $t("environment"), ie = $t("attributes"), se = $t("primitive"), oe = $t("getters"), ae = $t("setters"), ce = $t("typed array"), le = $t("throwing"), ue = $t("promise"), fe = $t("generator"), he = $t("allocator"), de = $t("fallback"), ge = $t("signature"), pe = $t("controller"), ye = $t("proxy type"), me = $t("read only"), be = $t("no cache"), we = $t("update"), ve = $t("reset"), Se = $t("vivificate"), Ie = $t("visit"), Ae = $t("shape"), xe = $t("initialize"), Ee = $t("restrict"), Me = $t("finalize"), Ue = $t("proxy"), ke = $t("cast"), Oe = $t("return"), Ve = $t("yield"), Be = $t("transform");
    function Te(t, e, n) {
        if (n) {
            const {set: r, get: i, value: s, enumerable: o, configurable: a = !0, writable: c = !0} = n;
            Object.defineProperty(t, e, i || r ? {
                get: i,
                set: r,
                configurable: a,
                enumerable: o
            } : {
                value: s,
                configurable: a,
                enumerable: o,
                writable: c
            });
        }
        return t;
    }
    function $e(t, e) {
        for (const [n, r] of Object.entries(e)) Te(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            Te(t, n, e[n]);
        }
        return t;
    }
    function ze(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function _e(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function Ce({type: t, bitSize: e}) {
        switch (t) {
          case P.Bool:
            return "boolean";

          case P.Int:
          case P.Uint:
            if (e > 32) return "bigint";

          case P.Float:
            return "number";
        }
    }
    function je(t, e = "utf-8") {
        const n = Fe[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let i = 0;
            for (const e of t) r.set(e, i), i += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function Le(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (Re[e] ||= new TextEncoder).encode(t);
    }
    const Fe = {}, Re = {};
    function Ne(t, e, n) {
        let r = 0, i = t.length;
        if (0 === i) return 0;
        for (;r < i; ) {
            const s = Math.floor((r + i) / 2);
            n(t[s]) <= e ? r = s + 1 : i = s;
        }
        return i;
    }
    function Pe(t, e) {
        return !!e && !!(t & e - 1);
    }
    function De(t, e) {
        return t + (e - 1) & ~(e - 1);
    }
    const We = 4294967295;
    function Ze(t) {
        return Number(t);
    }
    const Ge = BigInt(Number.MAX_SAFE_INTEGER), qe = BigInt(Number.MIN_SAFE_INTEGER);
    function Je(t) {
        if (t > Ge || t < qe) throw new RangeError("Number is too big/small");
        return Number(t);
    }
    function He(t, e, n) {
        return t.getUint32(e, n);
    }
    function Ye(t, e, n) {
        return He(t, e, n);
    }
    function Xe(t) {
        return 2863311530 === t || -1431655766 === t;
    }
    function Ke(t, e) {
        return t + e;
    }
    function Qe(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function tn(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function en(t, e) {
        const n = [], r = new Map, i = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) i(n);
        };
        for (const e of t) i(e.instance.template), i(e.static.template);
        return n;
    }
    function nn(t, e) {
        return t === e || t?.[ge] === e[ge] && t?.[re] !== e?.[re];
    }
    function rn(t, e) {
        return t instanceof e || nn(t?.constructor, e);
    }
    function sn(t, e) {
        return "function" == typeof t?.[e];
    }
    function on(t) {
        return "function" == typeof t?.then;
    }
    function an(t, e) {
        const n = {};
        for (const [r, i] of Object.entries(e)) t & i && (n[r] = !0);
        return n;
    }
    function cn(t, e) {
        for (const [n, r] of Object.entries(e)) if (n === t) return r;
    }
    function ln({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function un(t) {
        return new DataView(new ArrayBuffer(t));
    }
    function fn(t, e, n = 0) {
        const r = new Uint8Array(t.buffer, t.byteOffset, t.byteLength);
        e[de]?.(!1, n);
        const i = new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
        r.set(i, n), t[de]?.(!0, n);
    }
    function hn(t, e = 0, n = t.byteLength - e) {
        new Uint8Array(t.buffer, t.byteOffset, t.byteLength).fill(0, e, e + n), t[de]?.(!0, e, n);
    }
    function dn(t, e) {
        fn(t[zt], e[zt]);
    }
    function gn() {
        return this;
    }
    function pn() {
        return String(this);
    }
    function yn() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return t[be] ? void 0 : this.map.get(t);
        }
        save(t, e) {
            t[be] || this.map.set(t, e);
        }
    }
    const mn = 1, bn = 2, wn = 4, vn = 8, Sn = () => 1e3 * new Date;
    function In(t, e, n) {
        const r = {};
        return n & mn ? r.atime = t : n & bn && (r.atime = Sn()), n & wn ? r.mtime = e : n & vn && (r.mtime = Sn()), 
        r;
    }
    const An = {
        name: "",
        mixins: []
    };
    function xn(t) {
        return An.mixins.includes(t) || An.mixins.push(t), t;
    }
    function En() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: i} = r;
            Te(r, "name", ze(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = i[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                Te(i, e, ze(r));
            }
            return r;
        }(An.name, An.mixins);
    }
    function Mn(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, i) {
                const s = n.getUint8(i) >> t & r;
                e.setUint8(0, s);
            };
            {
                const e = 255 ^ r << t;
                return function(n, i, s) {
                    const o = i.getUint8(0), a = n.getUint8(s) & e | (o & r) << t;
                    n.setUint8(s, a);
                };
            }
        }
        {
            const r = 8 - t, i = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(s, o, a) {
                    let c, l = a, u = 0, f = o.getUint8(l++), h = f >> t & i, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), c = g >= 8 ? 255 & h : h & n, s.setUint8(u++, c), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, s = 255 ^ i << t, o = 255 ^ n;
                return function(r, i, a) {
                    let c, l, u = 0, f = a, h = r.getUint8(f), d = h & s, g = t, p = e + g;
                    do {
                        p > g && (c = i.getUint8(u++), d |= c << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    xn({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: i, byteSize: s} = e, o = [], a = void 0 === s && (7 & r || 7 & i);
            a && o.push("Unaligned");
            let c = D[n];
            r > 32 && (n === P.Int || n === P.Uint) && (c = r <= 64 ? `Big${c}` : `Jumbo${c}`), 
            o.push(c, `${n === P.Bool && s ? s << 3 : r}`), a && o.push(`@${i}`);
            const l = t + o.join("");
            let u = this.accessorCache.get(l);
            if (u) return u;
            if (u = DataView.prototype[l], !u) {
                for (;o.length > 0; ) {
                    const n = `getAccessor${o.join("")}`;
                    if (u = this[n]?.(t, e)) break;
                    o.pop();
                }
                if (!u) throw new Error(`No accessor available: ${l}`);
            }
            if (u && this.usingBufferFallback()) {
                const e = u;
                u = "get" === t ? function(t, n) {
                    return this[de]?.(!1, t, s), e.call(this, t, n);
                } : function(t, n, r) {
                    e.call(this, t, n, r), this[de]?.(!0, t, s);
                };
            }
            return u.name || Te(u, "name", ze(l)), this.accessorCache.set(l, u), u;
        }
    }), xn({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), i = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & i) - (n & r);
            } : function(t, e, n) {
                const s = e < 0 ? r | e & i : e & i;
                this.setBigUint64(t, s, n);
            };
        }
    }), xn({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const i = e & r;
                this.setBigUint64(t, i, n);
            };
        }
    }), xn({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, i = this.getAccessor(t, {
                type: P.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!i.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, s) {
                    i.call(this, n, r ? e : t, s);
                };
            }
        }
    }), xn({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = un(8), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, a = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(a), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, a = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : s ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | c << 52n | (a >> 60n) + BigInt((a & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, a = (0x7ff0000000000000n & i) >> 52n, c = 0x000fffffffffffffn & i;
                let l;
                l = 0n === a ? o << 127n | c << 60n : 0x07ffn === a ? o << 127n | 0x7fffn << 112n | (c ? 1n : 0n) : o << 127n | a - 1023n + 16383n << 112n | c << 60n, 
                s.call(this, t, l, n);
            };
        }
    }), xn({
        getAccessorFloat16(t, e) {
            const n = un(4), r = DataView.prototype.setUint16, i = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = i.call(this, t, e), s = r >>> 15, o = (31744 & r) >> 10, a = 1023 & r;
                if (0 === o) return s ? -0 : 0;
                if (31 === o) return a ? NaN : s ? -1 / 0 : 1 / 0;
                const c = s << 31 | o - 15 + 127 << 23 | a << 13;
                return n.setUint32(0, c, e), n.getFloat32(0, e);
            } : function(t, e, i) {
                n.setFloat32(0, e, i);
                const s = n.getUint32(0, i), o = s >>> 31, a = (2139095040 & s) >> 23, c = 8388607 & s, l = a - 127 + 15;
                let u;
                u = 0 === a ? o << 15 : 255 === a ? o << 15 | 31744 | (c ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | c >> 13, 
                r.call(this, t, u, i);
            };
        }
    }), xn({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = un(8), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, a = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : s ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | c << 52n | (a >> 11n) + BigInt((a & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, a = (0x7ff0000000000000n & i) >> 52n, c = 0x000fffffffffffffn & i;
                let l;
                l = 0n === a ? o << 79n | c << 11n : 0x07ffn === a ? o << 79n | 0x7fffn << 64n | (c ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | a - 1023n + 16383n << 64n | c << 11n | 0x00008000000000000000n, 
                s.call(this, t, l, n);
            };
        }
    }), xn({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: P.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), i = 2 ** (n - 1), s = i - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & s) - (r & i);
                } : function(t, n, r) {
                    const o = n < 0 ? i | n & s : n & s;
                    e.call(this, t, o, r);
                };
            }
        }
    }), xn({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n - 1), s = i - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & s) - (n & i);
            } : function(t, e, n) {
                const o = e < 0 ? i | e & s : e & s;
                r.call(this, t, o, n);
            };
        }
    }), xn({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & i;
            } : function(t, e, n) {
                const s = e & i;
                r.call(this, t, s, n);
            };
        }
    }), xn({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let i = 0, s = t + 8 * (n - 1); i < n; i++, s -= 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                } else for (let i = 0, s = t; i < n; i++, s += 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                }
                return r;
            } : function(t, e, r) {
                let i = e;
                const s = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                }
            };
        }
    }), xn({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const i = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), s = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return i.call(this, t, e) & s;
                } : function(t, e, n) {
                    const r = e & s;
                    i.call(this, t, r, n);
                };
            }
        }
    }), xn({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), i = e ? n | r : n & ~r;
                this.setInt8(t, i);
            };
        }
    }), xn({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> i;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << i;
                    return function(n, s) {
                        let o = this.getUint8(n);
                        o = o & t | (s < 0 ? e | s & r : s & r) << i, this.setUint8(n, o);
                    };
                }
            }
        }
    }), xn({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> i & e;
                };
                {
                    const t = 255 ^ e << i;
                    return function(n, r) {
                        const s = this.getUint8(n) & t | (r & e) << i;
                        this.setUint8(n, s);
                    };
                }
            }
        }
    }), xn({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r, s = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = un(s);
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: s
                }), r = Mn(i, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: s
                }), r = Mn(i, n, !1);
                return function(e, n, i) {
                    t.call(o, 0, n, i), r(this, o, e);
                };
            }
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        errno=bt;
        hide=!0;
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: i, type: s, byteSize: o} = t, a = n.byteLength, c = 1 !== o ? "s" : "";
            let l;
            if (s !== e.Slice || r) {
                l = `${i} has ${s === e.Slice ? r.length * o : o} byte${c}, received ${a}`;
            } else l = `${i} has elements that are ${o} byte${c} in length, received ${a}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: i} = t, s = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(Cn);
            let a;
            i && o.push(Cn(i.name)), a = n === e.Slice ? `Expecting ${Ln(o)} that can accommodate items ${r} byte${s} in length` : `Expecting ${Ln(o)} that is ${r} byte${s} in length`, 
            super(a);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let i;
            "string" === r || "number" === r || zn(e) ? (zn(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            i = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : i = `Error of the type ${n} expected, received ${e}`, 
            super(i);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Error given is not a part of error set ${n}: ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: i}} = t;
            super(`${r} needs an initializer for one of its union properties: ${i.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, i = [];
            if (Array.isArray(e)) for (const t of e) i.push(Cn(t)); else i.push(Cn(e));
            const s = _n(n);
            super(`${r} expects ${Ln(i)} as argument, received ${s}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [i]}, type: s, constructor: o} = t, a = [], c = Ce(i);
            if (c) {
                let t;
                switch (i.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = c;
                }
                a.push(`array of ${t}s`);
            } else a.push("array of objects");
            o[ce] && a.push(o[ce].name), s === e.Slice && r && a.push("length"), super(t, a.join(" or "), n);
        }
    }
    class InvalidEnumValue extends TypeError {
        errno=dt;
        constructor(t, e) {
            super(`Received '${e}', which is not among the following possible values:\n\n${Object.keys(t).map((t => `${t}\n`)).join("")}`);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: i, instance: {members: [s]}} = t, {structure: {constructor: o}} = s, {length: a, constructor: c} = n, l = e?.length ?? i, u = 1 !== l ? "s" : "";
            let f;
            f = c === o ? "only a single one" : c.child === o ? `a slice/array that has ${a}` : `${a} initializer${a > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let i;
            i = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(i);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const i = 1 !== (t -= r) ? "s" : "", s = n ? "at least " : "";
                this.message = `Expecting ${s}${t} argument${i}, received ${e}`, this.stack = kn(this.stack, "new Arg(");
            };
            r(0), Te(this, we, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: i} = t;
            super(`${i} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = _n(e);
            super(`Expected ${Cn(t)}, received ${n}`);
        }
    }
    class InvalidStream extends TypeError {
        constructor(t, e) {
            const n = [];
            t & Et.fd_read && n.push("ReadableStreamDefaultReader", "ReadableStreamBYOBReader", "Blob", "Uint8Array"), 
            t & Et.fd_write && n.push("WritableStreamDefaultWriter", "array", "null"), t & Et.fd_readdir && n.push("Map");
            super(`Expected ${n.join(", ")}, or an object with the appropriate stream interface, received ${e}`);
        }
    }
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${jn(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + D[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class InvalidFileDescriptor extends Error {
        errno=lt;
        constructor() {
            super("Invalid file descriptor");
        }
    }
    class InvalidPath extends Error {
        errno=yt;
        constructor(t) {
            super(`Invalid relative path '${t}'`);
        }
    }
    class MissingStreamMethod extends Error {
        constructor(t, e = vt) {
            super(`Missing stream method '${t}'`), this.errno = e, this.hide = e === vt;
        }
    }
    class InvalidArgument extends Error {
        errno=dt;
        constructor() {
            super("Invalid argument");
        }
    }
    class WouldBlock extends Error {
        errno=ct;
        hide=!0;
        constructor() {
            super("Would block");
        }
    }
    class TooManyFiles extends Error {
        errno=pt;
        constructor() {
            super("Too many open files");
        }
    }
    class Deadlock extends Error {
        errno=ut;
        constructor() {
            super("Deadlock");
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = kn(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function Un(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = kn(t.stack, "new Arg(");
        };
        return n(0), Te(t, we, {
            value: n,
            enumerable: !1
        }), t;
    }
    function kn(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function On() {
        throw new ReadOnly;
    }
    function Vn(t = !1, e, n, r, i) {
        const s = t => {
            let n;
            return i ? n = i(t) : t.hide || console.error(t), n ?? t.errno ?? e;
        }, o = t => {
            const e = r?.(t);
            return e ?? ot;
        };
        try {
            const e = n();
            if (on(e)) {
                if (!t) throw new Deadlock;
                return e.then(o).catch(s);
            }
            return o(e);
        } catch (t) {
            return s(t);
        }
    }
    function Bn(t, e) {
        if (!(t[0] & e)) throw new InvalidFileDescriptor;
    }
    function Tn(t, e, n) {
        if (!sn(t, e)) throw new MissingStreamMethod(e, n);
    }
    function $n(t, e) {
        if (!0 === t) return ot;
        if (!1 === t) return e;
        throw new TypeMismatch("boolean", t);
    }
    function zn(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function _n(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        Cn(n);
    }
    function Cn(t) {
        return `${jn(t)} ${t}`;
    }
    function jn(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function Ln(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function Fn(t) {
        let n, r = 1, i = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[jt]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[zt]) t.constructor[Ft] === e.Pointer && (t = t["*"]), 
        n = t[zt], i = t.constructor, r = i[ne]; else {
            "string" == typeof t && (t = Le(t));
            const {buffer: e, byteOffset: i, byteLength: s, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== i && void 0 !== s && (n = new DataView(e, i, s), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: i
        };
    }
    xn({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: i}, ptr: s} = this, o = i(s, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const a = o["*"][zt];
                return a[jt].align = e, a;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = Fn(e), i = n?.[jt];
                    if (!i) throw new TypeMismatch("object containing allocated Zig memory", e);
                    const {address: s} = i;
                    if (-1 === s) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: a} = this;
                    o(a, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe: () => ({
            value(t) {
                const {dv: e, align: n, constructor: r} = Fn(t);
                if (!e) throw new TypeMismatch("string, DataView, typed array, or Zig object", t);
                const i = this.alloc(e.byteLength, n);
                return fn(i, e), r ? r(i) : i;
            }
        })
    });
    const Rn = [ "log", "mkdir", "stat", "utimes", "open", "rename", "readlink", "rmdir", "symlink", "unlink" ];
    xn({
        init() {
            this.variables = [], this.listenerMap = new Map, this.envVariables = this.envVarArrays = null;
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: () => this.initPromise,
                abandon: () => this.abandonModule?.(),
                redirect: (t, e) => this.redirectStream(t, e),
                sizeOf: e => t(e?.[te]),
                alignOf: e => t(e?.[ne]),
                typeOf: e => Nn[t(e?.[Ft])],
                on: (t, e) => this.addListener(t, e),
                set: (t, e) => this.setObject(t, e)
            };
        },
        addListener(t, e) {
            const n = Rn.indexOf(t);
            if (!(n >= 0)) throw new Error(`Unknown event: ${t}`);
            if (!this.ioRedirection) throw new Error("Redirection disabled");
            this.listenerMap.set(t, e), n >= 1 && this.setRedirectionMask(t, !!e);
        },
        hasListener(t) {
            return this.listenerMap.get(t);
        },
        setObject(t, e) {
            if ("object" != typeof e) throw new TypeMismatch("object", e);
            if ("env" !== t) throw new Error(`Unknown object: ${t}`);
            this.envVariables = e, this.libc && this.initializeLibc();
        },
        triggerEvent(t, e) {
            const n = this.listenerMap.get(t);
            return n?.(e);
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = s(r);
                return t;
            }, r = [], i = t => t.length ? t.buffer : new ArrayBuffer(0), s = t => {
                const {memory: e, structure: s, actual: o, slots: a} = t;
                if (e) {
                    if (o) return o;
                    {
                        const {array: o, offset: c, length: l} = e, u = this.obtainView(i(o), c, l), {handle: f} = t, {constructor: h} = s, d = h.call(re, u);
                        return a && n(d[_t], a), void 0 !== f ? this.variables.push({
                            handle: f,
                            object: d
                        }) : void 0 === c && r.push(d), t.actual = d, d;
                    }
                }
                return s;
            }, o = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: r} = t.template, s = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: o} = n;
                        s[zt] = this.obtainView(i(t), e, o), void 0 !== r && this.variables.push({
                            handle: r,
                            object: s
                        });
                    }
                    if (e) {
                        const t = s[_t] = {};
                        o.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of o) n(t, e);
            for (const e of t) this.finalizeStructure(e);
            for (const t of r) this.makeReadOnly(t);
        },
        imports: {
            initializeLibc: {}
        }
    });
    const Nn = l.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    xn({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[zt]), i = this.createJsThunk(t, n);
                if (!i) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(i, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                try {
                    const i = e(n);
                    if (Ie in i) {
                        i[Ie]("reset", st.IgnoreUncreated);
                        const t = this.startContext();
                        this.updatePointerTargets(t, i, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const s = [ ...i ], o = i.hasOwnProperty(Oe), a = Vn(r || o, ht, (() => t(...s)), (t => {
                        if (t?.[Symbol.asyncIterator]) {
                            if (!i.hasOwnProperty(Ve)) throw new UnexpectedGenerator;
                            this.pipeContents(t, i);
                        } else i[Oe](t);
                    }), (t => {
                        try {
                            if (e[le] && t instanceof Error) return i[Oe](t), ot;
                            throw t;
                        } catch (e) {
                            console.error(t);
                        }
                    }));
                    return o ? ot : a;
                } catch (t) {
                    return console.error(t), ht;
                }
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, a = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === s)).length;
            return {
                value() {
                    let c, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, y, m = this[d];
                        if (p === P.Object && m?.[zt]?.[jt] && (m = new m.constructor(m)), g.type === e.Struct) switch (g.purpose) {
                          case s:
                            t = 1 === a ? "allocator" : "allocator" + ++l, y = this[he] = m;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (y = o.createPromiseCallback(this, m));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (y = o.createGeneratorCallback(this, m));
                            break;

                          case i:
                            t = "signal", 1 == ++f && (y = o.createInboundSignal(m));
                        }
                        void 0 !== t ? void 0 !== y && (c ||= {}, c[t] = y) : h.push(m);
                    } catch (t) {
                        h.push(t);
                    }
                    return c && h.push(c), h[Symbol.iterator]();
                }
            };
        },
        handleJscall(t, e, n, r) {
            const i = this.obtainZigView(e, n, !1), s = this.jsFunctionCallerMap.get(t);
            return s ? s(i, r) : ht;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[zt]), i = this.getViewAddress(e);
                this.destroyJsThunk(r, i), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJscall: {
                async: !0
            },
            releaseFunction: {}
        },
        imports: {
            createJsThunk: {},
            destroyJsThunk: {},
            finalizeAsyncCall: {}
        }
    }), xn({
        createOutboundCaller(t, e) {
            const n = this, r = function(...i) {
                const s = new e(i, this?.[he]);
                return n.invokeThunk(t, r, s);
            };
            return r;
        },
        copyArguments(t, o, l, u, f) {
            let h = 0, d = 0, g = 0;
            const p = t[ae];
            for (const {type: y, structure: m} of l) {
                let l, b, w, v;
                if (m.type === e.Struct) switch (m.purpose) {
                  case s:
                    l = (1 == ++g ? u?.allocator ?? u?.allocator1 : u?.[`allocator${g}`]) ?? this.createDefaultAllocator(t, m);
                    break;

                  case n:
                    b ||= this.createPromise(m, t, u?.callback), l = b;
                    break;

                  case r:
                    w ||= this.createGenerator(m, t, u?.callback), l = w;
                    break;

                  case i:
                    v ||= this.createSignal(m, u?.signal), l = v;
                    break;

                  case a:
                    l = this.createFile(o[d++]);
                    break;

                  case c:
                    l = this.createDirectory(o[d++]);
                }
                if (void 0 === l && (l = o[d++], void 0 === l && y !== P.Void)) throw new UndefinedArgument;
                try {
                    p[h++].call(t, l, f);
                } catch (t) {
                    throw Un(t, h - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), i = n[ie], s = this.getViewAddress(t[zt]), o = this.getViewAddress(e[zt]), a = Me in n, c = Ie in n;
            c && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[zt]), u = i ? this.getViewAddress(i[zt]) : 0;
            this.updateShadows(r);
            let f = !1;
            const h = () => {
                this.updateShadowTargets(r), c && this.updatePointerTargets(r, n), this.flushStreams?.(), 
                this.endContext(), f = !0;
            };
            a && (n[Me] = h);
            if (!(i ? this.runVariadicThunk(s, o, l, u, i.length) : this.runThunk(s, o, l))) throw f || h(), 
            new ZigError;
            const d = e[Be];
            if (a) {
                let t = null;
                if (!f) try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (d && (t = d(t)), n[Oe](t)) : d && (n[Be] = d), n[ue] ?? n[fe];
            }
            h();
            try {
                const {retval: t} = n;
                return d ? d(t) : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    });
    class AsyncReader {
        bytes=null;
        promise=null;
        done=!1;
        readnb(t) {
            if ("number" != typeof this.poll()) throw new WouldBlock;
            return this.shift(t);
        }
        async read(t) {
            return await this.poll(), this.shift(t);
        }
        store({done: t, value: e}) {
            return t ? (this.done = !0, 0) : (e instanceof Uint8Array || (e = e instanceof ArrayBuffer ? new Uint8Array(e) : e.buffer instanceof ArrayBuffer ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : Le(e + "")), 
            this.bytes = e, e.length);
        }
        shift(t) {
            let e;
            return this.bytes && (this.bytes.length > t ? (e = this.bytes.subarray(0, t), this.bytes = this.bytes.subarray(t)) : (e = this.bytes, 
            this.bytes = null)), e ?? new Uint8Array(0);
        }
        poll() {
            const t = this.bytes?.length;
            return t || (this.promise ??= this.fetch().then((t => (this.promise = null, this.store(t)))));
        }
    }
    class WebStreamReader extends AsyncReader {
        onClose=null;
        constructor(t) {
            super();
            const e = t instanceof ReadableStream ? t.getReader() : t;
            this.reader = e, Dn(t, this);
        }
        async fetch() {
            return this.reader.read();
        }
        destroy() {
            this.done || this.reader.cancel(), this.bytes = null;
        }
        valueOf() {
            return this.reader;
        }
    }
    class WebStreamReaderBYOB extends WebStreamReader {
        async fetch() {
            const t = new Uint8Array(Wn);
            return this.reader.read(t);
        }
    }
    class AsyncWriter {
        promise=null;
        writenb(t) {
            if ("number" != typeof this.poll()) throw new WouldBlock;
            this.queue(t);
        }
        async write(t) {
            await this.poll(), await this.queue(t);
        }
        queue(t) {
            return this.promise = this.send(t).then((() => {
                this.promise = null;
            }));
        }
        poll() {
            return this.promise?.then?.((() => Zn)) ?? Zn;
        }
    }
    class WebStreamWriter extends AsyncWriter {
        onClose=null;
        done=!1;
        constructor(t) {
            let e;
            super(), t instanceof WritableStream ? (e = t.getWriter(), t.close = async () => {
                delete t.close, await e.close(), e.releaseLock();
            }) : e = t, this.writer = e, e.closed.catch(yn).then((() => {
                this.done = !0, this.onClose?.();
            }));
        }
        async send(t) {
            await this.writer.write(t);
        }
        destroy() {
            this.done || this.writer.close();
        }
        valueOf() {
            return this.writer;
        }
    }
    class BlobReader extends AsyncReader {
        pos=0;
        onClose=null;
        constructor(t) {
            super(), this.blob = t, this.size = t.size, Dn(t, this);
        }
        async fetch() {
            const t = await this.pread(Wn, this.pos), {length: e} = t;
            return {
                done: !e,
                value: e ? t : null
            };
        }
        async pread(t, e) {
            const n = this.blob.slice(e, e + t), r = new Response(n), i = await r.arrayBuffer();
            return new Uint8Array(i);
        }
        async read(t) {
            const e = await super.read(t);
            return this.pos += e.length, e;
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            return this.done = !1, this.bytes = null, this.pos = Pn(e, t, this.pos, this.size);
        }
        valueOf() {
            return this.blob;
        }
    }
    class Uint8ArrayReader {
        pos=0;
        onClose=null;
        constructor(t) {
            this.array = t, this.size = t.length, Dn(t, this);
        }
        readnb(t) {
            return this.read(t);
        }
        read(t) {
            const e = this.pread(t, this.pos);
            return this.pos += e.length, e;
        }
        pread(t, e) {
            return this.array.subarray(e, e + t);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            return this.pos = Pn(e, t, this.pos, this.size);
        }
        poll() {
            return this.size - this.pos;
        }
        valueOf() {
            return this.array;
        }
    }
    class Uint8ArrayReadWriter extends Uint8ArrayReader {
        writenb(t) {
            return this.write(t);
        }
        write(t) {
            this.pwrite(t, this.pos), this.pos += t.length;
        }
        pwrite(t, e) {
            this.array.set(t, e);
        }
    }
    class StringReader extends Uint8ArrayReader {
        constructor(t) {
            super(Le(t)), this.string = t, Dn(t, this);
        }
        valueOf() {
            return this.string;
        }
    }
    class ArrayWriter {
        constructor(t) {
            this.array = t, this.closeCB = null, Dn(t, this);
        }
        writenb(t) {
            this.write(t);
        }
        write(t) {
            this.array.push(t);
        }
        poll() {
            return Zn;
        }
        valueOf() {
            return this.array;
        }
    }
    class NullStream {
        read() {
            return this.pread();
        }
        pread() {
            return new Uint8Array(0);
        }
        write() {}
        pwrite() {}
        poll(t) {
            return t === Ot ? 0 : Zn;
        }
        valueOf() {
            return null;
        }
    }
    class MapDirectory {
        onClose=null;
        keys=null;
        cookie=0;
        constructor(t) {
            this.map = t, this.size = t.size, Dn(t, this);
        }
        readdir() {
            const t = this.cookie;
            let e;
            switch (t) {
              case 0:
              case 1:
                e = {
                    name: ".".repeat(t + 1),
                    type: "directory"
                };
                break;

              default:
                this.keys || (this.keys = [ ...this.map.keys() ]);
                const n = this.keys[t - 2];
                if (void 0 === n) return null;
                e = {
                    name: n,
                    ...this.map.get(n)
                };
            }
            return this.cookie++, e;
        }
        seek(t) {
            return this.cookie = t;
        }
        tell() {
            return this.cookie;
        }
        valueOf() {
            return this.map;
        }
    }
    function Pn(t, e, n, r) {
        let i = -1;
        switch (t) {
          case 0:
            i = e;
            break;

          case 1:
            i = n + e;
            break;

          case 2:
            i = r + e;
        }
        if (!(i >= 0 && i <= r)) throw new InvalidArgument;
        return i;
    }
    function Dn(t, e) {
        if ("object" == typeof t) {
            const n = t.close;
            Te(t, "close", {
                value: () => {
                    n?.(), e.onClose?.(), delete t.close;
                }
            });
        }
    }
    const Wn = 8192, Zn = 16777216;
    function Gn(t, e) {
        return Ne(t, e, (t => t.address));
    }
    xn({
        convertDirectory: t => t instanceof Map ? new MapDirectory(t) : sn(t, "readdir") ? t : void 0
    }), xn({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: i, bitSize: s} = n;
            if ("set" === e) return s > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const i = Number(e);
                if (!isFinite(i)) throw new InvalidIntConversion(e);
                r.call(this, t, i, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & p.IsSize && s > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, i) {
                        const s = r.call(this, n, i);
                        return e <= s && s <= t ? Number(s) : s;
                    };
                }
            }
            return r;
        }
    }), xn({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const i = e[zt];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: s, targets: o} = n;
                    let a, c = 0;
                    for (const t of o) {
                        const e = t[zt], n = e.byteOffset, r = t.constructor[ne] ?? e[ne];
                        (void 0 === c || r > c) && (c = r, a = n);
                    }
                    const l = s - e, u = this.allocateShadowMemory(l + c, 1), f = this.getViewAddress(u), h = De(Ke(f, a - e), c), d = Ke(h, e - a);
                    for (const t of o) {
                        const n = t[zt], r = n.byteOffset;
                        if (r !== a) {
                            const i = t.constructor[ne] ?? n[ne];
                            if (Pe(Ke(d, r - e), i)) throw new AlignmentConflict(i, c);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), y = new DataView(i.buffer, Number(e), l), m = this.registerMemory(d, l, 1, r, y, p);
                    t.shadowList.push(m), n.address = d;
                }
                return Ke(n.address, i.byteOffset - n.start);
            }
            {
                const n = e.constructor[ne] ?? i[ne], s = i.byteLength, o = this.allocateShadowMemory(s, n), a = this.getViewAddress(o), c = this.registerMemory(a, s, 1, r, i, o);
                return t.shadowList.push(c), a;
            }
        },
        updateShadows(t) {
            for (let {targetDV: e, shadowDV: n} of t.shadowList) fn(n, e);
        },
        updateShadowTargets(t) {
            for (let {targetDV: e, shadowDV: n, writable: r} of t.shadowList) r && fn(e, n);
        },
        registerMemory(t, e, n, r, i, s) {
            const o = Gn(this.memoryList, t);
            let a = this.memoryList[o - 1];
            return a?.address === t && a.len === e ? a.writable ||= r : (a = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: i,
                shadowDV: s
            }, this.memoryList.splice(o, 0, a)), a;
        },
        unregisterMemory(t, e) {
            const n = Gn(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            Xe(n) && (n = 0);
            let i = n * (r ?? 0);
            const s = Gn(this.memoryList, e), o = this.memoryList[s - 1];
            let a;
            if (o?.address === e && o.len === i) a = o.targetDV; else if (o?.address <= e && Ke(e, i) <= Ke(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: s} = o;
                n && (i = s.byteLength - t), a = this.obtainView(s.buffer, s.byteOffset + t, i), 
                n && (a[ne] = o.align);
            }
            if (a) {
                let {targetDV: e, shadowDV: n} = o;
                n && t && !t.shadowList.includes(o) && fn(e, n);
            } else a = this.obtainZigView(e, i);
            return a;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[jt], n = e?.address;
            n && -1 !== n && (e.address = -1, this.unregisterBuffer(Ke(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[jt];
            if (e) return e.address;
            return Ke(this.getBufferAddress(t.buffer), t.byteOffset);
        },
        ...{
            imports: {
                getBufferAddress: {},
                obtainExternBuffer: {}
            },
            exports: {
                getViewAddress: {}
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (Xe(t) && (t = e > 0 ? 0 : We), !t && e) return null;
                let r, i, s;
                if (n) {
                    s = Gn(this.externBufferList, t);
                    const n = this.externBufferList[s - 1];
                    n?.address <= t && Ke(t, e) <= Ke(n.address, n.len) && (r = n.buffer, i = Number(t - n.address));
                }
                r || (r = e > 0 ? this.obtainExternBuffer(t, e, de) : new ArrayBuffer(0), r[jt] = {
                    address: t,
                    len: e
                }, i = 0, n && this.externBufferList.splice(s, 0, {
                    address: t,
                    len: e,
                    buffer: r
                }));
                const o = this.obtainView(r, i, e, n);
                return o[de]?.(!1), o;
            },
            unregisterBuffer(t) {
                const e = Gn(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const i = e[zt];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(i.buffer);
                        for (const e of n.targets) {
                            const r = e[zt].byteOffset, i = e.constructor[ne];
                            if (Pe(Ke(t, r), i)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return Ke(n.address, i.byteOffset);
                } else {
                    const t = e.constructor[ne], n = this.getViewAddress(i);
                    if (!Pe(n, t)) {
                        const e = i.byteLength;
                        return this.registerMemory(n, e, t, r, i), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), xn({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: {}
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const {async: r = !1} = n;
                    let i = this[e];
                    i && (r && (i = this.addPromiseHandling(i)), t[e] = i.bind(this));
                }
                return t;
            },
            addPromiseHandling(t) {
                const e = t.length - 1;
                return function(...n) {
                    const r = n[e], i = !!r;
                    n[e] = i;
                    const s = t.call(this, ...n);
                    return i ? (on(s) ? s.then((t => this.finalizeAsyncCall(r, t))) : this.finalizeAsyncCall(r, s), 
                    ot) : s;
                };
            },
            importFunctions(t) {
                for (const [e] of Object.entries(this.imports)) {
                    const n = t[e];
                    n && (Te(this, e, ze(n)), this.destructors.push((() => this[e] = qn)));
                }
            }
        }
    });
    const qn = () => {
        throw new Error("Module was abandoned");
    };
    xn({
        linkVariables(t) {
            for (const {object: e, handle: n} of this.variables) {
                const r = e[zt], i = this.recreateAddress(n);
                let s = e[zt] = this.obtainZigView(i, r.byteLength);
                t && fn(s, r), e.constructor[Qt]?.save?.(s, e), this.destructors.push((() => {
                    fn(e[zt] = this.allocateMemory(s.byteLength), s);
                }));
                const o = t => {
                    const e = t[_t];
                    if (e) {
                        const t = s.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[zt];
                            if (e.buffer === r.buffer) {
                                const i = t + e.byteOffset - r.byteOffset;
                                n[zt] = this.obtainView(s.buffer, i, e.byteLength), n.constructor[Qt]?.save?.(s, n), 
                                o(n);
                            }
                        }
                    }
                };
                o(e), e[Ie]?.((function() {
                    this[we]();
                }), st.IgnoreInactive);
            }
            this.createDeferredThunks?.();
        },
        imports: {
            recreateAddress: null
        }
    }), xn({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, i = [], s = function(t) {
                if (void 0 === n.get(this)) {
                    const t = this[_t][0];
                    if (t) {
                        const e = {
                            target: t,
                            writable: !this.constructor.const
                        }, o = t[zt];
                        if (o[jt]) n.set(this, null); else {
                            n.set(this, t);
                            const a = r.get(o.buffer);
                            if (a) {
                                const t = Array.isArray(a) ? a : [ a ], n = Ne(t, o.byteOffset, (t => t.target[zt].byteOffset));
                                t.splice(n, 0, e), Array.isArray(a) || (r.set(o.buffer, t), i.push(t));
                            } else r.set(o.buffer, e);
                            t[Ie]?.(s, 0);
                        }
                    }
                }
            }, o = st.IgnoreRetval | st.IgnoreInactive;
            e[Ie](s, o);
            const a = this.findTargetClusters(i), c = new Map;
            for (const t of a) for (const e of t.targets) c.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = c.get(r), i = n?.writable ?? !e.constructor.const;
                e[Ht] = this.getTargetAddress(t, r, n, i), Yt in e && (e[Yt] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, i = function(e) {
                if (!r.get(this)) {
                    r.set(this, !0);
                    const n = this[_t][0], s = n && e & st.IsImmutable ? n : this[we](t, !0, !(e & st.IsInactive)), o = this.constructor.const ? st.IsImmutable : 0;
                    o & st.IsImmutable || n && !n[zt][jt] && n[Ie]?.(i, o), s !== n && s && !s[zt][jt] && s?.[Ie]?.(i, o);
                }
            }, s = n ? st.IgnoreRetval : 0;
            e[Ie](i, s);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, i = 0, s = null;
                for (const {target: o, writable: a} of n) {
                    const n = o[zt], {byteOffset: c, byteLength: l} = n, u = c + l;
                    let f = !0;
                    t && (i > c ? (s ? s.writable ||= a : (s = {
                        targets: [ t ],
                        start: r,
                        end: i,
                        address: void 0,
                        misaligned: void 0,
                        writable: a
                    }, e.push(s)), s.targets.push(o), u > i ? s.end = u : f = !1) : s = null), f && (t = o, 
                    r = c, i = u);
                }
            }
            return e;
        }
    }), xn({
        convertReader: t => t instanceof ReadableStream || t instanceof ReadableStreamDefaultReader ? new WebStreamReader(t) : "function" == typeof ReadableStreamBYOBReader && t instanceof ReadableStreamBYOBReader ? new WebStreamReaderBYOB(t) : t instanceof Blob ? new BlobReader(t) : t instanceof Uint8Array ? new Uint8ArrayReadWriter(t) : "string" == typeof t || t instanceof String ? new StringReader(t) : null === t ? new NullStream : sn(t, "read") ? t : void 0
    }), xn({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === P.Int;
                    let i = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** i) : 0,
                            max: 2 ** i - 1
                        };
                    }
                    i = BigInt(i);
                    return {
                        min: r ? -(2n ** i) : 0n,
                        max: 2n ** i - 1n
                    };
                }(n);
                return function(i, s, o) {
                    if (s < t || s > e) throw new Overflow(n, s);
                    r.call(this, i, s, o);
                };
            }
            return r;
        }
    }), xn({
        init() {
            this.streamLocationMap = new Map([ [ Ut.root, "" ] ]);
        },
        obtainStreamLocation(t, e, n) {
            const r = this.obtainZigView(e, n, !1);
            let i = je(new Uint8Array(r.buffer, r.byteOffset, r.byteLength)).trim();
            if (i.startsWith("/dev/fd/")) {
                const t = parseInt(i.slice(8)), e = this.getStreamLocation(t);
                if (!e) throw new InvalidPath(i);
                return e;
            }
            i.endsWith("/") && (i = i.slice(0, -1));
            const s = i.trim().split("/"), o = [];
            for (const t of s) if (".." === t) {
                if (!(o.length > 0)) throw new InvalidPath(i);
                o.pop();
            } else "." !== t && "" != t && o.push(t);
            s[0] || (t = Ut.root);
            const [a] = this.getStream(t);
            return {
                parent: a.valueOf(),
                path: o.join("/")
            };
        },
        getStreamLocation(t) {
            return this.streamLocationMap.get(t);
        },
        setStreamLocation(t, e) {
            const n = this.streamLocationMap;
            e ? n.set(t, e) : n.delete(t);
        }
    });
    const Jn = [ Et.fd_read, 0 ], Hn = [ Et.fd_write, 0 ], Yn = Et.fd_seek | Et.fd_fdstat_set_flags | Et.fd_tell | Et.path_create_directory | Et.path_create_file | Et.path_open | Et.fd_readdir | Et.path_filestat_get | Et.path_filestat_set_size | Et.path_filestat_set_times | Et.fd_filestat_get | Et.fd_filestat_set_times | Et.path_remove_directory | Et.path_unlink_file, Xn = Et.fd_datasync | Et.fd_read | Et.fd_seek | Et.fd_sync | Et.fd_tell | Et.fd_write | Et.fd_advise | Et.fd_allocate | Et.fd_filestat_get | Et.fd_filestat_set_times | Et.fd_filestat_set_size;
    xn({
        init() {
            const t = {
                cookie: 0n,
                readdir() {
                    const t = Number(this.cookie);
                    let e = null;
                    switch (t) {
                      case 0:
                      case 1:
                        e = {
                            name: ".".repeat(t + 1),
                            type: "directory"
                        };
                    }
                    return e;
                },
                seek(t) {
                    return this.cookie = t;
                },
                tell() {
                    return this.cookie;
                },
                valueOf: () => null
            };
            this.streamMap = new Map([ [ Ut.root, [ t, this.getDefaultRights("dir"), 0 ] ], [ Ut.stdout, [ this.createLogWriter("stdout"), Hn, 0 ] ], [ Ut.stderr, [ this.createLogWriter("stderr"), Hn, 0 ] ] ]), 
            this.flushRequestMap = new Map, this.nextStreamHandle = Ut.min;
        },
        getStream(t) {
            const e = this.streamMap.get(t);
            if (!e) {
                if (2 < t && t < Ut.min) throw new Unsupported;
                throw new InvalidFileDescriptor;
            }
            return e;
        },
        createStreamHandle(t, e, n = 0) {
            if (!this.ioRedirection) throw new Unsupported;
            let r = this.nextStreamHandle++;
            if (r > Ut.max) {
                for (r = Ut.min; this.streamMap.get(r); ) if (r++, r > Ut.max) throw new TooManyFiles;
                this.nextStreamHandle = r + 1;
            }
            return this.streamMap.set(r, [ t, e, n ]), t.onClose = () => this.destroyStreamHandle(r), 
            "linux" === process.platform && 4 === this.streamMap.size && this.setSyscallTrap(!0), 
            r;
        },
        destroyStreamHandle(t) {
            const e = this.streamMap.get(t);
            if (e) {
                const [n] = e;
                n?.destroy?.(), this.streamMap.delete(t), "linux" === process.platform && 3 === this.streamMap.size && this.setSyscallTrap(!1);
            }
        },
        redirectStream(t, e) {
            const n = this.streamMap, r = Ut[t], i = n.get(r);
            if (void 0 !== e) {
                let i, s;
                if (r === Ut.stdin) i = this.convertReader(e), s = Jn; else if (r === Ut.stdout || r === Ut.stderr) i = this.convertWriter(e), 
                s = Hn; else {
                    if (r !== Ut.root) throw new Error(`Expecting 'stdin', 'stdout', 'stderr', or 'root', received ${t}`);
                    i = this.convertDirectory(e), s = this.getDefaultRights("dir");
                }
                if (!i) throw new InvalidStream(s[0], e);
                n.set(r, [ i, s, 0 ]);
            } else n.delete(r);
            return i?.[0];
        },
        createLogWriter(t) {
            const e = this;
            return {
                pending: [],
                write(t) {
                    const n = t.lastIndexOf(10);
                    if (-1 === n) this.pending.push(t); else {
                        const e = t.subarray(0, n), r = t.subarray(n + 1);
                        this.dispatch([ ...this.pending, e ]), this.pending.splice(0), r.length > 0 && this.pending.push(r);
                    }
                    e.scheduleFlush(this, this.pending.length > 0, 250);
                },
                dispatch(n) {
                    const r = je(n);
                    null == e.triggerEvent("log", {
                        source: t,
                        message: r
                    }) && console.log(r);
                },
                flush() {
                    this.pending.length > 0 && (this.dispatch(this.pending), this.pending.splice(0));
                }
            };
        },
        scheduleFlush(t, e, n) {
            const r = this.flushRequestMap, i = r.get(t);
            i && (clearTimeout(i), r.delete(t)), e && r.set(t, setTimeout((() => {
                t.flush(), r.delete(t);
            }), n));
        },
        flushStreams() {
            const t = this.flushRequestMap;
            if (t.size > 0) {
                for (const [e, n] of t) e.flush(), clearTimeout(n);
                t.clear();
            }
        },
        getDefaultRights: t => "dir" === t ? [ Yn, Yn | Xn ] : [ Xn, 0 ],
        imports: {
            setRedirectionMask: {},
            setSyscallTrap: {}
        }
    }), xn({}), xn({
        convertWriter: t => t instanceof WritableStream || t instanceof WritableStreamDefaultWriter ? new WebStreamWriter(t) : Array.isArray(t) ? new ArrayWriter(t) : t instanceof Uint8Array ? new Uint8ArrayReadWriter(t) : null === t ? new NullStream : "function" == typeof t?.write ? t : void 0
    }), xn({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), i = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: i
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    }), xn({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = Ze(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let i = this.allocatorVtable;
            if (!i) {
                const {noResize: t, noRemap: e} = r;
                i = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (i.remap = e), this.destructors.push((() => this.freeFunction(i.alloc))), 
                this.destructors.push((() => this.freeFunction(i.free)));
            }
            let s = We;
            if (n) {
                const e = [];
                s = this.nextAllocatorContextId++, this.allocatorContextMap.set(s, e), t[ve] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(s);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(s, 0),
                vtable: i
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][zt]), i = r != We ? this.allocatorContextMap.get(r) : null, s = 1 << n, o = this.allocateJSMemory(e, s);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, s, !0, o), Te(o, jt, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), i?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][zt], i = this.getViewAddress(r), s = r.byteLength;
            this.unregisterMemory(i, s);
        }
    }), xn({
        createDirectory(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return t;
            const e = this.convertDirectory(t);
            if (!e) throw new InvalidStream(Et.fd_readdir, t);
            let n = this.createStreamHandle(e, this.getDefaultRights("dir"));
            return "win32" === process.platform && (n = this.obtainZigView(Ze(n << 1), 0)), 
            {
                fd: n
            };
        }
    }), xn({
        createFile(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) {
                let {fd: e} = t;
                if ("win32" === process.platform) {
                    const t = this.getFileHandle(e);
                    e = this.obtainZigView(t, 0, !1);
                }
                return {
                    handle: e
                };
            }
            if ("object" == typeof t && "number" == typeof t?.handle) return t;
            const e = this.convertReader(t) ?? this.convertWriter(t);
            if (!e) throw new InvalidStream(Et.fd_read | Et.fd_write, t);
            const n = this.getDefaultRights("file"), r = {
                read: Et.fd_read,
                write: Et.fd_write,
                seek: Et.fd_seek,
                tell: Et.fd_tell,
                allocate: Et.fd_allocate
            };
            for (const [t, i] of Object.entries(r)) sn(e, t) || (n[0] &= ~i);
            let i = this.createStreamHandle(e, n);
            return "win32" === process.platform && (i = this.obtainZigView(Ze(i << 1), 0, !1)), 
            {
                handle: i
            };
        },
        imports: {
            getFileHandle: {}
        }
    }), xn({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = Ze(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: i}} = t;
            if (n) {
                if ("function" != typeof n) throw new TypeMismatch("function", n);
            } else {
                const t = e[fe] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const s = this.nextGeneratorContextId++, o = this.obtainZigView(s, 0, !1);
            this.generatorContextMap.set(s, {
                func: n,
                args: e
            });
            let a = this.generatorCallbackMap.get(r);
            a || (a = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][zt], r = this.getViewAddress(n), i = this.generatorContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i, s = e instanceof Error;
                    if (!s && e) {
                        const t = n[Be];
                        t && (e = t(e));
                    }
                    const o = !1 === await (2 === t.length ? t(s ? e : null, s ? null : e) : t(e)) || s || null === e;
                    if (n[ve]?.(o), !o) return !0;
                    n[Me](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, a), this.destructors.push((() => this.freeFunction(a)))), 
            e[Oe] = t => a(o, t);
            const c = {
                ptr: o,
                callback: a
            }, l = i.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                c.allocator = this.createJsAllocator(e, t, !0);
            }
            return c;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[Ve] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[Ve](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[Ve](t)) break;
                    e[Ve](null);
                } catch (t) {
                    if (!e.constructor[le]) throw t;
                    e[Ve](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    xn({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = Ze(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new TypeMismatch("function", n);
            } else e[ue] = new Promise(((t, r) => {
                n = n => {
                    if (n?.[zt]?.[jt] && (n = new n.constructor(n)), n instanceof Error) r(n); else {
                        if (n) {
                            const t = e[Be];
                            t && (n = t(n));
                        }
                        t(n);
                    }
                };
            }));
            const i = this.nextPromiseContextId++, s = this.obtainZigView(i, 0, !1);
            this.promiseContextMap.set(i, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][zt], r = this.getViewAddress(n), i = this.promiseContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[Me](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[Oe] = t => o(s, t), {
                ptr: s,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[Oe] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[Oe](n);
            };
        }
    }), xn({
        copyUint64(t, e) {
            const n = un(8);
            n.setBigUint64(0, BigInt(e), this.littleEndian), this.moveExternBytes(n, t, !0);
        },
        copyUint32(t, e) {
            const n = un(4);
            n.setUint32(0, e, this.littleEndian), this.moveExternBytes(n, t, !0);
        }
    }), xn({
        clockResGet(t, e) {
            return this.copyUint64(e, 1000n), ot;
        }
    }), xn({
        clockTimeGet(t, e, n) {
            const r = 0 === t ? Date.now() : performance.now();
            return this.copyUint64(n, BigInt(Math.ceil(1e6 * r))), ot;
        }
    }), xn({
        environGet(t, e) {
            const n = this.envVarArrays;
            let r = 0, i = 0;
            for (const t of n) r += t.length, i++;
            const s = un(4 * i), o = new Uint8Array(r);
            let a = 0, c = 0, l = this.littleEndian;
            for (const t of n) s.setUint32(a, e + c, l), a += 4, o.set(t, c), c += t.length;
            return this.moveExternBytes(s, t, !0), this.moveExternBytes(o, e, !0), 0;
        },
        exports: {
            environGet: {}
        }
    }), xn({
        environSizesGet(t, e) {
            let n = this.envVariables;
            if (!n) return bt;
            const r = this.envVarArrays = [];
            for (const [t, e] of Object.entries(n)) {
                const n = Le(`${t}=${e}\0`);
                r.push(n);
            }
            let i = 0;
            for (const t of r) i += t.length;
            return this.copyUint32(t, r.length), this.copyUint32(e, i), 0;
        },
        exports: {
            environSizesGet: {}
        }
    });
    const Kn = {
        normal: 0,
        sequential: 1,
        random: 2,
        willNeed: 3,
        dontNeed: 4,
        noReuse: 5
    };
    xn({
        fdAdvise(t, e, n, r, i) {
            return Vn(i, lt, (() => {
                const [i] = this.getStream(t);
                if (sn(i, "advise")) {
                    const t = Object.keys(Kn);
                    return i.advise(Je(e), Je(n), t[r]);
                }
            }));
        },
        exports: {
            fdAdvise: {
                async: !0
            }
        }
    }), xn({
        fdAllocate(t, e, n, r) {
            return Vn(r, lt, (() => {
                const [r] = this.getStream(t);
                return Tn(r, "allocate", mt), r.allocate(Je(e), Je(n));
            }));
        },
        exports: {
            fdAllocate: {
                async: !0
            }
        }
    }), xn({
        fdClose(t, e) {
            return Vn(e, lt, (() => (this.setStreamLocation?.(t), this.destroyStreamHandle(t))));
        },
        exports: {
            fdClose: {
                async: !0
            }
        }
    }), xn({
        fdDatasync(t, e) {
            return Vn(e, lt, (() => {
                const [e] = this.getStream(t);
                if (sn(e, "datasync")) return e.datasync();
            }));
        },
        exports: {
            fdDatasync: {
                async: !0
            }
        }
    }), xn({
        fdFdstatGet(t, e, n) {
            return Vn(n, lt, (() => {
                const [n, r, i] = this.getStream(t);
                let s;
                if (n.type) {
                    if (s = cn(n.type, It), void 0 === s) throw new InvalidEnumValue(It, n.type);
                } else s = r[0] & (Et.fd_read | Et.fd_write) ? It.file : It.directory;
                const o = un(24);
                o.setUint8(0, s), o.setUint16(2, i, !0), o.setBigUint64(8, BigInt(r[0]), !0), o.setBigUint64(16, BigInt(r[1]), !0), 
                this.moveExternBytes(o, e, !0);
            }));
        },
        exports: {
            fdFdstatGet: {
                async: !0
            }
        }
    }), xn({
        fdFdstatSetFlags(t, e, n) {
            const r = Mt.append | Mt.nonblock;
            return Vn(n, lt, (() => {
                const n = this.getStream(t), [i, s, o] = n;
                e & Mt.nonblock && (s[0] & Et.fd_read && Tn(i, "readnb", wt), s[0] & Et.fd_write && Tn(i, "writenb", wt)), 
                n[2] = o & ~r | e & r;
            }));
        },
        exports: {
            fdFdstatSetFlags: {
                async: !0
            }
        }
    }), xn({
        fdFdstatSetRights(t, e, n) {
            return Vn(n, lt, (() => {
                const n = this.getStream(t), [r, i] = n;
                if (e & ~i) throw new InvalidFileDescriptor;
                n[1] = i;
            }));
        },
        exports: {
            fdFdstatSetRights: {
                async: !0
            }
        }
    }), xn({
        copyStat(t, e) {
            if (!1 === e) return yt;
            if ("object" != typeof e || !e) throw new TypeMismatch("object or false", e);
            const {ino: n = 1, type: r = "unknown", size: i = 0, atime: s = 0, mtime: o = 0, ctime: a = 0} = e, c = cn(r, It);
            if (void 0 === c) throw new InvalidEnumValue(It, r);
            const l = this.littleEndian, u = un(64);
            u.setBigUint64(0, 0n, l), u.setBigUint64(8, BigInt(n), l), u.setUint8(16, c), u.setBigUint64(24, 1n, l), 
            u.setBigUint64(32, BigInt(i), l), u.setBigUint64(40, BigInt(s), l), u.setBigUint64(48, BigInt(o), l), 
            u.setBigUint64(56, BigInt(a), l), this.moveExternBytes(u, t, l);
        },
        inferStat(t) {
            if (t) return {
                size: t.size,
                type: sn(t, "readdir") ? "directory" : "file"
            };
        }
    }), xn({
        fdFilestatGet(t, e, n) {
            return Vn(n, lt, (() => {
                const [e] = this.getStream(t);
                if (this.hasListener("stat")) {
                    const n = e.valueOf(), r = this.getStreamLocation?.(t);
                    return this.triggerEvent("stat", {
                        ...r,
                        target: n,
                        flags: {}
                    });
                }
                return this.inferStat(e);
            }), (t => this.copyStat(e, t)));
        },
        exports: {
            fdFilestatGet: {
                async: !0
            }
        }
    }), xn({
        fdFilestatSetTimesEvent: "utimes",
        fdFilestatSetTimes(t, e, n, r, i) {
            return Vn(i, lt, (() => {
                const [i] = this.getStream(t), s = i.valueOf(), o = this.getStreamLocation?.(t), a = In(e, n, r);
                return this.triggerEvent("utimes", {
                    ...o,
                    target: s,
                    times: a,
                    flags: {}
                });
            }), (t => void 0 === t ? St : $n(t, lt)));
        },
        exports: {
            fdFilestatSetTimes: {
                async: !0
            }
        }
    }), xn({
        fdPread(t, e, n, r, i, s) {
            const o = this.littleEndian, a = [];
            let c = 0;
            return Vn(s, gt, (() => {
                const [i, s] = this.getStream(t);
                Bn(s, Et.fd_read), Tn(i, "pread");
                const l = un(8 * n);
                this.moveExternBytes(l, e, !1);
                for (let t = 0; t < n; t++) {
                    const e = He(l, 8 * t, o), n = Ye(l, 8 * t + 4, o);
                    a.push({
                        ptr: e,
                        len: n
                    }), c += n;
                }
                return i.pread(c, Je(r));
            }), (t => {
                let {byteOffset: e, byteLength: n, buffer: r} = t;
                for (const {ptr: t, len: i} of a) if (n > 0) {
                    const s = new DataView(r, e, Math.min(n, i));
                    this.moveExternBytes(s, t, !0), e += i, n -= i;
                }
                this.copyUint32(i, t.length);
            }));
        },
        ...{
            exports: {
                fdPread: {
                    async: !0
                },
                fdPread1: {
                    async: !0
                }
            },
            fdPread1(t, e, n, r, i, s) {
                return Vn(s, gt, (() => {
                    const [e, i] = this.getStream(t);
                    return Bn(i, Et.fd_read), Tn(e, "pread"), e.pread(n, Je(r));
                }), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUint32(i, t.length);
                }));
            }
        }
    }), xn({
        fdPwrite(t, e, n, r, i, s) {
            const o = this.littleEndian;
            let a = 0;
            return Vn(s, gt, (() => {
                const [i, s] = this.getStream(t);
                Bn(s, Et.fd_write), Tn(i, "pwrite");
                const c = un(8 * n);
                this.moveExternBytes(c, e, !1);
                const l = [];
                for (let t = 0; t < n; t++) {
                    const e = He(c, 8 * t, o), n = Ye(c, 8 * t + 4, o);
                    l.push({
                        ptr: e,
                        len: n
                    }), a += n;
                }
                const u = new ArrayBuffer(a);
                let f = 0;
                for (const {ptr: t, len: e} of l) {
                    const n = new DataView(u, f, e);
                    this.moveExternBytes(n, t, !1), f += e;
                }
                const h = new Uint8Array(u);
                return i.pwrite(h, Je(r));
            }), (() => this.copyUint32(i, a)));
        },
        ...{
            exports: {
                fdPwrite: {
                    async: !0
                },
                fdPwrite1: {
                    async: !0
                }
            },
            fdPwrite1(t, e, n, r, i, s) {
                return Vn(s, gt, (() => {
                    const [i, s] = this.getStream(t);
                    Bn(s, Et.fd_write), Tn(i, "pwrite");
                    const o = new Uint8Array(n);
                    return this.moveExternBytes(o, e, !1), i.pwrite(o, Je(r));
                }), (() => this.copyUint32(i, n)));
            }
        }
    }), xn({
        fdRead(t, e, n, r, i) {
            const s = this.littleEndian, o = [];
            let a = 0;
            return Vn(i, lt, (() => {
                const [r, i, c] = this.getStream(t);
                Bn(i, Et.fd_read);
                const l = un(8 * n);
                this.moveExternBytes(l, e, !1);
                for (let t = 0; t < n; t++) {
                    const e = He(l, 8 * t, s), n = Ye(l, 8 * t + 4, s);
                    o.push({
                        ptr: e,
                        len: n
                    }), a += n;
                }
                return (c & Mt.nonblock ? r.readnb : r.read).call(r, a);
            }), (t => {
                let {byteOffset: e, byteLength: n, buffer: i} = t;
                for (const {ptr: t, len: r} of o) {
                    const s = Math.min(n, r);
                    if (s > 0) {
                        const r = new DataView(i, e, s);
                        this.moveExternBytes(r, t, !0), e += s, n -= s;
                    }
                }
                this.copyUint32(r, t.length);
            }));
        },
        ...{
            exports: {
                fdRead: {
                    async: !0
                },
                fdRead1: {
                    async: !0
                }
            },
            fdRead1(t, e, n, r, i) {
                return Vn(i, lt, (() => {
                    const [e, r, i] = this.getStream(t);
                    Bn(r, Et.fd_read);
                    return (i & Mt.nonblock ? e.readnb : e.read).call(e, n);
                }), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUint32(r, t.length);
                }));
            }
        }
    }), xn({
        fdReaddir(t, e, n, r, i, s) {
            if (n < 24) return dt;
            let o, a;
            return Vn(s, lt, (() => ([o] = this.getStream(t), o.tell())), (t => Vn(s, lt, (() => {
                r = t;
                const e = o.readdir();
                return a = on(e), e;
            }), (t => {
                const s = un(n);
                let c = n, l = 0;
                for (;t; ) {
                    const {name: e, type: n = "unknown", ino: i = 1} = t, u = Le(e), f = cn(n, It);
                    if (void 0 === f) throw new InvalidEnumValue(It, n);
                    if (c < 24 + u.length) {
                        o.seek(Number(r));
                        break;
                    }
                    s.setBigUint64(l, BigInt(++r), !0), s.setBigUint64(l + 8, BigInt(i), !0), s.setUint32(l + 16, u.length, !0), 
                    s.setUint8(l + 20, f), l += 24, c -= 24;
                    for (let t = 0; t < u.length; t++, l++) s.setUint8(l, u[t]);
                    c -= u.length, t = c > 40 && !a ? o.readdir() : null;
                }
                this.moveExternBytes(s, e, !0), this.copyUint32(i, l);
            }))));
        },
        exports: {
            fdReaddir: {
                async: !0
            }
        }
    }), xn({
        fdSeek(t, e, n, r, i) {
            return Vn(i, lt, (() => {
                const [r] = this.getStream(t);
                return Tn(r, "seek"), r.seek(Je(e), n);
            }), (t => this.copyUint64(r, t)));
        },
        exports: {
            fdSeek: {
                async: !0
            }
        }
    }), xn({
        fdSync(t, e) {
            return Vn(e, lt, (() => {
                const [e] = this.getStream(t);
                if (sn(e, "sync")) return e.sync?.();
            }));
        },
        exports: {
            fdSync: {
                async: !0
            }
        }
    }), xn({
        fdTell(t, e, n) {
            return Vn(n, lt, (() => {
                const [e] = this.getStream(t);
                return Tn(e, "tell"), e.tell();
            }), (t => this.copyUint64(e, t)));
        },
        exports: {
            fdTell: {
                async: !0
            }
        }
    }), xn({
        fdWrite(t, e, n, r, i) {
            const s = this.littleEndian;
            let o = 0;
            return Vn(i, lt, (() => {
                const [r, i, a] = this.getStream(t);
                Bn(i, Et.fd_write);
                const c = un(8 * n);
                this.moveExternBytes(c, e, !1);
                const l = [];
                for (let t = 0; t < n; t++) {
                    const e = He(c, 8 * t, s), n = Ye(c, 8 * t + 4, s);
                    l.push({
                        ptr: e,
                        len: n
                    }), o += n;
                }
                const u = new ArrayBuffer(o);
                let f = 0;
                for (const {ptr: t, len: e} of l) {
                    const n = new DataView(u, f, e);
                    this.moveExternBytes(n, t, !1), f += e;
                }
                const h = new Uint8Array(u);
                return (a & Mt.nonblock ? r.writenb : r.write).call(r, h);
            }), (() => {
                r && this.copyUint32(r, o);
            }));
        },
        fdWriteStderr(t, e) {
            return Vn(e, lt, (() => {
                const [e, n, r] = this.getStream(2);
                return Bn(n, Et.fd_write), e.write(t);
            })), 0;
        },
        ...{
            exports: {
                fdWrite: {
                    async: !0
                },
                fdWrite1: {
                    async: !0
                },
                fdWriteStderr: {
                    async: !0
                }
            },
            fdWrite1(t, e, n, r, i) {
                return Vn(i, lt, (() => {
                    const [r, i, s] = this.getStream(t);
                    Bn(i, Et.fd_write);
                    const o = s & Mt.nonblock ? r.writenb : r.write, a = new Uint8Array(n);
                    return this.moveExternBytes(a, e, !1), o.call(r, a);
                }), (() => {
                    r && this.copyUint32(r, n);
                }));
            }
        }
    }), xn({
        pathCreateDirectoryEvent: "mkdir",
        pathCreateDirectory(t, e, n, r) {
            return Vn(r, yt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("mkdir", r, yt);
            }), (t => void 0 === t ? bt : t instanceof Map ? ft : $n(t, yt)));
        },
        exports: {
            pathCreateDirectory: {
                async: !0
            }
        }
    }), xn({
        pathFilestatGetEvent: "stat/open",
        pathFilestatGet(t, e, n, r, i, s) {
            let o = !1;
            return Vn(s, yt, (() => {
                const i = this.obtainStreamLocation(t, n, r);
                let s = {
                    ...an(e, xt)
                };
                return this.hasListener("stat") ? this.triggerEvent("stat", {
                    ...i,
                    flags: s
                }) : (s = {
                    ...s,
                    dryrun: !0
                }, o = !0, this.triggerEvent("open", {
                    ...i,
                    rights: {},
                    flags: s
                }));
            }), (t => {
                if (void 0 === t) return bt;
                if (!1 === t) return yt;
                if (o) {
                    const e = this.convertReader(t) ?? this.convertWriter(t) ?? this.convertDirectory(t);
                    if (!e) throw new InvalidStream(Et.fd_read | Et.fd_write | Et.fd_readdir, t);
                    t = this.inferStat(e);
                }
                return this.copyStat(i, t);
            }));
        },
        exports: {
            pathFilestatGet: {
                async: !0
            }
        }
    }), xn({
        pathFilestatSetTimesEvent: "utimes",
        pathFilestatSetTimes(t, e, n, r, i, s, o, a) {
            return Vn(a, yt, (() => {
                const a = this.obtainStreamLocation(t, n, r), c = In(i, s, o), l = an(e, xt);
                return this.triggerEvent("utimes", {
                    ...a,
                    times: c,
                    flags: l
                });
            }), (t => void 0 === t ? bt : $n(t, yt)));
        },
        exports: {
            pathFilestatSetTimes: {
                async: !0
            }
        }
    });
    const Qn = {
        read: Et.fd_read,
        write: Et.fd_write,
        readdir: Et.fd_readdir
    };
    function tr() {
        Object.assign(this, {
            resolved: !0
        });
    }
    function er(t) {
        Object.assign(this, {
            resolved: !0,
            length: t
        });
    }
    function nr(t) {
        console.error(t), Object.assign(this, {
            resolved: !0,
            error: lt
        });
    }
    let rr, ir;
    function sr() {
        const t = or.toString(), e = t.indexOf("{") + 1, n = t.lastIndexOf("}");
        return t.slice(e, n);
    }
    function or() {
        const t = WebAssembly;
        let e, n;
        function r(r) {
            switch (r.type) {
              case "start":
                {
                    const {executable: i, memory: s, options: o} = r, a = {
                        env: {
                            memory: s
                        },
                        wasi: {},
                        wasi_snapshot_preview1: {}
                    }, c = () => {
                        throw new Error("Exit");
                    }, l = (t, e) => "timed-out" !== Atomics.wait(t, 0, 0, e) ? (2 === Atomics.load(t, 0) && (n.exports.wasi_thread_clean(0), 
                    c()), Atomics.load(t, 1)) : 0, u = () => new Int32Array(new SharedArrayBuffer(8));
                    for (const {module: n, name: r, kind: o} of t.Module.imports(i)) {
                        const t = a[n];
                        if ("function" === o && t && (t[r] = "proc_exit" === r ? c : function(...t) {
                            const i = u();
                            return e.postMessage({
                                type: "call",
                                module: n,
                                name: r,
                                args: t,
                                futex: i
                            }), l(i);
                        }, "fd_write" === r)) {
                            const i = t[r];
                            t[r] = function(t, o, a, c) {
                                if (2 === t) {
                                    const t = new DataView(s.buffer);
                                    let i = 0;
                                    const f = [];
                                    for (let e = 0, n = 0; e < a; e++, n += 8) {
                                        const e = t.getUint32(o + n, !0), r = t.getUint32(o + n + 4, !0);
                                        f.push({
                                            ptr: e,
                                            len: r
                                        }), i += r;
                                    }
                                    const h = new Uint8Array(i);
                                    let d = 0;
                                    for (const {ptr: e, len: n} of f) {
                                        const r = new Uint8Array(t.buffer, e, n);
                                        h.set(r, d), d += n;
                                    }
                                    const g = u();
                                    return e.postMessage({
                                        type: "call",
                                        module: n,
                                        name: `${r}_stderr`,
                                        args: [ h ],
                                        futex: g
                                    }, [ h.buffer ]), t.setUint32(c, i, !0), l(g, 5e4);
                                }
                                return i(t, o, a, c);
                            };
                        }
                    }
                    o.tableInitial && (a.env.__indirect_function_table = new t.Table({
                        initial: o.tableInitial,
                        element: "anyfunc"
                    })), n = new t.Instance(i, a);
                }
                break;

              case "run":
                try {
                    n.exports.wasi_thread_start(r.tid, r.taddr);
                } catch {}
                e.postMessage({
                    type: "done"
                });
                break;

              case "clean":
                try {
                    n.exports.wasi_thread_clean(r.raddr);
                } catch {}
                e.postMessage({
                    type: "done"
                });
                break;

              case "end":
                e.close();
            }
        }
        "object" == typeof self ? (self.onmessage = t => r(t.data), e = self) : import("node:worker_threads").then((t => {
            e = t.parentPort, e.on("message", r);
        }));
    }
    function ar(t, n) {
        const {byteSize: r, type: i} = n;
        if (!(i === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function cr(t) {
        throw new BufferExpected(t);
    }
    xn({
        pathOpenEvent: "open",
        pathOpen(t, e, n, r, i, s, o, a, c, l) {
            const u = [ Number(s), Number(o) ];
            let f;
            return u[0] & (Et.fd_read | Et.fd_write | Et.fd_readdir) || (u[0] |= Et.fd_read), 
            Vn(l, yt, (() => {
                f = this.obtainStreamLocation(t, n, r);
                const s = an(u[0], Qn), o = {
                    ...an(e, xt),
                    ...an(i, At),
                    ...an(a, Mt)
                };
                return this.triggerEvent("open", {
                    ...f,
                    rights: s,
                    flags: o
                });
            }), (t => {
                if (void 0 === t) return bt;
                if (!1 === t) return yt;
                const e = this.convertReader(t) ?? this.convertWriter(t) ?? this.convertDirectory(t);
                if (!e) throw new InvalidStream(u[0], t);
                const n = this.createStreamHandle(e, u, a);
                this.setStreamLocation?.(n, f), this.copyUint32(c, n);
            }));
        },
        exports: {
            pathOpen: {
                async: !0
            }
        }
    }), xn({
        pathReadlinkEvent: "readlink",
        pathReadlink(t, e, n, r, i, s, o) {
            return Vn(o, yt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("readlink", r, yt);
            }), (t => {
                if (void 0 === t) return bt;
                if (!1 === t) return yt;
                if ("string" != typeof t) throw new TypeMismatch("string", t);
                const e = Le(t).slice(0, i);
                this.moveExternBytes(e, r, this.littleEndian), this.copyUint32(s, e.length);
            }));
        },
        exports: {
            pathReadlink: {
                async: !0
            }
        }
    }), xn({
        pathRemoveDirectory: "rmdir",
        pathRemoveDirectory(t, e, n, r) {
            return Vn(r, yt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("rmdir", r, yt);
            }), (t => void 0 === t ? bt : $n(t, yt)));
        },
        exports: {
            pathRemoveDirectory: {
                async: !0
            }
        }
    }), xn({
        pathRenameEvent: "rename",
        pathRename(t, e, n, r, i, s, o) {
            return Vn(o, yt, (() => {
                const o = this.obtainStreamLocation(t, e, n), {path: a, parent: c} = this.obtainStreamLocation(r, i, s);
                return this.triggerEvent("rename", {
                    ...o,
                    newParent: c,
                    newPath: a
                }, yt);
            }), (t => void 0 === t ? bt : $n(t, yt)));
        },
        exports: {
            pathRename: {
                async: !0
            }
        }
    }), xn({
        pathSymlinkEvent: "symlink",
        pathSymlink(t, e, n, r, i, s) {
            return Vn(s, yt, (() => {
                const s = this.obtainZigView(t, e, !1), o = je(new Uint8Array(s.buffer, s.byteOffset, s.byteLength)).trim(), a = this.obtainStreamLocation(n, r, i);
                return this.triggerEvent("symlink", {
                    ...a,
                    target: o
                }, yt);
            }), (t => void 0 === t ? bt : $n(t, yt)));
        },
        exports: {
            pathSymlink: {
                async: !0
            }
        }
    }), xn({
        pathUnlinkFileEvent: "unlink",
        pathUnlinkFile(t, e, n, r) {
            return Vn(r, yt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("unlink", r, yt);
            }), (t => void 0 === t ? bt : $n(t, yt)));
        },
        exports: {
            pathUnlinkFile: {
                async: !0
            }
        }
    }), xn({
        pollOneoff(t, e, n, r, i) {
            const s = [], o = [], a = this.littleEndian;
            return Vn(i, lt, (() => {
                const e = un(48 * n);
                this.moveExternBytes(e, t, !1);
                for (let t = 0; t < n; t++) {
                    const n = 48 * t, r = e.getBigUint64(n, a), i = e.getUint8(n + 8), c = {
                        tag: i,
                        userdata: r,
                        error: ot
                    };
                    let l;
                    switch (s.push(c), i) {
                      case kt:
                        {
                            let t = e.getBigUint64(n + 24, a);
                            const r = new Int32Array(new SharedArrayBuffer(4)), i = tr.bind(c);
                            if (0n === t) i(); else {
                                const e = Math.ceil(Number(t) / 1e6);
                                l = Atomics.waitAsync(r, 0, 0, e).value.then(i);
                            }
                        }
                        break;

                      case Vt:
                      case Ot:
                        {
                            const t = e.getInt32(n + 16, a), r = er.bind(c), s = nr.bind(c);
                            try {
                                const [e] = this.getStream(t);
                                Tn(e, "poll");
                                const n = e.poll(i);
                                on(n) ? l = n.then(r, s) : r(n);
                            } catch (t) {
                                if (t.errno === bt) throw t;
                                s(t);
                            }
                        }
                        break;

                      default:
                        throw new InvalidArgument;
                    }
                    l && o.push(l);
                }
                if (o.length === s.length) return Promise.any(o);
            }), (() => {
                let t = 0;
                for (const e of s) e.resolved && t++;
                const n = un(32 * t);
                let i = 0;
                for (const t of s) if (t.resolved) {
                    const e = 32 * i;
                    n.setBigUint64(e, t.userdata, a), n.setUint16(e + 8, t.error, a), n.setUint8(e + 10, t.tag), 
                    void 0 !== t.length && (0 === t.length ? n.setUint16(e + 24, 1, a) : n.setBigUint64(e + 16, BigInt(t.length), a)), 
                    i++;
                }
                this.moveExternBytes(n, e, !0), this.copyUint32(r, t);
            }));
        },
        exports: {
            pollOneoff: {
                async: !0
            }
        }
    }), xn({
        init() {
            this.nextThreadId = 1, this.workers = [], "node" === process.env.COMPAT && "function" != typeof Worker && import("node:worker_threads").then((t => rr = t.Worker));
        },
        getThreadHandler(t) {
            switch (t) {
              case "thread-spawn":
                return "object" != typeof window || window.crossOriginIsolated || console.warn("%cHTML document is not cross-origin isolated %c\n\nWebAssembly multithreading in the browser is only possibly when %cwindow.crossOriginIsolated%c = true. Visit https://developer.mozilla.org/en-US/docs/Web/API/Window/crossOriginIsolated for information on how to enable it.", "color: red;font-size: 200%;font-weight:bold", "", "background-color: lightgrey;font-weight:bold", ""), 
                this.spawnThread.bind(this);

              case "thread-cancel":
                return this.cancelThread.bind(this);

              case "thread-address":
                return this.getThreadAddress.bind(this);
            }
        },
        spawnThread(t) {
            const e = this.nextThreadId++;
            1073741824 === this.nextThreadId && (this.nextThreadId = 1);
            return this.createWorker().run(e, t), e;
        },
        cancelThread(t, e) {
            const n = this.workers.find((e => e.tid === t));
            if (n) if (e) {
                n.end(!0);
                this.createWorker().clean(e);
            } else n.canceled = !0;
        },
        getThreadAddress(t) {
            return this.workers.find((e => e.tid === t)).taddr;
        },
        createWorker() {
            const t = t => {
                switch (t.type) {
                  case "call":
                    {
                        const {module: n, name: r, args: i, futex: s} = t;
                        if (e.canceled) e.canceled = !1, e.signal(s, 2); else {
                            const t = this.exportedModules[n]?.[r], o = t?.(...i, !0), a = t => e.signal(s, 1, t);
                            on(o) ? o.then(a) : a(o);
                        }
                    }
                    break;

                  case "done":
                    e.end();
                }
            };
            let e;
            if ("function" == typeof Worker) {
                const n = function() {
                    if (!ir) {
                        const t = sr();
                        ir = URL.createObjectURL(new Blob([ t ], {
                            type: "text/javascript"
                        }));
                    }
                    return ir;
                }();
                e = new Worker(n, {
                    name: "zig"
                }), e.addEventListener("message", (e => t(e.data)));
            } else if ("node" === process.env.COMPAT) {
                const n = sr();
                e = new rr(n, {
                    eval: !0
                }), e.on("message", t);
            }
            const {executable: n, memory: r, options: i} = this;
            return e.postMessage({
                type: "start",
                executable: n,
                memory: r,
                options: i
            }), e.signal = (t, e, n) => {
                0 === Atomics.load(t, 0) && (Atomics.store(t, 0, e), Atomics.store(t, 1, 0 | n), 
                Atomics.notify(t, 0, 1));
            }, e.run = (t, n) => {
                e.tid = t, e.taddr = n, e.canceled = !1, e.postMessage({
                    type: "run",
                    tid: t,
                    taddr: n
                });
            }, e.clean = t => {
                e.postMessage({
                    type: "clean",
                    raddr: t
                });
            }, e.end = (t = !1) => {
                t ? e.terminate() : e.postMessage({
                    type: "end"
                }), function(t, e) {
                    const n = t.indexOf(e);
                    -1 !== n && t.splice(n, 1);
                }(this.workers, e);
            }, this.workers.push(e), e;
        }
    }), xn({
        init() {
            this.comptime = !1, this.structureMap = new Map, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.ioRedirection = !0, this.libc = !1;
        },
        createView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.moveExternBytes(n, t, !1), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[jt].handle = r, n;
            }
        },
        createInstance(t, e, n) {
            const {constructor: r} = t, i = r.call(re, e);
            return n && Object.assign(i[_t], n), i;
        },
        createTemplate: (t, e) => ({
            [zt]: t,
            [_t]: e
        }),
        appendList(t, e) {
            t.push(e);
        },
        getStructure(t) {
            return this.structureMap.get(t);
        },
        setStructure(t, e) {
            this.structureMap.set(t, e);
        },
        beginStructure(t) {
            this.defineStructure(t);
        },
        finishStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        enableCallback(t, e, n) {
            t.static.template = e, this.updateArgStructMembers(t.instance.members[0].structure, n);
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & et), this.runtimeSafety = !!(t & nt), this.ioRedirection = !!(t & it), 
            this.libc = !!(t & rt);
            const e = this.getFactoryThunk(), n = {
                [zt]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                for (const t of e[Dt]) try {
                    const n = e[t];
                    n?.[Ie] && this.updatePointerTargets(null, n);
                } catch {}
                if (n & h && r && r[zt]) {
                    const t = Object.create(e.prototype);
                    t[zt] = r[zt], t[_t] = r[_t], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, ioRedirection: r, libc: i} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    ioRedirection: r,
                    libc: i
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of en(this.structures, _t)) {
                const n = e[zt]?.[jt];
                if (n) {
                    const {address: r, len: i, handle: s} = n, o = e[zt] = this.createView(r, i, !0, 0);
                    void 0 !== s && (o.handle = s), t.push({
                        address: r,
                        len: i,
                        owner: e,
                        replaced: !1,
                        handle: s
                    });
                } else this.makeReadOnly(e);
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && Ke(n.address, n.len) <= Ke(e.address, e.len)) {
                const t = e.owner[zt], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[zt] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = en(this.structures, _t);
            for (const t of e) t[zt]?.[jt] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${l[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, flags: n = 0} = t;
            switch (e.type) {
              case P.Bool:
                return "bool";

              case P.Int:
                return n & p.IsSize ? "isize" : `i${e.bitSize}`;

              case P.Uint:
                return n & p.IsSize ? "usize" : `u${e.bitSize}`;

              case P.Float:
                return `f${e.bitSize}`;

              case P.Void:
                return "void";

              case P.Literal:
                return "enum_literal";

              case P.Null:
                return "null";

              case P.Undefined:
                return "undefined";

              case P.Type:
                return "type";

              case P.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & v[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & C.IsGlobal ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let i = "*", s = n.structure.name;
            if (n.structure.type === e.Slice && (s = s.slice(3)), r & U && (i = r & M ? "[]" : r & k ? "[*c]" : "[*]"), 
            !(r & k)) {
                const t = n.structure.constructor?.[Wt];
                t && (i = i.slice(0, -1) + `:${t.value}` + i.slice(-1));
            }
            return r & O && (i = `${i}const `), i + s;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & _ ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${i})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${i})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t, n = e.structure.name;
            return n ? n.slice(4, -1) : "fn ()";
        },
        exports: {
            createView: {},
            createInstance: {},
            createTemplate: {},
            appendList: {},
            getStructure: {},
            setStructure: {},
            beginStructure: {},
            finishStructure: {},
            enableCallback: {}
        },
        imports: {
            getFactoryThunk: {},
            getModuleAttributes: {}
        }
    }), xn({
        init() {
            this.viewMap = new WeakMap;
            {
                const t = this;
                this.fallbackHandler = function(e, n, r) {
                    let {address: i} = this[jt], s = this;
                    (n > 0 || void 0 !== r) && (s = new DataView(s.buffer, s.byteOffset + n, r), i = Ke(i, n)), 
                    t.moveExternBytes(s, i, e);
                }, this.needFallback = void 0;
            }
        },
        extractView(t, n, r = cr) {
            const {type: i, byteSize: s, constructor: o} = t;
            let a;
            const c = n?.[Symbol.toStringTag];
            if (c && ("DataView" === c ? a = this.registerView(n) : "ArrayBuffer" === c ? a = this.obtainView(n, 0, n.byteLength) : (c && c === o[ce]?.name || "Uint8ClampedArray" === c && o[ce] === Uint8Array || "Uint8Array" === c && n instanceof Buffer) && (a = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !a) {
                const r = n?.[zt];
                if (r) {
                    const {constructor: o, instance: {members: [a]}} = t;
                    if (rn(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(i)) {
                        const {byteSize: o, structure: {constructor: c}} = a, l = tn(n, c);
                        if (void 0 !== l) {
                            if (i === e.Slice || l * o === s) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return a ? void 0 !== s && ar(a, t) : r?.(t, n), a;
        },
        assignView(t, n, r, i, s) {
            const {byteSize: o, type: a} = r, c = o ?? 1, l = {
                [zt]: n
            };
            if (t[zt]) {
                const i = a === e.Slice ? c * t.length : c;
                if (n.byteLength !== i) throw new BufferSizeMismatch(r, n, t);
                t.constructor[Wt]?.validateData?.(l, t.length), dn(t, l);
            } else {
                void 0 !== o && ar(n, r);
                const e = n.byteLength / c;
                t.constructor[Wt]?.validateData?.(l, e), s && (i = !0), t[Ae](i ? null : n, e, s), 
                i && dn(t, l);
            }
        },
        findViewAt(t, e, n) {
            let r, i = this.viewMap.get(t);
            if (i) if (i instanceof DataView) if (i.byteOffset === e && i.byteLength === n) r = i, 
            i = null; else {
                const e = i, n = `${e.byteOffset}:${e.byteLength}`;
                i = new Map([ [ n, e ] ]), this.viewMap.set(t, i);
            } else r = i.get(`${e}:${n}`);
            return {
                existing: r,
                entry: i
            };
        },
        obtainView(t, e, n, r = !0) {
            let i;
            if (r) {
                const {existing: r, entry: s} = this.findViewAt(t, e, n);
                if (r) return r;
                i = new DataView(t, e, n), s ? s.set(`${e}:${n}`, i) : this.viewMap.set(t, i);
            } else i = new DataView(t, e, n), i[be] = !0;
            {
                const r = t[jt];
                if (r) {
                    const s = Ke(r.address, e);
                    i[jt] = {
                        address: s,
                        len: n
                    }, t[de] && (i[de] = this.fallbackHandler);
                }
            }
            return i;
        },
        registerView(t) {
            if (!t[jt]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: i, entry: s} = this.findViewAt(e, n, r);
                if (i) return i;
                s ? s.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: {},
                syncExternalBuffer: {},
                moveExternBytes: {}
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > lr && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let i = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    i = De(t, e) - t;
                }
                return this.obtainView(r, Number(i), t);
            }
        }
    });
    const lr = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8, ur = Bt.proxyMaps ??= [ 0, tt.Const, tt.ReadOnly, tt.Const | tt.ReadOnly ].reduce(((t, e) => (t[e] = new WeakMap, 
    t)), {}), fr = Bt.proxyTargetMap ??= new WeakMap;
    function hr(t, e) {
        const n = t, r = ur[e & (tt.Const | tt.ReadOnly)];
        let i = r.get(n);
        return i || (i = new Proxy(t, xr[e]), r.set(n, i), fr.set(i, {
            target: t,
            type: e
        })), i;
    }
    function dr(t, n = !1) {
        const {type: r, flags: i} = t;
        let s = n && r !== e.Function ? tt.ReadOnly : 0;
        return i & g && (r === e.Pointer ? (s |= tt.Pointer, i & O && (s |= tt.Const)) : s |= tt.Slice), 
        s;
    }
    function gr(t) {
        if (("object" == typeof t || "function" == typeof t) && t) return fr.get(t);
    }
    function pr(t) {
        const e = gr(t);
        return e ? [ e.target, e.type ] : [ t, 0 ];
    }
    function yr(t) {
        const e = gr(t);
        let n;
        if (e) {
            if (e.type & tt.ReadOnly) return t;
            n = e.type | tt.ReadOnly, t = e.target;
        } else {
            if (!t?.[zt] || "object" != typeof t || t[me]) return t;
            n = t.constructor[ye] ?? tt.ReadOnly;
        }
        return hr(t, n);
    }
    const mr = {
        get(t, e) {
            if (e in t) return t[e];
            return t[Zt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[Zt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[Zt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[Zt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, br = {
        ...mr,
        set(t, e, n) {
            if (e in t) On(); else {
                t[Zt][e] = n;
            }
            return !0;
        }
    }, wr = {
        get(t, e) {
            const n = t[e];
            return "string" == typeof e ? yr(n) : n;
        },
        set(t, e, n) {
            On();
        }
    }, vr = {
        ...mr,
        get: (t, e) => e in t ? wr.get(t, e) : wr.get(t[Zt], e),
        set: (t, e, n) => (e in t ? t[e] = n : On(), !0)
    }, Sr = {
        ...br,
        set: wr.set
    }, Ir = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length"), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    }, Ar = {
        ...Ir,
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? yr(t.get(n)) : "set" === e ? On : t[e];
        },
        set: On
    }, xr = {
        [tt.Pointer]: mr,
        [tt.Pointer | tt.Const]: vr,
        [tt.Pointer | tt.ReadOnly]: br,
        [tt.Pointer | tt.ReadOnly | tt.Const]: Sr,
        [tt.Slice]: Ir,
        [tt.Slice | tt.ReadOnly]: Ar,
        [tt.ReadOnly]: wr
    };
    function Er(t) {
        const [n] = pr(t);
        if (n?.[zt] && !n[me]) {
            n[me] = !0;
            const t = n.constructor[Ft];
            t === e.Pointer ? Mr(n, [ "length" ]) : t === e.Array || t === e.Slice ? (Mr(n), 
            function(t) {
                const {get: e} = t;
                $e(t, {
                    get: ze((function(t) {
                        return Er(e.call(this, t));
                    })),
                    set: ze(On)
                });
            }(n)) : Mr(n);
        }
        return t;
    }
    function Mr(t, e = []) {
        const n = Object.getOwnPropertyDescriptors(t.constructor.prototype);
        for (const [r, i] of Object.entries(n)) if (!e.includes(r)) {
            const {get: e, set: n} = i;
            i.get = e ? function() {
                return Er(e.call(this));
            } : void 0, i.set = n ? On : void 0, Te(t, r, i);
        }
    }
    function Ur(t) {
        const e = gr(t);
        if (e) {
            const {target: t} = e;
            return e.type & tt.Pointer ? t["*"] : t;
        }
        return t;
    }
    function kr() {
        const t = Ur(this), e = t.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Or(t) {
        const e = _e(t), n = Ur(this), r = n.length;
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r) {
                    const r = i++;
                    t = [ r, e((() => n.get(r))) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function Vr(t) {
        return {
            [Symbol.iterator]: Or.bind(this, t),
            length: this.length
        };
    }
    function Br(t) {
        return {
            [Symbol.iterator]: $r.bind(this, t),
            length: this[Dt].length
        };
    }
    function Tr(t) {
        return Br.call(this, t)[Symbol.iterator]();
    }
    function $r(t) {
        const e = _e(t), n = this, r = this[Dt];
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r.length) {
                    const o = r[i++];
                    t = [ o, e((() => n[o])) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function zr(t) {
        return {
            [Symbol.iterator]: Cr.bind(this, t),
            length: this[Dt].length
        };
    }
    function _r(t) {
        return zr.call(this, t)[Symbol.iterator]();
    }
    function Cr(t) {
        const e = _e(t), n = this, r = this[Dt], i = this[oe];
        let s = 0;
        return {
            next() {
                let t, o;
                if (s < r.length) {
                    const a = r[s++];
                    t = [ a, e((() => i[a].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function jr() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t[e], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Lr() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Fr() {
        return {
            [Symbol.iterator]: Lr.bind(this),
            length: this.length
        };
    }
    function Rr(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function Nr(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function Pr(t) {
        return qr.call(this, t).$;
    }
    function Dr(t) {
        return Pr.call(this, t)?.string ?? null;
    }
    function Wr(t) {
        return Pr.call(this, t)?.typedArray ?? null;
    }
    function Zr(t) {
        return Pr.call(this, t)?.clampedArray ?? null;
    }
    function Gr(t) {
        return Pr.call(this, t)?.valueOf?.() ?? null;
    }
    function qr(t) {
        return this[_t][t] ?? this[Se](t);
    }
    function Jr(t, e, n) {
        qr.call(this, t)[xe](e, n);
    }
    xn({
        makeReadOnly(t) {
            Er(t);
        }
    }), xn({
        defineArrayEntries: () => ze(Vr),
        defineArrayIterator: () => ze(kr)
    }), xn({
        defineStructEntries: () => ze(Br),
        defineStructIterator: () => ze(Tr)
    }), xn({
        defineUnionEntries: () => ze(zr),
        defineUnionIterator: () => ze(_r)
    }), xn({
        defineVectorEntries: () => ze(Fr),
        defineVectorIterator: () => ze(jr)
    }), xn({
        defineZigIterator: () => ze(Rr)
    }), xn({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, i = this[`defineMember${D[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${l[e]}`];
                if (n) return n.call(this, i, t);
            }
            return i;
        }
    }), xn({
        defineBase64(t) {
            const e = this;
            return ln({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new TypeMismatch("string", n);
                    const i = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, i, t, !1, r);
                }
            });
        }
    }), xn({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), xn({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return ln({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new TypeMismatch(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), xn({
        defineDataView(t) {
            const e = this;
            return ln({
                get() {
                    const t = this[zt];
                    return t[de]?.(!1), t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new TypeMismatch("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), xn({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), xn({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), xn({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return Nr(e, {
                get(t) {
                    return this[_t][t].string;
                },
                set: On
            });
        }
    }), xn({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: On
        })
    }), xn({
        defineMemberObject(t) {
            const {flags: e, structure: n, slot: r} = t;
            let i, s;
            return i = e & Y ? Dr : e & K ? Wr : e & Q ? Zr : e & X ? Gr : n.flags & (u | g) ? Pr : qr, 
            s = e & Z ? On : Jr, Nr(r, {
                get: i,
                set: s
            });
        }
    }), xn({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: i} = t, s = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return s.call(this[zt], t, n);
                        },
                        set: function(e) {
                            return o.call(this[zt], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return s.call(this[zt], e * i, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[zt], t * i, e, n);
                    }
                };
            }
        }
    }), xn({}), xn({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: i}} = t, {get: s} = this.defineMember(r), {get: o} = this.defineMember(n), a = s.call(i, 0), c = !!(r.flags & W), {runtimeSafety: l} = this;
            return ze({
                value: a,
                bytes: i[zt],
                validateValue(e, n, r) {
                    if (c) {
                        if (l && e === a && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== a && n === r - 1) throw new MissingSentinel(t, a, r);
                    }
                },
                validateData(n, r) {
                    if (c) if (l) for (let e = 0; e < r; e++) {
                        const i = o.call(n, e);
                        if (i === a && e !== r - 1) throw new MisplacedSentinel(t, a, e, r);
                        if (i !== a && e === r - 1) throw new MissingSentinel(t, a, r);
                    } else if (r > 0 && r * e === n[zt].byteLength) {
                        if (o.call(n, r - 1) !== a) throw new MissingSentinel(t, a, r);
                    }
                },
                isRequired: c
            });
        },
        imports: {
            findSentinel: null
        }
    }), xn({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return ln({
                get() {
                    let t = je(this.typedArray, r);
                    const e = this.constructor[Wt]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, i) {
                    if ("string" != typeof n) throw new TypeMismatch("string", n);
                    const s = this.constructor[Wt]?.value;
                    void 0 !== s && n.charCodeAt(n.length - 1) !== s && (n += String.fromCharCode(s));
                    const o = Le(n, r), a = new DataView(o.buffer);
                    e.assignView(this, a, t, !1, i);
                }
            });
        }
    }), xn({
        defineValueOf: () => ({
            value() {
                return Xr(this, !1);
            }
        })
    });
    const Hr = BigInt(Number.MAX_SAFE_INTEGER), Yr = BigInt(Number.MIN_SAFE_INTEGER);
    function Xr(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, i = _e(r), s = new Map, o = function(t) {
            const a = "function" == typeof t ? e.Struct : t?.constructor?.[Ft];
            if (void 0 === a) {
                if (n) {
                    if ("bigint" == typeof t && Yr <= t && t <= Hr) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let c = s.get(t);
            if (void 0 === c) {
                let n;
                switch (a) {
                  case e.Struct:
                    n = t[Gt](r), c = t.constructor[Rt] & v.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[Gt](r), c = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[Gt](), c = [];
                    break;

                  case e.Pointer:
                    try {
                        c = t["*"];
                    } catch (t) {
                        c = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    c = i((() => String(t)));
                    break;

                  case e.Opaque:
                    c = {};
                    break;

                  default:
                    c = i((() => t.$));
                }
                if (c = o(c), s.set(t, c), n) for (const [t, e] of n) c[t] = o(e);
            }
            return c;
        };
        return o(t);
    }
    xn({
        defineToJSON: () => ({
            value() {
                return Xr(this, !0);
            }
        })
    }), xn({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return Nr(n, {
                get(t) {
                    const e = this[_t][t];
                    return e?.constructor;
                },
                set: On
            });
        }
    }), xn({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return ln({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new TypeMismatch(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), xn({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), xn({
        defineMemberUndefined: t => ({
            get: function() {},
            set: On
        })
    }), xn({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), xn({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), xn({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${l[e]}`], i = [], s = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [ae]: ze(s),
                [Jt]: ze(i)
            }, a = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !s[t] && "$" !== t && (s[t] = n, i.push(t));
            }
            return $e(a.prototype, o), a;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: i, align: s, byteSize: o, flags: a, signature: c, static: {members: u, template: f}} = t, h = [], d = {
                name: ze(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [ge]: ze(c),
                [re]: ze(this),
                [ne]: ze(s),
                [te]: ze(o),
                [Ft]: ze(r),
                [Rt]: ze(a),
                [Dt]: ze(h),
                [ce]: ze(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [Gt]: this.defineStructEntries(),
                [Dt]: ze(h)
            }, g = {
                [Symbol.toStringTag]: ze(n)
            };
            if (u) for (const t of u) {
                const {name: n, slot: r, flags: i} = t;
                if (t.structure.type === e.Function) {
                    let t = f[_t][r];
                    i & Y ? t[Be] = t => t.string : i & Q ? t[Be] = t => t.clampedArray : i & K ? t[Be] = t => t.typedArray : i & X && (t[Be] = t => t.valueOf()), 
                    d[n] = ze(t), t.name || Te(t, "name", ze(n));
                    const [e, s] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], o = "get" === e ? 0 : 1;
                    if (e && t.length === o) {
                        d[s] ||= {};
                        d[s][e] = t;
                    }
                    if (i & q) {
                        const r = function(...e) {
                            try {
                                let [n, r] = pr(this);
                                return i & J && r === tt.Pointer && (n = n["*"]), t(n, ...e);
                            } catch (t) {
                                throw t[we]?.(1), t;
                            }
                        };
                        if ($e(r, {
                            name: ze(n),
                            length: ze(t.length - 1)
                        }), g[n] = ze(r), e && r.length === o) {
                            (g[s] ||= {})[e] = r;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[_t] = h.length > 0 && ze(f[_t]);
            const p = this[`finalize${l[r]}`];
            !1 !== p?.call(this, t, d, g) && ($e(i.prototype, g), $e(i, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: i, align: s, flags: o, instance: {members: a, template: c}} = t, {onCastError: l} = n;
            let u;
            if (c?.[_t]) {
                const t = a.filter((t => t.flags & Z));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, p = function(n, a = {}) {
                const {allocator: y} = a, m = this instanceof p;
                let b, w, v = !1;
                if (m) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (b = this, o & d && (b[_t] = {}), Ae in b) b[xe](n, y), w = b[zt]; else {
                        const t = r !== e.Pointer ? y : null;
                        b[zt] = w = h.allocateMemory(i, s, t);
                    }
                } else {
                    if (ke in p && (b = p[ke].call(this, n, a), !1 !== b)) return b;
                    w = h.extractView(t, n, l), (b = f.find(w)) ? v = !0 : (b = Object.create(p.prototype), 
                    Ae in b ? h.assignView(b, w, t, !1, !1) : b[zt] = w, o & d && (b[_t] = {}));
                }
                if (!v) {
                    if (u) for (const t of u) b[_t][t] = c[_t][t];
                    b[Ee]?.(), m && (Ae in b || b[xe](n, y)), Me in b && (b = b[Me]()), f.save(w, b);
                }
                return o & g && (m || !this) ? b[Ue]() : b;
            };
            return Te(p, Qt, ze(f)), p;
        },
        createInitializer: t => function(e, n) {
            const [r, i] = pr(e), [s] = pr(this);
            return t.call(s, r, n, i);
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const [i] = pr(n), [s] = pr(this), o = Object.keys(i);
                if (i instanceof Error) throw i;
                const a = s[Jt], c = s[ae];
                for (const e of o) if (!(e in c)) throw new NoProperty(t, e);
                let l = 0, u = 0, f = 0, h = 0;
                for (const t of a) {
                    const e = c[t];
                    e.special ? t in i && h++ : (l++, t in i ? u++ : e.required && f++);
                }
                if (0 !== f && 0 === h) {
                    const e = a.filter((t => c[t].required && !(t in i)));
                    throw new MissingInitializers(t, e);
                }
                if (h + u > o.length) for (const t of a) t in i && (o.includes(t) || o.push(t));
                u < l && 0 === h && e && e[zt] && dn(s, e);
                for (const t of o) {
                    c[t].call(s, i[t], r);
                }
                return o.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) switch (n) {
              case e.Enum:
              case e.ErrorSet:
              case e.Primitive:
                {
                    const {byteSize: t, type: e} = r.members[0];
                    return globalThis[(t > 4 && e !== P.Float ? "Big" : "") + (e === P.Float ? "Float" : e === P.Int ? "Int" : "Uint") + 8 * t + "Array"];
                }

              case e.Array:
              case e.Slice:
              case e.Vector:
                return this.getTypedArray(r.members[0].structure);
            }
        }
    }), xn({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: i, length: s, instance: {members: o}} = t, a = this, c = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = a.allocateMemory(r, i)) : (u = Object.create(l.prototype), 
                f = t), u[zt] = f, n & d && (u[_t] = {}), !o) return u;
                {
                    let r;
                    if (n & F && t.length === s + 1 && (r = t.pop()), t.length !== s) throw new ArgumentCountMismatch(s, t.length);
                    n & N && (u[Me] = null), a.copyArguments(u, t, c, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = ze(c.length), e[Se] = n & f && this.defineVivificatorStruct(t), 
            e[Ie] = n & h && this.defineVisitorArgStruct(o), e[Oe] = ze((function(t) {
                u.call(this, t, this[he]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(c), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[le] = ze(!!(n & R));
        },
        updateArgStructMembers(t, e) {
            const {constructor: {prototype: n}, instance: {members: r}} = t;
            for (const [t, i] of r.entries()) {
                const r = e[t];
                if (r !== i.flags) {
                    i.flags = r;
                    const t = this.defineMember(i);
                    Te(n, i.name, t);
                }
            }
        }
    }), xn({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                return $e(this, {
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), this;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, i = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, s = this[zt], o = s.byteOffset + n * t, a = i.obtainView(s.buffer, o, n, !s[be]);
                    return this[_t][t] = e.call(Ct, a);
                }
            };
        }
    }), xn({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: i} = t, s = this.createApplier(t), o = this.defineMember(r), {set: a} = o, c = this.createConstructor(t), l = this.createInitializer((function(e, r) {
                if (rn(e, c)) dn(this, e), i & h && this[Ie]("copy", st.Vivificate, e); else if ("string" == typeof e && i & m && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = Qe(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) a.call(this, i++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }));
            return e.$ = {
                get: function() {
                    return hr(this, tt.Slice);
                },
                set: l
            }, e.length = ze(n), e.entries = e[Gt] = this.defineArrayEntries(), i & b && (e.typedArray = this.defineTypedArray(t), 
            i & m && (e.string = this.defineString(t)), i & w && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[xe] = ze(l), e[Me] = this.defineFinalizerArray(o), 
            e[Se] = i & f && this.defineVivificatorArray(t), e[Ie] = i & h && this.defineVisitorArray(), 
            e[Ue] = {
                value() {
                    return hr(this, tt.Slice);
                }
            }, e[ye] = ze(tt.Slice), c;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = ze(r.structure.constructor), e[Wt] = n & y && this.defineSentinel(t);
        }
    }), xn({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: i, set: s} = r, {get: o} = this.defineMember(n, !1), a = this.createApplier(t), c = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return e.$ = r, e.toString = ze(pn), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[Lt];

                      default:
                        return o.call(this);
                    }
                }
            }, e[xe] = ze((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === a.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && s.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [i]}, static: {members: s, template: o}} = t, a = o[_t], {get: c, set: l} = this.defineMember(i, !1), u = {};
            for (const {name: t, flags: n, slot: r} of s) if (n & G) {
                const n = a[r];
                Te(n, Lt, ze(t));
                const i = c.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[i] = n;
            }
            e[ke] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & x) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            Te(e, Lt, ze(n)), Te(r, n, ze(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[Pt] instanceof r && t[Pt];
                }
            }, e[ce] = ze(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === P.Object) return t;
            const i = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    t = i(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), xn({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: i, flags: s} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: C.IsGlobal,
                    byteSize: i,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && s & C.IsGlobal) return this.globalErrorSet;
            const o = this.defineMember(r), {set: a} = o, c = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return n.$ = o, n[xe] = ze((function(e) {
                if (e instanceof u[Nt]) a.call(this, e); else if (e && "object" == typeof e && !zn(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && a.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [i]}, static: {members: s, template: o}} = t;
            if (this.globalErrorSet && r & C.IsGlobal) return !1;
            const a = o?.[_t] ?? {}, c = r & C.IsGlobal ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(i, !1);
            for (const {name: t, slot: n} of s) {
                const r = a[n], i = l.call(r);
                let s = this.globalItemsByIndex[i];
                const o = !!s;
                s || (s = new this.ZigError(t, i));
                const u = ze(s);
                e[t] = u;
                const f = `${s}`;
                e[f] = u, c[i] = s, o || ($e(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[Dt].push(t), this.globalItemsByIndex[i] = s);
            }
            e[ke] = {
                value: t => "number" == typeof t ? c[t] : "string" == typeof t ? n[t] : t instanceof n[Nt] ? c[Number(t)] : zn(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[Nt] = ze(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === P.Object) return t;
            const i = t => {
                const {constructor: e, flags: n} = r, i = e(t);
                if (!i) {
                    if (n & C.IsGlobal && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, Te(this.globalErrorSet, `${e}`, ze(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r, t) : new ErrorExpected(r, t);
                }
                return i;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = i(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function Kr(t, e) {
        return nn(t?.constructor?.child, e) && t["*"];
    }
    function Qr(t, e, n) {
        if (n & U) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & k && Kr(t, e.child)) return !0;
        }
        return !1;
    }
    function ti() {
        return this[Yt];
    }
    function ei(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function ni() {
        throw new InaccessiblePointer;
    }
    function ri() {
        const t = {
            get: ni,
            set: ni
        };
        $e(this, {
            "*": t,
            $: t,
            [Zt]: t
        });
    }
    function ii(t) {
        return t <= 2 || t >= Ut.min;
    }
    function si(t, e, n, r) {
        let i, s = this[_t][t];
        if (!s) {
            if (n & st.IgnoreUncreated) return;
            s = this[Se](t);
        }
        r && (i = r[_t][t], !i) || s[Ie](e, n, i);
    }
    xn({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), d = n.type === P.Void, g = r.structure.constructor, {bitOffset: p, byteSize: y} = n, m = function() {
                hn(this[zt], p >> 3, y), this[Ie]?.("clear", st.IgnoreUncreated);
            }, b = this.createApplier(t), w = this.createInitializer((function(t, e) {
                if (rn(t, v)) dn(this, t), i & h && (l.call(this) || this[Ie]("copy", 0, t)); else if (t instanceof g[Nt] && g(t)) c.call(this, t), 
                m.call(this); else if (void 0 !== t || d) try {
                    return o.call(this, t, e), void u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = g(t) ?? g.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure, t);
                        c.call(this, e), m.call(this);
                    } else if (zn(t)) c.call(this, t), m.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === b.call(this, t)) throw e;
                    }
                }
            })), v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw a.call(this);
                    return s.call(this);
                },
                set: w
            }, e[xe] = ze(w), e[Se] = i & f && this.defineVivificatorStruct(t), e[Ie] = i & h && this.defineVisitorErrorUnion(n, l), 
            v;
        }
    }), xn({
        defineFunction(t, n) {
            const {instance: {members: [r], template: i}} = t, {structure: {constructor: s}} = r, o = this, a = function(n) {
                const r = this instanceof a;
                let c;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new TypeMismatch("function", n);
                    if (s[Ft] === e.VariadicStruct || !a[pe]) throw new Unsupported;
                    c = o.getFunctionThunk(n, a[pe]);
                } else {
                    if (this !== re) throw new NoCastingToFunction;
                    c = n;
                }
                const l = s.prototype.length, u = r ? o.createInboundCaller(n, s) : o.createOutboundCaller(i, s);
                return $e(u, {
                    length: ze(l),
                    name: ze(r ? n.name : "")
                }), Object.setPrototypeOf(u, a.prototype), u[zt] = c, u;
            };
            return Object.setPrototypeOf(a.prototype, Function.prototype), n.valueOf = n.toJSON = ze(gn), 
            a;
        },
        finalizeFunction(t, e, n) {
            e[pe] = {
                get: () => t.static?.template
            }, n[Symbol.toStringTag] = void 0;
        }
    }), xn({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, i = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[xe] = ze((() => {
                throw new CreatingOpaque(t);
            })), i;
        }
    }), xn({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), l = n.type === P.Void, {bitOffset: u, byteSize: d} = n, g = this.createInitializer((function(t, e) {
                rn(t, p) ? (dn(this, t), i & h && a.call(this) && this[Ie]("copy", st.Vivificate, t)) : null === t ? (c.call(this, 0), 
                i & E && hn(this[zt], u >> 3, d), this[Ie]?.("clear", st.IgnoreUncreated)) : (void 0 !== t || l) && (o.call(this, t, e), 
                i & E ? c.call(this, 1) : i & h && (a.call(this) || c.call(this, 13)));
            })), p = t.constructor = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    return a.call(this) ? s.call(this) : (this[Ie]?.("clear", st.IgnoreUncreated), null);
                },
                set: g
            }, e[xe] = ze(g), e[Se] = i & f && this.defineVivificatorStruct(t), e[Ie] = i & h && this.defineVisitorOptional(n, a), 
            p;
        }
    }), xn({
        definePointer(t, n) {
            const {flags: r, byteSize: i, instance: {members: [s]}} = t, {structure: o} = s, {type: a, flags: c, byteSize: l = 1} = o, f = r & M ? i / 2 : i, {get: h, set: d} = this.defineMember({
                type: P.Uint,
                bitOffset: 0,
                bitSize: 8 * f,
                byteSize: f,
                structure: {
                    byteSize: f
                }
            }), {get: y, set: m} = r & M ? this.defineMember({
                type: P.Uint,
                bitOffset: 8 * f,
                bitSize: 8 * f,
                byteSize: f,
                structure: {
                    flags: p.IsSize,
                    byteSize: f
                }
            }) : {}, b = function(t, n = !0, i = !0) {
                if (n || this[zt][jt]) {
                    if (!i) return this[_t][0] = void 0;
                    {
                        const n = C.child, i = h.call(this), s = r & M ? y.call(this) : a === e.Slice && c & B ? $.findSentinel(i, n[Wt].bytes) + 1 : 1;
                        if (i !== this[Xt] || s !== this[Kt]) {
                            const e = $.findMemory(t, i, s, n[te]), o = e ? n.call(re, e) : null;
                            return this[_t][0] = o, this[Xt] = i, this[Kt] = s, r & M && (this[qt] = null), 
                            o;
                        }
                    }
                }
                return this[_t][0];
            }, w = function(t) {
                d.call(this, t), this[Xt] = t;
            }, v = c & B ? 1 : 0, S = r & M || c & B ? function(t) {
                m?.call?.(this, t - v), this[Kt] = t;
            } : null, I = dr(t), A = dr(o, r & O), x = function(t = !0) {
                const e = !this[_t][0], n = b.call(this, null, e);
                if (!n) {
                    if (r & V) return null;
                    throw new NullPointer;
                }
                return A && t ? hr(n, A) : n;
            }, E = c & u ? function() {
                return x.call(this).$;
            } : x, T = r & O ? On : function(t) {
                return x.call(this).$ = t;
            }, $ = this, z = this.createInitializer((function(n, i, s) {
                const l = o.constructor;
                if (Kr(n, l)) {
                    if (!(r & O) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[_t][0];
                } else if (r & U) Qr(n, l, r) && (n = l.call(re, n[_t][0][zt])); else if (a === e.Slice && c & _ && n) if (n.constructor[Ft] === e.Pointer) n = n[Zt]?.[zt]; else if (n[zt]) n = n[zt]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof l) {
                    if ((s === tt.ReadOnly || n[me]) && !(r & O)) throw new ReadOnlyTarget(t);
                } else if (rn(n, l)) n = l.call(re, n[zt]); else if (r & k && r & U && n instanceof l.child) n = l.call(re, n[zt]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[ce];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== tn(t, e.child)) return !0;
                    }
                    return !1;
                }(n, l)) {
                    const t = $.extractView(o, n);
                    n = l.call(re, t);
                } else if (null == n || n[zt]) {
                    if (!(void 0 === n || r & V && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & k && r & U && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = l.prototype[ae];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (ce in l && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    const e = n = new l(n, {
                        allocator: i
                    });
                    c & g && (n = gr(e).target);
                }
                const u = n?.[zt]?.[jt];
                if (-1 === u?.address) throw new PreviouslyFreed(n);
                this[Zt] = n;
            })), C = this.createConstructor(t);
            return n["*"] = {
                get: E,
                set: T
            }, n.$ = {
                get: a === e.Pointer ? gn : function() {
                    return hr(this, I);
                },
                set: z
            }, n.length = {
                get: function() {
                    const t = x.call(this, !1);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = x.call(this, !1);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[zt], i = n[jt];
                    let s;
                    if (!i) if (r & M) this[qt] ||= e.length, s = this[qt]; else {
                        s = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > s) throw new InvalidSliceLength(t, s);
                    const a = t * l, c = i ? $.obtainZigView(i.address, a) : $.obtainView(n.buffer, n.byteOffset, a), u = o.constructor;
                    this[_t][0] = u.call(re, c), S?.call?.(this, t);
                }
            }, n.slice = a === e.Slice && {
                value(t, e) {
                    const n = this[Zt].slice(t, e);
                    return new C(n);
                }
            }, n.subarray = a === e.Slice && {
                value(t, e, n) {
                    const r = this[Zt].subarray(t, e, n);
                    return new C(r);
                }
            }, n[Symbol.toPrimitive] = a === e.Primitive && {
                value(t) {
                    return this[Zt][Symbol.toPrimitive](t);
                }
            }, n[xe] = ze(z), n[Me] = a === e.Function && {
                value() {
                    const t = function(...e) {
                        return t["*"].call(this, ...e);
                    };
                    return t[zt] = this[zt], t[_t] = this[_t], Object.setPrototypeOf(t, C.prototype), 
                    t;
                }
            }, n[Ue] = I && {
                value() {
                    return hr(this, I);
                }
            }, n[ye] = ze(I), n[Zt] = {
                get: x,
                set: function(t) {
                    if (void 0 !== t) {
                        if (t) {
                            const e = t[zt][jt];
                            if (e) {
                                const {address: n, js: r} = e;
                                w.call(this, n), S?.call?.(this, t.length), r && (t[zt][jt] = void 0);
                            } else if (this[zt][jt]) throw new ZigMemoryTargetRequired;
                        } else this[zt][jt] && (w.call(this, 0), S?.call?.(this, 0));
                        this[_t][0] = t ?? null, r & M && (this[qt] = null);
                    }
                }
            }, n[we] = ze(b), n[Ht] = {
                set: w
            }, n[Yt] = {
                set: S
            }, n[Ie] = this.defineVisitor(), n[Xt] = ze(0), n[Kt] = ze(0), n[qt] = r & M && ze(null), 
            n.dataView = n.base64 = void 0, C;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: i, instance: {members: [s]}} = t, {structure: o} = s, {type: a, constructor: c} = o;
            n.child = c !== Object ? ze(c) : {
                get: () => o.constructor
            }, n.const = ze(!!(r & O)), n[ke] = {
                value(n, s) {
                    if (this === re || this === Ct || n instanceof i) return !1;
                    if (Kr(n, c)) return new i(c(n["*"]), s);
                    if (Qr(n, c, r)) return new i(n);
                    if (a === e.Slice) return new i(c(n), s);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    }), xn({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: i, set: s} = this.defineMember(n), o = function(e) {
                if (rn(e, a)) dn(this, e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = Ce(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && s.call(this, e);
            }, a = this.createConstructor(t);
            return e.$ = {
                get: i,
                set: o
            }, e[xe] = ze(o), e[Symbol.toPrimitive] = ze(i), a;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[ee] = ze(n.bitSize), e[se] = ze(n.type);
        }
    }), xn({
        defineSlice(t, e) {
            const {align: n, flags: r, instance: {members: [i]}} = t, {byteSize: s} = i, o = this, a = function(t, e, r) {
                t || (t = o.allocateMemory(e * s, n, r)), this[zt] = t, this[Yt] = e;
            }, c = function(e, n) {
                if (n !== this[Yt]) throw new ArrayLengthMismatch(t, this, e);
            }, l = this.defineMember(i), {set: u} = l, d = this.createApplier(t), g = this.createInitializer((function(e, n) {
                if (rn(e, y)) this[zt] ? c.call(this, e, e.length) : a.call(this, null, e.length, n), 
                dn(this, e), r & h && this[Ie]("copy", st.Vivificate, e); else if ("string" == typeof e && r & T) g.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = Qe(e), this[zt] ? c.call(this, e, e.length) : a.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) y[Wt]?.validateValue(r, t, e.length), u.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[zt] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[zt]);
                    a.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === d.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            })), p = function(t, e) {
                const n = this[Yt], r = this[zt];
                t = void 0 === t ? 0 : ei(t, n), e = void 0 === e ? n : ei(e, n);
                const i = t * s, a = e * s - i;
                return o.obtainView(r.buffer, r.byteOffset + i, a);
            }, y = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    return hr(this, tt.Slice);
                },
                set: g
            }, e.length = {
                get: ti
            }, r & $ && (e.typedArray = this.defineTypedArray(t), r & T && (e.string = this.defineString(t)), 
            r & z && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[Gt] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = p.call(this, t, e);
                    return y(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: i = !1} = r, s = p.call(this, t, e), a = o.allocateMemory(s.byteLength, n, i), c = y(a);
                    return fn(a, s), c;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[Ae] = ze(a), e[xe] = ze(g), 
            e[Me] = this.defineFinalizerArray(l), e[Se] = r & f && this.defineVivificatorArray(t), 
            e[Ie] = r & h && this.defineVisitorArray(), e[Ue] = {
                value() {
                    return hr(this, tt.Slice);
                }
            }, e[ye] = ze(tt.Slice), y;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = ze(r.structure.constructor), e[Wt] = n & B && this.defineSentinel(t);
        }
    }), xn({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === P.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: i, byteSize: s, structure: {constructor: o}} = e, a = this[zt], c = a.byteOffset + (i >> 3);
                    let l = s;
                    if (void 0 === l) {
                        if (7 & i) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(a.buffer, c, l, !a[be]);
                    return this[_t][t] = o.call(Ct, u);
                }
            };
        }
    }), xn({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: i, instance: {members: a}} = t, c = a.find((t => t.flags & H)), l = c && this.defineMember(c), u = this.createApplier(t), d = this.createInitializer((function(e, n) {
                if (rn(e, g)) dn(this, e), r & h && this[Ie]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            })), g = this.createConstructor(t), p = e[ae].value, y = e[Jt].value, m = [];
            for (const t of a.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: i} = e[n] = this.defineMember(t);
                i && (r & W && (i.required = !0), p[n] = i, y.push(n)), m.push(n);
            }
            return e.$ = {
                get: gn,
                set: d
            }, e.length = ze(i), e.entries = r & v.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & v.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[xe] = ze(d), e[Se] = r & f && this.defineVivificatorStruct(t), e[Ie] = r & h && this.defineVisitorStruct(a), 
            e[Gt] = r & v.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[Dt] = ze(m), n === s && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), g;
        }
    }), xn({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: i}} = t, s = !!(r & S), a = s ? i.slice(0, -1) : i, c = s ? i[i.length - 1] : null, {get: l, set: u} = this.defineMember(c), {get: d} = this.defineMember(c, !1), g = r & I ? function() {
                return l.call(this)[Lt];
            } : function() {
                const t = l.call(this);
                return a[t].name;
            }, p = r & I ? function(t) {
                const {constructor: e} = c.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = a.findIndex((e => e.name === t));
                u.call(this, e);
            }, y = this.createApplier(t), m = this.createInitializer((function(e, n) {
                if (rn(e, b)) dn(this, e), r & h && this[Ie]("copy", st.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of E) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === y.call(this, e, n)) throw new MissingUnionInitializer(t, e, s);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            })), b = this.createConstructor(t), w = {}, v = e[ae].value, x = e[Jt].value, E = [];
            for (const n of a) {
                const {name: i} = n, {get: o, set: a} = this.defineMember(n), c = s ? function() {
                    const e = g.call(this);
                    if (i !== e) {
                        if (r & I) return null;
                        throw new InactiveUnionProperty(t, i, e);
                    }
                    return o.call(this);
                } : o, l = s && a ? function(e) {
                    const n = g.call(this);
                    if (i !== n) throw new InactiveUnionProperty(t, i, n);
                    a.call(this, e);
                } : a, u = s && a ? function(t) {
                    p.call(this, i), this[Ie]?.("clear", st.IgnoreUncreated), a.call(this, t);
                } : a;
                e[i] = {
                    get: c,
                    set: l
                }, v[i] = u, w[i] = o, x.push(i), E.push(i);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: m
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & I && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return g.call(this);

                      default:
                        return d.call(this);
                    }
                }
            };
            const {comptime: M} = this;
            return e[Ee] = r & A && {
                value() {
                    return M || this[Ie](ri), this[Ie] = yn, this;
                }
            }, e[xe] = ze(m), e[Pt] = r & I && {
                get: l,
                set: u
            }, e[Se] = r & f && this.defineVivificatorStruct(t), e[Ie] = r & h && this.defineVisitorUnion(a, r & I ? d : null), 
            e[Gt] = this.defineUnionEntries(), e[Dt] = r & I ? {
                get() {
                    return [ g.call(this) ];
                }
            } : ze(E), e[oe] = ze(w), b;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & I && (e.tag = ze(r[r.length - 1].structure.constructor));
        }
    }), xn({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: i, length: s, instance: {members: o}} = t, a = this, c = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[zt] = a.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = a.littleEndian;
            };
            return $e(u, {
                [ne]: {
                    value: 4
                }
            }), $e(u.prototype, {
                set: ze((function(t, e, n, r, i) {
                    const s = this[zt], o = a.littleEndian;
                    s.setUint16(8 * t, e, o), s.setUint16(8 * t + 2, n, o), s.setUint16(8 * t + 4, r, o), 
                    s.setUint8(8 * t + 6, i == P.Float), s.setUint8(8 * t + 7, i == P.Int || i == P.Float);
                }))
            }), e[Se] = i & f && this.defineVivificatorStruct(t), e[Ie] = this.defineVisitorVariadicStruct(o), 
            e[Oe] = ze((function(t) {
                l.call(this, t, this[he]);
            })), function(t) {
                if (t.length < s) throw new ArgumentCountMismatch(s, t.length, !0);
                let e = n, i = r;
                const o = t.slice(s), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[zt], o = n?.constructor?.[ne];
                    if (!r || !o) {
                        throw Un(new InvalidVariadicArgument, s + t);
                    }
                    o > i && (i = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = a.allocateMemory(e, i);
                h[ne] = i, this[zt] = h, this[_t] = {}, a.copyArguments(this, t, c);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: i, structure: {align: s}}] of c.entries()) f.set(t, e >> 3, n, s, r), 
                i > d && (d = i);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[zt], i = l[t], o = a.obtainView(h.buffer, i, r), c = this[_t][n] = e.constructor.call(Ct, o), u = e.constructor[ee] ?? 8 * r, g = e.constructor[ne], p = e.constructor[se];
                    c.$ = e, f.set(s + t, i, u, g, p);
                }
                this[ie] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[le] = ze(!!(n & R)), e[ne] = ze(void 0);
        }
    }), xn({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [i]}} = t, s = this.createApplier(t), o = this.createInitializer((function(e) {
                if (rn(e, a)) dn(this, e), n & h && this[Ie]("copy", st.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) this[i++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            })), a = this.createConstructor(t), {bitSize: c} = i;
            for (let t = 0, s = 0; t < r; t++, s += c) e[t] = n & h ? this.defineMember({
                ...i,
                slot: t
            }) : this.defineMember({
                ...i,
                bitOffset: s
            });
            return e.$ = {
                get: gn,
                set: o
            }, e.length = ze(r), n & j && (e.typedArray = this.defineTypedArray(t), n & L && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[Gt] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[xe] = ze(o), e[Se] = n & f && this.defineVivificatorArray(t), e[Ie] = n & h && this.defineVisitorArray(), 
            a;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = ze(n.structure.constructor);
        }
    }), xn({
        fdLockGet(t, e, n) {
            const r = this.littleEndian;
            return Vn(n, at, (() => {
                const [n] = this.getStream(t);
                if (sn(n, "getlock")) {
                    const t = un(24);
                    this.moveExternBytes(t, e, !1);
                    const i = t.getUint16(0, r), s = t.getUint16(2, r), o = t.getUint32(4, r), a = Je(t.getBigInt64(8, r)), c = Je(t.getBigUint64(16, r));
                    return n.getlock({
                        type: i,
                        whence: s,
                        start: a,
                        length: c,
                        pid: o
                    });
                }
            }), (t => {
                let n;
                t ? (n = un(24), n.setUint16(0, t.type ?? 0, r), n.setUint16(2, t.whence ?? 0, r), 
                n.setUint32(4, t.pid ?? 0, r), n.setBigInt64(8, BigInt(t.start ?? 0), r), n.setBigUint64(16, BigInt(t.length ?? 0), r)) : (n = un(2), 
                n.setUint16(0, 2, r)), this.moveExternBytes(n, e, !0);
            }));
        },
        exports: {
            fdLockGet: {
                async: !0
            }
        }
    }), xn({
        fdLockSet(t, e, n, r) {
            const i = this.littleEndian;
            return Vn(r, ct, (() => {
                const [r] = this.getStream(t);
                if (sn(r, "setlock")) {
                    const t = un(24);
                    this.moveExternBytes(t, e, !1);
                    const s = t.getUint16(0, i), o = t.getUint16(2, i), a = t.getUint32(4, i), c = Je(t.getBigUint64(8, i)), l = Je(t.getBigUint64(16, i));
                    return r.setlock({
                        type: s,
                        whence: o,
                        start: c,
                        len: l,
                        pid: a
                    }, n);
                }
                return !0;
            }), (t => $n(t, ct)));
        },
        exports: {
            fdLockSet: {
                async: !0
            }
        }
    }), xn({
        fdSendfile(t, e, n, r, i, s, o) {
            return Vn(o, lt, (() => {
                let s, o;
                if (ii(e)) {
                    const [t, n] = this.getStream(e);
                    Bn(n, Et.fd_read), r ? (Tn(t, "pread", dt), s = (e, n) => t.pread(e, Je(n))) : s = e => t.read(e);
                } else s = r ? (t, n) => this.readFile(e, t, n) : t => this.readFile(e, t);
                if (ii(t)) {
                    const [e, n, r] = this.getStream(t);
                    Bn(n, Et.fd_write);
                    const i = r & Mt.nonblock ? e.writenb : e.write;
                    o = t => i.call(e, t);
                } else o = e => this.writeFile(t, e);
                let a = n, c = i, l = 0, u = 0;
                const f = () => {
                    if (c -= u, l += u, a += BigInt(u), 0 === c) return l;
                    const t = Math.min(c, 1048576), e = s(t, a);
                    return on(e) ? e.then(h) : h(e);
                }, h = t => {
                    if (u = t.length, 0 === u) return l;
                    const e = o(t);
                    return on(e) ? e.then(f) : f();
                };
                return f();
            }), (t => {
                r && this.copyUint64(r, n + BigInt(t)), this.copyUint32(s, t);
            }));
        },
        imports: {
            readFile: {},
            writeFile: {}
        },
        exports: {
            fdSendfile: {
                async: !0
            }
        }
    }), xn({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? oi[t] : t, r.call(this, e, n);
            }
        })
    });
    const oi = {
        copy(t, e) {
            const n = e[_t][0];
            if (this[zt][jt] && n && !n[zt][jt]) throw new ZigMemoryTargetRequired;
            this[_t][0] = n;
        },
        clear(t) {
            t & st.IsInactive && (this[_t][0] = void 0);
        },
        reset() {
            this[_t][0] = void 0, this[Xt] = void 0;
        }
    };
    return xn({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: i, structure: s}] of t.entries()) s.flags & h && (0 === r ? n = i : e.push(i));
            return {
                value(t, r, i) {
                    if (!(r & st.IgnoreArguments) && e.length > 0) for (const n of e) si.call(this, n, t, r | st.IsImmutable, i);
                    r & st.IgnoreRetval || void 0 === n || si.call(this, n, t, r, i);
                }
            };
        }
    }), xn({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, i = this.length; r < i; r++) si.call(this, r, t, e, n);
            }
        })
    }), xn({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) && (r |= st.IsInactive), r & st.IsInactive && r & st.IgnoreInactive || si.call(this, n, t, r, i);
                }
            };
        }
    }), xn({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) || (r |= st.IsInactive), r & st.IsInactive && r & st.IgnoreInactive || si.call(this, n, t, r, i);
                }
            };
        }
    }), xn({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & h)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const i of e) si.call(this, i, t, n, r);
                }
            };
        }
    }), xn({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: i}] of t.entries()) i?.flags & h && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, i) {
                    const s = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== s && (n |= st.IsInactive), n & st.IsInactive && n & st.IgnoreInactive || si.call(this, o, t, n, i);
                    }
                }
            };
        }
    }), xn({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & h ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & st.IgnoreArguments)) for (const [i, s] of Object.entries(this[_t])) i !== n && Ie in s && si.call(this, i, t, e | st.IsImmutable, r);
                    e & st.IgnoreRetval || void 0 === n || si.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (En());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
