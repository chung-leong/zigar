(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, i = 3, s = 4, o = 5, c = 6, a = 7, l = 8, u = 9, f = Object.keys(e), h = 1, d = 2, g = 4, p = 8, y = 16, m = 16, b = 32, w = 64, v = 128, S = {
        IsExtern: 16,
        IsPacked: 32,
        IsTuple: 64,
        IsOptional: 128
    }, A = 16, I = 32, x = 64, M = 16, E = 16, V = 16, U = 32, O = 64, B = 128, $ = 256, C = 16, k = 32, z = 64, T = 128, F = 256, j = 16, L = 16, N = 32, P = 16, _ = 32, D = 64, R = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, W = Object.keys(R), Z = 1, q = 2, J = 4, G = 16, H = 64, Y = 128, X = 1, K = 2, Q = 4, tt = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, et = 0, nt = 8, rt = 16, it = 20, st = 21, ot = 28, ct = 29, at = 44, lt = {
        unknown: 0,
        blockDevice: 1,
        characterDevice: 2,
        directory: 3,
        file: 4,
        socketDgram: 5,
        socketStream: 6,
        symbolicLink: 7
    }, ut = 1, ft = 2, ht = 3, dt = 1048575, gt = globalThis[Symbol.for("ZIGAR")] ||= {};
    function pt(t) {
        return gt[t] ||= Symbol(t);
    }
    function yt(t) {
        return pt(t);
    }
    const mt = yt("memory"), bt = yt("slots"), wt = yt("parent"), vt = yt("zig"), St = yt("name"), At = yt("type"), It = yt("flags"), xt = yt("class"), Mt = yt("tag"), Et = yt("props"), Vt = yt("pointer"), Ut = yt("sentinel"), Ot = yt("array"), Bt = yt("target"), $t = yt("entries"), Ct = yt("max length"), kt = yt("keys"), zt = yt("address"), Tt = yt("length"), Ft = yt("last address"), jt = yt("last length"), Lt = yt("proxy"), Nt = yt("cache"), Pt = yt("size"), _t = yt("bit size"), Dt = yt("align"), Rt = yt("const target"), Wt = yt("environment"), Zt = yt("attributes"), qt = yt("primitive"), Jt = yt("getters"), Gt = yt("setters"), Ht = yt("typed array"), Yt = yt("throwing"), Xt = yt("promise"), Kt = yt("generator"), Qt = yt("allocator"), te = yt("fallback"), ee = yt("signature"), ne = yt("string retval"), re = yt("update"), ie = yt("reset"), se = yt("vivificate"), oe = yt("visit"), ce = yt("copy"), ae = yt("shape"), le = yt("initialize"), ue = yt("restrict"), fe = yt("finalize"), he = yt("cast"), de = yt("return"), ge = yt("yield");
    function pe(t, e, n) {
        if (n) {
            const {set: r, get: i, value: s, enumerable: o, configurable: c = !0, writable: a = !0} = n;
            Object.defineProperty(t, e, i || r ? {
                get: i,
                set: r,
                configurable: c,
                enumerable: o
            } : {
                value: s,
                configurable: c,
                enumerable: o,
                writable: a
            });
        }
        return t;
    }
    function ye(t, e) {
        for (const [n, r] of Object.entries(e)) pe(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            pe(t, n, e[n]);
        }
        return t;
    }
    function me(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function be(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function we({type: t, bitSize: e}) {
        switch (t) {
          case R.Bool:
            return "boolean";

          case R.Int:
          case R.Uint:
            if (e > 32) return "bigint";

          case R.Float:
            return "number";
        }
    }
    function ve(t, e = "utf-8") {
        const n = Ae[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let i = 0;
            for (const e of t) r.set(e, i), i += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function Se(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (Ie[e] ||= new TextEncoder).encode(t);
    }
    const Ae = {}, Ie = {};
    function xe(t, e, n) {
        let r = 0, i = t.length;
        if (0 === i) return 0;
        for (;r < i; ) {
            const s = Math.floor((r + i) / 2);
            n(t[s]) <= e ? r = s + 1 : i = s;
        }
        return i;
    }
    const Me = function(t, e) {
        return !!e && !!(t & BigInt(e - 1));
    }, Ee = function(t, e) {
        return t + BigInt(e - 1) & ~BigInt(e - 1);
    }, Ve = 0xFFFFFFFFFFFFFFFFn, Ue = -1n, Oe = function(t) {
        return BigInt(t);
    }, Be = function(t, e) {
        return t + BigInt(e);
    };
    function $e(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function Ce(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function ke(t, e) {
        const n = [], r = new Map, i = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) i(n);
        };
        for (const e of t) i(e.instance.template), i(e.static.template);
        return n;
    }
    function ze(t, e) {
        return t === e || t?.[ee] === e[ee] && t?.[Wt] !== e?.[Wt];
    }
    function Te(t, e) {
        return t instanceof e || ze(t?.constructor, e);
    }
    function Fe(t, e) {
        return "function" == typeof t?.[e];
    }
    function je(t) {
        return "function" == typeof t?.then;
    }
    function Le(t, e) {
        const n = {};
        for (const [r, i] of Object.entries(e)) t & i && (n[r] = !0);
        return n;
    }
    function Ne(t, e) {
        for (const [n, r] of Object.entries(e)) if (n === t) return r;
    }
    function Pe({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function _e(t) {
        return new DataView(new ArrayBuffer(t));
    }
    function De() {
        return this;
    }
    function Re() {
        return this[Lt];
    }
    function We() {
        return String(this);
    }
    function Ze() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return this.map.get(t);
        }
        save(t, e) {
            return this.map.set(t, e), e;
        }
    }
    const qe = 1, Je = 2, Ge = 4, He = 8, Ye = () => 1e3 * new Date;
    function Xe(t, e, n) {
        const r = {};
        return n & qe ? r.atime = t : n & Je && (r.atime = Ye()), n & Ge ? r.mtime = e : n & He && (r.mtime = Ye()), 
        r;
    }
    const Ke = {
        name: "",
        mixins: []
    };
    function Qe(t) {
        return Ke.mixins.includes(t) || Ke.mixins.push(t), t;
    }
    function tn() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: i} = r;
            pe(r, "name", me(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = i[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                pe(i, e, me(r));
            }
            return r;
        }(Ke.name, Ke.mixins);
    }
    function en(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, i) {
                const s = n.getUint8(i) >> t & r;
                e.setUint8(0, s);
            };
            {
                const e = 255 ^ r << t;
                return function(n, i, s) {
                    const o = i.getUint8(0), c = n.getUint8(s) & e | (o & r) << t;
                    n.setUint8(s, c);
                };
            }
        }
        {
            const r = 8 - t, i = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(s, o, c) {
                    let a, l = c, u = 0, f = o.getUint8(l++), h = f >> t & i, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), a = g >= 8 ? 255 & h : h & n, s.setUint8(u++, a), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, s = 255 ^ i << t, o = 255 ^ n;
                return function(r, i, c) {
                    let a, l, u = 0, f = c, h = r.getUint8(f), d = h & s, g = t, p = e + g;
                    do {
                        p > g && (a = i.getUint8(u++), d |= a << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    Qe({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: i, byteSize: s} = e, o = [], c = void 0 === s && (7 & r || 7 & i);
            c && o.push("Unaligned");
            let a = W[n];
            r > 32 && (n === R.Int || n === R.Uint) && (a = r <= 64 ? `Big${a}` : `Jumbo${a}`), 
            o.push(a, `${n === R.Bool && s ? 8 * s : r}`), c && o.push(`@${i}`);
            const l = t + o.join("");
            let u = DataView.prototype[l];
            if (u && this.usingBufferFallback()) {
                const e = this, i = u, s = function(t) {
                    const {buffer: e, byteOffset: n, byteLength: i} = this, s = e[te];
                    if (s) {
                        if (t < 0 || t + r / 8 > i) throw new RangeError("Offset is outside the bounds of the DataView");
                        return s + Oe(n + t);
                    }
                };
                u = "get" === t ? function(t, o) {
                    const c = s.call(this, t);
                    return void 0 !== c ? e.getNumericValue(n, r, c) : i.call(this, t, o);
                } : function(t, o, c) {
                    const a = s.call(this, t);
                    return void 0 !== a ? e.setNumericValue(n, r, a, o) : i.call(this, t, o, c);
                };
            }
            if (u) return u;
            if (u = this.accessorCache.get(l), u) return u;
            for (;o.length > 0; ) {
                const n = `getAccessor${o.join("")}`;
                if (u = this[n]?.(t, e)) break;
                o.pop();
            }
            if (!u) throw new Error(`No accessor available: ${l}`);
            return pe(u, "name", me(l)), this.accessorCache.set(l, u), u;
        },
        imports: {
            getNumericValue: null,
            setNumericValue: null
        }
    }), Qe({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), i = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & i) - (n & r);
            } : function(t, e, n) {
                const s = e < 0 ? r | e & i : e & i;
                this.setBigUint64(t, s, n);
            };
        }
    }), Qe({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const i = e & r;
                this.setBigUint64(t, i, n);
            };
        }
    }), Qe({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, i = this.getAccessor(t, {
                type: R.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!i.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, s) {
                    i.call(this, n, r ? e : t, s);
                };
            }
        }
    }), Qe({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = _e(8), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, c = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(c), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, c = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = c ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return c ? NaN : s ? -1 / 0 : 1 / 0;
                const a = o - 16383n + 1023n;
                if (a >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | a << 52n | (c >> 60n) + BigInt((c & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, c = (0x7ff0000000000000n & i) >> 52n, a = 0x000fffffffffffffn & i;
                let l;
                l = 0n === c ? o << 127n | a << 60n : 0x07ffn === c ? o << 127n | 0x7fffn << 112n | (a ? 1n : 0n) : o << 127n | c - 1023n + 16383n << 112n | a << 60n, 
                s.call(this, t, l, n);
            };
        }
    }), Qe({
        getAccessorFloat16(t, e) {
            const n = _e(4), r = DataView.prototype.setUint16, i = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = i.call(this, t, e), s = r >>> 15, o = (31744 & r) >> 10, c = 1023 & r;
                if (0 === o) return s ? -0 : 0;
                if (31 === o) return c ? NaN : s ? -1 / 0 : 1 / 0;
                const a = s << 31 | o - 15 + 127 << 23 | c << 13;
                return n.setUint32(0, a, e), n.getFloat32(0, e);
            } : function(t, e, i) {
                n.setFloat32(0, e, i);
                const s = n.getUint32(0, i), o = s >>> 31, c = (2139095040 & s) >> 23, a = 8388607 & s, l = c - 127 + 15;
                let u;
                u = 0 === c ? o << 15 : 255 === c ? o << 15 | 31744 | (a ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | a >> 13, 
                r.call(this, t, u, i);
            };
        }
    }), Qe({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = _e(8), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, c = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = c ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return c ? NaN : s ? -1 / 0 : 1 / 0;
                const a = o - 16383n + 1023n;
                if (a >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | a << 52n | (c >> 11n) + BigInt((c & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, c = (0x7ff0000000000000n & i) >> 52n, a = 0x000fffffffffffffn & i;
                let l;
                l = 0n === c ? o << 79n | a << 11n : 0x07ffn === c ? o << 79n | 0x7fffn << 64n | (a ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | c - 1023n + 16383n << 64n | a << 11n | 0x00008000000000000000n, 
                s.call(this, t, l, n);
            };
        }
    }), Qe({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: R.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), i = 2 ** (n - 1), s = i - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & s) - (r & i);
                } : function(t, n, r) {
                    const o = n < 0 ? i | n & s : n & s;
                    e.call(this, t, o, r);
                };
            }
        }
    }), Qe({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n - 1), s = i - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & s) - (n & i);
            } : function(t, e, n) {
                const o = e < 0 ? i | e & s : e & s;
                r.call(this, t, o, n);
            };
        }
    }), Qe({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & i;
            } : function(t, e, n) {
                const s = e & i;
                r.call(this, t, s, n);
            };
        }
    }), Qe({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let i = 0, s = t + 8 * (n - 1); i < n; i++, s -= 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                } else for (let i = 0, s = t; i < n; i++, s += 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                }
                return r;
            } : function(t, e, r) {
                let i = e;
                const s = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                }
            };
        }
    }), Qe({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const i = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), s = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return i.call(this, t, e) & s;
                } : function(t, e, n) {
                    const r = e & s;
                    i.call(this, t, r, n);
                };
            }
        }
    }), Qe({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), i = e ? n | r : n & ~r;
                this.setInt8(t, i);
            };
        }
    }), Qe({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> i;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << i;
                    return function(n, s) {
                        let o = this.getUint8(n);
                        o = o & t | (s < 0 ? e | s & r : s & r) << i, this.setUint8(n, o);
                    };
                }
            }
        }
    }), Qe({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> i & e;
                };
                {
                    const t = 255 ^ e << i;
                    return function(n, r) {
                        const s = this.getUint8(n) & t | (r & e) << i;
                        this.setUint8(n, s);
                    };
                }
            }
        }
    }), Qe({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r, s = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = _e(s);
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: s
                }), r = en(i, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: s
                }), r = en(i, n, !1);
                return function(e, n, i) {
                    t.call(o, 0, n, i), r(this, o, e);
                };
            }
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: i, type: s, byteSize: o} = t, c = n.byteLength, a = 1 !== o ? "s" : "";
            let l;
            if (s !== e.Slice || r) {
                l = `${i} has ${s === e.Slice ? r.length * o : o} byte${a}, received ${c}`;
            } else l = `${i} has elements that are ${o} byte${a} in length, received ${c}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: i} = t, s = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(hn);
            let c;
            i && o.push(hn(i.name)), c = n === e.Slice ? `Expecting ${gn(o)} that can accommodate items ${r} byte${s} in length` : `Expecting ${gn(o)} that is ${r} byte${s} in length`, 
            super(c);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let i;
            "string" === r || "number" === r || un(e) ? (un(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            i = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : i = `Error of the type ${n} expected, received ${e}`, 
            super(i);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Error given is not a part of error set ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: i}} = t;
            super(`${r} needs an initializer for one of its union properties: ${i.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, i = [];
            if (Array.isArray(e)) for (const t of e) i.push(hn(t)); else i.push(hn(e));
            const s = fn(n);
            super(`${r} expects ${gn(i)} as argument, received ${s}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [i]}, type: s, constructor: o} = t, c = [], a = we(i);
            if (a) {
                let t;
                switch (i.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = a;
                }
                c.push(`array of ${t}s`);
            } else c.push("array of objects");
            o[Ht] && c.push(o[Ht].name), s === e.Slice && r && c.push("length"), super(t, c.join(" or "), n);
        }
    }
    class InvalidEnumValue extends TypeError {
        code=ot;
        constructor(t, e) {
            super(`Received '${e}', which is not among the following possible values:\n\n${Object.keys(t).map((t => `${t}\n`)).join("")}`);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: i, instance: {members: [s]}} = t, {structure: {constructor: o}} = s, {length: c, constructor: a} = n, l = e?.length ?? i, u = 1 !== l ? "s" : "";
            let f;
            f = a === o ? "only a single one" : a.child === o ? `a slice/array that has ${c}` : `${c} initializer${c > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let i;
            i = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(i);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const i = 1 !== (t -= r) ? "s" : "", s = n ? "at least " : "";
                this.message = `Expecting ${s}${t} argument${i}, received ${e}`, this.stack = sn(this.stack, "new Arg(");
            };
            r(0), pe(this, re, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: i} = t;
            super(`${i} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    let nn = class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = fn(e);
            super(`Expected ${hn(t)}, received ${n}`);
        }
    };
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${dn(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + W[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class InvalidFileDescriptor extends Error {
        code=nt;
        constructor() {
            super("Invalid file descriptor");
        }
    }
    class InvalidArgument extends Error {
        code=ot;
        constructor() {
            super("Invalid argument");
        }
    }
    class Deadlock extends Error {
        code=rt;
        constructor() {
            super("Unable to await promise");
        }
    }
    class MissingEventListener extends Error {
        constructor(t, e) {
            super(`Missing event listener: ${t}`), this.code = e;
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = sn(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function rn(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = sn(t.stack, "new Arg(");
        };
        return n(0), pe(t, re, {
            value: n,
            enumerable: !1
        }), t;
    }
    function sn(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function on() {
        throw new ReadOnly;
    }
    function cn(t, e, n) {
        if (t.bytes += n, t.calls++, 100 === t.calls) {
            const n = t.bytes / t.calls;
            if (n < 8) {
                throw new Error(`Inefficient ${e} access. Each call is only ${"read" === e ? "reading" : "writing"} ${n} byte${1 !== n ? "s" : ""}. Please use std.io.Buffered${"read" === e ? "Reader" : "Writer"}.`);
            }
        }
    }
    function an(t = !1, e, n, r, i) {
        const s = t => (i ? i(t) : console.error(t)) ?? t.code ?? e, o = t => {
            const e = r?.(t);
            return e ?? et;
        };
        try {
            const e = n();
            if (je(e)) {
                if (!t) throw new Deadlock;
                return e.then(o).catch(s);
            }
            return o(e);
        } catch (t) {
            return s(t);
        }
    }
    function ln(t, e) {
        if (!0 === t) return et;
        if (!1 === t) return e;
        throw new nn("boolean", t);
    }
    function un(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function fn(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        hn(n);
    }
    function hn(t) {
        return `${dn(t)} ${t}`;
    }
    function dn(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function gn(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function pn(t) {
        let n, r = 1, i = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[vt]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[mt]) t.constructor[At] === e.Pointer && (t = t["*"]), 
        n = t[mt], i = t.constructor, r = i[Dt]; else {
            "string" == typeof t && (t = Se(t));
            const {buffer: e, byteOffset: i, byteLength: s, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== i && void 0 !== s && (n = new DataView(e, i, s), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: i
        };
    }
    Qe({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: i}, ptr: s} = this, o = i(s, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const c = o["*"][mt];
                return c[vt].align = e, c;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = pn(e), i = n?.[vt];
                    if (!i) throw new nn("object containing allocated Zig memory", e);
                    const {address: s} = i;
                    if (s === Ue) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: c} = this;
                    o(c, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe() {
            const t = this.getCopyFunction();
            return {
                value(e) {
                    const {dv: n, align: r, constructor: i} = pn(e);
                    if (!n) throw new nn("string, DataView, typed array, or Zig object", e);
                    const s = this.alloc(n.byteLength, r);
                    return t(s, n), i ? i(s) : s;
                }
            };
        }
    }), Qe({
        init() {
            this.variables = [], this.listenerMap = new Map([ [ "log", t => console.log(t.message) ] ]);
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: (...t) => this.initialize?.(...t),
                abandon: () => this.abandonModule?.(),
                redirect: (t, e) => this.redirectStream(t, e),
                sizeOf: e => t(e?.[Pt]),
                alignOf: e => t(e?.[Dt]),
                typeOf: e => yn[t(e?.[At])],
                on: (t, e) => this.addListener(t, e)
            };
        },
        addListener(t, e) {
            this.listenerMap.set(t, e);
        },
        triggerEvent(t, e, n) {
            const r = this.listenerMap.get(t);
            if (r) return r(e);
            if (n) throw new MissingEventListener(t, n);
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = i(r);
                return t;
            }, r = t => t.length ? t.buffer : new ArrayBuffer(0), i = t => {
                const {memory: e, structure: i, actual: s} = t;
                if (e) {
                    if (s) return s;
                    {
                        const {array: s, offset: o, length: c} = e, a = this.obtainView(r(s), o, c), {handle: l, const: u} = t, f = i?.constructor, h = t.actual = f.call(Wt, a);
                        return u && this.makeReadOnly(h), t.slots && n(h[bt], t.slots), l && this.variables.push({
                            handle: l,
                            object: h
                        }), h;
                    }
                }
                return i;
            }, s = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: i} = t.template, o = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: s} = n;
                        o[mt] = this.obtainView(r(t), e, s), i && this.variables.push({
                            handle: i,
                            object: o
                        });
                    }
                    if (e) {
                        const t = o[bt] = {};
                        s.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of s) n(t, e);
            for (const e of t) this.finalizeStructure(e);
        }
    });
    const yn = f.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    Qe({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[mt]), i = this.createJsThunk(t, n);
                if (!i) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(i, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                try {
                    const i = e(n);
                    if (oe in i) {
                        i[oe]("reset");
                        const t = this.startContext();
                        this.updatePointerTargets(t, i, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const s = i.hasOwnProperty(de), o = an(r || s, st, (() => t(...i)), (t => {
                        if (t?.[Symbol.asyncIterator]) {
                            if (!i.hasOwnProperty(ge)) throw new UnexpectedGenerator;
                            this.pipeContents(t, i);
                        } else i[de](t);
                    }), (t => {
                        try {
                            if (e[Yt] && t instanceof Error) return i[de](t), et;
                            throw t;
                        } catch (e) {
                            console.error(t);
                        }
                    }));
                    return s ? et : o;
                } catch (t) {
                    return console.error(t), st;
                }
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, c = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === s)).length;
            return {
                value() {
                    let a, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, y, m = this[d];
                        if (p === R.Object && m?.[mt]?.[vt] && (m = new m.constructor(m)), g.type === e.Struct) switch (g.purpose) {
                          case s:
                            t = 1 === c ? "allocator" : "allocator" + ++l, y = this[Qt] = m;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (y = o.createPromiseCallback(this, m));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (y = o.createGeneratorCallback(this, m));
                            break;

                          case i:
                            t = "signal", 1 == ++f && (y = o.createInboundSignal(m));
                        }
                        void 0 !== t ? void 0 !== y && (a ||= {}, a[t] = y) : h.push(m);
                    } catch (t) {
                        h.push(t);
                    }
                    return a && h.push(a), h[Symbol.iterator]();
                }
            };
        },
        handleJsCall(t, e, n, r) {
            const i = this.obtainZigView(e, n, !1), s = this.jsFunctionCallerMap.get(t);
            return s ? s(i, r) : st;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[mt]), i = this.getViewAddress(e);
                this.destroyJsThunk(r, i), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJsCall: {},
            releaseFunction: {}
        },
        imports: {
            createJsThunk: {},
            destroyJsThunk: {},
            finalizeAsyncCall: {}
        }
    }), Qe({
        createOutboundCaller(t, e) {
            const n = this, r = function(...i) {
                const s = new e(i, this?.[Qt]);
                return n.invokeThunk(t, r, s);
            };
            return r;
        },
        copyArguments(t, o, f, h, d) {
            let g = 0, p = 0, y = 0;
            const m = t[Gt];
            for (const {type: b, structure: w} of f) {
                let f, v, S, A;
                if (w.type === e.Struct) switch (w.purpose) {
                  case s:
                    f = (1 == ++y ? h?.allocator ?? h?.allocator1 : h?.[`allocator${y}`]) ?? this.createDefaultAllocator(t, w);
                    break;

                  case n:
                    v ||= this.createPromise(w, t, h?.callback), f = v;
                    break;

                  case r:
                    S ||= this.createGenerator(w, t, h?.callback), f = S;
                    break;

                  case i:
                    A ||= this.createSignal(w, h?.signal), f = A;
                    break;

                  case c:
                    f = this.createReader(o[p++]);
                    break;

                  case a:
                    f = this.createWriter(o[p++]);
                    break;

                  case l:
                    f = this.createFile(o[p++]);
                    break;

                  case u:
                    f = this.createDirectory(o[p++]);
                }
                if (void 0 === f && (f = o[p++], void 0 === f && b !== R.Void)) throw new UndefinedArgument;
                try {
                    m[g++].call(t, f, d);
                } catch (t) {
                    throw rn(t, g - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), i = n[Zt], s = this.getViewAddress(t[mt]), o = this.getViewAddress(e[mt]), c = fe in n, a = oe in n;
            a && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[mt]), u = i ? this.getViewAddress(i[mt]) : 0;
            this.updateShadows(r);
            const f = () => {
                this.updateShadowTargets(r), a && this.updatePointerTargets(r, n), this.flushStreams?.(), 
                this.endContext();
            };
            c && (n[fe] = f);
            if (!(i ? this.runVariadicThunk(s, o, l, u, i.length) : this.runThunk(s, o, l))) throw f(), 
            new ZigError;
            if (c) {
                let t = null;
                try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (e[ne] && t && (t = t.string), n[de](t)) : e[ne] && (n[ne] = !0), 
                n[Xt] ?? n[Kt];
            }
            f();
            try {
                const {retval: t} = n;
                return e[ne] && t ? t.string : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    }), Qe({
        init() {
            const t = {
                type: R.Int,
                bitSize: 8,
                byteSize: 1
            }, e = {
                type: R.Int,
                bitSize: 16,
                byteSize: 2
            }, n = {
                type: R.Int,
                bitSize: 32,
                byteSize: 4
            }, r = this.getAccessor("get", t), i = this.getAccessor("set", t), s = this.getAccessor("get", e), o = this.getAccessor("set", e), c = this.getAccessor("get", n), a = this.getAccessor("set", n);
            this.copiers = {
                0: Ze,
                1: function(t, e) {
                    i.call(t, 0, r.call(e, 0));
                },
                2: function(t, e) {
                    o.call(t, 0, s.call(e, 0, !0), !0);
                },
                4: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0);
                },
                8: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0), a.call(t, 4, c.call(e, 4, !0), !0);
                },
                16: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0), a.call(t, 4, c.call(e, 4, !0), !0), a.call(t, 8, c.call(e, 8, !0), !0), 
                    a.call(t, 12, c.call(e, 12, !0), !0);
                },
                any: function(t, e) {
                    let n = 0, s = t.byteLength;
                    for (;n + 4 <= s; ) a.call(t, n, c.call(e, n, !0), !0), n += 4;
                    for (;n + 1 <= s; ) i.call(t, n, r.call(e, n)), n++;
                }
            }, this.resetters = {
                0: Ze,
                1: function(t, e) {
                    i.call(t, e, 0);
                },
                2: function(t, e) {
                    o.call(t, e, 0, !0);
                },
                4: function(t, e) {
                    a.call(t, e, 0, !0);
                },
                8: function(t, e) {
                    a.call(t, e + 0, 0, !0), a.call(t, e + 4, 0, !0);
                },
                16: function(t, e) {
                    a.call(t, e + 0, 0, !0), a.call(t, e + 4, 0, !0), a.call(t, e + 8, 0, !0), a.call(t, e + 12, 0, !0);
                },
                any: function(t, e, n) {
                    let r = e;
                    for (;r + 4 <= n; ) a.call(t, r, 0, !0), r += 4;
                    for (;r + 1 <= n; ) i.call(t, r, 0), r++;
                }
            };
        },
        defineCopier(t, e) {
            const n = this.getCopyFunction(t, e);
            return {
                value(t) {
                    const e = t[mt], r = this[mt];
                    n(r, e);
                }
            };
        },
        defineResetter(t, e) {
            const n = this.getResetFunction(e);
            return {
                value() {
                    const r = this[mt];
                    n(r, t, e);
                }
            };
        },
        getCopyFunction(t, e = !1) {
            return (e ? void 0 : this.copiers[t]) ?? this.copiers.any;
        },
        getResetFunction(t) {
            return this.resetters[t] ?? this.resetters.any;
        },
        imports: {
            moveExternBytes: {}
        }
    }), Qe({
        convertDirectory(t) {
            if (t instanceof Map) return new MapDirectory(t);
            if (Fe(t, "readdir")) return t;
            throw new nn("map or object with directory interface", t);
        }
    });
    class MapDirectory {
        onClose=null;
        constructor(t) {
            this.map = t, t.close = () => this.onClose?.();
        }
        * readdir() {
            for (const [t, e] of this.map) yield {
                name: t,
                ...e
            };
        }
        valueOf() {
            return this.map;
        }
    }
    function mn(t, e) {
        return xe(t, e, (t => t.address));
    }
    Qe({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: i, bitSize: s} = n;
            if ("set" === e) return s > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const i = Number(e);
                if (!isFinite(i)) throw new InvalidIntConversion(e);
                r.call(this, t, i, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & y && s > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, i) {
                        const s = r.call(this, n, i);
                        return e <= s && s <= t ? Number(s) : s;
                    };
                }
            }
            return r;
        }
    }), Qe({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const i = e[mt];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: s, targets: o} = n;
                    let c, a = 0;
                    for (const t of o) {
                        const e = t[mt], n = e.byteOffset, r = t.constructor[Dt] ?? e[Dt];
                        (void 0 === a || r > a) && (a = r, c = n);
                    }
                    const l = s - e, u = this.allocateShadowMemory(l + a, 1), f = this.getViewAddress(u), h = Ee(Be(f, c - e), a), d = Be(h, e - c);
                    for (const t of o) {
                        const n = t[mt], r = n.byteOffset;
                        if (r !== c) {
                            const i = t.constructor[Dt] ?? n[Dt];
                            if (Me(Be(d, r - e), i)) throw new AlignmentConflict(i, a);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), y = new DataView(i.buffer, Number(e), l), m = this.registerMemory(d, l, 1, r, y, p);
                    t.shadowList.push(m), n.address = d;
                }
                return Be(n.address, i.byteOffset - n.start);
            }
            {
                const n = e.constructor[Dt] ?? i[Dt], s = i.byteLength, o = this.allocateShadowMemory(s, n), c = this.getViewAddress(o), a = this.registerMemory(c, s, 1, r, i, o);
                return t.shadowList.push(a), c;
            }
        },
        updateShadows(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r} of t.shadowList) e(r, n);
        },
        updateShadowTargets(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r, writable: i} of t.shadowList) i && e(n, r);
        },
        registerMemory(t, e, n, r, i, s) {
            const o = mn(this.memoryList, t);
            let c = this.memoryList[o - 1];
            return c?.address === t && c.len === e ? c.writable ||= r : (c = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: i,
                shadowDV: s
            }, this.memoryList.splice(o, 0, c)), c;
        },
        unregisterMemory(t, e) {
            const n = mn(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            let i = n * (r ?? 0);
            const s = mn(this.memoryList, e), o = this.memoryList[s - 1];
            let c;
            if (o?.address === e && o.len === i) c = o.targetDV; else if (o?.address <= e && Be(e, i) <= Be(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: s} = o;
                n && (i = s.byteLength - t), c = this.obtainView(s.buffer, s.byteOffset + t, i), 
                n && (c[Dt] = o.align);
            }
            if (c) {
                let {targetDV: e, shadowDV: n} = o;
                if (n && t && !t.shadowList.includes(o)) {
                    this.getCopyFunction()(e, n);
                }
            } else c = this.obtainZigView(e, i);
            return c;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[vt], n = e?.address;
            n && n !== Ue && (e.address = Ue, this.unregisterBuffer(Be(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[vt];
            if (e) return e.address;
            {
                const e = this.getBufferAddress(t.buffer);
                return Be(e, t.byteOffset);
            }
        },
        obtainZigArray(t, e) {
            const n = this.obtainZigView(t, e, !1);
            return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        },
        ...{
            imports: {
                getBufferAddress: {},
                obtainExternBuffer: {}
            },
            exports: {
                getViewAddress: {}
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (function(t) {
                    return 0xaaaaaaaaaaaaaaaan === t;
                }(t) && (t = e > 0 ? 0 : Ve), !t && e) return null;
                let r, i;
                if (n) {
                    const n = mn(this.externBufferList, t), s = this.externBufferList[n - 1];
                    s?.address <= t && Be(t, e) <= Be(s.address, s.len) ? (r = s.buffer, i = Number(t - s.address)) : (r = e > 0 ? this.obtainExternBuffer(t, e, te) : new ArrayBuffer(0), 
                    this.externBufferList.splice(n, 0, {
                        address: t,
                        len: e,
                        buffer: r
                    }), i = 0);
                } else r = e > 0 ? this.obtainExternBuffer(t, e, te) : new ArrayBuffer(0), i = 0;
                return r[vt] = {
                    address: t,
                    len: e
                }, this.obtainView(r, i, e);
            },
            unregisterBuffer(t) {
                const e = mn(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const i = e[mt];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(i.buffer);
                        for (const e of n.targets) {
                            const r = e[mt].byteOffset, i = e.constructor[Dt], s = Be(t, r);
                            if (Me(s, i)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return Be(n.address, i.byteOffset);
                } else {
                    const t = e.constructor[Dt], n = this.getViewAddress(i);
                    if (!Me(n, t)) {
                        const e = i.byteLength;
                        return this.registerMemory(n, e, t, r, i), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), Qe({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: {}
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const {async: r = !1} = n;
                    let i = this[e];
                    i && (r && (i = this.addPromiseHandling(i)), t[e] = i.bind(this));
                }
                return t;
            },
            addPromiseHandling(t) {
                const e = t.length - 1;
                return function(...n) {
                    try {
                        const r = n[e], i = !!r;
                        n[e] = i;
                        const s = t.call(this, ...n);
                        if (!i || !je(s)) return s;
                        s.then((t => this.finalizeAsyncCall(r, t)));
                    } catch (t) {
                        console.error(t);
                    }
                };
            },
            importFunctions(t) {
                for (const [e] of Object.entries(this.imports)) {
                    const n = t[e];
                    n && (pe(this, e, me(n)), this.destructors.push((() => this[e] = bn)));
                }
            }
        }
    });
    const bn = () => {
        throw new Error("Module was abandoned");
    };
    Qe({
        linkVariables(t) {
            const e = this.getCopyFunction();
            for (const {object: n, handle: r} of this.variables) {
                const i = n[mt], s = this.recreateAddress(r);
                let o = n[mt] = this.obtainZigView(s, i.byteLength);
                t && e(o, i), n.constructor[Nt]?.save?.(o, n), this.destructors.push((() => {
                    const t = n[mt] = this.allocateMemory(o.bytelength);
                    e(t, o);
                }));
                const c = t => {
                    const e = t[bt];
                    if (e) {
                        const t = o.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[mt];
                            if (e.buffer === i.buffer) {
                                const r = t + e.byteOffset - i.byteOffset;
                                n[mt] = this.obtainView(o.buffer, r, e.byteLength), n.constructor[Nt]?.save?.(o, n), 
                                c(n);
                            }
                        }
                    }
                };
                c(n), n[oe]?.((function() {
                    this[re]();
                }), tt.IgnoreInactive);
            }
        },
        imports: {
            recreateAddress: null
        }
    }), Qe({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, i = [], s = function(t) {
                const e = this[Vt];
                if (void 0 === n.get(e)) {
                    const t = e[bt][0];
                    if (t) {
                        const o = {
                            target: t,
                            writable: !e.constructor.const
                        }, c = t[mt];
                        if (c[vt]) n.set(e, null); else {
                            n.set(e, t);
                            const a = r.get(c.buffer);
                            if (a) {
                                const t = Array.isArray(a) ? a : [ a ], e = xe(t, c.byteOffset, (t => t.target[mt].byteOffset));
                                t.splice(e, 0, o), Array.isArray(a) || (r.set(c.buffer, t), i.push(t));
                            } else r.set(c.buffer, o);
                            t[oe]?.(s, 0);
                        }
                    }
                }
            }, o = tt.IgnoreRetval | tt.IgnoreInactive;
            e[oe](s, o);
            const c = this.findTargetClusters(i), a = new Map;
            for (const t of c) for (const e of t.targets) a.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = a.get(r), i = n?.writable ?? !e.constructor.const;
                e[zt] = this.getTargetAddress(t, r, n, i), Tt in e && (e[Tt] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, i = function(e) {
                const n = this[Vt];
                if (!r.get(n)) {
                    r.set(n, !0);
                    const s = n[bt][0], o = s && e & tt.IsImmutable ? s : n[re](t, !0, !(e & tt.IsInactive)), c = n.constructor.const ? tt.IsImmutable : 0;
                    c & tt.IsImmutable || s && !s[mt][vt] && s[oe]?.(i, c), o !== s && o && !o[mt][vt] && o?.[oe]?.(i, c);
                }
            }, s = n ? tt.IgnoreRetval : 0;
            e[oe](i, s);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, i = 0, s = null;
                for (const {target: o, writable: c} of n) {
                    const n = o[mt], {byteOffset: a, byteLength: l} = n, u = a + l;
                    let f = !0;
                    t && (i > a ? (s ? s.writable ||= c : (s = {
                        targets: [ t ],
                        start: r,
                        end: i,
                        address: void 0,
                        misaligned: void 0,
                        writable: c
                    }, e.push(s)), s.targets.push(o), u > i ? s.end = u : f = !1) : s = null), f && (t = o, 
                    r = a, i = u);
                }
            }
            return e;
        }
    }), Qe({
        convertReader(t) {
            if (t instanceof ReadableStreamDefaultReader) return new WebStreamReader(t);
            if (t instanceof ReadableStreamBYOBReader) return new WebStreamReaderBYOB(t);
            if (t instanceof Blob) return new BlobReader(t);
            if (t instanceof Uint8Array) return new Uint8ArrayReader(t);
            if (null === t) return new NullStream;
            if (Fe(t, "read")) return t;
            throw new nn("ReadableStreamDefaultReader, ReadableStreamBYOBReader, Blob, Uint8Array, or object with reader interface", t);
        }
    });
    class WebStreamReader {
        done=!1;
        bytes=null;
        onClose=null;
        constructor(t) {
            this.reader = t, t.close = () => this.onClose?.();
        }
        async read(t) {
            for (;(!this.bytes || this.bytes.length < t) && !this.done; ) {
                let {value: t} = await this.reader.read();
                if (t) if (t instanceof Uint8Array || (t instanceof ArrayBuffer ? t = new Uint8Array(t) : t.buffer instanceof ArrayBuffer && (t = new Uint8Array(t.buffer, t.byteOffset, t.byteLength))), 
                this.bytes) {
                    const e = this.bytes.length, n = t.length, r = new Uint8Array(e + n);
                    r.set(this.bytes), r.set(t, e), this.bytes = r;
                } else this.bytes = t; else this.done = !0;
            }
            let e;
            return this.bytes && (this.bytes.length > t ? (e = this.bytes.subarray(0, t), this.bytes = this.bytes.subarray(t)) : (e = this.bytes, 
            this.bytes = null)), e ?? new Uint8Array(0);
        }
        destroy() {
            this.done || this.reader.cancel(), this.bytes = null;
        }
        valueOf() {
            return this.reader;
        }
    }
    class WebStreamReaderBYOB extends WebStreamReader {
        bytes=null;
        async read(t) {
            let e;
            if ((!this.bytes || this.bytes.length < t) && (this.bytes = new Uint8Array(t)), 
            !this.done) {
                const {value: t} = await this.reader.read(this.bytes);
                t ? e = t : this.done = !0;
            }
            return e ?? new Uint8Array(0);
        }
    }
    class BlobReader {
        pos=0n;
        onClose=null;
        constructor(t) {
            this.blob = t, this.size = BigInt(t.size ?? t.length), t.close = () => this.onClose?.();
        }
        async read(t) {
            const e = Number(this.pos), n = e + t, r = this.blob.slice(e, n), i = new Response(r), s = await i.arrayBuffer();
            return this.pos = BigInt(n), new Uint8Array(s);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            const {size: n} = this;
            let r = -1n;
            switch (e) {
              case 0:
                r = t;
                break;

              case 1:
                r = this.pos + t;
                break;

              case 2:
                r = n + t;
            }
            if (!(r >= 0n && r <= n)) throw new InvalidArgument;
            return this.pos = r;
        }
        valueOf() {
            return this.blob;
        }
    }
    class Uint8ArrayReader extends BlobReader {
        read(t) {
            const e = Number(this.pos), n = e + t;
            return this.pos = BigInt(n), this.blob.subarray(e, n);
        }
    }
    class NullStream {
        read() {
            return 0;
        }
        write() {}
    }
    Qe({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === R.Int;
                    let i = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** i) : 0,
                            max: 2 ** i - 1
                        };
                    }
                    i = BigInt(i);
                    return {
                        min: r ? -(2n ** i) : 0n,
                        max: 2n ** i - 1n
                    };
                }(n);
                return function(i, s, o) {
                    if (s < t || s > e) throw new Overflow(n, s);
                    r.call(this, i, s, o);
                };
            }
            return r;
        }
    }), Qe({
        init() {
            this.streamLocationMap = new Map([ [ ht, "" ] ]);
        },
        obtainStreamLocation(t, e, n) {
            let r = ve(this.obtainZigArray(e, n)).trim();
            r.endsWith("/") && (r = r.slice(0, -1));
            const i = r.trim().split("/"), s = [];
            for (const t of i) ".." === t ? s.pop() : "." !== t && "" != t && s.push(t);
            return {
                parent: this.getStream(t).valueOf(),
                path: s.join("/")
            };
        },
        getStreamLocation(t) {
            return this.streamLocationMap.get(t);
        },
        setStreamLocation(t, e) {
            const n = this.streamLocationMap;
            e ? n.set(t, e) : n.delete(t);
        },
        getDirectoryEntries(t) {
            return this.getStream(t).readdir();
        }
    }), Qe({
        init() {
            const t = {
                * readdir() {},
                valueOf: () => null
            };
            this.streamMap = new Map([ [ ut, this.createLogWriter("stdout") ], [ ft, this.createLogWriter("stderr") ], [ ht, t ] ]), 
            this.flushRequestMap = new Map, this.nextStreamHandle = dt;
        },
        getStream(t, e) {
            const n = this.streamMap.get(t);
            if (!n || e && !Fe(n, e)) throw new InvalidFileDescriptor;
            return n;
        },
        createStreamHandle(t) {
            const e = this.nextStreamHandle++;
            return this.streamMap.set(e, t), t.onClose = () => this.closeStream(e), e;
        },
        destroyStreamHandle(t) {
            const e = this.streamMap.get(t);
            e?.destroy?.(), this.streamMap.delete(t);
        },
        redirectStream(t, e) {
            const n = this.streamMap, r = 3 === t ? ht : t, i = n.get(r);
            if (void 0 !== e) {
                let i;
                if (0 === t) i = this.convertReader(e); else if (1 === t || 2 === t) i = this.convertWriter(e); else {
                    if (3 !== t) throw new Error(`Expecting 0, 1, 2, or 3, received ${r}`);
                    i = this.convertDirectory(e);
                }
                n.set(r, i);
            } else n.delete(r);
            return i;
        },
        createLogWriter(t) {
            const e = this;
            return {
                pending: [],
                write(t) {
                    const n = t.lastIndexOf(10);
                    if (-1 === n) this.pending.push(t); else {
                        const e = t.subarray(0, n), r = t.subarray(n + 1);
                        this.dispatch([ ...this.pending, e ]), this.pending.splice(0), r.length > 0 && this.pending.push(r);
                    }
                    e.scheduleFlush(this, this.pending.length > 0, 250);
                },
                dispatch(n) {
                    const r = ve(n);
                    e.triggerEvent("log", {
                        source: t,
                        message: r
                    });
                },
                flush() {
                    this.pending.length > 0 && (this.dispatch(this.pending), this.pending.splice(0));
                }
            };
        },
        scheduleFlush(t, e, n) {
            const r = this.flushRequestMap, i = r.get(t);
            i && (clearTimeout(i), r.delete(t)), e && r.set(t, setTimeout((() => {
                t.flush(), r.delete(t);
            }), n));
        },
        flushStreams() {
            this.libc && this.flushStdout?.();
            const t = this.flushRequestMap;
            if (t.size > 0) {
                for (const [e, n] of t) e.flush(), clearTimeout(n);
                t.clear();
            }
        },
        imports: {
            flushStdout: {}
        }
    }), Qe({}), Qe({
        convertWriter(t) {
            if (t instanceof WritableStreamDefaultWriter) return new WebStreamWriter(t);
            if (Array.isArray(t)) return new ArrayWriter(t);
            if (null === t) return new NullStream;
            if ("function" == typeof t?.write) return t;
            throw new nn("WritableStreamDefaultWriter, array, null, or object with writer interface", t);
        }
    });
    class WebStreamWriter {
        onClose=null;
        done=!1;
        constructor(t) {
            this.writer = t, t.closed.catch(Ze).then((() => {
                this.done = !0, this.onClose?.();
            }));
        }
        async write(t) {
            await this.writer.write(t);
        }
        destroy() {
            this.done || this.writer.close();
        }
    }
    class ArrayWriter {
        constructor(t) {
            this.array = t, this.closeCB = null, t.close = () => this.onClose?.();
        }
        write(t) {
            this.array.push(t);
        }
    }
    Qe({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), i = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: i
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    }), Qe({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = Oe(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let i = this.allocatorVtable;
            if (!i) {
                const {noResize: t, noRemap: e} = r;
                i = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (i.remap = e), this.destructors.push((() => this.freeFunction(i.alloc))), 
                this.destructors.push((() => this.freeFunction(i.free)));
            }
            let s = Ve;
            if (n) {
                const e = [];
                s = this.nextAllocatorContextId++, this.allocatorContextMap.set(s, e), t[ie] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(s);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(s, 0),
                vtable: i
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][mt]), i = r != Ve ? this.allocatorContextMap.get(r) : null, s = 1 << n, o = this.allocateJSMemory(e, s);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, s, !0, o), pe(o, vt, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), i?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][mt], i = this.getViewAddress(r), s = r.byteLength;
            this.unregisterMemory(i, s);
        }
    }), Qe({
        createDirectory(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return t;
            const e = this.convertDirectory(t);
            return {
                fd: this.createStreamHandle(e)
            };
        }
    }), Qe({
        createFile(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return {
                handle: t.fd
            };
            if ("object" == typeof t && "number" == typeof t?.handle) return t;
            let e;
            try {
                e = this.convertReader(t);
            } catch (n) {
                try {
                    e = this.convertWriter(t);
                } catch {
                    throw n;
                }
            }
            return {
                handle: this.createStreamHandle(e)
            };
        }
    }), Qe({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = Oe(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: i}} = t;
            if (n) {
                if ("function" != typeof n) throw new nn("function", n);
            } else {
                const t = e[Kt] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const s = this.nextGeneratorContextId++, o = this.obtainZigView(s, 0, !1);
            this.generatorContextMap.set(s, {
                func: n,
                args: e
            });
            let c = this.generatorCallbackMap.get(r);
            c || (c = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][mt], r = this.getViewAddress(n), i = this.generatorContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i, s = e instanceof Error;
                    !s && n[ne] && e && (e = e.string);
                    const o = !1 === await (2 === t.length ? t(s ? e : null, s ? null : e) : t(e)) || s || null === e;
                    if (n[ie]?.(o), !o) return !0;
                    n[fe](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, c), this.destructors.push((() => this.freeFunction(c)))), 
            e[de] = t => c(o, t);
            const a = {
                ptr: o,
                callback: c
            }, l = i.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                a.allocator = this.createJsAllocator(e, t, !0);
            }
            return a;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[ge] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[ge](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[ge](t)) break;
                    e[ge](null);
                } catch (t) {
                    if (!e.constructor[Yt]) throw t;
                    e[ge](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    Qe({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = Oe(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new nn("function", n);
            } else e[Xt] = new Promise(((t, r) => {
                n = n => {
                    n?.[mt]?.[vt] && (n = new n.constructor(n)), n instanceof Error ? r(n) : (e[ne] && n && (n = n.string), 
                    t(n));
                };
            }));
            const i = this.nextPromiseContextId++, s = this.obtainZigView(i, 0, !1);
            this.promiseContextMap.set(i, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][mt], r = this.getViewAddress(n), i = this.promiseContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[fe](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[de] = t => o(s, t), {
                ptr: s,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[de] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[de](n);
            };
        }
    }), Qe({
        init() {
            this.readerCallback = null, this.readerMap = new Map, this.nextReaderId = Oe(4096), 
            this.readerProgressMap = new Map;
        },
        createReader(t) {
            if ("object" == typeof t && t && "context" in t && "readFn" in t) return t;
            const e = this.convertReader(t), n = this.nextReaderId++, r = this.obtainZigView(n, 0, !1), i = e.onClose = () => {
                this.readerMap.delete(n), this.readerProgressMap.delete(n);
            };
            this.readerMap.set(n, e), this.readerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let s = this.readerCallback;
            if (!s) {
                const t = t => {
                    throw console.error(t), i(), t;
                };
                s = this.readerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][mt]), i = this.readerMap.get(r);
                    if (!i) return 0;
                    try {
                        const e = n["*"][mt].byteLength, s = t => {
                            const e = t.length, r = this.getViewAddress(n["*"][mt]);
                            return this.moveExternBytes(t, r, !0), e;
                        };
                        cn(this.readerProgressMap.get(r), "read", e);
                        const o = i.read(e);
                        return je(o) ? o.then(s).catch(t) : s(o);
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(s)));
            }
            return {
                context: r,
                readFn: s
            };
        }
    }), Qe({
        init() {
            this.writerCallback = null, this.writerMap = new Map, this.nextWriterContextId = Oe(8192), 
            this.writerProgressMap = new Map;
        },
        createWriter(t) {
            if ("object" == typeof t && t && "context" in t && "writeFn" in t) return t;
            const e = this.convertWriter(t), n = this.nextWriterContextId++, r = this.obtainZigView(n, 0, !1), i = e.onClose = () => {
                this.writerMap.delete(n), this.writerProgressMap.delete(n);
            };
            this.writerMap.set(n, e), this.writerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let s = this.writerCallback;
            if (!s) {
                const t = t => {
                    throw console.error(t), i(), t;
                };
                s = this.writerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][mt]), i = this.writerMap.get(r);
                    if (!i) return 0;
                    try {
                        const e = n["*"][mt];
                        cn(this.writerProgressMap.get(r), "write", e.byteLength);
                        const s = e.byteLength, o = new Uint8Array(e.buffer, e.byteOffset, s), c = new Uint8Array(o), a = i.write(c);
                        return je(a) ? a.then((() => s), t) : s;
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(s)));
            }
            return {
                context: r,
                writeFn: s
            };
        }
    }), Qe({
        environGet(t, e) {
            let n = 0, r = 0;
            for (const t of this.envVariables) n += t.length, r++;
            const i = _e(8 * r), s = new Uint8Array(n);
            let o = 0, c = 0, a = this.littleEndian;
            for (const t of this.envVariables) i.setBigUint64(o, e + BigInt(c), a), o += 8, 
            s.set(t, c), c += t.length;
            return this.moveExternBytes(i, t, !0), this.moveExternBytes(s, e, !0), et;
        }
    }), Qe({
        copyUsize(t, e) {
            this.copyUint64(t, e);
        },
        copyUint64(t, e) {
            const n = _e(8);
            n.setBigUint64(0, BigInt(e), this.littleEndian), this.moveExternBytes(n, t, !0);
        },
        copyUint32(t, e) {
            const n = _e(4);
            n.setUint32(0, e, this.littleEndian), this.moveExternBytes(n, t, !0);
        }
    }), Qe({
        environSizesGet(t, e) {
            const n = this.listenerMap.get("env"), r = n?.() ?? {};
            if ("object" != typeof r) throw new TypeMismatch("object", r);
            const i = this.envVariables = [];
            for (const [t, e] of Object.entries(r)) {
                const n = Se(`${t}=${e}\0`);
                i.push(n);
            }
            let s = 0;
            for (const t of i) s += t.length;
            return this.copyUsize(t, i.length), this.copyUsize(e, s), et;
        }
    });
    const wn = {
        normal: 0,
        sequential: 1,
        random: 2,
        willNeed: 3,
        dontNeed: 4,
        noReuse: 5
    };
    Qe({
        fdAdvise(t, e, n, r, i) {
            return an(i, nt, (() => {
                const i = this.getStream(t), s = Object.keys(wn);
                return i.advise?.(e, n, s[r]);
            }));
        }
    }), Qe({
        fdAllocate(t, e, n, r) {
            return an(r, nt, (() => this.getStream(t).allocate(e, n)));
        }
    }), Qe({
        fdClose(t, e) {
            return an(e, nt, (() => (this.setStreamLocation?.(t), this.destroyStreamHandle(t))));
        }
    }), Qe({
        fdDatasync(t, e) {
            return an(e, nt, (() => {
                const e = this.getStream(t);
                return e.datasync?.();
            }));
        }
    });
    const vn = {
        fd_datasync: 1,
        fd_read: 2,
        fd_seek: 4,
        fd_fdstat_set_flags: 8,
        fd_sync: 16,
        fd_tell: 32,
        fd_write: 64,
        fd_advise: 128,
        fd_allocate: 256,
        path_create_directory: 512,
        path_create_file: 1024,
        path_link_source: 2048,
        path_link_target: 4096,
        path_open: 8192,
        fd_readdir: 16384,
        path_readlink: 32768,
        path_rename_source: 65536,
        path_rename_target: 1 << 17,
        path_filestat_get: 1 << 18,
        path_filestat_set_size: 1 << 19,
        path_filestat_set_times: 1 << 20,
        fd_filestat_get: 1 << 21,
        fd_filestat_set_size: 1 << 22,
        fd_filestat_set_times: 1 << 23,
        path_symlink: 1 << 24,
        path_remove_directory: 1 << 25,
        path_unlink_file: 1 << 26,
        poll_fd_readwrite: 1 << 27,
        sock_shutdown: 1 << 28,
        sock_accept: 1 << 29
    };
    Qe({
        fdFdstatGet(t, e, n) {
            return an(n, nt, (() => {
                const n = this.getStream(t);
                let r, i = 0;
                i = vn.fd_filestat_get, this.listenerMap.get("set_times") && this.getStreamLocation?.(t) && (i |= vn.fd_filestat_set_times);
                for (const t of [ "read", "write", "seek", "tell", "advise", "allocate", "datasync", "sync", "readdir" ]) Fe(n, t) && (i |= vn[`fd_${t}`]);
                if (n.type) {
                    if (r = Ne(n.type, lt), void 0 === r) throw new InvalidEnumValue(lt, n.type);
                } else r = i & (vn.fd_read | vn.fd_write) ? lt.file : lt.directory;
                r === lt.directory && (i |= vn.path_open | vn.path_filestat_get);
                const s = _e(24);
                s.setUint8(0, r), s.setUint16(2, 0, !0), s.setBigUint64(8, BigInt(i), !0), s.setBigUint64(16, 0n, !0), 
                this.moveExternBytes(s, e, !0);
            }));
        }
    }), Qe({
        copyStat(t, e) {
            if (!1 === e) return at;
            if ("object" != typeof e || !e) throw new nn("object or false", e);
            let n = Ne(e.type, lt);
            if (void 0 === n) {
                if (e.type) throw new InvalidEnumValue(lt, e.type);
                n = lt.unknown;
            }
            const r = this.littleEndian, i = _e(64);
            i.setBigUint64(0, 0n, r), i.setBigUint64(8, 0n, r), i.setUint8(16, n), i.setBigUint64(24, 0n, r), 
            i.setBigUint64(32, BigInt(e.size ?? 0), r), i.setBigUint64(40, BigInt(e.atime ?? 0), r), 
            i.setBigUint64(48, BigInt(e.mtime ?? 0), r), i.setBigUint64(56, BigInt(e.ctime ?? 0), r), 
            this.moveExternBytes(i, t, r);
        }
    }), Qe({
        fdFilestatGet(t, e, n) {
            return an(n, nt, (() => {
                const e = this.getStream(t), n = e.valueOf(), r = this.getStreamLocation?.(t);
                try {
                    return this.triggerEvent("stat", {
                        ...r,
                        target: n,
                        flags: {}
                    }, at);
                } catch (t) {
                    if (t.code !== at) throw t;
                }
                return {
                    size: e.size,
                    type: "file"
                };
            }), (t => this.copyStat(e, t)));
        }
    }), Qe({
        fdFilestatSetTimes(t, e, n, r, i) {
            return an(i, nt, (() => {
                const i = this.getStream(t).valueOf(), s = this.getStreamLocation?.(t), o = Xe(e, n, r);
                return this.triggerEvent("set_times", {
                    ...s,
                    target: i,
                    times: o
                }, nt);
            }), (t => ln(t, nt)));
        }
    }), Qe({
        fdRead(t, e, n, r, i) {
            let s, o, c = 0, a = 0;
            const l = () => an(i, ct, (() => {
                s || (s = _e(16 * n), this.moveExternBytes(s, e, !1), o = this.getStream(t));
                const r = s.getUint32(16 * a + 8, !0);
                return o.read(r);
            }), (t => {
                const e = s.getUint32(16 * a, !0);
                if (this.moveExternBytes(t, e, !0), c += t.byteLength, ++a < n) return l();
                this.copyUint32(r, c);
            }));
            return l();
        },
        ...{
            exports: {
                fdRead: {
                    async: !0
                },
                fdRead1: {
                    async: !0
                }
            },
            fdRead1(t, e, n, r, i) {
                return an(i, ct, (() => this.getStream(t).read(n)), (t => {
                    const n = t.length;
                    this.moveExternBytes(t, e, !0), this.copyUint32(r, n);
                }));
            }
        }
    }), Qe({
        init() {
            this.readdirCookieMap = new Map, this.readdirNextCookie = 1n;
        },
        fdReaddir(t, e, n, r, i, s) {
            return n < 24 ? ot : an(s, nt, (() => {
                if (0n === r) return this.getDirectoryEntries(t);
            }), (s => {
                let o;
                if (0n === r) {
                    o = {
                        iterator: s[Symbol.iterator](),
                        count: 0,
                        entry: null
                    }, r = this.readdirNextCookie++, this.readdirCookieMap.set(r, o);
                } else o = this.readdirCookieMap.get(r);
                const c = _e(n);
                let a = n, l = 0;
                const u = t !== ht ? 2 : 1;
                if (o) {
                    let {iterator: t, entry: e} = o;
                    for (e && (o.entry = null); a >= 24; ) {
                        e || (e = ++o.count <= u ? {
                            value: {
                                name: ".".repeat(o.count),
                                type: "directory"
                            },
                            done: !1
                        } : t.next());
                        const {value: n, done: i} = e;
                        if (i) break;
                        const {name: s, type: f, ino: h = 0} = n, d = Se(s);
                        if (a < 24 + d.length) {
                            o.entry = e;
                            break;
                        }
                        const g = void 0 !== f ? Ne(f, lt) : lt.unknown;
                        if (void 0 === g) throw new InvalidEnumValue(lt, f);
                        c.setBigUint64(l, r, !0), c.setBigUint64(l + 8, BigInt(h), !0), c.setUint32(l + 16, d.length, !0), 
                        c.setUint8(l + 20, g), l += 24, a -= 24;
                        for (let t = 0; t < d.length; t++, l++) c.setUint8(l, d[t]);
                        a -= d.length, e = null;
                    }
                }
                this.moveExternBytes(c, e, !0), this.copyUint32(i, l), 0 === l && this.readdirCookieMap.delete(r);
            }));
        }
    }), Qe({
        fdSeek(t, e, n, r, i) {
            return an(i, nt, (() => this.getStream(t, "seek").seek(e, n)), (t => {
                const e = _e(8);
                e.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(e, r, !0);
            }));
        }
    }), Qe({
        fdSync(t, e) {
            return an(e, nt, (() => {
                const e = this.getStream(t);
                return e.sync?.();
            }));
        }
    }), Qe({
        fdTell(t, e, n) {
            return an(n, nt, (() => this.getStream(t, "tell").tell()), (t => {
                const n = _e(8);
                n.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(n, e, !0);
            }));
        }
    }), Qe({
        fdWrite(t, e, n, r, i) {
            let s, o, c = 0, a = 0;
            const l = () => an(i, ct, (() => {
                s || (s = _e(16 * n), this.moveExternBytes(s, e, !1), o = this.getStream(t, "write"));
                const r = this.littleEndian, i = s.getBigUint64(16 * c, r), l = Number(s.getBigUint64(16 * c + 8, r)), u = new Uint8Array(l);
                return this.moveExternBytes(u, i, !1), a += l, o.write(u);
            }), (() => {
                if (++c < n) return l();
                this.copyUint32(r, a);
            }));
            return l();
        },
        ...{
            exports: {
                fdWrite: {
                    async: !0
                },
                fdWrite1: {
                    async: !0
                }
            },
            fdWrite1(t, e, n, r, i) {
                return an(i, ct, (() => {
                    const r = this.getStream(t), i = new Uint8Array(n);
                    return this.moveExternBytes(i, e, !1), r.write(i);
                }), (() => this.copyUsize(r, n)));
            }
        }
    }), Qe({
        pathCreateDirectory(t, e, n, r) {
            return an(r, at, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("mkdir", r, at);
            }), (t => {
                if (!(t instanceof Map)) {
                    if (!0 === t) return it;
                    if (!1 === t) return at;
                    throw new nn("boolean", t);
                }
            }));
        }
    });
    const Sn = {
        symlinkFollow: 1
    };
    Qe({
        pathFilestatGet(t, e, n, r, i, s) {
            return an(s, at, (() => {
                const i = this.obtainStreamLocation(t, n, r), s = Le(e, Sn);
                return this.triggerEvent("stat", {
                    ...i,
                    flags: s
                }, at);
            }), (t => this.copyStat(i, t)));
        }
    }), Qe({
        pathFilestatSetTimes(t, e, n, r, i, s, o) {
            return an(o, at, (() => {
                const o = this.obtainStreamLocation(t, e, n), c = Xe(r, i, s);
                return this.triggerEvent("set_times", {
                    ...o,
                    times: c
                }, at);
            }), (t => ln(t, at)));
        }
    });
    const An = {
        create: 1,
        directory: 2,
        exclusive: 4,
        truncate: 8
    }, In = {
        read: 1n << 1n,
        write: 1n << 6n,
        readdir: 1n << 14n
    };
    function xn() {
        const t = En.toString(), e = t.indexOf("{") + 1, n = t.lastIndexOf("}");
        return t.slice(e, n);
    }
    let Mn;
    function En() {
        let t, e;
        function n({executable: n, memory: i, options: s, tid: o, arg: c}) {
            const a = WebAssembly, l = {
                memory: i
            }, u = {}, f = {}, h = {
                env: l,
                wasi: u,
                wasi_snapshot_preview1: f
            };
            for (const {module: t, name: e, kind: i} of a.Module.imports(n)) if ("function" === i) {
                const n = r(t, e);
                "env" === t ? l[e] = n : "wasi_snapshot_preview1" === t ? f[e] = n : "wasi" === t && (u[e] = n);
            }
            const {tableInitial: d} = s;
            l.__indirect_function_table = new a.Table({
                initial: d,
                element: "anyfunc"
            });
            const {exports: g} = new a.Instance(n, h), {wasi_thread_start: p} = g;
            p(o, c), t({
                type: "exit"
            }), e();
        }
        function r(e, n) {
            const r = new Int32Array(new SharedArrayBuffer(8));
            return function(...i) {
                return r[0] = 0, t({
                    type: "call",
                    module: e,
                    name: n,
                    args: i,
                    array: r
                }), Atomics.wait(r, 0, 0), r[1];
            };
        }
        "object" == typeof self || "node" !== process.env.COMPAT ? (self.onmessage = t => n(t.data), 
        t = t => self.postMessage(t), e = () => self.close()) : "node" === process.env.COMPAT && import("worker_threads").then((({parentPort: r, workerData: i}) => {
            t = t => r.postMessage(t), e = () => process.exit(), n(i);
        }));
    }
    function Vn(t, n) {
        const {byteSize: r, type: i} = n;
        if (!(i === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function Un(t) {
        throw new BufferExpected(t);
    }
    Qe({
        pathOpen(t, e, n, r, i, s, o, c, a, l) {
            const u = Le(s | o, In), f = Le(i, An);
            let h;
            return an(l, at, (() => (h = this.obtainStreamLocation(t, n, r), this.triggerEvent("open", {
                ...h,
                rights: u,
                flags: f
            }, at))), (t => {
                if (!1 === t) return at;
                let e;
                u.read || 0 === Object.values(u).length ? e = this.convertReader(t) : u.write ? e = this.convertWriter(t) : u.readdir && (e = this.convertDirectory(t));
                const n = this.createStreamHandle(e);
                this.setStreamLocation?.(n, h), this.copyUint32(a, n);
            }));
        }
    }), Qe({
        pathRemoveDirectory(t, e, n, r) {
            return an(r, at, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("rmdir", r, at);
            }), (t => ln(t, at)));
        }
    }), Qe({
        pathUnlinkFile(t, e, n, r) {
            return an(r, at, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("unlink", r, at);
            }), (t => ln(t, at)));
        }
    }), Qe({
        init() {
            this.nextThreadId = 1, this.workers = [];
        },
        getThreadHandler(t) {
            if ("thread-spawn" === t) return "object" != typeof window || window.crossOriginIsolated || console.warn("%cHTML document is not cross-origin isolated %c\n\nWebAssembly multithreading in the browser is only possibly when %cwindow.crossOriginIsolated%c = true. Visit https://developer.mozilla.org/en-US/docs/Web/API/Window/crossOriginIsolated for information on how to enable it.", "color: red;font-size: 200%;font-weight:bold", "", "background-color: lightgrey;font-weight:bold", ""), 
            this.spawnThread.bind(this);
        },
        spawnThread(t) {
            const e = this.nextThreadId;
            this.nextThreadId++;
            const {executable: n, memory: r, options: i} = this, s = {
                executable: n,
                memory: r,
                options: i,
                tid: e,
                arg: t
            }, o = (t, e) => {
                if ("call" === e.type) {
                    const {module: t, name: n, args: r, array: i} = e, s = this.exportedModules[t]?.[n], o = s?.(...r, !0), c = t => {
                        i && (i[1] = 0 | t, i[0] = 1, Atomics.notify(i, 0, 1));
                    };
                    je(o) ? o.then(c) : c(o);
                } else if ("exit" === e.type) {
                    const e = this.workers.indexOf(t);
                    -1 !== e && (t.detach(), this.workers.splice(e, 1));
                }
            }, c = "message";
            if ("function" == typeof Worker || "node" !== process.env.COMPAT) {
                const t = function() {
                    if (!Mn) {
                        const t = xn();
                        Mn = URL.createObjectURL(new Blob([ t ], {
                            type: "text/javascript"
                        }));
                    }
                    return Mn;
                }(), e = new Worker(t, {
                    name: "zig"
                }), n = t => o(e, t.data);
                e.addEventListener(c, n), e.detach = () => e.removeEventListener(c, n), e.postMessage(s), 
                this.workers.push(e);
            } else "node" === process.env.COMPAT && import("worker_threads").then((({Worker: t}) => {
                const e = new t(xn(), {
                    workerData: s,
                    eval: !0
                }), n = t => o(e, t);
                e.on(c, n), e.detach = () => e.off(c, n), this.workers.push(e);
            }));
            return e;
        }
    }), Qe({
        init() {
            this.comptime = !1, this.slots = {}, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.libc = !1;
        },
        readSlot(t, e) {
            const n = t ? t[bt] : this.slots;
            return n?.[e];
        },
        writeSlot(t, e, n) {
            const r = t ? t[bt] : this.slots;
            r && (r[e] = n);
        },
        createTemplate: t => ({
            [mt]: t,
            [bt]: {}
        }),
        beginStructure(t) {
            const {type: e, purpose: n, name: r, length: i, signature: s = -1n, byteSize: o, align: c, flags: a} = t;
            return {
                constructor: null,
                type: e,
                purpose: n,
                flags: a,
                signature: s,
                name: r,
                length: i,
                byteSize: o,
                align: c,
                instance: {
                    members: [],
                    template: null
                },
                static: {
                    members: [],
                    template: null
                }
            };
        },
        attachMember(t, e, n = !1) {
            (n ? t.static : t.instance).members.push(e);
        },
        attachTemplate(t, e, n = !1) {
            (n ? t.static : t.instance).template = e;
        },
        endStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        captureView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.moveExternBytes(n, t, !1), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[vt].handle = r, n;
            }
        },
        castView(t, e, n, r, i) {
            const {constructor: s, flags: o} = r, c = this.captureView(t, e, n, i), a = s.call(Wt, c);
            return o & g && this.updatePointerTargets(null, a), n && e > 0 && this.makeReadOnly?.(a), 
            a;
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & X), this.runtimeSafety = !!(t & K), this.libc = !!(t & Q);
            const e = this.getFactoryThunk(), n = {
                [mt]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                if (n & g && r && r[mt]) {
                    const t = Object.create(e.prototype);
                    t[mt] = r[mt], t[bt] = r[bt], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, libc: r} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    libc: r
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of ke(this.structures, bt)) {
                const n = e[mt]?.[vt];
                if (n) {
                    const {address: r, len: i, handle: s} = n, o = e[mt] = this.captureView(r, i, !0);
                    s && (o.handle = s), t.push({
                        address: r,
                        len: i,
                        owner: e,
                        replaced: !1,
                        handle: s
                    });
                }
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && Be(n.address, n.len) <= Be(e.address, e.len)) {
                const t = e.owner[mt], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[mt] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = ke(this.structures, bt);
            for (const t of e) t[mt]?.[vt] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${f[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, static: {template: n}, flags: r} = t;
            switch (e.type) {
              case R.Bool:
                return "bool";

              case R.Int:
                return r & y ? "isize" : `i${e.bitSize}`;

              case R.Uint:
                return r & y ? "usize" : `u${e.bitSize}`;

              case R.Float:
                return `f${e.bitSize}`;

              case R.Void:
                return "void";

              case R.Literal:
                return "enum_literal";

              case R.Null:
                return "null";

              case R.Undefined:
                return "undefined";

              case R.Type:
                return "type";

              case R.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & S[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & j ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let i = "*", s = n.structure.name;
            if (n.structure.type === e.Slice && (s = s.slice(3)), r & U && (i = r & V ? "[]" : r & O ? "[*c]" : "[*]"), 
            !(r & O)) {
                const t = n.structure.constructor?.[Ut];
                t && (i = i.slice(0, -1) + `:${t.value}` + i.slice(-1));
            }
            return r & B && (i = `${i}const `), i + s;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & F ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${i})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${i})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t;
            return e.structure.name.slice(4, -1);
        },
        exports: {
            captureView: {},
            castView: {},
            readSlot: {},
            writeSlot: {},
            beginStructure: {},
            attachMember: {},
            createTemplate: {},
            attachTemplate: {},
            defineStructure: {},
            endStructure: {}
        },
        imports: {
            getFactoryThunk: {},
            getModuleAttributes: {}
        }
    }), Qe({
        init() {
            this.viewMap = new WeakMap, this.needFallback = void 0;
        },
        extractView(t, n, r = Un) {
            const {type: i, byteSize: s, constructor: o} = t;
            let c;
            const a = n?.[Symbol.toStringTag];
            if (a && ("DataView" === a ? c = this.registerView(n) : "ArrayBuffer" === a ? c = this.obtainView(n, 0, n.byteLength) : (a && a === o[Ht]?.name || "Uint8ClampedArray" === a && o[Ht] === Uint8Array || "Uint8Array" === a && n instanceof Buffer) && (c = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !c) {
                const r = n?.[mt];
                if (r) {
                    const {constructor: o, instance: {members: [c]}} = t;
                    if (Te(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(i)) {
                        const {byteSize: o, structure: {constructor: a}} = c, l = Ce(n, a);
                        if (void 0 !== l) {
                            if (i === e.Slice || l * o === s) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return c ? void 0 !== s && Vn(c, t) : r?.(t, n), c;
        },
        assignView(t, n, r, i, s) {
            const {byteSize: o, type: c} = r, a = o ?? 1;
            if (t[mt]) {
                const i = c === e.Slice ? a * t.length : a;
                if (n.byteLength !== i) throw new BufferSizeMismatch(r, n, t);
                const s = {
                    [mt]: n
                };
                t.constructor[Ut]?.validateData?.(s, t.length), t[ce](s);
            } else {
                void 0 !== o && Vn(n, r);
                const e = n.byteLength / a, c = {
                    [mt]: n
                };
                t.constructor[Ut]?.validateData?.(c, e), s && (i = !0), t[ae](i ? null : n, e, s), 
                i && t[ce](c);
            }
            if (this.usingBufferFallback()) {
                const e = t[mt], n = e.buffer[te];
                void 0 !== n && this.syncExternalBuffer(e.buffer, n, !0);
            }
        },
        findViewAt(t, e, n) {
            let r, i = this.viewMap.get(t);
            if (i) if (i instanceof DataView) if (i.byteOffset === e && i.byteLength === n) r = i, 
            i = null; else {
                const e = i, n = `${e.byteOffset}:${e.byteLength}`;
                i = new Map([ [ n, e ] ]), this.viewMap.set(t, i);
            } else r = i.get(`${e}:${n}`);
            return {
                existing: r,
                entry: i
            };
        },
        obtainView(t, e, n) {
            const {existing: r, entry: i} = this.findViewAt(t, e, n);
            let s;
            if (r) return r;
            s = new DataView(t, e, n), i ? i.set(`${e}:${n}`, s) : this.viewMap.set(t, s);
            {
                const r = t[vt];
                r && (s[vt] = {
                    address: Be(r.address, e),
                    len: n
                });
            }
            return s;
        },
        registerView(t) {
            if (!t[vt]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: i, entry: s} = this.findViewAt(e, n, r);
                if (i) return i;
                s ? s.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: null,
                syncExternalBuffer: null
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > On && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let i = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    i = Ee(t, e) - t;
                }
                return this.obtainView(r, Number(i), t);
            }
        }
    });
    const On = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8;
    Qe({
        makeReadOnly(t) {
            Cn(t);
        }
    });
    const Bn = Object.getOwnPropertyDescriptors, $n = Object.defineProperty;
    function Cn(t) {
        const e = t[Vt];
        if (e) kn(e, [ "length" ]); else {
            const e = t[Ot];
            e ? (kn(e), function(t) {
                $n(t, "set", {
                    value: on
                });
                const e = t.get;
                $n(t, "get", {
                    value: function(t) {
                        const n = e.call(this, t);
                        return null === n?.[Rt] && Cn(n), n;
                    }
                });
            }(e)) : kn(t);
        }
    }
    function kn(t, e = []) {
        const n = Bn(t.constructor.prototype);
        for (const [r, i] of Object.entries(n)) i.set && !e.includes(r) && (i.set = on, 
        $n(t, r, i));
        $n(t, Rt, {
            value: t
        });
    }
    function zn() {
        const t = this[Ot] ?? this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Tn(t) {
        const e = be(t), n = this[Ot] ?? this, r = this.length;
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r) {
                    const r = i++;
                    t = [ r, e((() => n.get(r))) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function Fn(t) {
        return {
            [Symbol.iterator]: Tn.bind(this, t),
            length: this.length
        };
    }
    function jn(t) {
        return {
            [Symbol.iterator]: Nn.bind(this, t),
            length: this[Et].length
        };
    }
    function Ln(t) {
        return jn.call(this, t)[Symbol.iterator]();
    }
    function Nn(t) {
        const e = be(t), n = this, r = this[Et];
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r.length) {
                    const o = r[i++];
                    t = [ o, e((() => n[o])) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function Pn(t) {
        return {
            [Symbol.iterator]: Dn.bind(this, t),
            length: this[Et].length
        };
    }
    function _n(t) {
        return Pn.call(this, t)[Symbol.iterator]();
    }
    function Dn(t) {
        const e = be(t), n = this, r = this[Et], i = this[Jt];
        let s = 0;
        return {
            next() {
                let t, o;
                if (s < r.length) {
                    const c = r[s++];
                    t = [ c, e((() => i[c].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function Rn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t[e], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Wn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Zn() {
        return {
            [Symbol.iterator]: Wn.bind(this),
            length: this.length
        };
    }
    function qn(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function Jn(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function Gn(t) {
        return Hn.call(this, t).$;
    }
    function Hn(t) {
        return this[bt][t] ?? this[se](t);
    }
    function Yn(t) {
        const e = Hn.call(this, t).$;
        return e ? e.string : e;
    }
    function Xn(t, e, n) {
        Hn.call(this, t)[le](e, n);
    }
    Qe({
        defineArrayEntries: () => me(Fn),
        defineArrayIterator: () => me(zn)
    }), Qe({
        defineStructEntries: () => me(jn),
        defineStructIterator: () => me(Ln)
    }), Qe({
        defineUnionEntries: () => me(Pn),
        defineUnionIterator: () => me(_n)
    }), Qe({
        defineVectorEntries: () => me(Zn),
        defineVectorIterator: () => me(Rn)
    }), Qe({
        defineZigIterator: () => me(qn)
    }), Qe({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, i = this[`defineMember${W[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${f[e]}`];
                if (n) return n.call(this, i, t);
            }
            return i;
        }
    }), Qe({
        defineBase64(t) {
            const e = this;
            return Pe({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new nn("string", n);
                    const i = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, i, t, !1, r);
                }
            });
        }
    }), Qe({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), Qe({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return Pe({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new nn(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), Qe({
        defineDataView(t) {
            const e = this;
            return Pe({
                get() {
                    const t = this[mt];
                    if (e.usingBufferFallback()) {
                        const n = t.buffer[te];
                        void 0 !== n && e.syncExternalBuffer(t.buffer, n, !1);
                    }
                    return t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new nn("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), Qe({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), Qe({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), Qe({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return Jn(e, {
                get(t) {
                    return this[bt][t].string;
                },
                set: on
            });
        }
    }), Qe({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: on
        })
    }), Qe({
        defineMemberObject: t => Jn(t.slot, {
            get: t.flags & Y ? Yn : t.structure.flags & h ? Gn : Hn,
            set: t.flags & q ? on : Xn
        })
    }), Qe({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: i} = t, s = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return s.call(this[mt], t, n);
                        },
                        set: function(e) {
                            return o.call(this[mt], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return s.call(this[mt], e * i, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[mt], t * i, e, n);
                    }
                };
            }
        }
    }), Qe({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: i}} = t, {get: s} = this.defineMember(r), {get: o} = this.defineMember(n), c = s.call(i, 0), a = !!(r.flags & Z), {runtimeSafety: l} = this;
            return me({
                value: c,
                bytes: i[mt],
                validateValue(e, n, r) {
                    if (a) {
                        if (l && e === c && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== c && n === r - 1) throw new MissingSentinel(t, c, r);
                    }
                },
                validateData(n, r) {
                    if (a) if (l) for (let e = 0; e < r; e++) {
                        const i = o.call(n, e);
                        if (i === c && e !== r - 1) throw new MisplacedSentinel(t, c, e, r);
                        if (i !== c && e === r - 1) throw new MissingSentinel(t, c, r);
                    } else if (r > 0 && r * e === n[mt].byteLength) {
                        if (o.call(n, r - 1) !== c) throw new MissingSentinel(t, c, r);
                    }
                },
                isRequired: a
            });
        },
        imports: {
            findSentinel: null
        }
    }), Qe({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return Pe({
                get() {
                    let t = ve(this.typedArray, r);
                    const e = this.constructor[Ut]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, i) {
                    if ("string" != typeof n) throw new nn("string", n);
                    const s = this.constructor[Ut]?.value;
                    void 0 !== s && n.charCodeAt(n.length - 1) !== s && (n += String.fromCharCode(s));
                    const o = Se(n, r), c = new DataView(o.buffer);
                    e.assignView(this, c, t, !1, i);
                }
            });
        }
    }), Qe({
        defineValueOf: () => ({
            value() {
                return tr(this, !1);
            }
        })
    });
    const Kn = BigInt(Number.MAX_SAFE_INTEGER), Qn = BigInt(Number.MIN_SAFE_INTEGER);
    function tr(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, i = be(r), s = new Map, o = function(t) {
            const c = "function" == typeof t ? e.Struct : t?.constructor?.[At];
            if (void 0 === c) {
                if (n) {
                    if ("bigint" == typeof t && Qn <= t && t <= Kn) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let a = s.get(t);
            if (void 0 === a) {
                let n;
                switch (c) {
                  case e.Struct:
                    n = t[$t](r), a = t.constructor[It] & S.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[$t](r), a = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[$t](), a = [];
                    break;

                  case e.Pointer:
                    try {
                        a = t["*"];
                    } catch (t) {
                        a = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    a = i((() => String(t)));
                    break;

                  case e.Opaque:
                    a = {};
                    break;

                  default:
                    a = i((() => t.$));
                }
                if (a = o(a), s.set(t, a), n) for (const [t, e] of n) a[t] = o(e);
            }
            return a;
        };
        return o(t);
    }
    Qe({
        defineToJSON: () => ({
            value() {
                return tr(this, !0);
            }
        })
    }), Qe({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return Jn(n, {
                get(t) {
                    const e = this[bt][t];
                    return e?.constructor;
                },
                set: on
            });
        }
    }), Qe({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return Pe({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new nn(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), Qe({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), Qe({
        defineMemberUndefined: t => ({
            get: function() {},
            set: on
        })
    }), Qe({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), Qe({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), Qe({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${f[e]}`], i = [], s = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [Rt]: {
                    value: null
                },
                [Gt]: me(s),
                [kt]: me(i),
                [ce]: this.defineCopier(n)
            }, c = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !s[t] && "$" !== t && (s[t] = n, i.push(t));
            }
            return ye(c.prototype, o), c;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: i, align: s, byteSize: o, flags: c, signature: a, static: {members: l, template: u}} = t, h = [], d = {
                name: me(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [ee]: me(a),
                [Wt]: me(this),
                [Dt]: me(s),
                [Pt]: me(o),
                [At]: me(r),
                [It]: me(c),
                [Et]: me(h),
                [Ht]: me(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [$t]: this.defineStructEntries(),
                [Et]: me(h)
            }, g = {
                [Symbol.toStringTag]: me(n)
            };
            for (const t of l) {
                const {name: n, slot: r, flags: i} = t;
                if (t.structure.type === e.Function) {
                    let e = u[bt][r];
                    i & Y && (e[ne] = !0), d[n] = me(e), e.name || pe(e, "name", me(n));
                    const [s, o] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], c = "get" === s ? 0 : 1;
                    if (s && e.length === c) {
                        d[o] ||= {};
                        d[o][s] = e;
                    }
                    if (t.flags & G) {
                        const t = function(...t) {
                            try {
                                return e(this, ...t);
                            } catch (t) {
                                throw t[re]?.(1), t;
                            }
                        };
                        if (ye(t, {
                            name: me(n),
                            length: me(e.length - 1)
                        }), g[n] = me(t), s && t.length === c) {
                            (g[o] ||= {})[s] = t;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[bt] = h.length > 0 && me(u[bt]);
            const p = this[`finalize${f[r]}`];
            !1 !== p?.call(this, t, d, g) && (ye(i.prototype, g), ye(i, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: i, align: s, flags: o, instance: {members: c, template: a}} = t, {onCastError: l} = n;
            let u;
            if (a?.[bt]) {
                const t = c.filter((t => t.flags & q));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, d = function(n, c = {}) {
                const {allocator: g} = c, y = this instanceof d;
                let m, b;
                if (y) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (m = this, o & p && (m[bt] = {}), ae in m) m[le](n, g), b = m[mt]; else {
                        const t = r !== e.Pointer ? g : null;
                        m[mt] = b = h.allocateMemory(i, s, t);
                    }
                } else {
                    if (he in d && (m = d[he].call(this, n, c), !1 !== m)) return m;
                    if (b = h.extractView(t, n, l), m = f.find(b)) return m;
                    m = Object.create(d.prototype), ae in m ? h.assignView(m, b, t, !1, !1) : m[mt] = b, 
                    o & p && (m[bt] = {});
                }
                if (u) for (const t of u) m[bt][t] = a[bt][t];
                return m[ue]?.(), y && (ae in m || m[le](n, g)), fe in m && (m = m[fe]()), f.save(b, m);
            };
            return pe(d, Nt, me(f)), d;
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const i = Object.keys(n), s = this[kt], o = this[Gt];
                for (const e of i) if (!(e in o)) throw new NoProperty(t, e);
                let c = 0, a = 0, l = 0, u = 0;
                for (const t of s) {
                    const e = o[t];
                    e.special ? t in n && u++ : (c++, t in n ? a++ : e.required && l++);
                }
                if (0 !== l && 0 === u) {
                    const e = s.filter((t => o[t].required && !(t in n)));
                    throw new MissingInitializers(t, e);
                }
                if (u + a > i.length) for (const t of s) t in n && (i.includes(t) || i.push(t));
                a < c && 0 === u && e && e[mt] && this[ce](e);
                for (const t of i) {
                    o[t].call(this, n[t], r);
                }
                return i.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) {
                const [t] = r.members;
                switch (n) {
                  case e.Enum:
                  case e.ErrorSet:
                  case e.Primitive:
                    {
                        const {byteSize: e, type: n} = t;
                        return globalThis[(e > 4 && n !== R.Float ? "Big" : "") + (n === R.Float ? "Float" : n === R.Int ? "Int" : "Uint") + 8 * e + "Array"];
                    }

                  case e.Array:
                  case e.Slice:
                  case e.Vector:
                    return this.getTypedArray(t.structure);
                }
            }
        }
    }), Qe({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: i, length: s, instance: {members: o}} = t, c = this, a = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = c.allocateMemory(r, i)) : (u = Object.create(l.prototype), 
                f = t), u[mt] = f, n & p && (u[bt] = {}), !o) return u;
                {
                    let r;
                    if (n & P && t.length === s + 1 && (r = t.pop()), t.length !== s) throw new ArgumentCountMismatch(s, t.length);
                    n & D && (u[fe] = null), c.copyArguments(u, t, a, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = me(a.length), e[se] = n & d && this.defineVivificatorStruct(t), 
            e[oe] = n & g && this.defineVisitorArgStruct(o), e[de] = me((function(t) {
                u.call(this, t, this[Qt]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(a), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[Yt] = me(!!(n & _));
        }
    }), Qe({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                const n = new Proxy(this, er);
                return ye(this, {
                    [Lt]: {
                        value: n
                    },
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), n;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, i = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, s = this[mt], o = s.byteOffset + n * t, c = i.obtainView(s.buffer, o, n);
                    return this[bt][t] = e.call(wt, c);
                }
            };
        }
    });
    const er = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : e === Ot ? t : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length", Lt), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    };
    Qe({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: i} = t, s = this.createApplier(t), o = this.defineMember(r), {set: c} = o, a = this.createConstructor(t), l = function(e, r) {
                if (Te(e, a)) this[ce](e), i & g && this[oe]("copy", tt.Vivificate, e); else if ("string" == typeof e && i & b && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = $e(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) c.call(this, i++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            };
            return e.$ = {
                get: Re,
                set: l
            }, e.length = me(n), e.entries = e[$t] = this.defineArrayEntries(), i & w && (e.typedArray = this.defineTypedArray(t), 
            i & b && (e.string = this.defineString(t)), i & v && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[le] = me(l), e[fe] = this.defineFinalizerArray(o), 
            e[se] = i & d && this.defineVivificatorArray(t), e[oe] = i & g && this.defineVisitorArray(), 
            a;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = me(r.structure.constructor), e[Ut] = n & m && this.defineSentinel(t);
        }
    }), Qe({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: i, set: s} = r, {get: o} = this.defineMember(n, !1), c = this.createApplier(t), a = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, a, e);
                }
            });
            return e.$ = r, e.toString = me(We), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[St];

                      default:
                        return o.call(this);
                    }
                }
            }, e[le] = me((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === c.call(this, e)) throw new InvalidInitializer(t, a, e);
                } else void 0 !== e && s.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [i]}, static: {members: s, template: o}} = t, c = o[bt], {get: a, set: l} = this.defineMember(i, !1), u = {};
            for (const {name: t, flags: n, slot: r} of s) if (n & J) {
                const n = c[r];
                pe(n, St, me(t));
                const i = a.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[i] = n;
            }
            e[he] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & M) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            pe(e, St, me(n)), pe(r, n, me(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[Mt] instanceof r && t[Mt];
                }
            }, e[Ht] = me(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === R.Object) return t;
            const i = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    t = i(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), Qe({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: i, flags: s} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: j,
                    byteSize: i,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && s & j) return this.globalErrorSet;
            const o = this.defineMember(r), {set: c} = o, a = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, a, e);
                }
            });
            return n.$ = o, n[le] = me((function(e) {
                if (e instanceof u[xt]) c.call(this, e); else if (e && "object" == typeof e && !un(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, a, e);
                } else void 0 !== e && c.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [i]}, static: {members: s, template: o}} = t;
            if (this.globalErrorSet && r & j) return !1;
            const c = o?.[bt] ?? {}, a = r & j ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(i, !1);
            for (const {name: t, slot: n} of s) {
                const r = c[n], i = l.call(r);
                let s = this.globalItemsByIndex[i];
                const o = !!s;
                s || (s = new this.ZigError(t, i));
                const u = me(s);
                e[t] = u;
                const f = `${s}`;
                e[f] = u, a[i] = s, o || (ye(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[Et].push(t), this.globalItemsByIndex[i] = s);
            }
            e[he] = {
                value: t => "number" == typeof t ? a[t] : "string" == typeof t ? n[t] : t instanceof n[xt] ? a[Number(t)] : un(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[xt] = me(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === R.Object) return t;
            const i = t => {
                const {constructor: e, flags: n} = r, i = e(t);
                if (!i) {
                    if (n & j && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, pe(this.globalErrorSet, `${e}`, me(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r) : new ErrorExpected(r, t);
                }
                return i;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = i(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function nr(t, e) {
        return ze(t?.constructor?.child, e) && t["*"];
    }
    function rr(t, e, n) {
        if (n & U) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & O && nr(t, e.child)) return !0;
        }
        return !1;
    }
    Qe({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: c, set: a} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), f = n.type === R.Void, h = r.structure.constructor, p = function() {
                this[ie](), this[oe]?.("clear");
            }, y = this.createApplier(t), m = function(t, e) {
                if (Te(t, v)) this[ce](t), i & g && (l.call(this) || this[oe]("copy", 0, t)); else if (t instanceof h[xt] && h(t)) a.call(this, t), 
                p.call(this); else if (void 0 !== t || f) try {
                    o.call(this, t, e), u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = h(t) ?? h.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure);
                        a.call(this, e), p.call(this);
                    } else if (un(t)) a.call(this, t), p.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === y.call(this, t)) throw e;
                    }
                }
            }, {bitOffset: b, byteSize: w} = n, v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw c.call(this);
                    return s.call(this);
                },
                set: m
            }, e[le] = me(m), e[se] = i & d && this.defineVivificatorStruct(t), e[ie] = this.defineResetter(b / 8, w), 
            e[oe] = i & g && this.defineVisitorErrorUnion(n, l), v;
        }
    }), Qe({
        defineFunction(t, n) {
            const {instance: {members: [r], template: i}, static: {template: s}} = t, o = new ObjectCache, {structure: {constructor: c}} = r, a = this, l = function(n) {
                const r = this instanceof l;
                let u, f;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new nn("function", n);
                    if (c[At] === e.VariadicStruct || !s) throw new Unsupported;
                    u = a.getFunctionThunk(n, s);
                } else {
                    if (this !== Wt) throw new NoCastingToFunction;
                    u = n;
                }
                if (f = o.find(u)) return f;
                const h = c.prototype.length, d = r ? a.createInboundCaller(n, c) : a.createOutboundCaller(i, c);
                return ye(d, {
                    length: me(h),
                    name: me(r ? n.name : "")
                }), Object.setPrototypeOf(d, l.prototype), d[mt] = u, o.save(u, d), d;
            };
            return Object.setPrototypeOf(l.prototype, Function.prototype), n.valueOf = n.toJSON = me(De), 
            l;
        },
        finalizeFunction(t, e, n) {
            n[Symbol.toStringTag] = void 0;
        }
    }), Qe({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, i = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[le] = me((() => {
                throw new CreatingOpaque(t);
            })), i;
        }
    }), Qe({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: c, set: a} = this.defineMember(r), l = n.type === R.Void, u = function(t, e) {
                Te(t, f) ? (this[ce](t), i & g && c.call(this) && this[oe]("copy", tt.Vivificate, t)) : null === t ? (a.call(this, 0), 
                this[ie]?.(), this[oe]?.("clear")) : (void 0 !== t || l) && (o.call(this, t, e), 
                i & E ? a.call(this, 1) : i & g && (c.call(this) || a.call(this, 13)));
            }, f = t.constructor = this.createConstructor(t), {bitOffset: h, byteSize: p} = n;
            return e.$ = {
                get: function() {
                    return c.call(this) ? s.call(this) : (this[oe]?.("clear"), null);
                },
                set: u
            }, e[le] = me(u), e[ie] = i & E && this.defineResetter(h / 8, p), e[se] = i & d && this.defineVivificatorStruct(t), 
            e[oe] = i & g && this.defineVisitorOptional(n, c), f;
        }
    }), Qe({
        definePointer(t, n) {
            const {flags: r, byteSize: i, instance: {members: [s]}} = t, {structure: o} = s, {type: c, flags: a, byteSize: l = 1} = o, u = r & V ? i / 2 : i, {get: f, set: d} = this.defineMember({
                type: R.Uint,
                bitOffset: 0,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    byteSize: u
                }
            }), {get: g, set: p} = r & V ? this.defineMember({
                type: R.Uint,
                bitOffset: 8 * u,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    flags: y,
                    byteSize: u
                }
            }) : {}, m = function(t, n = !0, i = !0) {
                if (n || this[mt][vt]) {
                    if (!i) return this[bt][0] = void 0;
                    {
                        const n = E.child, i = f.call(this), s = r & V ? g.call(this) : c === e.Slice && a & C ? x.findSentinel(i, n[Ut].bytes) + 1 : 1;
                        if (i !== this[Ft] || s !== this[jt]) {
                            const e = x.findMemory(t, i, s, n[Pt]), o = e ? n.call(Wt, e) : null;
                            return this[bt][0] = o, this[Ft] = i, this[jt] = s, r & V && (this[Ct] = null), 
                            o;
                        }
                    }
                }
                return this[bt][0];
            }, b = function(t) {
                d.call(this, t), this[Ft] = t;
            }, w = a & C ? 1 : 0, v = r & V || a & C ? function(t) {
                p?.call?.(this, t - w), this[jt] = t;
            } : null, S = function() {
                const t = this[Vt] ?? this, e = !t[bt][0], n = m.call(t, null, e);
                if (!n) {
                    if (r & $) return null;
                    throw new NullPointer;
                }
                return r & B ? sr(n) : n;
            }, A = a & h ? function() {
                return S.call(this).$;
            } : S, I = r & B ? on : function(t) {
                return S.call(this).$ = t;
            }, x = this, M = function(n, i) {
                const s = o.constructor;
                if (nr(n, s)) {
                    if (!(r & B) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[bt][0];
                } else if (r & U) rr(n, s, r) && (n = s(n[bt][0][mt])); else if (c === e.Slice && a & F && n) if (n.constructor[At] === e.Pointer) n = n[Bt]?.[mt]; else if (n[mt]) n = n[mt]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof s) {
                    const e = n[Rt];
                    if (e) {
                        if (!(r & B)) throw new ReadOnlyTarget(t);
                        n = e;
                    }
                } else if (Te(n, s)) n = s.call(Wt, n[mt]); else if (r & O && r & U && n instanceof s.child) n = s(n[mt]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[Ht];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== Ce(t, e.child)) return !0;
                    }
                    return !1;
                }(n, s)) {
                    n = s(x.extractView(o, n));
                } else if (null == n || n[mt]) {
                    if (!(void 0 === n || r & $ && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & O && r & U && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = s.prototype[Gt];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (Ht in s && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    n = new s(n, {
                        allocator: i
                    });
                }
                const l = n?.[mt]?.[vt];
                if (l?.address === Ue) throw new PreviouslyFreed(n);
                this[Bt] = n;
            }, E = this.createConstructor(t);
            return n["*"] = {
                get: A,
                set: I
            }, n.$ = {
                get: Re,
                set: M
            }, n.length = {
                get: function() {
                    const t = S.call(this);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = S.call(this);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[mt], i = n[vt];
                    let s;
                    if (!i) if (r & V) this[Ct] ||= e.length, s = this[Ct]; else {
                        s = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > s) throw new InvalidSliceLength(t, s);
                    const c = t * l, a = i ? x.obtainZigView(i.address, c) : x.obtainView(n.buffer, n.byteOffset, c), u = o.constructor;
                    this[bt][0] = u.call(Wt, a), v?.call?.(this, t);
                }
            }, n.slice = c === e.Slice && {
                value(t, e) {
                    const n = this[Bt].slice(t, e);
                    return new E(n);
                }
            }, n.subarray = c === e.Slice && {
                value(t, e, n) {
                    const r = this[Bt].subarray(t, e, n);
                    return new E(r);
                }
            }, n[Symbol.toPrimitive] = c === e.Primitive && {
                value(t) {
                    return this[Bt][Symbol.toPrimitive](t);
                }
            }, n[le] = me(M), n[fe] = {
                value() {
                    const t = c !== e.Pointer ? or : {};
                    let n;
                    c === e.Function ? (n = function() {}, n[mt] = this[mt], n[bt] = this[bt], Object.setPrototypeOf(n, E.prototype)) : n = this;
                    const r = new Proxy(n, t);
                    return Object.defineProperty(n, Lt, {
                        value: r
                    }), r;
                }
            }, n[Bt] = {
                get: S,
                set: function(t) {
                    if (void 0 === t) return;
                    const e = this[Vt] ?? this;
                    if (t) {
                        const n = t[mt][vt];
                        if (n) {
                            const {address: e, js: r} = n;
                            b.call(this, e), v?.call?.(this, t.length), r && (t[mt][vt] = void 0);
                        } else if (e[mt][vt]) throw new ZigMemoryTargetRequired;
                    } else e[mt][vt] && (b.call(this, 0), v?.call?.(this, 0));
                    e[bt][0] = t ?? null, r & V && (e[Ct] = null);
                }
            }, n[re] = me(m), n[zt] = {
                set: b
            }, n[Tt] = {
                set: v
            }, n[oe] = this.defineVisitor(), n[Ft] = me(0), n[jt] = me(0), n[Ct] = r & V && me(null), 
            n.dataView = n.base64 = void 0, E;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: i, instance: {members: [s]}} = t, {structure: o} = s, {type: c, constructor: a} = o;
            n.child = a ? me(a) : {
                get: () => o.constructor
            }, n.const = me(!!(r & B)), n[he] = {
                value(n, s) {
                    if (this === Wt || this === wt || n instanceof i) return !1;
                    if (nr(n, a)) return new i(a(n["*"]), s);
                    if (rr(n, a, r)) return new i(n);
                    if (c === e.Slice) return new i(a(n), s);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    });
    const ir = new WeakMap;
    function sr(t) {
        let e = ir.get(t);
        if (!e) {
            const n = t[Vt];
            e = n ? new Proxy(n, cr) : new Proxy(t, ar), ir.set(t, e);
        }
        return e;
    }
    const or = {
        get(t, e) {
            if (e === Vt) return t;
            if (e in t) return t[e];
            return t[Bt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[Bt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[Bt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[Bt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, cr = {
        ...or,
        set(t, e, n) {
            if (e in t) on(); else {
                t[Bt][e] = n;
            }
            return !0;
        }
    }, ar = {
        get(t, e) {
            if (e === Rt) return t;
            {
                const n = t[e];
                return n?.[mt] ? sr(n) : n;
            }
        },
        set(t, e, n) {
            on();
        }
    };
    function lr() {
        return this[Tt];
    }
    function ur(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function fr() {
        throw new InaccessiblePointer;
    }
    function hr() {
        const t = {
            get: fr,
            set: fr
        };
        ye(this[Vt], {
            "*": t,
            $: t,
            [Vt]: t,
            [Bt]: t
        });
    }
    function dr(t, e, n, r) {
        let i, s = this[bt][t];
        if (!s) {
            if (n & tt.IgnoreUncreated) return;
            s = this[se](t);
        }
        r && (i = r[bt][t], !i) || s[oe](e, n, i);
    }
    Qe({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: i, set: s} = this.defineMember(n), o = function(e) {
                if (Te(e, c)) this[ce](e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = we(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && s.call(this, e);
            }, c = this.createConstructor(t);
            return e.$ = {
                get: i,
                set: o
            }, e[le] = me(o), e[Symbol.toPrimitive] = me(i), c;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[_t] = me(n.bitSize), e[qt] = me(n.type);
        }
    }), Qe({
        defineSlice(t, e) {
            const {align: n, flags: r, byteSize: i, name: s, instance: {members: [o]}} = t, {byteSize: c, structure: a} = o, l = this, u = function(t, e, r) {
                t || (t = l.allocateMemory(e * c, n, r)), this[mt] = t, this[Tt] = e;
            }, f = function(e, n) {
                if (n !== this[Tt]) throw new ArrayLengthMismatch(t, this, e);
            }, h = this.defineMember(o), {set: p} = h, y = this.createApplier(t), m = function(e, n) {
                if (Te(e, w)) this[mt] ? f.call(this, e, e.length) : u.call(this, null, e.length, n), 
                this[ce](e), r & g && this[oe]("copy", tt.Vivificate, e); else if ("string" == typeof e && r & k) m.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = $e(e), this[mt] ? f.call(this, e, e.length) : u.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) w[Ut]?.validateValue(r, t, e.length), p.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[mt] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[mt]);
                    u.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === y.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, b = function(t, e) {
                const n = this[Tt], r = this[mt];
                t = void 0 === t ? 0 : ur(t, n), e = void 0 === e ? n : ur(e, n);
                const i = t * c, s = e * c - i;
                return l.obtainView(r.buffer, r.byteOffset + i, s);
            }, w = this.createConstructor(t);
            return e.$ = {
                get: Re,
                set: m
            }, e.length = {
                get: lr
            }, r & z && (e.typedArray = this.defineTypedArray(t), r & k && (e.string = this.defineString(t)), 
            r & T && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[$t] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = b.call(this, t, e);
                    return w(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: i = !1} = r, s = b.call(this, t, e), o = l.allocateMemory(s.byteLength, n, i), c = w(o);
                    return c[ce]({
                        [mt]: s
                    }), c;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[ae] = me(u), e[ce] = this.defineCopier(i, !0), 
            e[le] = me(m), e[fe] = this.defineFinalizerArray(h), e[se] = r & d && this.defineVivificatorArray(t), 
            e[oe] = r & g && this.defineVisitorArray(), w;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = me(r.structure.constructor), e[Ut] = n & C && this.defineSentinel(t);
        }
    }), Qe({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === R.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: i, byteSize: s, structure: {constructor: o}} = e, c = this[mt], a = c.byteOffset + (i >> 3);
                    let l = s;
                    if (void 0 === l) {
                        if (7 & i) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(c.buffer, a, l);
                    return this[bt][t] = o.call(wt, u);
                }
            };
        }
    }), Qe({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: i, instance: {members: c}} = t, a = c.find((t => t.flags & H)), l = a && this.defineMember(a), u = this.createApplier(t), f = function(e, n) {
                if (Te(e, h)) this[ce](e), r & g && this[oe]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            }, h = this.createConstructor(t), p = e[Gt].value, y = e[kt].value, m = [];
            for (const t of c.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: i} = e[n] = this.defineMember(t);
                i && (r & Z && (i.required = !0), p[n] = i, y.push(n)), m.push(n);
            }
            return e.$ = {
                get: De,
                set: f
            }, e.length = me(i), e.entries = r & S.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & S.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[le] = me(f), e[se] = r & d && this.defineVivificatorStruct(t), e[oe] = r & g && this.defineVisitorStruct(c), 
            e[$t] = r & S.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[Et] = me(m), n === s && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), h;
        }
    }), Qe({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: i}} = t, s = !!(r & A), c = s ? i.slice(0, -1) : i, a = s ? i[i.length - 1] : null, {get: l, set: u} = this.defineMember(a), {get: f} = this.defineMember(a, !1), h = r & I ? function() {
                return l.call(this)[St];
            } : function() {
                const t = l.call(this);
                return c[t].name;
            }, p = r & I ? function(t) {
                const {constructor: e} = a.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = c.findIndex((e => e.name === t));
                u.call(this, e);
            }, y = this.createApplier(t), m = function(e, n) {
                if (Te(e, b)) this[ce](e), r & g && this[oe]("copy", tt.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of M) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === y.call(this, e, n)) throw new MissingUnionInitializer(t, e, s);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            }, b = this.createConstructor(t), w = {}, v = e[Gt].value, S = e[kt].value, M = [];
            for (const n of c) {
                const {name: i} = n, {get: o, set: c} = this.defineMember(n), a = s ? function() {
                    const e = h.call(this);
                    if (i !== e) {
                        if (r & I) return null;
                        throw new InactiveUnionProperty(t, i, e);
                    }
                    return this[oe]?.("clear"), o.call(this);
                } : o, l = s && c ? function(e) {
                    const n = h.call(this);
                    if (i !== n) throw new InactiveUnionProperty(t, i, n);
                    c.call(this, e);
                } : c, u = s && c ? function(t) {
                    p.call(this, i), c.call(this, t), this[oe]?.("clear");
                } : c;
                e[i] = {
                    get: a,
                    set: l
                }, v[i] = u, w[i] = o, S.push(i), M.push(i);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: m
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & I && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return h.call(this);

                      default:
                        return f.call(this);
                    }
                }
            };
            const {comptime: E} = this;
            return e[ue] = r & x && {
                value() {
                    return E || this[oe](hr), this[oe] = Ze, this;
                }
            }, e[le] = me(m), e[Mt] = r & I && {
                get: l,
                set: u
            }, e[se] = r & d && this.defineVivificatorStruct(t), e[oe] = r & g && this.defineVisitorUnion(c, r & I ? f : null), 
            e[$t] = this.defineUnionEntries(), e[Et] = r & I ? {
                get() {
                    return [ h.call(this) ];
                }
            } : me(M), e[Jt] = me(w), b;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & I && (e.tag = me(r[r.length - 1].structure.constructor));
        }
    }), Qe({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: i, length: s, instance: {members: o}} = t, c = this, a = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[mt] = c.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = c.littleEndian;
            };
            return ye(u, {
                [Dt]: {
                    value: 4
                }
            }), ye(u.prototype, {
                set: me((function(t, e, n, r, i) {
                    const s = this[mt], o = c.littleEndian;
                    s.setUint16(8 * t, e, o), s.setUint16(8 * t + 2, n, o), s.setUint16(8 * t + 4, r, o), 
                    s.setUint8(8 * t + 6, i == R.Float), s.setUint8(8 * t + 7, i == R.Int || i == R.Float);
                }))
            }), e[se] = i & d && this.defineVivificatorStruct(t), e[oe] = this.defineVisitorVariadicStruct(o), 
            e[de] = me((function(t) {
                l.call(this, t, this[Qt]);
            })), function(t) {
                if (t.length < s) throw new ArgumentCountMismatch(s, t.length, !0);
                let e = n, i = r;
                const o = t.slice(s), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[mt], o = n?.constructor?.[Dt];
                    if (!r || !o) {
                        throw rn(new InvalidVariadicArgument, s + t);
                    }
                    o > i && (i = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = c.allocateMemory(e, i);
                h[Dt] = i, this[mt] = h, this[bt] = {}, c.copyArguments(this, t, a);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: i, structure: {align: s}}] of a.entries()) f.set(t, e / 8, n, s, r), 
                i > d && (d = i);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[mt], i = l[t], o = c.obtainView(h.buffer, i, r), a = this[bt][n] = e.constructor.call(wt, o), u = e.constructor[_t] ?? 8 * r, g = e.constructor[Dt], p = e.constructor[qt];
                    a.$ = e, f.set(s + t, i, u, g, p);
                }
                this[Zt] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[Yt] = me(!!(n & _)), e[Dt] = me(void 0);
        }
    }), Qe({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [i]}} = t, s = this.createApplier(t), o = function(e) {
                if (Te(e, c)) this[ce](e), n & g && this[oe]("copy", tt.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) this[i++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, c = this.createConstructor(t, {
                initializer: o
            }), {bitSize: a} = i;
            for (let t = 0, s = 0; t < r; t++, s += a) e[t] = n & g ? this.defineMember({
                ...i,
                slot: t
            }) : this.defineMember({
                ...i,
                bitOffset: s
            });
            return e.$ = {
                get: De,
                set: o
            }, e.length = me(r), n & L && (e.typedArray = this.defineTypedArray(t), n & N && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[$t] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[le] = me(o), e[se] = n & d && this.defineVivificatorArray(t), e[oe] = n & g && this.defineVisitorArray(), 
            c;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = me(n.structure.constructor);
        }
    }), Qe({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? gr[t] : t, r.call(this, e, n);
            }
        })
    });
    const gr = {
        copy(t, e) {
            const n = e[bt][0];
            if (this[mt][vt] && n && !n[mt][vt]) throw new ZigMemoryTargetRequired;
            this[bt][0] = n;
        },
        clear(t) {
            t & tt.IsInactive && (this[bt][0] = void 0);
        },
        reset() {
            this[bt][0] = void 0, this[Ft] = void 0;
        }
    };
    return Qe({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: i, structure: s}] of t.entries()) s.flags & g && (0 === r ? n = i : e.push(i));
            return {
                value(t, r, i) {
                    if (!(r & tt.IgnoreArguments) && e.length > 0) for (const n of e) dr.call(this, n, t, r | tt.IsImmutable, i);
                    r & tt.IgnoreRetval || void 0 === n || dr.call(this, n, t, r, i);
                }
            };
        }
    }), Qe({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, i = this.length; r < i; r++) dr.call(this, r, t, e, n);
            }
        })
    }), Qe({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) && (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || dr.call(this, n, t, r, i);
                }
            };
        }
    }), Qe({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) || (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || dr.call(this, n, t, r, i);
                }
            };
        }
    }), Qe({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & g)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const i of e) dr.call(this, i, t, n, r);
                }
            };
        }
    }), Qe({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: i}] of t.entries()) i?.flags & g && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, i) {
                    const s = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== s && (n |= tt.IsInactive), n & tt.IsInactive && n & tt.IgnoreInactive || dr.call(this, o, t, n, i);
                    }
                }
            };
        }
    }), Qe({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & g ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & tt.IgnoreArguments)) for (const [i, s] of Object.entries(this[bt])) i !== n && oe in s && dr.call(this, i, t, e | tt.IsImmutable, r);
                    e & tt.IgnoreRetval || void 0 === n || dr.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (tn());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
