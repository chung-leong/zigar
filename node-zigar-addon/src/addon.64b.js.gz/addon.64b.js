(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, i = 3, s = 4, o = 5, c = 6, a = 7, l = Object.keys(e), u = 1, f = 2, h = 4, d = 8, g = 16, p = 16, b = 32, y = 64, m = 128, w = {
        IsExtern: 16,
        IsPacked: 32,
        IsTuple: 64,
        IsOptional: 128
    }, v = 16, S = 32, A = 64, I = 16, x = 16, M = 16, V = 32, E = 64, O = 128, C = 256, $ = 16, T = 32, U = 64, z = 128, B = 256, F = 16, k = 16, j = 32, N = 16, P = 32, L = 64, D = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, R = Object.keys(D), Z = 1, J = 2, q = 4, _ = 16, G = 64, W = 128, Y = 0, H = 1, X = 2, K = 1, Q = 2, tt = 4, et = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, nt = globalThis[Symbol.for("ZIGAR")] ||= {};
    function rt(t) {
        return nt[t] ||= Symbol(t);
    }
    function it(t) {
        return rt(t);
    }
    const st = it("memory"), ot = it("slots"), ct = it("parent"), at = it("zig"), lt = it("name"), ut = it("type"), ft = it("flags"), ht = it("class"), dt = it("tag"), gt = it("props"), pt = it("pointer"), bt = it("sentinel"), yt = it("array"), mt = it("target"), wt = it("entries"), vt = it("max length"), St = it("keys"), At = it("address"), It = it("length"), xt = it("last address"), Mt = it("last length"), Vt = it("proxy"), Et = it("cache"), Ot = it("size"), Ct = it("bit size"), $t = it("align"), Tt = it("const target"), Ut = it("environment"), zt = it("attributes"), Bt = it("primitive"), Ft = it("getters"), kt = it("setters"), jt = it("typed array"), Nt = it("throwing"), Pt = it("promise"), Lt = it("generator"), Dt = it("allocator"), Rt = it("fallback"), Zt = it("signature"), Jt = it("string retval"), qt = it("update"), _t = it("reset"), Gt = it("vivificate"), Wt = it("visit"), Yt = it("copy"), Ht = it("shape"), Xt = it("initialize"), Kt = it("restrict"), Qt = it("finalize"), te = it("cast"), ee = it("return"), ne = it("yield");
    function re(t, e, n) {
        if (n) {
            const {set: r, get: i, value: s, enumerable: o, configurable: c = !0, writable: a = !0} = n;
            Object.defineProperty(t, e, i || r ? {
                get: i,
                set: r,
                configurable: c,
                enumerable: o
            } : {
                value: s,
                configurable: c,
                enumerable: o,
                writable: a
            });
        }
        return t;
    }
    function ie(t, e) {
        for (const [n, r] of Object.entries(e)) re(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            re(t, n, e[n]);
        }
        return t;
    }
    function se(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function oe(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function ce({type: t, bitSize: e}) {
        switch (t) {
          case D.Bool:
            return "boolean";

          case D.Int:
          case D.Uint:
            if (e > 32) return "bigint";

          case D.Float:
            return "number";
        }
    }
    function ae(t, e = "utf-8") {
        const n = ue[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let i = 0;
            for (const e of t) r.set(e, i), i += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function le(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (fe[e] ||= new TextEncoder).encode(t);
    }
    const ue = {}, fe = {};
    function he(t, e, n) {
        let r = 0, i = t.length;
        if (0 === i) return 0;
        for (;r < i; ) {
            const s = Math.floor((r + i) / 2);
            n(t[s]) <= e ? r = s + 1 : i = s;
        }
        return i;
    }
    const de = function(t, e) {
        return !!e && !!(t & BigInt(e - 1));
    }, ge = function(t, e) {
        return t + BigInt(e - 1) & ~BigInt(e - 1);
    }, pe = 0xFFFFFFFFFFFFFFFFn, be = -1n, ye = function(t) {
        return BigInt(t);
    }, me = function(t, e) {
        return t + BigInt(e);
    };
    function we(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function ve(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function Se(t, e) {
        const n = [], r = new Map, i = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) i(n);
        };
        for (const e of t) i(e.instance.template), i(e.static.template);
        return n;
    }
    function Ae(t, e) {
        return t === e || t?.[Zt] === e[Zt] && t?.[Ut] !== e?.[Ut];
    }
    function Ie(t, e) {
        return t instanceof e || Ae(t?.constructor, e);
    }
    function xe({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function Me() {
        return this;
    }
    function Ve() {
        return this[Vt];
    }
    function Ee() {
        return String(this);
    }
    function Oe() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return this.map.get(t);
        }
        save(t, e) {
            return this.map.set(t, e), e;
        }
    }
    const Ce = {
        name: "",
        mixins: []
    };
    function $e(t) {
        return Ce.mixins.includes(t) || Ce.mixins.push(t), t;
    }
    function Te() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: i} = r;
            re(r, "name", se(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = i[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                re(i, e, se(r));
            }
            return r;
        }(Ce.name, Ce.mixins);
    }
    function Ue(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, i) {
                const s = n.getUint8(i) >> t & r;
                e.setUint8(0, s);
            };
            {
                const e = 255 ^ r << t;
                return function(n, i, s) {
                    const o = i.getUint8(0), c = n.getUint8(s) & e | (o & r) << t;
                    n.setUint8(s, c);
                };
            }
        }
        {
            const r = 8 - t, i = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(s, o, c) {
                    let a, l = c, u = 0, f = o.getUint8(l++), h = f >> t & i, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), a = g >= 8 ? 255 & h : h & n, s.setUint8(u++, a), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, s = 255 ^ i << t, o = 255 ^ n;
                return function(r, i, c) {
                    let a, l, u = 0, f = c, h = r.getUint8(f), d = h & s, g = t, p = e + g;
                    do {
                        p > g && (a = i.getUint8(u++), d |= a << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    $e({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: i, byteSize: s} = e, o = [], c = void 0 === s && (7 & r || 7 & i);
            c && o.push("Unaligned");
            let a = R[n];
            r > 32 && (n === D.Int || n === D.Uint) && (a = r <= 64 ? `Big${a}` : `Jumbo${a}`), 
            o.push(a, `${n === D.Bool && s ? 8 * s : r}`), c && o.push(`@${i}`);
            const l = t + o.join("");
            let u = DataView.prototype[l];
            if (u && this.usingBufferFallback()) {
                const e = this, i = u, s = function(t) {
                    const {buffer: e, byteOffset: n, byteLength: i} = this, s = e[Rt];
                    if (s) {
                        if (t < 0 || t + r / 8 > i) throw new RangeError("Offset is outside the bounds of the DataView");
                        return s + ye(n + t);
                    }
                };
                u = "get" === t ? function(t, o) {
                    const c = s.call(this, t);
                    return void 0 !== c ? e.getNumericValue(n, r, c) : i.call(this, t, o);
                } : function(t, o, c) {
                    const a = s.call(this, t);
                    return void 0 !== a ? e.setNumericValue(n, r, a, o) : i.call(this, t, o, c);
                };
            }
            if (u) return u;
            if (u = this.accessorCache.get(l), u) return u;
            for (;o.length > 0; ) {
                const n = `getAccessor${o.join("")}`;
                if (u = this[n]?.(t, e)) break;
                o.pop();
            }
            if (!u) throw new Error(`No accessor available: ${l}`);
            return re(u, "name", se(l)), this.accessorCache.set(l, u), u;
        },
        imports: {
            getNumericValue: null,
            setNumericValue: null
        }
    }), $e({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), i = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & i) - (n & r);
            } : function(t, e, n) {
                const s = e < 0 ? r | e & i : e & i;
                this.setBigUint64(t, s, n);
            };
        }
    }), $e({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const i = e & r;
                this.setBigUint64(t, i, n);
            };
        }
    }), $e({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, i = this.getAccessor(t, {
                type: D.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!i.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, s) {
                    i.call(this, n, r ? e : t, s);
                };
            }
        }
    }), $e({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = new DataView(new ArrayBuffer(8)), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, c = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(c), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, c = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = c ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return c ? NaN : s ? -1 / 0 : 1 / 0;
                const a = o - 16383n + 1023n;
                if (a >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | a << 52n | (c >> 60n) + BigInt((c & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, c = (0x7ff0000000000000n & i) >> 52n, a = 0x000fffffffffffffn & i;
                let l;
                l = 0n === c ? o << 127n | a << 60n : 0x07ffn === c ? o << 127n | 0x7fffn << 112n | (a ? 1n : 0n) : o << 127n | c - 1023n + 16383n << 112n | a << 60n, 
                s.call(this, t, l, n);
            };
        }
    }), $e({
        getAccessorFloat16(t, e) {
            const n = new DataView(new ArrayBuffer(4)), r = DataView.prototype.setUint16, i = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = i.call(this, t, e), s = r >>> 15, o = (31744 & r) >> 10, c = 1023 & r;
                if (0 === o) return s ? -0 : 0;
                if (31 === o) return c ? NaN : s ? -1 / 0 : 1 / 0;
                const a = s << 31 | o - 15 + 127 << 23 | c << 13;
                return n.setUint32(0, a, e), n.getFloat32(0, e);
            } : function(t, e, i) {
                n.setFloat32(0, e, i);
                const s = n.getUint32(0, i), o = s >>> 31, c = (2139095040 & s) >> 23, a = 8388607 & s, l = c - 127 + 15;
                let u;
                u = 0 === c ? o << 15 : 255 === c ? o << 15 | 31744 | (a ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | a >> 13, 
                r.call(this, t, u, i);
            };
        }
    }), $e({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = new DataView(new ArrayBuffer(8)), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, c = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = c ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return c ? NaN : s ? -1 / 0 : 1 / 0;
                const a = o - 16383n + 1023n;
                if (a >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | a << 52n | (c >> 11n) + BigInt((c & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, c = (0x7ff0000000000000n & i) >> 52n, a = 0x000fffffffffffffn & i;
                let l;
                l = 0n === c ? o << 79n | a << 11n : 0x07ffn === c ? o << 79n | 0x7fffn << 64n | (a ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | c - 1023n + 16383n << 64n | a << 11n | 0x00008000000000000000n, 
                s.call(this, t, l, n);
            };
        }
    }), $e({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: D.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), i = 2 ** (n - 1), s = i - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & s) - (r & i);
                } : function(t, n, r) {
                    const o = n < 0 ? i | n & s : n & s;
                    e.call(this, t, o, r);
                };
            }
        }
    }), $e({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n - 1), s = i - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & s) - (n & i);
            } : function(t, e, n) {
                const o = e < 0 ? i | e & s : e & s;
                r.call(this, t, o, n);
            };
        }
    }), $e({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & i;
            } : function(t, e, n) {
                const s = e & i;
                r.call(this, t, s, n);
            };
        }
    }), $e({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let i = 0, s = t + 8 * (n - 1); i < n; i++, s -= 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                } else for (let i = 0, s = t; i < n; i++, s += 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                }
                return r;
            } : function(t, e, r) {
                let i = e;
                const s = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                }
            };
        }
    }), $e({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const i = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), s = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return i.call(this, t, e) & s;
                } : function(t, e, n) {
                    const r = e & s;
                    i.call(this, t, r, n);
                };
            }
        }
    }), $e({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), i = e ? n | r : n & ~r;
                this.setInt8(t, i);
            };
        }
    }), $e({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> i;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << i;
                    return function(n, s) {
                        let o = this.getUint8(n);
                        o = o & t | (s < 0 ? e | s & r : s & r) << i, this.setUint8(n, o);
                    };
                }
            }
        }
    }), $e({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> i & e;
                };
                {
                    const t = 255 ^ e << i;
                    return function(n, r) {
                        const s = this.getUint8(n) & t | (r & e) << i;
                        this.setUint8(n, s);
                    };
                }
            }
        }
    }), $e({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r, s = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = new DataView(new ArrayBuffer(s));
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: s
                }), r = Ue(i, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: s
                }), r = Ue(i, n, !1);
                return function(e, n, i) {
                    t.call(o, 0, n, i), r(this, o, e);
                };
            }
        }
    }), $e({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), i = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: i
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: i, type: s, byteSize: o} = t, c = n.byteLength, a = 1 !== o ? "s" : "";
            let l;
            if (s !== e.Slice || r) {
                l = `${i} has ${s === e.Slice ? r.length * o : o} byte${a}, received ${c}`;
            } else l = `${i} has elements that are ${o} byte${a} in length, received ${c}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: i} = t, s = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(Pe);
            let c;
            i && o.push(Pe(i.name)), c = n === e.Slice ? `Expecting ${De(o)} that can accommodate items ${r} byte${s} in length` : `Expecting ${De(o)} that is ${r} byte${s} in length`, 
            super(c);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let i;
            "string" === r || "number" === r || je(e) ? (je(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            i = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : i = `Error of the type ${n} expected, received ${e}`, 
            super(i);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Error given is not a part of error set ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: i}} = t;
            super(`${r} needs an initializer for one of its union properties: ${i.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, i = [];
            if (Array.isArray(e)) for (const t of e) i.push(Pe(t)); else i.push(Pe(e));
            const s = Ne(n);
            super(`${r} expects ${De(i)} as argument, received ${s}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [i]}, type: s, constructor: o} = t, c = [], a = ce(i);
            if (a) {
                let t;
                switch (i.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = a;
                }
                c.push(`array of ${t}s`);
            } else c.push("array of objects");
            o[jt] && c.push(o[jt].name), s === e.Slice && r && c.push("length"), super(t, c.join(" or "), n);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: i, instance: {members: [s]}} = t, {structure: {constructor: o}} = s, {length: c, constructor: a} = n, l = e?.length ?? i, u = 1 !== l ? "s" : "";
            let f;
            f = a === o ? "only a single one" : a.child === o ? `a slice/array that has ${c}` : `${c} initializer${c > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let i;
            i = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(i);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const i = 1 !== (t -= r) ? "s" : "", s = n ? "at least " : "";
                this.message = `Expecting ${s}${t} argument${i}, received ${e}`, this.stack = Be(this.stack, "new Arg(");
            };
            r(0), re(this, qt, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: i} = t;
            super(`${i} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = Ne(e);
            super(`Expected ${Pe(t)}, received ${n}`);
        }
    }
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${Le(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + R[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = Be(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function ze(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = Be(t.stack, "new Arg(");
        };
        return n(0), re(t, qt, {
            value: n,
            enumerable: !1
        }), t;
    }
    function Be(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function Fe() {
        throw new ReadOnly;
    }
    function ke(t, e, n) {
        if (void 0 === t.bytes && (t.bytes = t.calls = 0), t.bytes += n, t.calls++, 100 === t.calls) {
            const n = t.bytes / t.calls;
            if (n < 8) {
                throw new Error(`Inefficient ${e} access. Each call is only ${"read" === e ? "reading" : "writing"} ${n} byte${1 !== n ? "s" : ""}. Please use std.io.Buffered${"read" === e ? "Reader" : "Writer"}.`);
            }
        }
    }
    function je(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function Ne(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        Pe(n);
    }
    function Pe(t) {
        return `${Le(t)} ${t}`;
    }
    function Le(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function De(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function Re(t) {
        let n, r = 1, i = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[at]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[st]) t.constructor[ut] === e.Pointer && (t = t["*"]), 
        n = t[st], i = t.constructor, r = i[$t]; else {
            "string" == typeof t && (t = le(t));
            const {buffer: e, byteOffset: i, byteLength: s, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== i && void 0 !== s && (n = new DataView(e, i, s), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: i
        };
    }
    $e({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: i}, ptr: s} = this, o = i(s, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const c = o["*"][st];
                return c[at].align = e, c;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = Re(e), i = n?.[at];
                    if (!i) throw new TypeMismatch("object containing allocated Zig memory", e);
                    const {address: s} = i;
                    if (s === be) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: c} = this;
                    o(c, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe() {
            const t = this.getCopyFunction();
            return {
                value(e) {
                    const {dv: n, align: r, constructor: i} = Re(e);
                    if (!n) throw new TypeMismatch("string, DataView, typed array, or Zig object", e);
                    const s = this.alloc(n.byteLength, r);
                    return t(s, n), i ? i(s) : s;
                }
            };
        }
    }), $e({
        init() {
            this.variables = [];
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: (...t) => this.initialize?.(...t),
                abandon: () => this.abandonModule?.(),
                connect: t => this.consoleObject = t,
                sizeOf: e => t(e?.[Ot]),
                alignOf: e => t(e?.[$t]),
                typeOf: e => Ze[t(e?.[ut])]
            };
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = i(r);
                return t;
            }, r = t => t.length ? t.buffer : new ArrayBuffer(0), i = t => {
                const {memory: e, structure: i, actual: s} = t;
                if (e) {
                    if (s) return s;
                    {
                        const {array: s, offset: o, length: c} = e, a = this.obtainView(r(s), o, c), {handle: l, const: u} = t, f = i?.constructor, h = t.actual = f.call(Ut, a);
                        return u && this.makeReadOnly(h), t.slots && n(h[ot], t.slots), l && this.variables.push({
                            handle: l,
                            object: h
                        }), h;
                    }
                }
                return i;
            }, s = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: i} = t.template, o = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: s} = n;
                        o[st] = this.obtainView(r(t), e, s), i && this.variables.push({
                            handle: i,
                            object: o
                        });
                    }
                    if (e) {
                        const t = o[ot] = {};
                        s.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of s) n(t, e);
            for (const e of t) this.finalizeStructure(e);
        }
    });
    const Ze = l.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    $e({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[st]), i = this.createJsThunk(t, n);
                if (!i) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(i, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                let i = Y, s = !1;
                try {
                    const o = e(n);
                    if (Wt in o) {
                        o[Wt]("reset");
                        const t = this.startContext();
                        this.updatePointerTargets(t, o, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const c = function(t) {
                        try {
                            if (!(e[Nt] && t instanceof Error)) throw t;
                            o[ee](t);
                        } catch (e) {
                            i = H, console.error(t);
                        }
                    }, a = function(t) {
                        try {
                            o[ee](t);
                        } catch (t) {
                            i = H, console.error(t);
                        }
                    };
                    try {
                        const e = t(...o), n = o.hasOwnProperty(ee);
                        if ("Promise" === e?.[Symbol.toStringTag]) if (r || n) {
                            const t = e.then(a, c);
                            r && t.then((() => this.finalizeAsyncCall(r, i))), s = !0, i = Y;
                        } else i = X; else if (e?.[Symbol.asyncIterator]) {
                            if (!o.hasOwnProperty(ne)) throw new UnexpectedGenerator;
                            this.pipeContents(e, o), i = Y;
                        } else null == e && n || a(e);
                    } catch (t) {
                        c(t);
                    }
                } catch (t) {
                    console.error(t), i = H;
                }
                return r && !s && this.finalizeAsyncCall(r, i), i;
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, c = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === s)).length;
            return {
                value() {
                    let a, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, b, y = this[d];
                        if (p === D.Object && y?.[st]?.[at] && (y = new y.constructor(y)), g.type === e.Struct) switch (g.purpose) {
                          case s:
                            t = 1 === c ? "allocator" : "allocator" + ++l, b = this[Dt] = y;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (b = o.createPromiseCallback(this, y));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (b = o.createGeneratorCallback(this, y));
                            break;

                          case i:
                            t = "signal", 1 == ++f && (b = o.createInboundSignal(y));
                        }
                        void 0 !== t ? void 0 !== b && (a ||= {}, a[t] = b) : h.push(y);
                    } catch (t) {
                        h.push(t);
                    }
                    return a && h.push(a), h[Symbol.iterator]();
                }
            };
        },
        handleJsCall(t, e, n, r = 0) {
            const i = this.obtainZigView(e, n, !1), s = this.jsFunctionCallerMap.get(t);
            return s ? s(i, r) : H;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[st]), i = this.getViewAddress(e);
                this.destroyJsThunk(r, i), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJsCall: null,
            releaseFunction: null
        },
        imports: {
            createJsThunk: null,
            destroyJsThunk: null,
            finalizeAsyncCall: null
        }
    }), $e({
        createOutboundCaller(t, e) {
            const n = this, r = function(...i) {
                const s = new e(i, this?.[Dt]);
                return n.invokeThunk(t, r, s);
            };
            return r;
        },
        copyArguments(t, o, l, u, f) {
            let h = 0, d = 0, g = 0;
            const p = t[kt];
            for (const {type: b, structure: y} of l) {
                let l, m, w, v;
                if (y.type === e.Struct) switch (y.purpose) {
                  case s:
                    l = (1 == ++g ? u?.allocator ?? u?.allocator1 : u?.[`allocator${g}`]) ?? this.createDefaultAllocator(t, y);
                    break;

                  case n:
                    m ||= this.createPromise(y, t, u?.callback), l = m;
                    break;

                  case r:
                    w ||= this.createGenerator(y, t, u?.callback), l = w;
                    break;

                  case i:
                    v ||= this.createSignal(y, u?.signal), l = v;
                    break;

                  case c:
                    l = this.createReader(o[d++]);
                    break;

                  case a:
                    l = this.createWriter(o[d++]);
                }
                if (void 0 === l && (l = o[d++], void 0 === l && b !== D.Void)) throw new UndefinedArgument;
                try {
                    p[h++].call(t, l, f);
                } catch (t) {
                    throw ze(t, h - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), i = n[zt], s = this.getViewAddress(t[st]), o = this.getViewAddress(e[st]), c = Qt in n, a = Wt in n;
            a && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[st]), u = i ? this.getViewAddress(i[st]) : 0;
            this.updateShadows(r);
            const f = () => {
                this.updateShadowTargets(r), a && this.updatePointerTargets(r, n), this.libc && this.flushStdout?.(), 
                this.flushConsole?.(), this.endContext();
            };
            c && (n[Qt] = f);
            if (!(i ? this.runVariadicThunk(s, o, l, u, i.length) : this.runThunk(s, o, l))) throw f(), 
            new ZigError;
            if (c) {
                let t = null;
                try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (e[Jt] && t && (t = t.string), n[ee](t)) : e[Jt] && (n[Jt] = !0), 
                n[Pt] ?? n[Lt];
            }
            f();
            try {
                const {retval: t} = n;
                return e[Jt] && t ? t.string : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    }), $e({
        init() {
            const t = {
                type: D.Int,
                bitSize: 8,
                byteSize: 1
            }, e = {
                type: D.Int,
                bitSize: 16,
                byteSize: 2
            }, n = {
                type: D.Int,
                bitSize: 32,
                byteSize: 4
            }, r = this.getAccessor("get", t), i = this.getAccessor("set", t), s = this.getAccessor("get", e), o = this.getAccessor("set", e), c = this.getAccessor("get", n), a = this.getAccessor("set", n);
            this.copiers = {
                0: Oe,
                1: function(t, e) {
                    i.call(t, 0, r.call(e, 0));
                },
                2: function(t, e) {
                    o.call(t, 0, s.call(e, 0, !0), !0);
                },
                4: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0);
                },
                8: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0), a.call(t, 4, c.call(e, 4, !0), !0);
                },
                16: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0), a.call(t, 4, c.call(e, 4, !0), !0), a.call(t, 8, c.call(e, 8, !0), !0), 
                    a.call(t, 12, c.call(e, 12, !0), !0);
                },
                any: function(t, e) {
                    let n = 0, s = t.byteLength;
                    for (;n + 4 <= s; ) a.call(t, n, c.call(e, n, !0), !0), n += 4;
                    for (;n + 1 <= s; ) i.call(t, n, r.call(e, n)), n++;
                }
            }, this.resetters = {
                0: Oe,
                1: function(t, e) {
                    i.call(t, e, 0);
                },
                2: function(t, e) {
                    o.call(t, e, 0, !0);
                },
                4: function(t, e) {
                    a.call(t, e, 0, !0);
                },
                8: function(t, e) {
                    a.call(t, e + 0, 0, !0), a.call(t, e + 4, 0, !0);
                },
                16: function(t, e) {
                    a.call(t, e + 0, 0, !0), a.call(t, e + 4, 0, !0), a.call(t, e + 8, 0, !0), a.call(t, e + 12, 0, !0);
                },
                any: function(t, e, n) {
                    let r = e;
                    for (;r + 4 <= n; ) a.call(t, r, 0, !0), r += 4;
                    for (;r + 1 <= n; ) i.call(t, r, 0), r++;
                }
            };
        },
        defineCopier(t, e) {
            const n = this.getCopyFunction(t, e);
            return {
                value(t) {
                    const e = t[st], r = this[st];
                    n(r, e);
                }
            };
        },
        defineResetter(t, e) {
            const n = this.getResetFunction(e);
            return {
                value() {
                    const r = this[st];
                    n(r, t, e);
                }
            };
        },
        getCopyFunction(t, e = !1) {
            return (e ? void 0 : this.copiers[t]) ?? this.copiers.any;
        },
        getResetFunction(t) {
            return this.resetters[t] ?? this.resetters.any;
        },
        imports: {
            copyExternBytes: null
        }
    }), $e({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = ye(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: i}} = t;
            if (n) {
                if ("function" != typeof n) throw new TypeMismatch("function", n);
            } else {
                const t = e[Lt] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const s = this.nextGeneratorContextId++, o = this.obtainZigView(s, 0, !1);
            this.generatorContextMap.set(s, {
                func: n,
                args: e
            });
            let c = this.generatorCallbackMap.get(r);
            c || (c = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][st], r = this.getViewAddress(n), i = this.generatorContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i, s = e instanceof Error;
                    !s && n[Jt] && e && (e = e.string);
                    const o = !1 === await (2 === t.length ? t(s ? e : null, s ? null : e) : t(e)) || s || null === e;
                    if (n[_t]?.(o), !o) return !0;
                    n[Qt](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, c), this.destructors.push((() => this.freeFunction(c)))), 
            e[ee] = t => c(o, t);
            const a = {
                ptr: o,
                callback: c
            }, l = i.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                a.allocator = this.createJsAllocator(e, t, !0);
            }
            return a;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[ne] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[ne](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[ne](t)) break;
                    e[ne](null);
                } catch (t) {
                    if (!e.constructor[Nt]) throw t;
                    e[ne](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    function Je(t, e) {
        return he(t, e, (t => t.address));
    }
    $e({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: i, bitSize: s} = n;
            if ("set" === e) return s > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const i = Number(e);
                if (!isFinite(i)) throw new InvalidIntConversion(e);
                r.call(this, t, i, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & g && s > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, i) {
                        const s = r.call(this, n, i);
                        return e <= s && s <= t ? Number(s) : s;
                    };
                }
            }
            return r;
        }
    }), $e({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = ye(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let i = this.allocatorVtable;
            if (!i) {
                const {noResize: t, noRemap: e} = r;
                i = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (i.remap = e), this.destructors.push((() => this.freeFunction(i.alloc))), 
                this.destructors.push((() => this.freeFunction(i.free)));
            }
            let s = pe;
            if (n) {
                const e = [];
                s = this.nextAllocatorContextId++, this.allocatorContextMap.set(s, e), t[_t] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(s);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(s, 0),
                vtable: i
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][st]), i = r != pe ? this.allocatorContextMap.get(r) : null, s = 1 << n, o = this.allocateJSMemory(e, s);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, s, !0, o), re(o, at, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), i?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][st], i = this.getViewAddress(r), s = r.byteLength;
            this.unregisterMemory(i, s);
        }
    }), $e({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const i = e[st];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: s, targets: o} = n;
                    let c, a = 0;
                    for (const t of o) {
                        const e = t[st], n = e.byteOffset, r = t.constructor[$t] ?? e[$t];
                        (void 0 === a || r > a) && (a = r, c = n);
                    }
                    const l = s - e, u = this.allocateShadowMemory(l + a, 1), f = this.getViewAddress(u), h = ge(me(f, c - e), a), d = me(h, e - c);
                    for (const t of o) {
                        const n = t[st], r = n.byteOffset;
                        if (r !== c) {
                            const i = t.constructor[$t] ?? n[$t];
                            if (de(me(d, r - e), i)) throw new AlignmentConflict(i, a);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), b = new DataView(i.buffer, Number(e), l), y = this.registerMemory(d, l, 1, r, b, p);
                    t.shadowList.push(y), n.address = d;
                }
                return me(n.address, i.byteOffset - n.start);
            }
            {
                const n = e.constructor[$t] ?? i[$t], s = i.byteLength, o = this.allocateShadowMemory(s, n), c = this.getViewAddress(o), a = this.registerMemory(c, s, 1, r, i, o);
                return t.shadowList.push(a), c;
            }
        },
        updateShadows(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r} of t.shadowList) e(r, n);
        },
        updateShadowTargets(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r, writable: i} of t.shadowList) i && e(n, r);
        },
        registerMemory(t, e, n, r, i, s) {
            const o = Je(this.memoryList, t);
            let c = this.memoryList[o - 1];
            return c?.address === t && c.len === e ? c.writable ||= r : (c = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: i,
                shadowDV: s
            }, this.memoryList.splice(o, 0, c)), c;
        },
        unregisterMemory(t, e) {
            const n = Je(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            let i = n * (r ?? 0);
            const s = Je(this.memoryList, e), o = this.memoryList[s - 1];
            let c;
            if (o?.address === e && o.len === i) c = o.targetDV; else if (o?.address <= e && me(e, i) <= me(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: s} = o;
                n && (i = s.byteLength - t), c = this.obtainView(s.buffer, s.byteOffset + t, i), 
                n && (c[$t] = o.align);
            }
            if (c) {
                let {targetDV: e, shadowDV: n} = o;
                if (n && t && !t.shadowList.includes(o)) {
                    this.getCopyFunction()(e, n);
                }
            } else c = this.obtainZigView(e, i);
            return c;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[at], n = e?.address;
            n && n !== be && (e.address = be, this.unregisterBuffer(me(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[at];
            if (e) return e.address;
            {
                const e = this.getBufferAddress(t.buffer);
                return me(e, t.byteOffset);
            }
        },
        ...{
            imports: {
                getBufferAddress: null,
                obtainExternBuffer: null
            },
            exports: {
                getViewAddress: null
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (function(t) {
                    return 0xaaaaaaaaaaaaaaaan === t;
                }(t) && (t = e > 0 ? 0 : pe), !t && e) return null;
                let r, i;
                if (n) {
                    const n = Je(this.externBufferList, t), s = this.externBufferList[n - 1];
                    s?.address <= t && me(t, e) <= me(s.address, s.len) ? (r = s.buffer, i = Number(t - s.address)) : (r = e > 0 ? this.obtainExternBuffer(t, e, Rt) : new ArrayBuffer(0), 
                    this.externBufferList.splice(n, 0, {
                        address: t,
                        len: e,
                        buffer: r
                    }), i = 0);
                } else r = e > 0 ? this.obtainExternBuffer(t, e, Rt) : new ArrayBuffer(0), i = 0;
                return r[at] = {
                    address: t,
                    len: e
                }, this.obtainView(r, i, e);
            },
            unregisterBuffer(t) {
                const e = Je(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const i = e[st];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(i.buffer);
                        for (const e of n.targets) {
                            const r = e[st].byteOffset, i = e.constructor[$t], s = me(t, r);
                            if (de(s, i)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return me(n.address, i.byteOffset);
                } else {
                    const t = e.constructor[$t], n = this.getViewAddress(i);
                    if (!de(n, t)) {
                        const e = i.byteLength;
                        return this.registerMemory(n, e, t, r, i), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), $e({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: null
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const r = this[n ?? e];
                    r && (t[e] = r.bind(this));
                }
                return t;
            },
            importFunctions(t) {
                for (const [e, n] of Object.entries(this.imports)) {
                    const r = t[n ?? e];
                    r && (re(this, e, se(r)), this.destructors.push((() => this[e] = qe)));
                }
            }
        }
    });
    const qe = () => {
        throw new Error("Module was abandoned");
    };
    function _e(t, n) {
        const {byteSize: r, type: i} = n;
        if (!(i === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function Ge(t) {
        throw new BufferExpected(t);
    }
    $e({
        linkVariables(t) {
            const e = this.getCopyFunction();
            for (const {object: n, handle: r} of this.variables) {
                const i = n[st], s = this.recreateAddress(r);
                let o = n[st] = this.obtainZigView(s, i.byteLength);
                t && e(o, i), n.constructor[Et]?.save?.(o, n), this.destructors.push((() => {
                    const t = n[st] = this.allocateMemory(o.bytelength);
                    e(t, o);
                }));
                const c = t => {
                    const e = t[ot];
                    if (e) {
                        const t = o.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[st];
                            if (e.buffer === i.buffer) {
                                const r = t + e.byteOffset - i.byteOffset;
                                n[st] = this.obtainView(o.buffer, r, e.byteLength), n.constructor[Et]?.save?.(o, n), 
                                c(n);
                            }
                        }
                    }
                };
                c(n), n[Wt]?.((function() {
                    this[qt]();
                }), et.IgnoreInactive);
            }
        },
        imports: {
            recreateAddress: null
        }
    }), $e({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, i = [], s = function(t) {
                const e = this[pt];
                if (void 0 === n.get(e)) {
                    const t = e[ot][0];
                    if (t) {
                        const o = {
                            target: t,
                            writable: !e.constructor.const
                        }, c = t[st];
                        if (c[at]) n.set(e, null); else {
                            n.set(e, t);
                            const a = r.get(c.buffer);
                            if (a) {
                                const t = Array.isArray(a) ? a : [ a ], e = he(t, c.byteOffset, (t => t.target[st].byteOffset));
                                t.splice(e, 0, o), Array.isArray(a) || (r.set(c.buffer, t), i.push(t));
                            } else r.set(c.buffer, o);
                            t[Wt]?.(s, 0);
                        }
                    }
                }
            }, o = et.IgnoreRetval | et.IgnoreInactive;
            e[Wt](s, o);
            const c = this.findTargetClusters(i), a = new Map;
            for (const t of c) for (const e of t.targets) a.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = a.get(r), i = n?.writable ?? !e.constructor.const;
                e[At] = this.getTargetAddress(t, r, n, i), It in e && (e[It] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, i = function(e) {
                const n = this[pt];
                if (!r.get(n)) {
                    r.set(n, !0);
                    const s = n[ot][0], o = s && e & et.IsImmutable ? s : n[qt](t, !0, !(e & et.IsInactive)), c = n.constructor.const ? et.IsImmutable : 0;
                    c & et.IsImmutable || s && !s[st][at] && s[Wt]?.(i, c), o !== s && o && !o[st][at] && o?.[Wt]?.(i, c);
                }
            }, s = n ? et.IgnoreRetval : 0;
            e[Wt](i, s);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, i = 0, s = null;
                for (const {target: o, writable: c} of n) {
                    const n = o[st], {byteOffset: a, byteLength: l} = n, u = a + l;
                    let f = !0;
                    t && (i > a ? (s ? s.writable ||= c : (s = {
                        targets: [ t ],
                        start: r,
                        end: i,
                        address: void 0,
                        misaligned: void 0,
                        writable: c
                    }, e.push(s)), s.targets.push(o), u > i ? s.end = u : f = !1) : s = null), f && (t = o, 
                    r = a, i = u);
                }
            }
            return e;
        }
    }), $e({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = ye(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new TypeMismatch("function", n);
            } else e[Pt] = new Promise(((t, r) => {
                n = n => {
                    n?.[st]?.[at] && (n = new n.constructor(n)), n instanceof Error ? r(n) : (e[Jt] && n && (n = n.string), 
                    t(n));
                };
            }));
            const i = this.nextPromiseContextId++, s = this.obtainZigView(i, 0, !1);
            this.promiseContextMap.set(i, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][st], r = this.getViewAddress(n), i = this.promiseContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[Qt](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[ee] = t => o(s, t), {
                ptr: s,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[ee] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[ee](n);
            };
        }
    }), $e({
        init() {
            this.readerCallback = null, this.readerContextMap = new Map, this.nextReaderContextId = ye(4096);
        },
        createReader(t) {
            if (t instanceof ReadableStreamDefaultReader || t instanceof ReadableStreamBYOBReader) {
                const e = this.nextReaderContextId++, n = this.obtainZigView(e, 0, !1);
                this.readerContextMap.set(e, {
                    reader: t,
                    leftover: null,
                    finished: !1
                });
                let r = this.readerCallback;
                return r || (r = this.readerCallback = async (t, e) => {
                    const n = this.getViewAddress(t["*"][st]), r = this.readerContextMap.get(n);
                    if (!r) return 0;
                    try {
                        const t = e["*"][st], i = new Uint8Array(t.buffer, t.byteOffset, t.byteLength);
                        ke(r, "read", i.length);
                        let {reader: s, finished: o, leftover: c} = r, a = 0;
                        if (s instanceof ReadableStreamBYOBReader) {
                            const {done: t, value: e} = await s.read(i);
                            a = e.byteLength, o = t;
                        } else {
                            for (;a < i.length && !o; ) {
                                if (!c) {
                                    const {done: t, value: e} = await s.read();
                                    o = t, c = new Uint8Array(e);
                                }
                                const t = Math.min(c.length, i.length - a);
                                for (let e = 0; e < t; e++) i[a + e] = c[e];
                                if (a += t, c.length > t) c = c.slice(t); else if (c = null, o) break;
                            }
                            r.leftover = c, r.finished = o;
                        }
                        return o && this.readerContextMap.delete(n), a;
                    } catch (t) {
                        throw this.readerContextMap.delete(n), t;
                    }
                }, this.destructors.push((() => this.freeFunction(r)))), {
                    context: n,
                    readFn: r
                };
            }
            if ("object" == typeof t && t && "context" in t && "readFn" in t) return t;
            throw new TypeMismatch("ReadableStreamDefaultReader or ReadableStreamBYOBReader", t);
        }
    }), $e({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === D.Int;
                    let i = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** i) : 0,
                            max: 2 ** i - 1
                        };
                    }
                    i = BigInt(i);
                    return {
                        min: r ? -(2n ** i) : 0n,
                        max: 2n ** i - 1n
                    };
                }(n);
                return function(i, s, o) {
                    if (s < t || s > e) throw new Overflow(n, s);
                    r.call(this, i, s, o);
                };
            }
            return r;
        }
    }), $e({
        init() {
            this.consoleObject = null, this.consolePending = [], this.consoleTimeout = 0;
        },
        writeToConsole(t) {
            try {
                const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength).slice(), n = e.lastIndexOf(10);
                if (-1 === n) this.consolePending.push(e); else {
                    const t = e.subarray(0, n), r = e.subarray(n + 1);
                    this.writeToConsoleNow([ ...this.consolePending, t ]), this.consolePending.splice(0), 
                    r.length > 0 && this.consolePending.push(r);
                }
                return clearTimeout(this.consoleTimeout), this.consoleTimeout = 0, this.consolePending.length > 0 && (this.consoleTimeout = setTimeout((() => {
                    this.writeToConsoleNow(this.consolePending), this.consolePending.splice(0);
                }), 250)), !0;
            } catch (t) {
                return console.error(t), !1;
            }
        },
        writeToConsoleNow(t) {
            const e = this.consoleObject ?? globalThis.console;
            e.log?.call?.(e, ae(t));
        },
        flushConsole() {
            this.consolePending.length > 0 && (this.writeToConsoleNow(this.consolePending), 
            this.consolePending.splice(0), clearTimeout(this.consoleTimeout));
        },
        ...{
            exports: {
                writeBytes: null
            },
            imports: {
                flushStdout: null
            },
            writeBytes(t, e) {
                const n = this.obtainZigView(t, e, !1);
                return n && this.writeToConsole(n) ? Y : H;
            }
        }
    }), $e({
        init() {
            this.comptime = !1, this.slots = {}, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.libc = !1;
        },
        readSlot(t, e) {
            const n = t ? t[ot] : this.slots;
            return n?.[e];
        },
        writeSlot(t, e, n) {
            const r = t ? t[ot] : this.slots;
            r && (r[e] = n);
        },
        createTemplate: t => ({
            [st]: t,
            [ot]: {}
        }),
        beginStructure(t) {
            const {type: e, purpose: n, name: r, length: i, signature: s = -1n, byteSize: o, align: c, flags: a} = t;
            return {
                constructor: null,
                type: e,
                purpose: n,
                flags: a,
                signature: s,
                name: r,
                length: i,
                byteSize: o,
                align: c,
                instance: {
                    members: [],
                    template: null
                },
                static: {
                    members: [],
                    template: null
                }
            };
        },
        attachMember(t, e, n = !1) {
            (n ? t.static : t.instance).members.push(e);
        },
        attachTemplate(t, e, n = !1) {
            (n ? t.static : t.instance).template = e;
        },
        endStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        captureView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.copyExternBytes(n, t, e), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[at].handle = r, n;
            }
        },
        castView(t, e, n, r, i) {
            const {constructor: s, flags: o} = r, c = this.captureView(t, e, n, i), a = s.call(Ut, c);
            return o & h && this.updatePointerTargets(null, a), n && e > 0 && this.makeReadOnly?.(a), 
            a;
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & K), this.runtimeSafety = !!(t & Q), this.libc = !!(t & tt);
            const e = this.getFactoryThunk(), n = {
                [st]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                if (n & h && r && r[st]) {
                    const t = Object.create(e.prototype);
                    t[st] = r[st], t[ot] = r[ot], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, libc: r} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    libc: r
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of Se(this.structures, ot)) {
                const n = e[st]?.[at];
                if (n) {
                    const {address: r, len: i, handle: s} = n, o = e[st] = this.captureView(r, i, !0);
                    s && (o.handle = s), t.push({
                        address: r,
                        len: i,
                        owner: e,
                        replaced: !1,
                        handle: s
                    });
                }
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && me(n.address, n.len) <= me(e.address, e.len)) {
                const t = e.owner[st], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[st] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = Se(this.structures, ot);
            for (const t of e) t[st]?.[at] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${l[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, static: {template: n}, flags: r} = t;
            switch (e.type) {
              case D.Bool:
                return "bool";

              case D.Int:
                return r & g ? "isize" : `i${e.bitSize}`;

              case D.Uint:
                return r & g ? "usize" : `u${e.bitSize}`;

              case D.Float:
                return `f${e.bitSize}`;

              case D.Void:
                return "void";

              case D.Literal:
                return "enum_literal";

              case D.Null:
                return "null";

              case D.Undefined:
                return "undefined";

              case D.Type:
                return "type";

              case D.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & w[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & F ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let i = "*", s = n.structure.name;
            if (n.structure.type === e.Slice && (s = s.slice(3)), r & V && (i = r & M ? "[]" : r & E ? "[*c]" : "[*]"), 
            !(r & E)) {
                const t = n.structure.constructor?.[bt];
                t && (i = i.slice(0, -1) + `:${t.value}` + i.slice(-1));
            }
            return r & O && (i = `${i}const `), i + s;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & B ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${i})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${i})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t;
            return e.structure.name.slice(4, -1);
        },
        exports: {
            captureView: null,
            castView: null,
            readSlot: null,
            writeSlot: null,
            beginStructure: null,
            attachMember: null,
            createTemplate: null,
            attachTemplate: null,
            defineStructure: null,
            endStructure: null
        },
        imports: {
            getFactoryThunk: null,
            getModuleAttributes: null
        }
    }), $e({}), $e({
        init() {
            this.viewMap = new WeakMap, this.needFallback = void 0;
        },
        extractView(t, n, r = Ge) {
            const {type: i, byteSize: s, constructor: o} = t;
            let c;
            const a = n?.[Symbol.toStringTag];
            if (a && ("DataView" === a ? c = this.registerView(n) : "ArrayBuffer" === a ? c = this.obtainView(n, 0, n.byteLength) : (a && a === o[jt]?.name || "Uint8ClampedArray" === a && o[jt] === Uint8Array || "Uint8Array" === a && n instanceof Buffer) && (c = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !c) {
                const r = n?.[st];
                if (r) {
                    const {constructor: o, instance: {members: [c]}} = t;
                    if (Ie(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(i)) {
                        const {byteSize: o, structure: {constructor: a}} = c, l = ve(n, a);
                        if (void 0 !== l) {
                            if (i === e.Slice || l * o === s) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return c ? void 0 !== s && _e(c, t) : r?.(t, n), c;
        },
        assignView(t, n, r, i, s) {
            const {byteSize: o, type: c} = r, a = o ?? 1;
            if (t[st]) {
                const i = c === e.Slice ? a * t.length : a;
                if (n.byteLength !== i) throw new BufferSizeMismatch(r, n, t);
                const s = {
                    [st]: n
                };
                t.constructor[bt]?.validateData?.(s, t.length), t[Yt](s);
            } else {
                void 0 !== o && _e(n, r);
                const e = n.byteLength / a, c = {
                    [st]: n
                };
                t.constructor[bt]?.validateData?.(c, e), s && (i = !0), t[Ht](i ? null : n, e, s), 
                i && t[Yt](c);
            }
            if (this.usingBufferFallback()) {
                const e = t[st], n = e.buffer[Rt];
                void 0 !== n && this.syncExternalBuffer(e.buffer, n, !0);
            }
        },
        findViewAt(t, e, n) {
            let r, i = this.viewMap.get(t);
            if (i) if (i instanceof DataView) if (i.byteOffset === e && i.byteLength === n) r = i, 
            i = null; else {
                const e = i, n = `${e.byteOffset}:${e.byteLength}`;
                i = new Map([ [ n, e ] ]), this.viewMap.set(t, i);
            } else r = i.get(`${e}:${n}`);
            return {
                existing: r,
                entry: i
            };
        },
        obtainView(t, e, n) {
            const {existing: r, entry: i} = this.findViewAt(t, e, n);
            let s;
            if (r) return r;
            s = new DataView(t, e, n), i ? i.set(`${e}:${n}`, s) : this.viewMap.set(t, s);
            {
                const r = t[at];
                r && (s[at] = {
                    address: me(r.address, e),
                    len: n
                });
            }
            return s;
        },
        registerView(t) {
            if (!t[at]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: i, entry: s} = this.findViewAt(e, n, r);
                if (i) return i;
                s ? s.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: null,
                syncExternalBuffer: null
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > We && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let i = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    i = ge(t, e) - t;
                }
                return this.obtainView(r, Number(i), t);
            }
        }
    });
    const We = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8;
    $e({}), $e({
        makeReadOnly(t) {
            Xe(t);
        }
    });
    const Ye = Object.getOwnPropertyDescriptors, He = Object.defineProperty;
    function Xe(t) {
        const e = t[pt];
        if (e) Ke(e, [ "length" ]); else {
            const e = t[yt];
            e ? (Ke(e), function(t) {
                He(t, "set", {
                    value: Fe
                });
                const e = t.get;
                He(t, "get", {
                    value: function(t) {
                        const n = e.call(this, t);
                        return null === n?.[Tt] && Xe(n), n;
                    }
                });
            }(e)) : Ke(t);
        }
    }
    function Ke(t, e = []) {
        const n = Ye(t.constructor.prototype);
        for (const [r, i] of Object.entries(n)) i.set && !e.includes(r) && (i.set = Fe, 
        He(t, r, i));
        He(t, Tt, {
            value: t
        });
    }
    function Qe() {
        const t = this[yt] ?? this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function tn(t) {
        const e = oe(t), n = this[yt] ?? this, r = this.length;
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r) {
                    const r = i++;
                    t = [ r, e((() => n.get(r))) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function en(t) {
        return {
            [Symbol.iterator]: tn.bind(this, t),
            length: this.length
        };
    }
    function nn(t) {
        return {
            [Symbol.iterator]: sn.bind(this, t),
            length: this[gt].length
        };
    }
    function rn(t) {
        return nn.call(this, t)[Symbol.iterator]();
    }
    function sn(t) {
        const e = oe(t), n = this, r = this[gt];
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r.length) {
                    const o = r[i++];
                    t = [ o, e((() => n[o])) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function on(t) {
        return {
            [Symbol.iterator]: an.bind(this, t),
            length: this[gt].length
        };
    }
    function cn(t) {
        return on.call(this, t)[Symbol.iterator]();
    }
    function an(t) {
        const e = oe(t), n = this, r = this[gt], i = this[Ft];
        let s = 0;
        return {
            next() {
                let t, o;
                if (s < r.length) {
                    const c = r[s++];
                    t = [ c, e((() => i[c].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function ln() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t[e], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function un() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function fn() {
        return {
            [Symbol.iterator]: un.bind(this),
            length: this.length
        };
    }
    function hn(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function dn(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function gn(t) {
        return pn.call(this, t).$;
    }
    function pn(t) {
        return this[ot][t] ?? this[Gt](t);
    }
    function bn(t) {
        const e = pn.call(this, t).$;
        return e ? e.string : e;
    }
    function yn(t, e, n) {
        pn.call(this, t)[Xt](e, n);
    }
    $e({
        init() {
            this.writerCallback = null, this.writerContextMap = new Map, this.nextWriterContextId = ye(8192);
        },
        createWriter(t) {
            if (t instanceof WritableStreamDefaultWriter) {
                const e = this.nextWriterContextId++, n = this.obtainZigView(e, 0, !1);
                this.writerContextMap.set(e, {
                    writer: t
                }), t.closed.catch(Oe).then((() => this.writerContextMap.delete(e)));
                let r = this.writerCallback;
                return r || (r = this.writerCallback = async (t, e) => {
                    const n = this.getViewAddress(t["*"][st]), r = this.writerContextMap.get(n);
                    if (!r) return 0;
                    try {
                        const t = e["*"][st], n = new Uint8Array(t.buffer, t.byteOffset, t.byteLength);
                        ke(r, "write", n.length);
                        const {writer: i} = r;
                        return await i.write(new Uint8Array(n)), n.length;
                    } catch (t) {
                        throw this.writerContextMap.delete(n), t;
                    }
                }, this.destructors.push((() => this.freeFunction(r)))), {
                    context: n,
                    writeFn: r
                };
            }
            if ("object" == typeof t && t && "context" in t && "writeFn" in t) return t;
            throw new TypeMismatch("WritableStreamDefaultWriter", t);
        }
    }), $e({
        defineArrayEntries: () => se(en),
        defineArrayIterator: () => se(Qe)
    }), $e({
        defineStructEntries: () => se(nn),
        defineStructIterator: () => se(rn)
    }), $e({
        defineUnionEntries: () => se(on),
        defineUnionIterator: () => se(cn)
    }), $e({
        defineVectorEntries: () => se(fn),
        defineVectorIterator: () => se(ln)
    }), $e({
        defineZigIterator: () => se(hn)
    }), $e({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, i = this[`defineMember${R[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${l[e]}`];
                if (n) return n.call(this, i, t);
            }
            return i;
        }
    }), $e({
        defineBase64(t) {
            const e = this;
            return xe({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new TypeMismatch("string", n);
                    const i = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, i, t, !1, r);
                }
            });
        }
    }), $e({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), $e({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return xe({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new TypeMismatch(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), $e({
        defineDataView(t) {
            const e = this;
            return xe({
                get() {
                    const t = this[st];
                    if (e.usingBufferFallback()) {
                        const n = t.buffer[Rt];
                        void 0 !== n && e.syncExternalBuffer(t.buffer, n, !1);
                    }
                    return t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new TypeMismatch("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), $e({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), $e({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), $e({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return dn(e, {
                get(t) {
                    return this[ot][t].string;
                },
                set: Fe
            });
        }
    }), $e({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: Fe
        })
    }), $e({
        defineMemberObject: t => dn(t.slot, {
            get: t.flags & W ? bn : t.structure.flags & u ? gn : pn,
            set: t.flags & J ? Fe : yn
        })
    }), $e({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: i} = t, s = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return s.call(this[st], t, n);
                        },
                        set: function(e) {
                            return o.call(this[st], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return s.call(this[st], e * i, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[st], t * i, e, n);
                    }
                };
            }
        }
    }), $e({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: i}} = t, {get: s} = this.defineMember(r), {get: o} = this.defineMember(n), c = s.call(i, 0), a = !!(r.flags & Z), {runtimeSafety: l} = this;
            return se({
                value: c,
                bytes: i[st],
                validateValue(e, n, r) {
                    if (a) {
                        if (l && e === c && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== c && n === r - 1) throw new MissingSentinel(t, c, r);
                    }
                },
                validateData(n, r) {
                    if (a) if (l) for (let e = 0; e < r; e++) {
                        const i = o.call(n, e);
                        if (i === c && e !== r - 1) throw new MisplacedSentinel(t, c, e, r);
                        if (i !== c && e === r - 1) throw new MissingSentinel(t, c, r);
                    } else if (r > 0 && r * e === n[st].byteLength) {
                        if (o.call(n, r - 1) !== c) throw new MissingSentinel(t, c, r);
                    }
                },
                isRequired: a
            });
        },
        imports: {
            findSentinel: null
        }
    }), $e({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return xe({
                get() {
                    let t = ae(this.typedArray, r);
                    const e = this.constructor[bt]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, i) {
                    if ("string" != typeof n) throw new TypeMismatch("string", n);
                    const s = this.constructor[bt]?.value;
                    void 0 !== s && n.charCodeAt(n.length - 1) !== s && (n += String.fromCharCode(s));
                    const o = le(n, r), c = new DataView(o.buffer);
                    e.assignView(this, c, t, !1, i);
                }
            });
        }
    }), $e({
        defineValueOf: () => ({
            value() {
                return vn(this, !1);
            }
        })
    });
    const mn = BigInt(Number.MAX_SAFE_INTEGER), wn = BigInt(Number.MIN_SAFE_INTEGER);
    function vn(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, i = oe(r), s = new Map, o = function(t) {
            const c = "function" == typeof t ? e.Struct : t?.constructor?.[ut];
            if (void 0 === c) {
                if (n) {
                    if ("bigint" == typeof t && wn <= t && t <= mn) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let a = s.get(t);
            if (void 0 === a) {
                let n;
                switch (c) {
                  case e.Struct:
                    n = t[wt](r), a = t.constructor[ft] & w.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[wt](r), a = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[wt](), a = [];
                    break;

                  case e.Pointer:
                    try {
                        a = t["*"];
                    } catch (t) {
                        a = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    a = i((() => String(t)));
                    break;

                  case e.Opaque:
                    a = {};
                    break;

                  default:
                    a = i((() => t.$));
                }
                if (a = o(a), s.set(t, a), n) for (const [t, e] of n) a[t] = o(e);
            }
            return a;
        };
        return o(t);
    }
    $e({
        defineToJSON: () => ({
            value() {
                return vn(this, !0);
            }
        })
    }), $e({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return dn(n, {
                get(t) {
                    const e = this[ot][t];
                    return e?.constructor;
                },
                set: Fe
            });
        }
    }), $e({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return xe({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new TypeMismatch(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), $e({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), $e({
        defineMemberUndefined: t => ({
            get: function() {},
            set: Fe
        })
    }), $e({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), $e({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), $e({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${l[e]}`], i = [], s = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [Tt]: {
                    value: null
                },
                [kt]: se(s),
                [St]: se(i),
                [Yt]: this.defineCopier(n)
            }, c = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !s[t] && "$" !== t && (s[t] = n, i.push(t));
            }
            return ie(c.prototype, o), c;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: i, align: s, byteSize: o, flags: c, signature: a, static: {members: u, template: f}} = t, h = [], d = {
                name: se(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [Zt]: se(a),
                [Ut]: se(this),
                [$t]: se(s),
                [Ot]: se(o),
                [ut]: se(r),
                [ft]: se(c),
                [gt]: se(h),
                [jt]: se(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [wt]: this.defineStructEntries(),
                [gt]: se(h)
            }, g = {
                [Symbol.toStringTag]: se(n)
            };
            for (const t of u) {
                const {name: n, slot: r, flags: i} = t;
                if (t.structure.type === e.Function) {
                    let e = f[ot][r];
                    i & W && (e[Jt] = !0), d[n] = se(e), e.name || re(e, "name", se(n));
                    const [s, o] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], c = "get" === s ? 0 : 1;
                    if (s && e.length === c) {
                        d[o] ||= {};
                        d[o][s] = e;
                    }
                    if (t.flags & _) {
                        const t = function(...t) {
                            try {
                                return e(this, ...t);
                            } catch (t) {
                                throw t[qt]?.(1), t;
                            }
                        };
                        if (ie(t, {
                            name: se(n),
                            length: se(e.length - 1)
                        }), g[n] = se(t), s && t.length === c) {
                            (g[o] ||= {})[s] = t;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[ot] = h.length > 0 && se(f[ot]);
            const p = this[`finalize${l[r]}`];
            !1 !== p?.call(this, t, d, g) && (ie(i.prototype, g), ie(i, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: i, align: s, flags: o, instance: {members: c, template: a}} = t, {onCastError: l} = n;
            let u;
            if (a?.[ot]) {
                const t = c.filter((t => t.flags & J));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, g = function(n, c = {}) {
                const {allocator: p} = c, b = this instanceof g;
                let y, m;
                if (b) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (y = this, o & d && (y[ot] = {}), Ht in y) y[Xt](n, p), m = y[st]; else {
                        const t = r !== e.Pointer ? p : null;
                        y[st] = m = h.allocateMemory(i, s, t);
                    }
                } else {
                    if (te in g && (y = g[te].call(this, n, c), !1 !== y)) return y;
                    if (m = h.extractView(t, n, l), y = f.find(m)) return y;
                    y = Object.create(g.prototype), Ht in y ? h.assignView(y, m, t, !1, !1) : y[st] = m, 
                    o & d && (y[ot] = {});
                }
                if (u) for (const t of u) y[ot][t] = a[ot][t];
                return y[Kt]?.(), b && (Ht in y || y[Xt](n, p)), Qt in y && (y = y[Qt]()), f.save(m, y);
            };
            return re(g, Et, se(f)), g;
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const i = Object.keys(n), s = this[St], o = this[kt];
                for (const e of i) if (!(e in o)) throw new NoProperty(t, e);
                let c = 0, a = 0, l = 0, u = 0;
                for (const t of s) {
                    const e = o[t];
                    e.special ? t in n && u++ : (c++, t in n ? a++ : e.required && l++);
                }
                if (0 !== l && 0 === u) {
                    const e = s.filter((t => o[t].required && !(t in n)));
                    throw new MissingInitializers(t, e);
                }
                if (u + a > i.length) for (const t of s) t in n && (i.includes(t) || i.push(t));
                a < c && 0 === u && e && e[st] && this[Yt](e);
                for (const t of i) {
                    o[t].call(this, n[t], r);
                }
                return i.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) {
                const [t] = r.members;
                switch (n) {
                  case e.Enum:
                  case e.ErrorSet:
                  case e.Primitive:
                    {
                        const {byteSize: e, type: n} = t;
                        return globalThis[(e > 4 && n !== D.Float ? "Big" : "") + (n === D.Float ? "Float" : n === D.Int ? "Int" : "Uint") + 8 * e + "Array"];
                    }

                  case e.Array:
                  case e.Slice:
                  case e.Vector:
                    return this.getTypedArray(t.structure);
                }
            }
        }
    }), $e({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: i, length: s, instance: {members: o}} = t, c = this, a = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = c.allocateMemory(r, i)) : (u = Object.create(l.prototype), 
                f = t), u[st] = f, n & d && (u[ot] = {}), !o) return u;
                {
                    let r;
                    if (n & N && t.length === s + 1 && (r = t.pop()), t.length !== s) throw new ArgumentCountMismatch(s, t.length);
                    n & L && (u[Qt] = null), c.copyArguments(u, t, a, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = se(a.length), e[Gt] = n & f && this.defineVivificatorStruct(t), 
            e[Wt] = n & h && this.defineVisitorArgStruct(o), e[ee] = se((function(t) {
                u.call(this, t, this[Dt]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(a), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[Nt] = se(!!(n & P));
        }
    }), $e({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                const n = new Proxy(this, Sn);
                return ie(this, {
                    [Vt]: {
                        value: n
                    },
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), n;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, i = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, s = this[st], o = s.byteOffset + n * t, c = i.obtainView(s.buffer, o, n);
                    return this[ot][t] = e.call(ct, c);
                }
            };
        }
    });
    const Sn = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : e === yt ? t : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length", Vt), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    };
    $e({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: i} = t, s = this.createApplier(t), o = this.defineMember(r), {set: c} = o, a = this.createConstructor(t), l = function(e, r) {
                if (Ie(e, a)) this[Yt](e), i & h && this[Wt]("copy", et.Vivificate, e); else if ("string" == typeof e && i & b && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = we(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) c.call(this, i++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            };
            return e.$ = {
                get: Ve,
                set: l
            }, e.length = se(n), e.entries = e[wt] = this.defineArrayEntries(), i & y && (e.typedArray = this.defineTypedArray(t), 
            i & b && (e.string = this.defineString(t)), i & m && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[Xt] = se(l), e[Qt] = this.defineFinalizerArray(o), 
            e[Gt] = i & f && this.defineVivificatorArray(t), e[Wt] = i & h && this.defineVisitorArray(), 
            a;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = se(r.structure.constructor), e[bt] = n & p && this.defineSentinel(t);
        }
    }), $e({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: i, set: s} = r, {get: o} = this.defineMember(n, !1), c = this.createApplier(t), a = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, a, e);
                }
            });
            return e.$ = r, e.toString = se(Ee), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[lt];

                      default:
                        return o.call(this);
                    }
                }
            }, e[Xt] = se((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === c.call(this, e)) throw new InvalidInitializer(t, a, e);
                } else void 0 !== e && s.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [i]}, static: {members: s, template: o}} = t, c = o[ot], {get: a, set: l} = this.defineMember(i, !1), u = {};
            for (const {name: t, flags: n, slot: r} of s) if (n & q) {
                const n = c[r];
                re(n, lt, se(t));
                const i = a.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[i] = n;
            }
            e[te] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & I) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            re(e, lt, se(n)), re(r, n, se(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[dt] instanceof r && t[dt];
                }
            }, e[jt] = se(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === D.Object) return t;
            const i = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    t = i(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), $e({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: i, flags: s} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: F,
                    byteSize: i,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && s & F) return this.globalErrorSet;
            const o = this.defineMember(r), {set: c} = o, a = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, a, e);
                }
            });
            return n.$ = o, n[Xt] = se((function(e) {
                if (e instanceof u[ht]) c.call(this, e); else if (e && "object" == typeof e && !je(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, a, e);
                } else void 0 !== e && c.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [i]}, static: {members: s, template: o}} = t;
            if (this.globalErrorSet && r & F) return !1;
            const c = o?.[ot] ?? {}, a = r & F ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(i, !1);
            for (const {name: t, slot: n} of s) {
                const r = c[n], i = l.call(r);
                let s = this.globalItemsByIndex[i];
                const o = !!s;
                s || (s = new this.ZigError(t, i));
                const u = se(s);
                e[t] = u;
                const f = `${s}`;
                e[f] = u, a[i] = s, o || (ie(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[gt].push(t), this.globalItemsByIndex[i] = s);
            }
            e[te] = {
                value: t => "number" == typeof t ? a[t] : "string" == typeof t ? n[t] : t instanceof n[ht] ? a[Number(t)] : je(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[ht] = se(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === D.Object) return t;
            const i = t => {
                const {constructor: e, flags: n} = r, i = e(t);
                if (!i) {
                    if (n & F && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, re(this.globalErrorSet, `${e}`, se(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r) : new ErrorExpected(r, t);
                }
                return i;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = i(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function An(t, e) {
        return Ae(t?.constructor?.child, e) && t["*"];
    }
    function In(t, e, n) {
        if (n & V) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & E && An(t, e.child)) return !0;
        }
        return !1;
    }
    $e({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: c, set: a} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), d = n.type === D.Void, g = r.structure.constructor, p = function() {
                this[_t](), this[Wt]?.("clear");
            }, b = this.createApplier(t), y = function(t, e) {
                if (Ie(t, v)) this[Yt](t), i & h && (l.call(this) || this[Wt]("copy", 0, t)); else if (t instanceof g[ht] && g(t)) a.call(this, t), 
                p.call(this); else if (void 0 !== t || d) try {
                    o.call(this, t, e), u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = g(t) ?? g.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure);
                        a.call(this, e), p.call(this);
                    } else if (je(t)) a.call(this, t), p.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === b.call(this, t)) throw e;
                    }
                }
            }, {bitOffset: m, byteSize: w} = n, v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw c.call(this);
                    return s.call(this);
                },
                set: y
            }, e[Xt] = se(y), e[Gt] = i & f && this.defineVivificatorStruct(t), e[_t] = this.defineResetter(m / 8, w), 
            e[Wt] = i & h && this.defineVisitorErrorUnion(n, l), v;
        }
    }), $e({
        defineFunction(t, n) {
            const {instance: {members: [r], template: i}, static: {template: s}} = t, o = new ObjectCache, {structure: {constructor: c}} = r, a = this, l = function(n) {
                const r = this instanceof l;
                let u, f;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new TypeMismatch("function", n);
                    if (c[ut] === e.VariadicStruct || !s) throw new Unsupported;
                    u = a.getFunctionThunk(n, s);
                } else {
                    if (this !== Ut) throw new NoCastingToFunction;
                    u = n;
                }
                if (f = o.find(u)) return f;
                const h = c.prototype.length, d = r ? a.createInboundCaller(n, c) : a.createOutboundCaller(i, c);
                return ie(d, {
                    length: se(h),
                    name: se(r ? n.name : "")
                }), Object.setPrototypeOf(d, l.prototype), d[st] = u, o.save(u, d), d;
            };
            return Object.setPrototypeOf(l.prototype, Function.prototype), n.valueOf = n.toJSON = se(Me), 
            l;
        },
        finalizeFunction(t, e, n) {
            n[Symbol.toStringTag] = void 0;
        }
    }), $e({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, i = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[Xt] = se((() => {
                throw new CreatingOpaque(t);
            })), i;
        }
    }), $e({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: c, set: a} = this.defineMember(r), l = n.type === D.Void, u = function(t, e) {
                Ie(t, d) ? (this[Yt](t), i & h && c.call(this) && this[Wt]("copy", et.Vivificate, t)) : null === t ? (a.call(this, 0), 
                this[_t]?.(), this[Wt]?.("clear")) : (void 0 !== t || l) && (o.call(this, t, e), 
                i & x ? a.call(this, 1) : i & h && (c.call(this) || a.call(this, 13)));
            }, d = t.constructor = this.createConstructor(t), {bitOffset: g, byteSize: p} = n;
            return e.$ = {
                get: function() {
                    return c.call(this) ? s.call(this) : (this[Wt]?.("clear"), null);
                },
                set: u
            }, e[Xt] = se(u), e[_t] = i & x && this.defineResetter(g / 8, p), e[Gt] = i & f && this.defineVivificatorStruct(t), 
            e[Wt] = i & h && this.defineVisitorOptional(n, c), d;
        }
    }), $e({
        definePointer(t, n) {
            const {flags: r, byteSize: i, instance: {members: [s]}} = t, {structure: o} = s, {type: c, flags: a, byteSize: l = 1} = o, f = r & M ? i / 2 : i, {get: h, set: d} = this.defineMember({
                type: D.Uint,
                bitOffset: 0,
                bitSize: 8 * f,
                byteSize: f,
                structure: {
                    byteSize: f
                }
            }), {get: p, set: b} = r & M ? this.defineMember({
                type: D.Uint,
                bitOffset: 8 * f,
                bitSize: 8 * f,
                byteSize: f,
                structure: {
                    flags: g,
                    byteSize: f
                }
            }) : {}, y = function(t, n = !0, i = !0) {
                if (n || this[st][at]) {
                    if (!i) return this[ot][0] = void 0;
                    {
                        const n = U.child, i = h.call(this), s = r & M ? p.call(this) : c === e.Slice && a & $ ? x.findSentinel(i, n[bt].bytes) + 1 : 1;
                        if (i !== this[xt] || s !== this[Mt]) {
                            const e = x.findMemory(t, i, s, n[Ot]), o = e ? n.call(Ut, e) : null;
                            return this[ot][0] = o, this[xt] = i, this[Mt] = s, r & M && (this[vt] = null), 
                            o;
                        }
                    }
                }
                return this[ot][0];
            }, m = function(t) {
                d.call(this, t), this[xt] = t;
            }, w = a & $ ? 1 : 0, v = r & M || a & $ ? function(t) {
                b?.call?.(this, t - w), this[Mt] = t;
            } : null, S = function() {
                const t = this[pt] ?? this, e = !t[ot][0], n = y.call(t, null, e);
                if (!n) {
                    if (r & C) return null;
                    throw new NullPointer;
                }
                return r & O ? Mn(n) : n;
            }, A = a & u ? function() {
                return S.call(this).$;
            } : S, I = r & O ? Fe : function(t) {
                return S.call(this).$ = t;
            }, x = this, T = function(n, i) {
                const s = o.constructor;
                if (An(n, s)) {
                    if (!(r & O) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[ot][0];
                } else if (r & V) In(n, s, r) && (n = s(n[ot][0][st])); else if (c === e.Slice && a & B && n) if (n.constructor[ut] === e.Pointer) n = n[mt]?.[st]; else if (n[st]) n = n[st]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof s) {
                    const e = n[Tt];
                    if (e) {
                        if (!(r & O)) throw new ReadOnlyTarget(t);
                        n = e;
                    }
                } else if (Ie(n, s)) n = s.call(Ut, n[st]); else if (r & E && r & V && n instanceof s.child) n = s(n[st]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[jt];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== ve(t, e.child)) return !0;
                    }
                    return !1;
                }(n, s)) {
                    n = s(x.extractView(o, n));
                } else if (null == n || n[st]) {
                    if (!(void 0 === n || r & C && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & E && r & V && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = s.prototype[kt];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (jt in s && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    n = new s(n, {
                        allocator: i
                    });
                }
                const l = n?.[st]?.[at];
                if (l?.address === be) throw new PreviouslyFreed(n);
                this[mt] = n;
            }, U = this.createConstructor(t);
            return n["*"] = {
                get: A,
                set: I
            }, n.$ = {
                get: Ve,
                set: T
            }, n.length = {
                get: function() {
                    const t = S.call(this);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = S.call(this);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[st], i = n[at];
                    let s;
                    if (!i) if (r & M) this[vt] ||= e.length, s = this[vt]; else {
                        s = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > s) throw new InvalidSliceLength(t, s);
                    const c = t * l, a = i ? x.obtainZigView(i.address, c) : x.obtainView(n.buffer, n.byteOffset, c), u = o.constructor;
                    this[ot][0] = u.call(Ut, a), v?.call?.(this, t);
                }
            }, n.slice = c === e.Slice && {
                value(t, e) {
                    const n = this[mt].slice(t, e);
                    return new U(n);
                }
            }, n.subarray = c === e.Slice && {
                value(t, e, n) {
                    const r = this[mt].subarray(t, e, n);
                    return new U(r);
                }
            }, n[Symbol.toPrimitive] = c === e.Primitive && {
                value(t) {
                    return this[mt][Symbol.toPrimitive](t);
                }
            }, n[Xt] = se(T), n[Qt] = {
                value() {
                    const t = c !== e.Pointer ? Vn : {};
                    let n;
                    c === e.Function ? (n = function() {}, n[st] = this[st], n[ot] = this[ot], Object.setPrototypeOf(n, U.prototype)) : n = this;
                    const r = new Proxy(n, t);
                    return Object.defineProperty(n, Vt, {
                        value: r
                    }), r;
                }
            }, n[mt] = {
                get: S,
                set: function(t) {
                    if (void 0 === t) return;
                    const e = this[pt] ?? this;
                    if (t) {
                        const n = t[st][at];
                        if (n) {
                            const {address: e, js: r} = n;
                            m.call(this, e), v?.call?.(this, t.length), r && (t[st][at] = void 0);
                        } else if (e[st][at]) throw new ZigMemoryTargetRequired;
                    } else e[st][at] && (m.call(this, 0), v?.call?.(this, 0));
                    e[ot][0] = t ?? null, r & M && (e[vt] = null);
                }
            }, n[qt] = se(y), n[At] = {
                set: m
            }, n[It] = {
                set: v
            }, n[Wt] = this.defineVisitor(), n[xt] = se(0), n[Mt] = se(0), n[vt] = r & M && se(null), 
            n.dataView = n.base64 = void 0, U;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: i, instance: {members: [s]}} = t, {structure: o} = s, {type: c, constructor: a} = o;
            n.child = a ? se(a) : {
                get: () => o.constructor
            }, n.const = se(!!(r & O)), n[te] = {
                value(n, s) {
                    if (this === Ut || this === ct || n instanceof i) return !1;
                    if (An(n, a)) return new i(a(n["*"]), s);
                    if (In(n, a, r)) return new i(n);
                    if (c === e.Slice) return new i(a(n), s);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    });
    const xn = new WeakMap;
    function Mn(t) {
        let e = xn.get(t);
        if (!e) {
            const n = t[pt];
            e = n ? new Proxy(n, En) : new Proxy(t, On), xn.set(t, e);
        }
        return e;
    }
    const Vn = {
        get(t, e) {
            if (e === pt) return t;
            if (e in t) return t[e];
            return t[mt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[mt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[mt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[mt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, En = {
        ...Vn,
        set(t, e, n) {
            if (e in t) Fe(); else {
                t[mt][e] = n;
            }
            return !0;
        }
    }, On = {
        get(t, e) {
            if (e === Tt) return t;
            {
                const n = t[e];
                return n?.[st] ? Mn(n) : n;
            }
        },
        set(t, e, n) {
            Fe();
        }
    };
    function Cn() {
        return this[It];
    }
    function $n(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function Tn() {
        throw new InaccessiblePointer;
    }
    function Un() {
        const t = {
            get: Tn,
            set: Tn
        };
        ie(this[pt], {
            "*": t,
            $: t,
            [pt]: t,
            [mt]: t
        });
    }
    function zn(t, e, n, r) {
        let i, s = this[ot][t];
        if (!s) {
            if (n & et.IgnoreUncreated) return;
            s = this[Gt](t);
        }
        r && (i = r[ot][t], !i) || s[Wt](e, n, i);
    }
    $e({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: i, set: s} = this.defineMember(n), o = function(e) {
                if (Ie(e, c)) this[Yt](e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = ce(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && s.call(this, e);
            }, c = this.createConstructor(t);
            return e.$ = {
                get: i,
                set: o
            }, e[Xt] = se(o), e[Symbol.toPrimitive] = se(i), c;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[Ct] = se(n.bitSize), e[Bt] = se(n.type);
        }
    }), $e({
        defineSlice(t, e) {
            const {align: n, flags: r, byteSize: i, name: s, instance: {members: [o]}} = t, {byteSize: c, structure: a} = o, l = this, u = function(t, e, r) {
                t || (t = l.allocateMemory(e * c, n, r)), this[st] = t, this[It] = e;
            }, d = function(e, n) {
                if (n !== this[It]) throw new ArrayLengthMismatch(t, this, e);
            }, g = this.defineMember(o), {set: p} = g, b = this.createApplier(t), y = function(e, n) {
                if (Ie(e, w)) this[st] ? d.call(this, e, e.length) : u.call(this, null, e.length, n), 
                this[Yt](e), r & h && this[Wt]("copy", et.Vivificate, e); else if ("string" == typeof e && r & T) y.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = we(e), this[st] ? d.call(this, e, e.length) : u.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) w[bt]?.validateValue(r, t, e.length), p.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[st] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[st]);
                    u.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === b.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, m = function(t, e) {
                const n = this[It], r = this[st];
                t = void 0 === t ? 0 : $n(t, n), e = void 0 === e ? n : $n(e, n);
                const i = t * c, s = e * c - i;
                return l.obtainView(r.buffer, r.byteOffset + i, s);
            }, w = this.createConstructor(t);
            return e.$ = {
                get: Ve,
                set: y
            }, e.length = {
                get: Cn
            }, r & U && (e.typedArray = this.defineTypedArray(t), r & T && (e.string = this.defineString(t)), 
            r & z && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[wt] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = m.call(this, t, e);
                    return w(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: i = !1} = r, s = m.call(this, t, e), o = l.allocateMemory(s.byteLength, n, i), c = w(o);
                    return c[Yt]({
                        [st]: s
                    }), c;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[Ht] = se(u), e[Yt] = this.defineCopier(i, !0), 
            e[Xt] = se(y), e[Qt] = this.defineFinalizerArray(g), e[Gt] = r & f && this.defineVivificatorArray(t), 
            e[Wt] = r & h && this.defineVisitorArray(), w;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = se(r.structure.constructor), e[bt] = n & $ && this.defineSentinel(t);
        }
    }), $e({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === D.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: i, byteSize: s, structure: {constructor: o}} = e, c = this[st], a = c.byteOffset + (i >> 3);
                    let l = s;
                    if (void 0 === l) {
                        if (7 & i) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(c.buffer, a, l);
                    return this[ot][t] = o.call(ct, u);
                }
            };
        }
    }), $e({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: i, instance: {members: c}} = t, a = c.find((t => t.flags & G)), l = a && this.defineMember(a), u = this.createApplier(t), d = function(e, n) {
                if (Ie(e, g)) this[Yt](e), r & h && this[Wt]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            }, g = this.createConstructor(t), p = e[kt].value, b = e[St].value, y = [];
            for (const t of c.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: i} = e[n] = this.defineMember(t);
                i && (r & Z && (i.required = !0), p[n] = i, b.push(n)), y.push(n);
            }
            return e.$ = {
                get: Me,
                set: d
            }, e.length = se(i), e.entries = r & w.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & w.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[Xt] = se(d), e[Gt] = r & f && this.defineVivificatorStruct(t), e[Wt] = r & h && this.defineVisitorStruct(c), 
            e[wt] = r & w.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[gt] = se(y), n === s && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), g;
        }
    }), $e({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: i}} = t, s = !!(r & v), c = s ? i.slice(0, -1) : i, a = s ? i[i.length - 1] : null, {get: l, set: u} = this.defineMember(a), {get: d} = this.defineMember(a, !1), g = r & S ? function() {
                return l.call(this)[lt];
            } : function() {
                const t = l.call(this);
                return c[t].name;
            }, p = r & S ? function(t) {
                const {constructor: e} = a.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = c.findIndex((e => e.name === t));
                u.call(this, e);
            }, b = this.createApplier(t), y = function(e, n) {
                if (Ie(e, m)) this[Yt](e), r & h && this[Wt]("copy", et.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of M) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === b.call(this, e, n)) throw new MissingUnionInitializer(t, e, s);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            }, m = this.createConstructor(t), w = {}, I = e[kt].value, x = e[St].value, M = [];
            for (const n of c) {
                const {name: i} = n, {get: o, set: c} = this.defineMember(n), a = s ? function() {
                    const e = g.call(this);
                    if (i !== e) {
                        if (r & S) return null;
                        throw new InactiveUnionProperty(t, i, e);
                    }
                    return this[Wt]?.("clear"), o.call(this);
                } : o, l = s && c ? function(e) {
                    const n = g.call(this);
                    if (i !== n) throw new InactiveUnionProperty(t, i, n);
                    c.call(this, e);
                } : c, u = s && c ? function(t) {
                    p.call(this, i), c.call(this, t), this[Wt]?.("clear");
                } : c;
                e[i] = {
                    get: a,
                    set: l
                }, I[i] = u, w[i] = o, x.push(i), M.push(i);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: y
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & S && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return g.call(this);

                      default:
                        return d.call(this);
                    }
                }
            };
            const {comptime: V} = this;
            return e[Kt] = r & A && {
                value() {
                    return V || this[Wt](Un), this[Wt] = Oe, this;
                }
            }, e[Xt] = se(y), e[dt] = r & S && {
                get: l,
                set: u
            }, e[Gt] = r & f && this.defineVivificatorStruct(t), e[Wt] = r & h && this.defineVisitorUnion(c, r & S ? d : null), 
            e[wt] = this.defineUnionEntries(), e[gt] = r & S ? {
                get() {
                    return [ g.call(this) ];
                }
            } : se(M), e[Ft] = se(w), m;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & S && (e.tag = se(r[r.length - 1].structure.constructor));
        }
    }), $e({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: i, length: s, instance: {members: o}} = t, c = this, a = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[st] = c.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = c.littleEndian;
            };
            return ie(u, {
                [$t]: {
                    value: 4
                }
            }), ie(u.prototype, {
                set: se((function(t, e, n, r, i) {
                    const s = this[st], o = c.littleEndian;
                    s.setUint16(8 * t, e, o), s.setUint16(8 * t + 2, n, o), s.setUint16(8 * t + 4, r, o), 
                    s.setUint8(8 * t + 6, i == D.Float), s.setUint8(8 * t + 7, i == D.Int || i == D.Float);
                }))
            }), e[Gt] = i & f && this.defineVivificatorStruct(t), e[Wt] = this.defineVisitorVariadicStruct(o), 
            e[ee] = se((function(t) {
                l.call(this, t, this[Dt]);
            })), function(t) {
                if (t.length < s) throw new ArgumentCountMismatch(s, t.length, !0);
                let e = n, i = r;
                const o = t.slice(s), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[st], o = n?.constructor?.[$t];
                    if (!r || !o) {
                        throw ze(new InvalidVariadicArgument, s + t);
                    }
                    o > i && (i = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = c.allocateMemory(e, i);
                h[$t] = i, this[st] = h, this[ot] = {}, c.copyArguments(this, t, a);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: i, structure: {align: s}}] of a.entries()) f.set(t, e / 8, n, s, r), 
                i > d && (d = i);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[st], i = l[t], o = c.obtainView(h.buffer, i, r), a = this[ot][n] = e.constructor.call(ct, o), u = e.constructor[Ct] ?? 8 * r, g = e.constructor[$t], p = e.constructor[Bt];
                    a.$ = e, f.set(s + t, i, u, g, p);
                }
                this[zt] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[Nt] = se(!!(n & P)), e[$t] = se(void 0);
        }
    }), $e({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [i]}} = t, s = this.createApplier(t), o = function(e) {
                if (Ie(e, c)) this[Yt](e), n & h && this[Wt]("copy", et.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) this[i++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, c = this.createConstructor(t, {
                initializer: o
            }), {bitSize: a} = i;
            for (let t = 0, s = 0; t < r; t++, s += a) e[t] = n & h ? this.defineMember({
                ...i,
                slot: t
            }) : this.defineMember({
                ...i,
                bitOffset: s
            });
            return e.$ = {
                get: Me,
                set: o
            }, e.length = se(r), n & k && (e.typedArray = this.defineTypedArray(t), n & j && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[wt] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[Xt] = se(o), e[Gt] = n & f && this.defineVivificatorArray(t), e[Wt] = n & h && this.defineVisitorArray(), 
            c;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = se(n.structure.constructor);
        }
    }), $e({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? Bn[t] : t, r.call(this, e, n);
            }
        })
    });
    const Bn = {
        copy(t, e) {
            const n = e[ot][0];
            if (this[st][at] && n && !n[st][at]) throw new ZigMemoryTargetRequired;
            this[ot][0] = n;
        },
        clear(t) {
            t & et.IsInactive && (this[ot][0] = void 0);
        },
        reset() {
            this[ot][0] = void 0, this[xt] = void 0;
        }
    };
    return $e({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: i, structure: s}] of t.entries()) s.flags & h && (0 === r ? n = i : e.push(i));
            return {
                value(t, r, i) {
                    if (!(r & et.IgnoreArguments) && e.length > 0) for (const n of e) zn.call(this, n, t, r | et.IsImmutable, i);
                    r & et.IgnoreRetval || void 0 === n || zn.call(this, n, t, r, i);
                }
            };
        }
    }), $e({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, i = this.length; r < i; r++) zn.call(this, r, t, e, n);
            }
        })
    }), $e({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) && (r |= et.IsInactive), r & et.IsInactive && r & et.IgnoreInactive || zn.call(this, n, t, r, i);
                }
            };
        }
    }), $e({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) || (r |= et.IsInactive), r & et.IsInactive && r & et.IgnoreInactive || zn.call(this, n, t, r, i);
                }
            };
        }
    }), $e({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & h)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const i of e) zn.call(this, i, t, n, r);
                }
            };
        }
    }), $e({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: i}] of t.entries()) i?.flags & h && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, i) {
                    const s = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== s && (n |= et.IsInactive), n & et.IsInactive && n & et.IgnoreInactive || zn.call(this, o, t, n, i);
                    }
                }
            };
        }
    }), $e({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & h ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & et.IgnoreArguments)) for (const [i, s] of Object.entries(this[ot])) i !== n && Wt in s && zn.call(this, i, t, e | et.IsImmutable, r);
                    e & et.IgnoreRetval || void 0 === n || zn.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (Te());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
