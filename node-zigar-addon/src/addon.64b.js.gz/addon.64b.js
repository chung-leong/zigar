(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, i = 3, s = 4, o = 5, a = 6, c = 7, l = 8, u = 9, f = Object.keys(e), h = 1, d = 2, g = 4, p = 8, y = 16, m = 16, b = 32, w = 64, v = 128, S = {
        IsExtern: 16,
        IsPacked: 32,
        IsTuple: 64,
        IsOptional: 128
    }, A = 16, I = 32, x = 64, M = 16, E = 16, V = 16, U = 32, O = 64, B = 128, $ = 256, k = 16, C = 32, z = 64, T = 128, F = 256, j = 16, L = 16, N = 32, P = 16, _ = 32, D = 64, R = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, W = Object.keys(R), Z = 1, q = 2, J = 4, G = 16, H = 64, Y = 128, X = 1, K = 2, Q = 4, tt = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, et = 0, nt = 8, rt = 16, it = 20, st = 21, ot = 28, at = 29, ct = 44, lt = {
        unknown: 0,
        blockDevice: 1,
        characterDevice: 2,
        directory: 3,
        file: 4,
        socketDgram: 5,
        socketStream: 6,
        symbolicLink: 7
    }, ut = {
        create: 1,
        directory: 2,
        exclusive: 4,
        truncate: 8
    }, ft = {
        symlinkFollow: 1
    }, ht = {
        fd_datasync: 1,
        fd_read: 2,
        fd_seek: 4,
        fd_fdstat_set_flags: 8,
        fd_sync: 16,
        fd_tell: 32,
        fd_write: 64,
        fd_advise: 128,
        fd_allocate: 256,
        path_create_directory: 512,
        path_create_file: 1024,
        path_link_source: 2048,
        path_link_target: 4096,
        path_open: 8192,
        fd_readdir: 16384,
        path_readlink: 32768,
        path_rename_source: 65536,
        path_rename_target: 1 << 17,
        path_filestat_get: 1 << 18,
        path_filestat_set_size: 1 << 19,
        path_filestat_set_times: 1 << 20,
        fd_filestat_get: 1 << 21,
        fd_filestat_set_size: 1 << 22,
        fd_filestat_set_times: 1 << 23,
        path_symlink: 1 << 24,
        path_remove_directory: 1 << 25,
        path_unlink_file: 1 << 26,
        poll_fd_readwrite: 1 << 27,
        sock_shutdown: 1 << 28,
        sock_accept: 1 << 29
    }, dt = {
        append: 1,
        dsync: 2,
        nonblock: 4,
        rsync: 8,
        sync: 16
    }, gt = 1, pt = 2, yt = -1, mt = 1048575, bt = globalThis[Symbol.for("ZIGAR")] ||= {};
    function wt(t) {
        return bt[t] ||= Symbol(t);
    }
    function vt(t) {
        return wt(t);
    }
    const St = vt("memory"), At = vt("slots"), It = vt("parent"), xt = vt("zig"), Mt = vt("name"), Et = vt("type"), Vt = vt("flags"), Ut = vt("class"), Ot = vt("tag"), Bt = vt("props"), $t = vt("pointer"), kt = vt("sentinel"), Ct = vt("array"), zt = vt("target"), Tt = vt("entries"), Ft = vt("max length"), jt = vt("keys"), Lt = vt("address"), Nt = vt("length"), Pt = vt("last address"), _t = vt("last length"), Dt = vt("proxy"), Rt = vt("cache"), Wt = vt("size"), Zt = vt("bit size"), qt = vt("align"), Jt = vt("const target"), Gt = vt("environment"), Ht = vt("attributes"), Yt = vt("primitive"), Xt = vt("getters"), Kt = vt("setters"), Qt = vt("typed array"), te = vt("throwing"), ee = vt("promise"), ne = vt("generator"), re = vt("allocator"), ie = vt("fallback"), se = vt("signature"), oe = vt("string retval"), ae = vt("update"), ce = vt("reset"), le = vt("vivificate"), ue = vt("visit"), fe = vt("copy"), he = vt("shape"), de = vt("initialize"), ge = vt("restrict"), pe = vt("finalize"), ye = vt("cast"), me = vt("return"), be = vt("yield");
    function we(t, e, n) {
        if (n) {
            const {set: r, get: i, value: s, enumerable: o, configurable: a = !0, writable: c = !0} = n;
            Object.defineProperty(t, e, i || r ? {
                get: i,
                set: r,
                configurable: a,
                enumerable: o
            } : {
                value: s,
                configurable: a,
                enumerable: o,
                writable: c
            });
        }
        return t;
    }
    function ve(t, e) {
        for (const [n, r] of Object.entries(e)) we(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            we(t, n, e[n]);
        }
        return t;
    }
    function Se(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function Ae(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function Ie({type: t, bitSize: e}) {
        switch (t) {
          case R.Bool:
            return "boolean";

          case R.Int:
          case R.Uint:
            if (e > 32) return "bigint";

          case R.Float:
            return "number";
        }
    }
    function xe(t, e = "utf-8") {
        const n = Ee[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let i = 0;
            for (const e of t) r.set(e, i), i += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function Me(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (Ve[e] ||= new TextEncoder).encode(t);
    }
    const Ee = {}, Ve = {};
    function Ue(t, e, n) {
        let r = 0, i = t.length;
        if (0 === i) return 0;
        for (;r < i; ) {
            const s = Math.floor((r + i) / 2);
            n(t[s]) <= e ? r = s + 1 : i = s;
        }
        return i;
    }
    const Oe = function(t, e) {
        return !!e && !!(t & BigInt(e - 1));
    }, Be = function(t, e) {
        return t + BigInt(e - 1) & ~BigInt(e - 1);
    }, $e = 0xFFFFFFFFFFFFFFFFn, ke = -1n, Ce = function(t) {
        return BigInt(t);
    }, ze = function(t, e) {
        return t + BigInt(e);
    };
    function Te(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function Fe(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function je(t, e) {
        const n = [], r = new Map, i = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) i(n);
        };
        for (const e of t) i(e.instance.template), i(e.static.template);
        return n;
    }
    function Le(t, e) {
        return t === e || t?.[se] === e[se] && t?.[Gt] !== e?.[Gt];
    }
    function Ne(t, e) {
        return t instanceof e || Le(t?.constructor, e);
    }
    function Pe(t, e) {
        return "function" == typeof t?.[e];
    }
    function _e(t) {
        return "function" == typeof t?.then;
    }
    function De(t, e) {
        const n = {};
        for (const [r, i] of Object.entries(e)) t & i && (n[r] = !0);
        return n;
    }
    function Re(t, e) {
        for (const [n, r] of Object.entries(e)) if (n === t) return r;
    }
    function We({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function Ze(t) {
        return new DataView(new ArrayBuffer(t));
    }
    function qe() {
        return this;
    }
    function Je() {
        return this[Dt];
    }
    function Ge() {
        return String(this);
    }
    function He() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return this.map.get(t);
        }
        save(t, e) {
            return this.map.set(t, e), e;
        }
    }
    const Ye = 1, Xe = 2, Ke = 4, Qe = 8, tn = () => 1e3 * new Date;
    function en(t, e, n) {
        const r = {};
        return n & Ye ? r.atime = t : n & Xe && (r.atime = tn()), n & Ke ? r.mtime = e : n & Qe && (r.mtime = tn()), 
        r;
    }
    const nn = {
        name: "",
        mixins: []
    };
    function rn(t) {
        return nn.mixins.includes(t) || nn.mixins.push(t), t;
    }
    function sn() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: i} = r;
            we(r, "name", Se(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = i[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                we(i, e, Se(r));
            }
            return r;
        }(nn.name, nn.mixins);
    }
    function on(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, i) {
                const s = n.getUint8(i) >> t & r;
                e.setUint8(0, s);
            };
            {
                const e = 255 ^ r << t;
                return function(n, i, s) {
                    const o = i.getUint8(0), a = n.getUint8(s) & e | (o & r) << t;
                    n.setUint8(s, a);
                };
            }
        }
        {
            const r = 8 - t, i = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(s, o, a) {
                    let c, l = a, u = 0, f = o.getUint8(l++), h = f >> t & i, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), c = g >= 8 ? 255 & h : h & n, s.setUint8(u++, c), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, s = 255 ^ i << t, o = 255 ^ n;
                return function(r, i, a) {
                    let c, l, u = 0, f = a, h = r.getUint8(f), d = h & s, g = t, p = e + g;
                    do {
                        p > g && (c = i.getUint8(u++), d |= c << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    rn({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: i, byteSize: s} = e, o = [], a = void 0 === s && (7 & r || 7 & i);
            a && o.push("Unaligned");
            let c = W[n];
            r > 32 && (n === R.Int || n === R.Uint) && (c = r <= 64 ? `Big${c}` : `Jumbo${c}`), 
            o.push(c, `${n === R.Bool && s ? 8 * s : r}`), a && o.push(`@${i}`);
            const l = t + o.join("");
            let u = DataView.prototype[l];
            if (u && this.usingBufferFallback()) {
                const e = this, i = u, s = function(t) {
                    const {buffer: e, byteOffset: n, byteLength: i} = this, s = e[ie];
                    if (s) {
                        if (t < 0 || t + r / 8 > i) throw new RangeError("Offset is outside the bounds of the DataView");
                        return s + Ce(n + t);
                    }
                };
                u = "get" === t ? function(t, o) {
                    const a = s.call(this, t);
                    return void 0 !== a ? e.getNumericValue(n, r, a) : i.call(this, t, o);
                } : function(t, o, a) {
                    const c = s.call(this, t);
                    return void 0 !== c ? e.setNumericValue(n, r, c, o) : i.call(this, t, o, a);
                };
            }
            if (u) return u;
            if (u = this.accessorCache.get(l), u) return u;
            for (;o.length > 0; ) {
                const n = `getAccessor${o.join("")}`;
                if (u = this[n]?.(t, e)) break;
                o.pop();
            }
            if (!u) throw new Error(`No accessor available: ${l}`);
            return we(u, "name", Se(l)), this.accessorCache.set(l, u), u;
        },
        imports: {
            getNumericValue: null,
            setNumericValue: null
        }
    }), rn({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), i = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & i) - (n & r);
            } : function(t, e, n) {
                const s = e < 0 ? r | e & i : e & i;
                this.setBigUint64(t, s, n);
            };
        }
    }), rn({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const i = e & r;
                this.setBigUint64(t, i, n);
            };
        }
    }), rn({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, i = this.getAccessor(t, {
                type: R.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!i.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, s) {
                    i.call(this, n, r ? e : t, s);
                };
            }
        }
    }), rn({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = Ze(8), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, a = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(a), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, a = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : s ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | c << 52n | (a >> 60n) + BigInt((a & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, a = (0x7ff0000000000000n & i) >> 52n, c = 0x000fffffffffffffn & i;
                let l;
                l = 0n === a ? o << 127n | c << 60n : 0x07ffn === a ? o << 127n | 0x7fffn << 112n | (c ? 1n : 0n) : o << 127n | a - 1023n + 16383n << 112n | c << 60n, 
                s.call(this, t, l, n);
            };
        }
    }), rn({
        getAccessorFloat16(t, e) {
            const n = Ze(4), r = DataView.prototype.setUint16, i = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = i.call(this, t, e), s = r >>> 15, o = (31744 & r) >> 10, a = 1023 & r;
                if (0 === o) return s ? -0 : 0;
                if (31 === o) return a ? NaN : s ? -1 / 0 : 1 / 0;
                const c = s << 31 | o - 15 + 127 << 23 | a << 13;
                return n.setUint32(0, c, e), n.getFloat32(0, e);
            } : function(t, e, i) {
                n.setFloat32(0, e, i);
                const s = n.getUint32(0, i), o = s >>> 31, a = (2139095040 & s) >> 23, c = 8388607 & s, l = a - 127 + 15;
                let u;
                u = 0 === a ? o << 15 : 255 === a ? o << 15 | 31744 | (c ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | c >> 13, 
                r.call(this, t, u, i);
            };
        }
    }), rn({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = Ze(8), i = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, s = function(t, e, r) {
                const i = 0xffffffffn & e, s = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(i), r), this.setUint32(t + (r ? 4 : n - 8), Number(s), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = i.call(this, t, e), s = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, a = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return s ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : s ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return s ? -t : t;
                }
                const l = s << 63n | c << 52n | (a >> 11n) + BigInt((a & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const i = r.getBigUint64(0, n), o = i >> 63n, a = (0x7ff0000000000000n & i) >> 52n, c = 0x000fffffffffffffn & i;
                let l;
                l = 0n === a ? o << 79n | c << 11n : 0x07ffn === a ? o << 79n | 0x7fffn << 64n | (c ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | a - 1023n + 16383n << 64n | c << 11n | 0x00008000000000000000n, 
                s.call(this, t, l, n);
            };
        }
    }), rn({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: R.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), i = 2 ** (n - 1), s = i - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & s) - (r & i);
                } : function(t, n, r) {
                    const o = n < 0 ? i | n & s : n & s;
                    e.call(this, t, o, r);
                };
            }
        }
    }), rn({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n - 1), s = i - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & s) - (n & i);
            } : function(t, e, n) {
                const o = e < 0 ? i | e & s : e & s;
                r.call(this, t, o, n);
            };
        }
    }), rn({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), i = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & i;
            } : function(t, e, n) {
                const s = e & i;
                r.call(this, t, s, n);
            };
        }
    }), rn({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let i = 0, s = t + 8 * (n - 1); i < n; i++, s -= 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                } else for (let i = 0, s = t; i < n; i++, s += 8) {
                    r = r << 64n | this.getBigUint64(s, e);
                }
                return r;
            } : function(t, e, r) {
                let i = e;
                const s = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = i & s;
                    this.setBigUint64(o, t, r), i >>= 64n;
                }
            };
        }
    }), rn({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const i = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), s = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return i.call(this, t, e) & s;
                } : function(t, e, n) {
                    const r = e & s;
                    i.call(this, t, r, n);
                };
            }
        }
    }), rn({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), i = e ? n | r : n & ~r;
                this.setInt8(t, i);
            };
        }
    }), rn({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> i;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << i;
                    return function(n, s) {
                        let o = this.getUint8(n);
                        o = o & t | (s < 0 ? e | s & r : s & r) << i, this.setUint8(n, o);
                    };
                }
            }
        }
    }), rn({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r;
            if (i + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> i & e;
                };
                {
                    const t = 255 ^ e << i;
                    return function(n, r) {
                        const s = this.getUint8(n) & t | (r & e) << i;
                        this.setUint8(n, s);
                    };
                }
            }
        }
    }), rn({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, i = 7 & r, s = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = Ze(s);
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: s
                }), r = on(i, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: s
                }), r = on(i, n, !1);
                return function(e, n, i) {
                    t.call(o, 0, n, i), r(this, o, e);
                };
            }
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: i, type: s, byteSize: o} = t, a = n.byteLength, c = 1 !== o ? "s" : "";
            let l;
            if (s !== e.Slice || r) {
                l = `${i} has ${s === e.Slice ? r.length * o : o} byte${c}, received ${a}`;
            } else l = `${i} has elements that are ${o} byte${c} in length, received ${a}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: i} = t, s = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(yn);
            let a;
            i && o.push(yn(i.name)), a = n === e.Slice ? `Expecting ${bn(o)} that can accommodate items ${r} byte${s} in length` : `Expecting ${bn(o)} that is ${r} byte${s} in length`, 
            super(a);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let i;
            "string" === r || "number" === r || gn(e) ? (gn(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            i = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : i = `Error of the type ${n} expected, received ${e}`, 
            super(i);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Error given is not a part of error set ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: i}} = t;
            super(`${r} needs an initializer for one of its union properties: ${i.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, i = [];
            if (Array.isArray(e)) for (const t of e) i.push(yn(t)); else i.push(yn(e));
            const s = pn(n);
            super(`${r} expects ${bn(i)} as argument, received ${s}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [i]}, type: s, constructor: o} = t, a = [], c = Ie(i);
            if (c) {
                let t;
                switch (i.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = c;
                }
                a.push(`array of ${t}s`);
            } else a.push("array of objects");
            o[Qt] && a.push(o[Qt].name), s === e.Slice && r && a.push("length"), super(t, a.join(" or "), n);
        }
    }
    class InvalidEnumValue extends TypeError {
        code=ot;
        constructor(t, e) {
            super(`Received '${e}', which is not among the following possible values:\n\n${Object.keys(t).map((t => `${t}\n`)).join("")}`);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: i, instance: {members: [s]}} = t, {structure: {constructor: o}} = s, {length: a, constructor: c} = n, l = e?.length ?? i, u = 1 !== l ? "s" : "";
            let f;
            f = c === o ? "only a single one" : c.child === o ? `a slice/array that has ${a}` : `${a} initializer${a > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let i;
            i = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(i);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const i = 1 !== (t -= r) ? "s" : "", s = n ? "at least " : "";
                this.message = `Expecting ${s}${t} argument${i}, received ${e}`, this.stack = ln(this.stack, "new Arg(");
            };
            r(0), we(this, ae, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: i} = t;
            super(`${i} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    let an = class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = pn(e);
            super(`Expected ${yn(t)}, received ${n}`);
        }
    };
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${mn(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + W[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class InvalidFileDescriptor extends Error {
        code=nt;
        constructor() {
            super("Invalid file descriptor");
        }
    }
    class InvalidArgument extends Error {
        code=ot;
        constructor() {
            super("Invalid argument");
        }
    }
    class Deadlock extends Error {
        code=rt;
        constructor() {
            super("Unable to await promise");
        }
    }
    class MissingEventListener extends Error {
        constructor(t, e) {
            super(`Missing event listener: ${t}`), this.code = e;
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = ln(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function cn(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = ln(t.stack, "new Arg(");
        };
        return n(0), we(t, ae, {
            value: n,
            enumerable: !1
        }), t;
    }
    function ln(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function un() {
        throw new ReadOnly;
    }
    function fn(t, e, n) {
        if (t.bytes += n, t.calls++, 100 === t.calls) {
            const n = t.bytes / t.calls;
            if (n < 8) {
                throw new Error(`Inefficient ${e} access. Each call is only ${"read" === e ? "reading" : "writing"} ${n} byte${1 !== n ? "s" : ""}. Please use std.io.Buffered${"read" === e ? "Reader" : "Writer"}.`);
            }
        }
    }
    function hn(t = !1, e, n, r, i) {
        const s = t => (i ? i(t) : console.error(t)) ?? t.code ?? e, o = t => {
            const e = r?.(t);
            return e ?? et;
        };
        try {
            const e = n();
            if (_e(e)) {
                if (!t) throw new Deadlock;
                return e.then(o).catch(s);
            }
            return o(e);
        } catch (t) {
            return s(t);
        }
    }
    function dn(t, e) {
        if (!0 === t) return et;
        if (!1 === t) return e;
        throw new an("boolean", t);
    }
    function gn(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function pn(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        yn(n);
    }
    function yn(t) {
        return `${mn(t)} ${t}`;
    }
    function mn(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function bn(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function wn(t) {
        let n, r = 1, i = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[xt]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[St]) t.constructor[Et] === e.Pointer && (t = t["*"]), 
        n = t[St], i = t.constructor, r = i[qt]; else {
            "string" == typeof t && (t = Me(t));
            const {buffer: e, byteOffset: i, byteLength: s, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== i && void 0 !== s && (n = new DataView(e, i, s), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: i
        };
    }
    rn({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: i}, ptr: s} = this, o = i(s, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const a = o["*"][St];
                return a[xt].align = e, a;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = wn(e), i = n?.[xt];
                    if (!i) throw new an("object containing allocated Zig memory", e);
                    const {address: s} = i;
                    if (s === ke) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: a} = this;
                    o(a, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe() {
            const t = this.getCopyFunction();
            return {
                value(e) {
                    const {dv: n, align: r, constructor: i} = wn(e);
                    if (!n) throw new an("string, DataView, typed array, or Zig object", e);
                    const s = this.alloc(n.byteLength, r);
                    return t(s, n), i ? i(s) : s;
                }
            };
        }
    }), rn({
        init() {
            this.variables = [], this.listenerMap = new Map([ [ "log", t => console.log(t.message) ] ]);
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: (...t) => this.initialize?.(...t),
                abandon: () => this.abandonModule?.(),
                redirect: (t, e) => this.redirectStream(t, e),
                sizeOf: e => t(e?.[Wt]),
                alignOf: e => t(e?.[qt]),
                typeOf: e => vn[t(e?.[Et])],
                on: (t, e) => this.addListener(t, e)
            };
        },
        addListener(t, e) {
            this.listenerMap.set(t, e), this.setRedirectionMask(t, !!e);
        },
        triggerEvent(t, e, n) {
            const r = this.listenerMap.get(t);
            if (r) return r(e);
            if (n) throw new MissingEventListener(t, n);
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = i(r);
                return t;
            }, r = t => t.length ? t.buffer : new ArrayBuffer(0), i = t => {
                const {memory: e, structure: i, actual: s} = t;
                if (e) {
                    if (s) return s;
                    {
                        const {array: s, offset: o, length: a} = e, c = this.obtainView(r(s), o, a), {handle: l, const: u} = t, f = i?.constructor, h = t.actual = f.call(Gt, c);
                        return u && this.makeReadOnly(h), t.slots && n(h[At], t.slots), l && this.variables.push({
                            handle: l,
                            object: h
                        }), h;
                    }
                }
                return i;
            }, s = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: i} = t.template, o = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: s} = n;
                        o[St] = this.obtainView(r(t), e, s), i && this.variables.push({
                            handle: i,
                            object: o
                        });
                    }
                    if (e) {
                        const t = o[At] = {};
                        s.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of s) n(t, e);
            for (const e of t) this.finalizeStructure(e);
        }
    });
    const vn = f.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    rn({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[St]), i = this.createJsThunk(t, n);
                if (!i) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(i, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                try {
                    const i = e(n);
                    if (ue in i) {
                        i[ue]("reset");
                        const t = this.startContext();
                        this.updatePointerTargets(t, i, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const s = i.hasOwnProperty(me), o = hn(r || s, st, (() => t(...i)), (t => {
                        if (t?.[Symbol.asyncIterator]) {
                            if (!i.hasOwnProperty(be)) throw new UnexpectedGenerator;
                            this.pipeContents(t, i);
                        } else i[me](t);
                    }), (t => {
                        try {
                            if (e[te] && t instanceof Error) return i[me](t), et;
                            throw t;
                        } catch (e) {
                            console.error(t);
                        }
                    }));
                    return s ? et : o;
                } catch (t) {
                    return console.error(t), st;
                }
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, a = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === s)).length;
            return {
                value() {
                    let c, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, y, m = this[d];
                        if (p === R.Object && m?.[St]?.[xt] && (m = new m.constructor(m)), g.type === e.Struct) switch (g.purpose) {
                          case s:
                            t = 1 === a ? "allocator" : "allocator" + ++l, y = this[re] = m;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (y = o.createPromiseCallback(this, m));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (y = o.createGeneratorCallback(this, m));
                            break;

                          case i:
                            t = "signal", 1 == ++f && (y = o.createInboundSignal(m));
                        }
                        void 0 !== t ? void 0 !== y && (c ||= {}, c[t] = y) : h.push(m);
                    } catch (t) {
                        h.push(t);
                    }
                    return c && h.push(c), h[Symbol.iterator]();
                }
            };
        },
        handleJscall(t, e, n, r) {
            const i = this.obtainZigView(e, n, !1), s = this.jsFunctionCallerMap.get(t);
            return s ? s(i, r) : st;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[St]), i = this.getViewAddress(e);
                this.destroyJsThunk(r, i), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJscall: {
                async: !0
            },
            releaseFunction: {}
        },
        imports: {
            createJsThunk: {},
            destroyJsThunk: {},
            finalizeAsyncCall: {}
        }
    }), rn({
        createOutboundCaller(t, e) {
            const n = this, r = function(...i) {
                const s = new e(i, this?.[re]);
                return n.invokeThunk(t, r, s);
            };
            return r;
        },
        copyArguments(t, o, f, h, d) {
            let g = 0, p = 0, y = 0;
            const m = t[Kt];
            for (const {type: b, structure: w} of f) {
                let f, v, S, A;
                if (w.type === e.Struct) switch (w.purpose) {
                  case s:
                    f = (1 == ++y ? h?.allocator ?? h?.allocator1 : h?.[`allocator${y}`]) ?? this.createDefaultAllocator(t, w);
                    break;

                  case n:
                    v ||= this.createPromise(w, t, h?.callback), f = v;
                    break;

                  case r:
                    S ||= this.createGenerator(w, t, h?.callback), f = S;
                    break;

                  case i:
                    A ||= this.createSignal(w, h?.signal), f = A;
                    break;

                  case a:
                    f = this.createReader(o[p++]);
                    break;

                  case c:
                    f = this.createWriter(o[p++]);
                    break;

                  case l:
                    f = this.createFile(o[p++]);
                    break;

                  case u:
                    f = this.createDirectory(o[p++]);
                }
                if (void 0 === f && (f = o[p++], void 0 === f && b !== R.Void)) throw new UndefinedArgument;
                try {
                    m[g++].call(t, f, d);
                } catch (t) {
                    throw cn(t, g - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), i = n[Ht], s = this.getViewAddress(t[St]), o = this.getViewAddress(e[St]), a = pe in n, c = ue in n;
            c && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[St]), u = i ? this.getViewAddress(i[St]) : 0;
            this.updateShadows(r);
            const f = () => {
                this.updateShadowTargets(r), c && this.updatePointerTargets(r, n), this.flushStreams?.(), 
                this.endContext();
            };
            a && (n[pe] = f);
            if (!(i ? this.runVariadicThunk(s, o, l, u, i.length) : this.runThunk(s, o, l))) throw f(), 
            new ZigError;
            if (a) {
                let t = null;
                try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (e[oe] && t && (t = t.string), n[me](t)) : e[oe] && (n[oe] = !0), 
                n[ee] ?? n[ne];
            }
            f();
            try {
                const {retval: t} = n;
                return e[oe] && t ? t.string : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    }), rn({
        init() {
            const t = {
                type: R.Int,
                bitSize: 8,
                byteSize: 1
            }, e = {
                type: R.Int,
                bitSize: 16,
                byteSize: 2
            }, n = {
                type: R.Int,
                bitSize: 32,
                byteSize: 4
            }, r = this.getAccessor("get", t), i = this.getAccessor("set", t), s = this.getAccessor("get", e), o = this.getAccessor("set", e), a = this.getAccessor("get", n), c = this.getAccessor("set", n);
            this.copiers = {
                0: He,
                1: function(t, e) {
                    i.call(t, 0, r.call(e, 0));
                },
                2: function(t, e) {
                    o.call(t, 0, s.call(e, 0, !0), !0);
                },
                4: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0);
                },
                8: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0), c.call(t, 4, a.call(e, 4, !0), !0);
                },
                16: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0), c.call(t, 4, a.call(e, 4, !0), !0), c.call(t, 8, a.call(e, 8, !0), !0), 
                    c.call(t, 12, a.call(e, 12, !0), !0);
                },
                any: function(t, e) {
                    let n = 0, s = t.byteLength;
                    for (;n + 4 <= s; ) c.call(t, n, a.call(e, n, !0), !0), n += 4;
                    for (;n + 1 <= s; ) i.call(t, n, r.call(e, n)), n++;
                }
            }, this.resetters = {
                0: He,
                1: function(t, e) {
                    i.call(t, e, 0);
                },
                2: function(t, e) {
                    o.call(t, e, 0, !0);
                },
                4: function(t, e) {
                    c.call(t, e, 0, !0);
                },
                8: function(t, e) {
                    c.call(t, e + 0, 0, !0), c.call(t, e + 4, 0, !0);
                },
                16: function(t, e) {
                    c.call(t, e + 0, 0, !0), c.call(t, e + 4, 0, !0), c.call(t, e + 8, 0, !0), c.call(t, e + 12, 0, !0);
                },
                any: function(t, e, n) {
                    let r = e;
                    for (;r + 4 <= n; ) c.call(t, r, 0, !0), r += 4;
                    for (;r + 1 <= n; ) i.call(t, r, 0), r++;
                }
            };
        },
        defineCopier(t, e) {
            const n = this.getCopyFunction(t, e);
            return {
                value(t) {
                    const e = t[St], r = this[St];
                    n(r, e);
                }
            };
        },
        defineResetter(t, e) {
            const n = this.getResetFunction(e);
            return {
                value() {
                    const r = this[St];
                    n(r, t, e);
                }
            };
        },
        getCopyFunction(t, e = !1) {
            return (e ? void 0 : this.copiers[t]) ?? this.copiers.any;
        },
        getResetFunction(t) {
            return this.resetters[t] ?? this.resetters.any;
        },
        imports: {
            moveExternBytes: {}
        }
    }), rn({
        convertDirectory(t) {
            if (t instanceof Map) return new MapDirectory(t);
            if (Pe(t, "readdir")) return t;
            throw new an("map or object with directory interface", t);
        }
    });
    class MapDirectory {
        onClose=null;
        constructor(t) {
            this.map = t, t.close = () => this.onClose?.();
        }
        * readdir() {
            for (const [t, e] of this.map) yield {
                name: t,
                ...e
            };
        }
        valueOf() {
            return this.map;
        }
    }
    function Sn(t, e) {
        return Ue(t, e, (t => t.address));
    }
    rn({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: i, bitSize: s} = n;
            if ("set" === e) return s > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const i = Number(e);
                if (!isFinite(i)) throw new InvalidIntConversion(e);
                r.call(this, t, i, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & y && s > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, i) {
                        const s = r.call(this, n, i);
                        return e <= s && s <= t ? Number(s) : s;
                    };
                }
            }
            return r;
        }
    }), rn({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const i = e[St];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: s, targets: o} = n;
                    let a, c = 0;
                    for (const t of o) {
                        const e = t[St], n = e.byteOffset, r = t.constructor[qt] ?? e[qt];
                        (void 0 === c || r > c) && (c = r, a = n);
                    }
                    const l = s - e, u = this.allocateShadowMemory(l + c, 1), f = this.getViewAddress(u), h = Be(ze(f, a - e), c), d = ze(h, e - a);
                    for (const t of o) {
                        const n = t[St], r = n.byteOffset;
                        if (r !== a) {
                            const i = t.constructor[qt] ?? n[qt];
                            if (Oe(ze(d, r - e), i)) throw new AlignmentConflict(i, c);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), y = new DataView(i.buffer, Number(e), l), m = this.registerMemory(d, l, 1, r, y, p);
                    t.shadowList.push(m), n.address = d;
                }
                return ze(n.address, i.byteOffset - n.start);
            }
            {
                const n = e.constructor[qt] ?? i[qt], s = i.byteLength, o = this.allocateShadowMemory(s, n), a = this.getViewAddress(o), c = this.registerMemory(a, s, 1, r, i, o);
                return t.shadowList.push(c), a;
            }
        },
        updateShadows(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r} of t.shadowList) e(r, n);
        },
        updateShadowTargets(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r, writable: i} of t.shadowList) i && e(n, r);
        },
        registerMemory(t, e, n, r, i, s) {
            const o = Sn(this.memoryList, t);
            let a = this.memoryList[o - 1];
            return a?.address === t && a.len === e ? a.writable ||= r : (a = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: i,
                shadowDV: s
            }, this.memoryList.splice(o, 0, a)), a;
        },
        unregisterMemory(t, e) {
            const n = Sn(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            let i = n * (r ?? 0);
            const s = Sn(this.memoryList, e), o = this.memoryList[s - 1];
            let a;
            if (o?.address === e && o.len === i) a = o.targetDV; else if (o?.address <= e && ze(e, i) <= ze(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: s} = o;
                n && (i = s.byteLength - t), a = this.obtainView(s.buffer, s.byteOffset + t, i), 
                n && (a[qt] = o.align);
            }
            if (a) {
                let {targetDV: e, shadowDV: n} = o;
                if (n && t && !t.shadowList.includes(o)) {
                    this.getCopyFunction()(e, n);
                }
            } else a = this.obtainZigView(e, i);
            return a;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[xt], n = e?.address;
            n && n !== ke && (e.address = ke, this.unregisterBuffer(ze(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[xt];
            if (e) return e.address;
            {
                const e = this.getBufferAddress(t.buffer);
                return ze(e, t.byteOffset);
            }
        },
        obtainZigArray(t, e) {
            const n = this.obtainZigView(t, e, !1);
            return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        },
        ...{
            imports: {
                getBufferAddress: {},
                obtainExternBuffer: {}
            },
            exports: {
                getViewAddress: {}
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (function(t) {
                    return 0xaaaaaaaaaaaaaaaan === t;
                }(t) && (t = e > 0 ? 0 : $e), !t && e) return null;
                let r, i;
                if (n) {
                    const n = Sn(this.externBufferList, t), s = this.externBufferList[n - 1];
                    s?.address <= t && ze(t, e) <= ze(s.address, s.len) ? (r = s.buffer, i = Number(t - s.address)) : (r = e > 0 ? this.obtainExternBuffer(t, e, ie) : new ArrayBuffer(0), 
                    this.externBufferList.splice(n, 0, {
                        address: t,
                        len: e,
                        buffer: r
                    }), i = 0);
                } else r = e > 0 ? this.obtainExternBuffer(t, e, ie) : new ArrayBuffer(0), i = 0;
                return r[xt] = {
                    address: t,
                    len: e
                }, this.obtainView(r, i, e);
            },
            unregisterBuffer(t) {
                const e = Sn(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const i = e[St];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(i.buffer);
                        for (const e of n.targets) {
                            const r = e[St].byteOffset, i = e.constructor[qt], s = ze(t, r);
                            if (Oe(s, i)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return ze(n.address, i.byteOffset);
                } else {
                    const t = e.constructor[qt], n = this.getViewAddress(i);
                    if (!Oe(n, t)) {
                        const e = i.byteLength;
                        return this.registerMemory(n, e, t, r, i), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), rn({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: {}
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const {async: r = !1} = n;
                    let i = this[e];
                    i && (r && (i = this.addPromiseHandling(i)), t[e] = i.bind(this));
                }
                return t;
            },
            addPromiseHandling(t) {
                const e = t.length - 1;
                return function(...n) {
                    const r = n[e], i = !!r;
                    n[e] = i;
                    const s = t.call(this, ...n);
                    return i ? (_e(s) ? s.then((t => this.finalizeAsyncCall(r, t))) : this.finalizeAsyncCall(r, s), 
                    et) : s;
                };
            },
            importFunctions(t) {
                for (const [e] of Object.entries(this.imports)) {
                    const n = t[e];
                    n && (we(this, e, Se(n)), this.destructors.push((() => this[e] = An)));
                }
            }
        }
    });
    const An = () => {
        throw new Error("Module was abandoned");
    };
    rn({
        linkVariables(t) {
            const e = this.getCopyFunction();
            for (const {object: n, handle: r} of this.variables) {
                const i = n[St], s = this.recreateAddress(r);
                let o = n[St] = this.obtainZigView(s, i.byteLength);
                t && e(o, i), n.constructor[Rt]?.save?.(o, n), this.destructors.push((() => {
                    const t = n[St] = this.allocateMemory(o.bytelength);
                    e(t, o);
                }));
                const a = t => {
                    const e = t[At];
                    if (e) {
                        const t = o.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[St];
                            if (e.buffer === i.buffer) {
                                const r = t + e.byteOffset - i.byteOffset;
                                n[St] = this.obtainView(o.buffer, r, e.byteLength), n.constructor[Rt]?.save?.(o, n), 
                                a(n);
                            }
                        }
                    }
                };
                a(n), n[ue]?.((function() {
                    this[ae]();
                }), tt.IgnoreInactive);
            }
        },
        imports: {
            recreateAddress: null
        }
    }), rn({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, i = [], s = function(t) {
                const e = this[$t];
                if (void 0 === n.get(e)) {
                    const t = e[At][0];
                    if (t) {
                        const o = {
                            target: t,
                            writable: !e.constructor.const
                        }, a = t[St];
                        if (a[xt]) n.set(e, null); else {
                            n.set(e, t);
                            const c = r.get(a.buffer);
                            if (c) {
                                const t = Array.isArray(c) ? c : [ c ], e = Ue(t, a.byteOffset, (t => t.target[St].byteOffset));
                                t.splice(e, 0, o), Array.isArray(c) || (r.set(a.buffer, t), i.push(t));
                            } else r.set(a.buffer, o);
                            t[ue]?.(s, 0);
                        }
                    }
                }
            }, o = tt.IgnoreRetval | tt.IgnoreInactive;
            e[ue](s, o);
            const a = this.findTargetClusters(i), c = new Map;
            for (const t of a) for (const e of t.targets) c.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = c.get(r), i = n?.writable ?? !e.constructor.const;
                e[Lt] = this.getTargetAddress(t, r, n, i), Nt in e && (e[Nt] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, i = function(e) {
                const n = this[$t];
                if (!r.get(n)) {
                    r.set(n, !0);
                    const s = n[At][0], o = s && e & tt.IsImmutable ? s : n[ae](t, !0, !(e & tt.IsInactive)), a = n.constructor.const ? tt.IsImmutable : 0;
                    a & tt.IsImmutable || s && !s[St][xt] && s[ue]?.(i, a), o !== s && o && !o[St][xt] && o?.[ue]?.(i, a);
                }
            }, s = n ? tt.IgnoreRetval : 0;
            e[ue](i, s);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, i = 0, s = null;
                for (const {target: o, writable: a} of n) {
                    const n = o[St], {byteOffset: c, byteLength: l} = n, u = c + l;
                    let f = !0;
                    t && (i > c ? (s ? s.writable ||= a : (s = {
                        targets: [ t ],
                        start: r,
                        end: i,
                        address: void 0,
                        misaligned: void 0,
                        writable: a
                    }, e.push(s)), s.targets.push(o), u > i ? s.end = u : f = !1) : s = null), f && (t = o, 
                    r = c, i = u);
                }
            }
            return e;
        }
    }), rn({
        convertReader(t) {
            if (t instanceof ReadableStreamDefaultReader) return new WebStreamReader(t);
            if (t instanceof ReadableStreamBYOBReader) return new WebStreamReaderBYOB(t);
            if (t instanceof Blob) return new BlobReader(t);
            if (t instanceof Uint8Array) return new Uint8ArrayReader(t);
            if (null === t) return new NullStream;
            if (Pe(t, "read")) return t;
            throw new an("ReadableStreamDefaultReader, ReadableStreamBYOBReader, Blob, Uint8Array, or object with reader interface", t);
        }
    });
    class WebStreamReader {
        done=!1;
        bytes=null;
        onClose=null;
        constructor(t) {
            this.reader = t, t.close = () => this.onClose?.();
        }
        async read(t) {
            for (;(!this.bytes || this.bytes.length < t) && !this.done; ) {
                let {value: t} = await this.reader.read();
                if (t) if (t instanceof Uint8Array || (t instanceof ArrayBuffer ? t = new Uint8Array(t) : t.buffer instanceof ArrayBuffer && (t = new Uint8Array(t.buffer, t.byteOffset, t.byteLength))), 
                this.bytes) {
                    const e = this.bytes.length, n = t.length, r = new Uint8Array(e + n);
                    r.set(this.bytes), r.set(t, e), this.bytes = r;
                } else this.bytes = t; else this.done = !0;
            }
            let e;
            return this.bytes && (this.bytes.length > t ? (e = this.bytes.subarray(0, t), this.bytes = this.bytes.subarray(t)) : (e = this.bytes, 
            this.bytes = null)), e ?? new Uint8Array(0);
        }
        destroy() {
            this.done || this.reader.cancel(), this.bytes = null;
        }
        valueOf() {
            return this.reader;
        }
    }
    class WebStreamReaderBYOB extends WebStreamReader {
        bytes=null;
        async read(t) {
            let e;
            if ((!this.bytes || this.bytes.length < t) && (this.bytes = new Uint8Array(t)), 
            !this.done) {
                const {value: t} = await this.reader.read(this.bytes);
                t ? e = t : this.done = !0;
            }
            return e ?? new Uint8Array(0);
        }
    }
    class BlobReader {
        pos=0n;
        onClose=null;
        constructor(t) {
            this.blob = t, this.size = BigInt(t.size ?? t.length), t.close = () => this.onClose?.();
        }
        async read(t) {
            const e = Number(this.pos), n = e + t, r = this.blob.slice(e, n), i = new Response(r), s = await i.arrayBuffer();
            return this.pos = BigInt(n), new Uint8Array(s);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            const {size: n} = this;
            let r = -1n;
            switch (e) {
              case 0:
                r = t;
                break;

              case 1:
                r = this.pos + t;
                break;

              case 2:
                r = n + t;
            }
            if (!(r >= 0n && r <= n)) throw new InvalidArgument;
            return this.pos = r;
        }
        valueOf() {
            return this.blob;
        }
    }
    class Uint8ArrayReader extends BlobReader {
        read(t) {
            const e = Number(this.pos), n = e + t;
            return this.pos = BigInt(n), this.blob.subarray(e, n);
        }
    }
    class NullStream {
        read() {
            return 0;
        }
        write() {}
    }
    rn({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === R.Int;
                    let i = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** i) : 0,
                            max: 2 ** i - 1
                        };
                    }
                    i = BigInt(i);
                    return {
                        min: r ? -(2n ** i) : 0n,
                        max: 2n ** i - 1n
                    };
                }(n);
                return function(i, s, o) {
                    if (s < t || s > e) throw new Overflow(n, s);
                    r.call(this, i, s, o);
                };
            }
            return r;
        }
    }), rn({
        init() {
            this.streamLocationMap = new Map([ [ yt, "" ] ]);
        },
        obtainStreamLocation(t, e, n) {
            let r = xe(this.obtainZigArray(e, n)).trim();
            r.endsWith("/") && (r = r.slice(0, -1));
            const i = r.trim().split("/"), s = [];
            for (const t of i) ".." === t ? s.pop() : "." !== t && "" != t && s.push(t);
            return {
                parent: this.getStream(t).valueOf(),
                path: s.join("/")
            };
        },
        getStreamLocation(t) {
            return this.streamLocationMap.get(t);
        },
        setStreamLocation(t, e) {
            const n = this.streamLocationMap;
            e ? n.set(t, e) : n.delete(t);
        },
        getDirectoryEntries(t) {
            return this.getStream(t).readdir();
        }
    }), rn({
        init() {
            const t = {
                * readdir() {},
                valueOf: () => null
            };
            this.streamMap = new Map([ [ gt, this.createLogWriter("stdout") ], [ pt, this.createLogWriter("stderr") ], [ yt, t ] ]), 
            this.flushRequestMap = new Map, this.nextStreamHandle = mt;
        },
        getStream(t, e) {
            const n = this.streamMap.get(t);
            if (!n || e && !Pe(n, e)) throw new InvalidFileDescriptor;
            return n;
        },
        createStreamHandle(t) {
            const e = this.nextStreamHandle++;
            return this.streamMap.set(e, t), t.onClose = () => this.destroyStreamHandle(e), 
            e;
        },
        destroyStreamHandle(t) {
            const e = this.streamMap.get(t);
            e?.destroy?.(), this.streamMap.delete(t);
        },
        redirectStream(t, e) {
            const n = this.streamMap, r = 3 === t ? yt : t, i = n.get(r);
            if (void 0 !== e) {
                let i;
                if (0 === t) i = this.convertReader(e); else if (1 === t || 2 === t) i = this.convertWriter(e); else {
                    if (3 !== t) throw new Error(`Expecting 0, 1, 2, or 3, received ${r}`);
                    i = this.convertDirectory(e);
                }
                n.set(r, i);
            } else n.delete(r);
            return i;
        },
        createLogWriter(t) {
            const e = this;
            return {
                pending: [],
                write(t) {
                    const n = t.lastIndexOf(10);
                    if (-1 === n) this.pending.push(t); else {
                        const e = t.subarray(0, n), r = t.subarray(n + 1);
                        this.dispatch([ ...this.pending, e ]), this.pending.splice(0), r.length > 0 && this.pending.push(r);
                    }
                    e.scheduleFlush(this, this.pending.length > 0, 250);
                },
                dispatch(n) {
                    const r = xe(n);
                    e.triggerEvent("log", {
                        source: t,
                        message: r
                    });
                },
                flush() {
                    this.pending.length > 0 && (this.dispatch(this.pending), this.pending.splice(0));
                }
            };
        },
        scheduleFlush(t, e, n) {
            const r = this.flushRequestMap, i = r.get(t);
            i && (clearTimeout(i), r.delete(t)), e && r.set(t, setTimeout((() => {
                t.flush(), r.delete(t);
            }), n));
        },
        flushStreams() {
            this.libc && this.flushStdout?.();
            const t = this.flushRequestMap;
            if (t.size > 0) {
                for (const [e, n] of t) e.flush(), clearTimeout(n);
                t.clear();
            }
        },
        imports: {
            flushStdout: {},
            setRedirectionMask: {}
        }
    }), rn({}), rn({
        convertWriter(t) {
            if (t instanceof WritableStreamDefaultWriter) return new WebStreamWriter(t);
            if (Array.isArray(t)) return new ArrayWriter(t);
            if (null === t) return new NullStream;
            if ("function" == typeof t?.write) return t;
            throw new an("WritableStreamDefaultWriter, array, null, or object with writer interface", t);
        }
    });
    class WebStreamWriter {
        onClose=null;
        done=!1;
        constructor(t) {
            this.writer = t, t.closed.catch(He).then((() => {
                this.done = !0, this.onClose?.();
            }));
        }
        async write(t) {
            await this.writer.write(t);
        }
        destroy() {
            this.done || this.writer.close();
        }
    }
    class ArrayWriter {
        constructor(t) {
            this.array = t, this.closeCB = null, t.close = () => this.onClose?.();
        }
        write(t) {
            this.array.push(t);
        }
    }
    rn({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), i = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: i
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    }), rn({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = Ce(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let i = this.allocatorVtable;
            if (!i) {
                const {noResize: t, noRemap: e} = r;
                i = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (i.remap = e), this.destructors.push((() => this.freeFunction(i.alloc))), 
                this.destructors.push((() => this.freeFunction(i.free)));
            }
            let s = $e;
            if (n) {
                const e = [];
                s = this.nextAllocatorContextId++, this.allocatorContextMap.set(s, e), t[ce] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(s);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(s, 0),
                vtable: i
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][St]), i = r != $e ? this.allocatorContextMap.get(r) : null, s = 1 << n, o = this.allocateJSMemory(e, s);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, s, !0, o), we(o, xt, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), i?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][St], i = this.getViewAddress(r), s = r.byteLength;
            this.unregisterMemory(i, s);
        }
    }), rn({
        createDirectory(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return t;
            const e = this.convertDirectory(t);
            return {
                fd: this.createStreamHandle(e)
            };
        }
    }), rn({
        createFile(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return {
                handle: t.fd
            };
            if ("object" == typeof t && "number" == typeof t?.handle) return t;
            let e;
            try {
                e = this.convertReader(t);
            } catch (n) {
                try {
                    e = this.convertWriter(t);
                } catch {
                    throw n;
                }
            }
            return {
                handle: this.createStreamHandle(e)
            };
        }
    }), rn({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = Ce(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: i}} = t;
            if (n) {
                if ("function" != typeof n) throw new an("function", n);
            } else {
                const t = e[ne] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const s = this.nextGeneratorContextId++, o = this.obtainZigView(s, 0, !1);
            this.generatorContextMap.set(s, {
                func: n,
                args: e
            });
            let a = this.generatorCallbackMap.get(r);
            a || (a = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][St], r = this.getViewAddress(n), i = this.generatorContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i, s = e instanceof Error;
                    !s && n[oe] && e && (e = e.string);
                    const o = !1 === await (2 === t.length ? t(s ? e : null, s ? null : e) : t(e)) || s || null === e;
                    if (n[ce]?.(o), !o) return !0;
                    n[pe](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, a), this.destructors.push((() => this.freeFunction(a)))), 
            e[me] = t => a(o, t);
            const c = {
                ptr: o,
                callback: a
            }, l = i.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                c.allocator = this.createJsAllocator(e, t, !0);
            }
            return c;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[be] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[be](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[be](t)) break;
                    e[be](null);
                } catch (t) {
                    if (!e.constructor[te]) throw t;
                    e[be](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    rn({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = Ce(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new an("function", n);
            } else e[ee] = new Promise(((t, r) => {
                n = n => {
                    n?.[St]?.[xt] && (n = new n.constructor(n)), n instanceof Error ? r(n) : (e[oe] && n && (n = n.string), 
                    t(n));
                };
            }));
            const i = this.nextPromiseContextId++, s = this.obtainZigView(i, 0, !1);
            this.promiseContextMap.set(i, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][St], r = this.getViewAddress(n), i = this.promiseContextMap.get(r);
                if (i) {
                    const {func: t, args: n} = i;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[pe](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[me] = t => o(s, t), {
                ptr: s,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, i = r["*"];
            return t[me] = e => i.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[me](n);
            };
        }
    }), rn({
        init() {
            this.readerCallback = null, this.readerMap = new Map, this.nextReaderId = Ce(4096), 
            this.readerProgressMap = new Map;
        },
        createReader(t) {
            if ("object" == typeof t && t && "context" in t && "readFn" in t) return t;
            const e = this.convertReader(t), n = this.nextReaderId++, r = this.obtainZigView(n, 0, !1), i = e.onClose = () => {
                this.readerMap.delete(n), this.readerProgressMap.delete(n);
            };
            this.readerMap.set(n, e), this.readerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let s = this.readerCallback;
            if (!s) {
                const t = t => {
                    throw console.error(t), i(), t;
                };
                s = this.readerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][St]), i = this.readerMap.get(r);
                    if (!i) return 0;
                    try {
                        const e = n["*"][St].byteLength, s = t => {
                            const e = t.length, r = this.getViewAddress(n["*"][St]);
                            return this.moveExternBytes(t, r, !0), e;
                        };
                        fn(this.readerProgressMap.get(r), "read", e);
                        const o = i.read(e);
                        return _e(o) ? o.then(s).catch(t) : s(o);
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(s)));
            }
            return {
                context: r,
                readFn: s
            };
        }
    }), rn({
        init() {
            this.writerCallback = null, this.writerMap = new Map, this.nextWriterContextId = Ce(8192), 
            this.writerProgressMap = new Map;
        },
        createWriter(t) {
            if ("object" == typeof t && t && "context" in t && "writeFn" in t) return t;
            const e = this.convertWriter(t), n = this.nextWriterContextId++, r = this.obtainZigView(n, 0, !1), i = e.onClose = () => {
                this.writerMap.delete(n), this.writerProgressMap.delete(n);
            };
            this.writerMap.set(n, e), this.writerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let s = this.writerCallback;
            if (!s) {
                const t = t => {
                    throw console.error(t), i(), t;
                };
                s = this.writerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][St]), i = this.writerMap.get(r);
                    if (!i) return 0;
                    try {
                        const e = n["*"][St];
                        fn(this.writerProgressMap.get(r), "write", e.byteLength);
                        const s = e.byteLength, o = new Uint8Array(e.buffer, e.byteOffset, s), a = new Uint8Array(o), c = i.write(a);
                        return _e(c) ? c.then((() => s), t) : s;
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(s)));
            }
            return {
                context: r,
                writeFn: s
            };
        }
    }), rn({
        environGet(t, e) {
            let n = 0, r = 0;
            for (const t of this.envVariables) n += t.length, r++;
            const i = Ze(8 * r), s = new Uint8Array(n);
            let o = 0, a = 0, c = this.littleEndian;
            for (const t of this.envVariables) i.setBigUint64(o, e + BigInt(a), c), o += 8, 
            s.set(t, a), a += t.length;
            return this.moveExternBytes(i, t, !0), this.moveExternBytes(s, e, !0), et;
        },
        exports: {
            environGet: {
                async: !0
            }
        }
    }), rn({
        copyUsize(t, e) {
            this.copyUint64(t, e);
        },
        copyUint64(t, e) {
            const n = Ze(8);
            n.setBigUint64(0, BigInt(e), this.littleEndian), this.moveExternBytes(n, t, !0);
        },
        copyUint32(t, e) {
            const n = Ze(4);
            n.setUint32(0, e, this.littleEndian), this.moveExternBytes(n, t, !0);
        }
    }), rn({
        environSizesGet(t, e) {
            const n = this.listenerMap.get("env"), r = n?.() ?? {};
            if ("object" != typeof r) throw new TypeMismatch("object", r);
            const i = this.envVariables = [];
            for (const [t, e] of Object.entries(r)) {
                const n = Me(`${t}=${e}\0`);
                i.push(n);
            }
            let s = 0;
            for (const t of i) s += t.length;
            return this.copyUsize(t, i.length), this.copyUsize(e, s), et;
        },
        exports: {
            environSizesGet: {
                async: !0
            }
        }
    });
    const In = {
        normal: 0,
        sequential: 1,
        random: 2,
        willNeed: 3,
        dontNeed: 4,
        noReuse: 5
    };
    rn({
        fdAdvise(t, e, n, r, i) {
            return hn(i, nt, (() => {
                const i = this.getStream(t), s = Object.keys(In);
                return i.advise?.(e, n, s[r]);
            }));
        },
        exports: {
            fdAdvise: {
                async: !0
            }
        }
    }), rn({
        fdAllocate(t, e, n, r) {
            return hn(r, nt, (() => this.getStream(t).allocate(e, n)));
        },
        exports: {
            fdAllocate: {
                async: !0
            }
        }
    }), rn({
        fdClose(t, e) {
            return hn(e, nt, (() => (this.setStreamLocation?.(t), this.destroyStreamHandle(t))));
        },
        exports: {
            fdClose: {
                async: !0
            }
        }
    }), rn({
        fdDatasync(t, e) {
            return hn(e, nt, (() => {
                const e = this.getStream(t);
                return e.datasync?.();
            }));
        },
        exports: {
            fdDatasync: {
                async: !0
            }
        }
    }), rn({
        fdFdstatGet(t, e, n) {
            return hn(n, nt, (() => {
                const n = this.getStream(t);
                let r, i = 0;
                i = ht.fd_filestat_get, this.listenerMap.get("set_times") && this.getStreamLocation?.(t) && (i |= ht.fd_filestat_set_times);
                for (const t of [ "read", "write", "seek", "tell", "advise", "allocate", "datasync", "sync", "readdir" ]) Pe(n, t) && (i |= ht[`fd_${t}`]);
                if (n.type) {
                    if (r = Re(n.type, lt), void 0 === r) throw new InvalidEnumValue(lt, n.type);
                } else r = i & (ht.fd_read | ht.fd_write) ? lt.file : lt.directory;
                r === lt.directory && (i |= ht.path_open | ht.path_filestat_get);
                const s = Ze(24);
                s.setUint8(0, r), s.setUint16(2, 0, !0), s.setBigUint64(8, BigInt(i), !0), s.setBigUint64(16, 0n, !0), 
                this.moveExternBytes(s, e, !0);
            }));
        },
        exports: {
            fdFdstatGet: {
                async: !0
            }
        }
    }), rn({
        copyStat(t, e) {
            if (!1 === e) return ct;
            if ("object" != typeof e || !e) throw new an("object or false", e);
            let n = Re(e.type, lt);
            if (void 0 === n) {
                if (e.type) throw new InvalidEnumValue(lt, e.type);
                n = lt.unknown;
            }
            const r = this.littleEndian, i = Ze(64);
            i.setBigUint64(0, 0n, r), i.setBigUint64(8, 0n, r), i.setUint8(16, n), i.setBigUint64(24, 0n, r), 
            i.setBigUint64(32, BigInt(e.size ?? 0), r), i.setBigUint64(40, BigInt(e.atime ?? 0), r), 
            i.setBigUint64(48, BigInt(e.mtime ?? 0), r), i.setBigUint64(56, BigInt(e.ctime ?? 0), r), 
            this.moveExternBytes(i, t, r);
        }
    }), rn({
        fdFilestatGet(t, e, n) {
            return hn(n, nt, (() => {
                const e = this.getStream(t), n = e.valueOf(), r = this.getStreamLocation?.(t);
                try {
                    return this.triggerEvent("stat", {
                        ...r,
                        target: n,
                        flags: {}
                    }, ct);
                } catch (t) {
                    if (t.code !== ct) throw t;
                }
                return {
                    size: e.size,
                    type: "file"
                };
            }), (t => this.copyStat(e, t)));
        },
        exports: {
            fdFilestatGet: {
                async: !0
            }
        }
    }), rn({
        fdFilestatSetTimes(t, e, n, r, i) {
            return hn(i, nt, (() => {
                const i = this.getStream(t).valueOf(), s = this.getStreamLocation?.(t), o = en(e, n, r);
                return this.triggerEvent("set_times", {
                    ...s,
                    target: i,
                    times: o
                }, nt);
            }), (t => dn(t, nt)));
        },
        exports: {
            fdFilestatSetTimes: {
                async: !0
            }
        }
    }), rn({
        fdRead(t, e, n, r, i) {
            let s, o, a = 0, c = 0;
            const l = () => hn(i, at, (() => {
                s || (s = Ze(16 * n), this.moveExternBytes(s, e, !1), o = this.getStream(t));
                const r = s.getUint32(16 * c + 8, !0);
                return o.read(r);
            }), (t => {
                const e = s.getUint32(16 * c, !0);
                if (this.moveExternBytes(t, e, !0), a += t.byteLength, ++c < n) return l();
                this.copyUint32(r, a);
            }));
            return l();
        },
        ...{
            exports: {
                fdRead: {
                    async: !0
                },
                fdRead1: {
                    async: !0
                }
            },
            fdRead1(t, e, n, r, i) {
                return hn(i, at, (() => this.getStream(t).read(n)), (t => {
                    const n = t.length;
                    this.moveExternBytes(t, e, !0), this.copyUint32(r, n);
                }));
            }
        }
    }), rn({
        init() {
            this.readdirCookieMap = new Map, this.readdirNextCookie = 1n;
        },
        fdReaddir(t, e, n, r, i, s) {
            return n < 24 ? ot : hn(s, nt, (() => {
                if (0n === r) return this.getDirectoryEntries(t);
            }), (s => {
                let o;
                if (0n === r) {
                    o = {
                        iterator: s[Symbol.iterator](),
                        count: 0,
                        entry: null
                    }, r = this.readdirNextCookie++, this.readdirCookieMap.set(r, o);
                } else o = this.readdirCookieMap.get(r);
                const a = Ze(n);
                let c = n, l = 0;
                const u = t !== yt ? 2 : 1;
                if (o) {
                    let {iterator: t, entry: e} = o;
                    for (e && (o.entry = null); c >= 24; ) {
                        e || (e = ++o.count <= u ? {
                            value: {
                                name: ".".repeat(o.count),
                                type: "directory"
                            },
                            done: !1
                        } : t.next());
                        const {value: n, done: i} = e;
                        if (i) break;
                        const {name: s, type: f, ino: h = 0} = n, d = Me(s);
                        if (c < 24 + d.length) {
                            o.entry = e;
                            break;
                        }
                        const g = void 0 !== f ? Re(f, lt) : lt.unknown;
                        if (void 0 === g) throw new InvalidEnumValue(lt, f);
                        a.setBigUint64(l, r, !0), a.setBigUint64(l + 8, BigInt(h), !0), a.setUint32(l + 16, d.length, !0), 
                        a.setUint8(l + 20, g), l += 24, c -= 24;
                        for (let t = 0; t < d.length; t++, l++) a.setUint8(l, d[t]);
                        c -= d.length, e = null;
                    }
                }
                this.moveExternBytes(a, e, !0), this.copyUint32(i, l), 0 === l && this.readdirCookieMap.delete(r);
            }));
        },
        exports: {
            fdReaddir: {
                async: !0
            }
        }
    }), rn({
        fdSeek(t, e, n, r, i) {
            return hn(i, nt, (() => this.getStream(t, "seek").seek(e, n)), (t => {
                const e = Ze(8);
                e.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(e, r, !0);
            }));
        },
        exports: {
            fdSeek: {
                async: !0
            }
        }
    }), rn({
        fdSync(t, e) {
            return hn(e, nt, (() => {
                const e = this.getStream(t);
                return e.sync?.();
            }));
        },
        exports: {
            fdSync: {
                async: !0
            }
        }
    }), rn({
        fdTell(t, e, n) {
            return hn(n, nt, (() => this.getStream(t, "tell").tell()), (t => {
                const n = Ze(8);
                n.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(n, e, !0);
            }));
        },
        exports: {
            fdTell: {
                async: !0
            }
        }
    }), rn({
        fdWrite(t, e, n, r, i) {
            let s, o, a = 0, c = 0;
            const l = () => hn(i, at, (() => {
                s || (s = Ze(16 * n), this.moveExternBytes(s, e, !1), o = this.getStream(t, "write"));
                const r = this.littleEndian, i = s.getBigUint64(16 * a, r), l = Number(s.getBigUint64(16 * a + 8, r)), u = new Uint8Array(l);
                return this.moveExternBytes(u, i, !1), c += l, o.write(u);
            }), (() => {
                if (++a < n) return l();
                this.copyUint32(r, c);
            }));
            return l();
        },
        ...{
            exports: {
                fdWrite: {
                    async: !0
                },
                fdWrite1: {
                    async: !0
                }
            },
            fdWrite1(t, e, n, r, i) {
                return hn(i, at, (() => {
                    const r = this.getStream(t), i = new Uint8Array(n);
                    return this.moveExternBytes(i, e, !1), r.write(i);
                }), (() => this.copyUint32(r, n)));
            }
        }
    }), rn({
        pathCreateDirectory(t, e, n, r) {
            return hn(r, ct, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("mkdir", r, ct);
            }), (t => {
                if (!(t instanceof Map)) {
                    if (!0 === t) return it;
                    if (!1 === t) return ct;
                    throw new an("boolean", t);
                }
            }));
        },
        exports: {
            pathCreateDirectory: {
                async: !0
            }
        }
    }), rn({
        pathFilestatGet(t, e, n, r, i, s) {
            return hn(s, ct, (() => {
                const i = this.obtainStreamLocation(t, n, r), s = De(e, ft);
                return this.triggerEvent("stat", {
                    ...i,
                    flags: s
                }, ct);
            }), (t => this.copyStat(i, t)));
        },
        exports: {
            pathFilestatGet: {
                async: !0
            }
        }
    }), rn({
        pathFilestatSetTimes(t, e, n, r, i, s, o) {
            return hn(o, ct, (() => {
                const o = this.obtainStreamLocation(t, e, n), a = en(r, i, s);
                return this.triggerEvent("set_times", {
                    ...o,
                    times: a
                }, ct);
            }), (t => dn(t, ct)));
        },
        exports: {
            pathFilestatSetTimes: {
                async: !0
            }
        }
    });
    const xn = {
        read: BigInt(ht.fd_read),
        write: BigInt(ht.fd_write),
        readdir: BigInt(ht.fd_readdir)
    };
    function Mn() {
        const t = Vn.toString(), e = t.indexOf("{") + 1, n = t.lastIndexOf("}");
        return t.slice(e, n);
    }
    let En;
    function Vn() {
        let t, e;
        function n({executable: n, memory: i, options: s, tid: o, arg: a}) {
            const c = WebAssembly, l = {
                memory: i
            }, u = {}, f = {}, h = {
                env: l,
                wasi: u,
                wasi_snapshot_preview1: f
            };
            for (const {module: t, name: e, kind: i} of c.Module.imports(n)) if ("function" === i) {
                const n = r(t, e);
                "env" === t ? l[e] = n : "wasi_snapshot_preview1" === t ? f[e] = n : "wasi" === t && (u[e] = n);
            }
            const {tableInitial: d} = s;
            l.__indirect_function_table = new c.Table({
                initial: d,
                element: "anyfunc"
            });
            const {exports: g} = new c.Instance(n, h), {wasi_thread_start: p} = g;
            p(o, a), t({
                type: "exit"
            }), e();
        }
        function r(e, n) {
            const r = new Int32Array(new SharedArrayBuffer(8));
            return function(...i) {
                return r[0] = 0, t({
                    type: "call",
                    module: e,
                    name: n,
                    args: i,
                    array: r
                }), Atomics.wait(r, 0, 0), r[1];
            };
        }
        "object" == typeof self || "node" !== process.env.COMPAT ? (self.onmessage = t => n(t.data), 
        t = t => self.postMessage(t), e = () => self.close()) : "node" === process.env.COMPAT && import("worker_threads").then((({parentPort: r, workerData: i}) => {
            t = t => r.postMessage(t), e = () => process.exit(), n(i);
        }));
    }
    function Un(t, n) {
        const {byteSize: r, type: i} = n;
        if (!(i === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function On(t) {
        throw new BufferExpected(t);
    }
    rn({
        pathOpen(t, e, n, r, i, s, o, a, c, l) {
            const u = De(s | o, xn), f = {
                ...De(e, ft),
                ...De(i, ut),
                ...De(a, dt)
            };
            let h;
            return hn(l, ct, (() => (h = this.obtainStreamLocation(t, n, r), this.triggerEvent("open", {
                ...h,
                rights: u,
                flags: f
            }, ct))), (t => {
                if (!1 === t) return ct;
                let e;
                u.read || 0 === Object.values(u).length ? e = this.convertReader(t) : u.write ? e = this.convertWriter(t) : u.readdir && (e = this.convertDirectory(t));
                const n = this.createStreamHandle(e);
                this.setStreamLocation?.(n, h), this.copyUint32(c, n);
            }));
        },
        exports: {
            pathOpen: {
                async: !0
            }
        }
    }), rn({
        pathRemoveDirectory(t, e, n, r) {
            return hn(r, ct, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("rmdir", r, ct);
            }), (t => dn(t, ct)));
        },
        exports: {
            pathRemoveDirectory: {
                async: !0
            }
        }
    }), rn({
        pathUnlinkFile(t, e, n, r) {
            return hn(r, ct, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("unlink", r, ct);
            }), (t => dn(t, ct)));
        },
        exports: {
            pathUnlinkFile: {
                async: !0
            }
        }
    }), rn({
        init() {
            this.nextThreadId = 1, this.workers = [];
        },
        getThreadHandler(t) {
            if ("thread-spawn" === t) return "object" != typeof window || window.crossOriginIsolated || console.warn("%cHTML document is not cross-origin isolated %c\n\nWebAssembly multithreading in the browser is only possibly when %cwindow.crossOriginIsolated%c = true. Visit https://developer.mozilla.org/en-US/docs/Web/API/Window/crossOriginIsolated for information on how to enable it.", "color: red;font-size: 200%;font-weight:bold", "", "background-color: lightgrey;font-weight:bold", ""), 
            this.spawnThread.bind(this);
        },
        spawnThread(t) {
            const e = this.nextThreadId;
            this.nextThreadId++;
            const {executable: n, memory: r, options: i} = this, s = {
                executable: n,
                memory: r,
                options: i,
                tid: e,
                arg: t
            }, o = (t, e) => {
                if ("call" === e.type) {
                    const {module: t, name: n, args: r, array: i} = e, s = this.exportedModules[t]?.[n], o = s?.(...r, !0), a = t => {
                        i && (i[1] = 0 | t, i[0] = 1, Atomics.notify(i, 0, 1));
                    };
                    _e(o) ? o.then(a) : a(o);
                } else if ("exit" === e.type) {
                    const e = this.workers.indexOf(t);
                    -1 !== e && (t.detach(), this.workers.splice(e, 1));
                }
            }, a = "message";
            if ("function" == typeof Worker || "node" !== process.env.COMPAT) {
                const t = function() {
                    if (!En) {
                        const t = Mn();
                        En = URL.createObjectURL(new Blob([ t ], {
                            type: "text/javascript"
                        }));
                    }
                    return En;
                }(), e = new Worker(t, {
                    name: "zig"
                }), n = t => o(e, t.data);
                e.addEventListener(a, n), e.detach = () => e.removeEventListener(a, n), e.postMessage(s), 
                this.workers.push(e);
            } else "node" === process.env.COMPAT && import("worker_threads").then((({Worker: t}) => {
                const e = new t(Mn(), {
                    workerData: s,
                    eval: !0
                }), n = t => o(e, t);
                e.on(a, n), e.detach = () => e.off(a, n), this.workers.push(e);
            }));
            return e;
        }
    }), rn({
        init() {
            this.comptime = !1, this.slots = {}, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.libc = !1;
        },
        readSlot(t, e) {
            const n = t ? t[At] : this.slots;
            return n?.[e];
        },
        writeSlot(t, e, n) {
            const r = t ? t[At] : this.slots;
            r && (r[e] = n);
        },
        createTemplate: t => ({
            [St]: t,
            [At]: {}
        }),
        beginStructure(t) {
            const {type: e, purpose: n, name: r, length: i, signature: s = -1n, byteSize: o, align: a, flags: c} = t;
            return {
                constructor: null,
                type: e,
                purpose: n,
                flags: c,
                signature: s,
                name: r,
                length: i,
                byteSize: o,
                align: a,
                instance: {
                    members: [],
                    template: null
                },
                static: {
                    members: [],
                    template: null
                }
            };
        },
        attachMember(t, e, n = !1) {
            (n ? t.static : t.instance).members.push(e);
        },
        attachTemplate(t, e, n = !1) {
            (n ? t.static : t.instance).template = e;
        },
        endStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        captureView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.moveExternBytes(n, t, !1), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[xt].handle = r, n;
            }
        },
        castView(t, e, n, r, i) {
            const {constructor: s, flags: o} = r, a = this.captureView(t, e, n, i), c = s.call(Gt, a);
            return o & g && this.updatePointerTargets(null, c), n && e > 0 && this.makeReadOnly?.(c), 
            c;
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & X), this.runtimeSafety = !!(t & K), this.libc = !!(t & Q);
            const e = this.getFactoryThunk(), n = {
                [St]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                if (n & g && r && r[St]) {
                    const t = Object.create(e.prototype);
                    t[St] = r[St], t[At] = r[At], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, libc: r} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    libc: r
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of je(this.structures, At)) {
                const n = e[St]?.[xt];
                if (n) {
                    const {address: r, len: i, handle: s} = n, o = e[St] = this.captureView(r, i, !0);
                    s && (o.handle = s), t.push({
                        address: r,
                        len: i,
                        owner: e,
                        replaced: !1,
                        handle: s
                    });
                }
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && ze(n.address, n.len) <= ze(e.address, e.len)) {
                const t = e.owner[St], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[St] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = je(this.structures, At);
            for (const t of e) t[St]?.[xt] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${f[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, static: {template: n}, flags: r} = t;
            switch (e.type) {
              case R.Bool:
                return "bool";

              case R.Int:
                return r & y ? "isize" : `i${e.bitSize}`;

              case R.Uint:
                return r & y ? "usize" : `u${e.bitSize}`;

              case R.Float:
                return `f${e.bitSize}`;

              case R.Void:
                return "void";

              case R.Literal:
                return "enum_literal";

              case R.Null:
                return "null";

              case R.Undefined:
                return "undefined";

              case R.Type:
                return "type";

              case R.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & S[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & j ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let i = "*", s = n.structure.name;
            if (n.structure.type === e.Slice && (s = s.slice(3)), r & U && (i = r & V ? "[]" : r & O ? "[*c]" : "[*]"), 
            !(r & O)) {
                const t = n.structure.constructor?.[kt];
                t && (i = i.slice(0, -1) + `:${t.value}` + i.slice(-1));
            }
            return r & B && (i = `${i}const `), i + s;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & F ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${i})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), i = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${i})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t;
            return e.structure.name.slice(4, -1);
        },
        exports: {
            captureView: {},
            castView: {},
            readSlot: {},
            writeSlot: {},
            beginStructure: {},
            attachMember: {},
            createTemplate: {},
            attachTemplate: {},
            defineStructure: {},
            endStructure: {}
        },
        imports: {
            getFactoryThunk: {},
            getModuleAttributes: {}
        }
    }), rn({
        init() {
            this.viewMap = new WeakMap, this.needFallback = void 0;
        },
        extractView(t, n, r = On) {
            const {type: i, byteSize: s, constructor: o} = t;
            let a;
            const c = n?.[Symbol.toStringTag];
            if (c && ("DataView" === c ? a = this.registerView(n) : "ArrayBuffer" === c ? a = this.obtainView(n, 0, n.byteLength) : (c && c === o[Qt]?.name || "Uint8ClampedArray" === c && o[Qt] === Uint8Array || "Uint8Array" === c && n instanceof Buffer) && (a = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !a) {
                const r = n?.[St];
                if (r) {
                    const {constructor: o, instance: {members: [a]}} = t;
                    if (Ne(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(i)) {
                        const {byteSize: o, structure: {constructor: c}} = a, l = Fe(n, c);
                        if (void 0 !== l) {
                            if (i === e.Slice || l * o === s) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return a ? void 0 !== s && Un(a, t) : r?.(t, n), a;
        },
        assignView(t, n, r, i, s) {
            const {byteSize: o, type: a} = r, c = o ?? 1;
            if (t[St]) {
                const i = a === e.Slice ? c * t.length : c;
                if (n.byteLength !== i) throw new BufferSizeMismatch(r, n, t);
                const s = {
                    [St]: n
                };
                t.constructor[kt]?.validateData?.(s, t.length), t[fe](s);
            } else {
                void 0 !== o && Un(n, r);
                const e = n.byteLength / c, a = {
                    [St]: n
                };
                t.constructor[kt]?.validateData?.(a, e), s && (i = !0), t[he](i ? null : n, e, s), 
                i && t[fe](a);
            }
            if (this.usingBufferFallback()) {
                const e = t[St], n = e.buffer[ie];
                void 0 !== n && this.syncExternalBuffer(e.buffer, n, !0);
            }
        },
        findViewAt(t, e, n) {
            let r, i = this.viewMap.get(t);
            if (i) if (i instanceof DataView) if (i.byteOffset === e && i.byteLength === n) r = i, 
            i = null; else {
                const e = i, n = `${e.byteOffset}:${e.byteLength}`;
                i = new Map([ [ n, e ] ]), this.viewMap.set(t, i);
            } else r = i.get(`${e}:${n}`);
            return {
                existing: r,
                entry: i
            };
        },
        obtainView(t, e, n) {
            const {existing: r, entry: i} = this.findViewAt(t, e, n);
            let s;
            if (r) return r;
            s = new DataView(t, e, n), i ? i.set(`${e}:${n}`, s) : this.viewMap.set(t, s);
            {
                const r = t[xt];
                r && (s[xt] = {
                    address: ze(r.address, e),
                    len: n
                });
            }
            return s;
        },
        registerView(t) {
            if (!t[xt]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: i, entry: s} = this.findViewAt(e, n, r);
                if (i) return i;
                s ? s.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: null,
                syncExternalBuffer: null
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > Bn && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let i = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    i = Be(t, e) - t;
                }
                return this.obtainView(r, Number(i), t);
            }
        }
    });
    const Bn = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8;
    rn({
        makeReadOnly(t) {
            Cn(t);
        }
    });
    const $n = Object.getOwnPropertyDescriptors, kn = Object.defineProperty;
    function Cn(t) {
        const e = t[$t];
        if (e) zn(e, [ "length" ]); else {
            const e = t[Ct];
            e ? (zn(e), function(t) {
                kn(t, "set", {
                    value: un
                });
                const e = t.get;
                kn(t, "get", {
                    value: function(t) {
                        const n = e.call(this, t);
                        return null === n?.[Jt] && Cn(n), n;
                    }
                });
            }(e)) : zn(t);
        }
    }
    function zn(t, e = []) {
        const n = $n(t.constructor.prototype);
        for (const [r, i] of Object.entries(n)) i.set && !e.includes(r) && (i.set = un, 
        kn(t, r, i));
        kn(t, Jt, {
            value: t
        });
    }
    function Tn() {
        const t = this[Ct] ?? this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Fn(t) {
        const e = Ae(t), n = this[Ct] ?? this, r = this.length;
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r) {
                    const r = i++;
                    t = [ r, e((() => n.get(r))) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function jn(t) {
        return {
            [Symbol.iterator]: Fn.bind(this, t),
            length: this.length
        };
    }
    function Ln(t) {
        return {
            [Symbol.iterator]: Pn.bind(this, t),
            length: this[Bt].length
        };
    }
    function Nn(t) {
        return Ln.call(this, t)[Symbol.iterator]();
    }
    function Pn(t) {
        const e = Ae(t), n = this, r = this[Bt];
        let i = 0;
        return {
            next() {
                let t, s;
                if (i < r.length) {
                    const o = r[i++];
                    t = [ o, e((() => n[o])) ], s = !1;
                } else s = !0;
                return {
                    value: t,
                    done: s
                };
            }
        };
    }
    function _n(t) {
        return {
            [Symbol.iterator]: Rn.bind(this, t),
            length: this[Bt].length
        };
    }
    function Dn(t) {
        return _n.call(this, t)[Symbol.iterator]();
    }
    function Rn(t) {
        const e = Ae(t), n = this, r = this[Bt], i = this[Xt];
        let s = 0;
        return {
            next() {
                let t, o;
                if (s < r.length) {
                    const a = r[s++];
                    t = [ a, e((() => i[a].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function Wn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = t[e], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function Zn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, i;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], i = !1;
                } else i = !0;
                return {
                    value: r,
                    done: i
                };
            }
        };
    }
    function qn() {
        return {
            [Symbol.iterator]: Zn.bind(this),
            length: this.length
        };
    }
    function Jn(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function Gn(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function Hn(t) {
        return Yn.call(this, t).$;
    }
    function Yn(t) {
        return this[At][t] ?? this[le](t);
    }
    function Xn(t) {
        const e = Yn.call(this, t).$;
        return e ? e.string : e;
    }
    function Kn(t, e, n) {
        Yn.call(this, t)[de](e, n);
    }
    rn({
        defineArrayEntries: () => Se(jn),
        defineArrayIterator: () => Se(Tn)
    }), rn({
        defineStructEntries: () => Se(Ln),
        defineStructIterator: () => Se(Nn)
    }), rn({
        defineUnionEntries: () => Se(_n),
        defineUnionIterator: () => Se(Dn)
    }), rn({
        defineVectorEntries: () => Se(qn),
        defineVectorIterator: () => Se(Wn)
    }), rn({
        defineZigIterator: () => Se(Jn)
    }), rn({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, i = this[`defineMember${W[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${f[e]}`];
                if (n) return n.call(this, i, t);
            }
            return i;
        }
    }), rn({
        defineBase64(t) {
            const e = this;
            return We({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new an("string", n);
                    const i = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, i, t, !1, r);
                }
            });
        }
    }), rn({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), rn({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return We({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new an(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), rn({
        defineDataView(t) {
            const e = this;
            return We({
                get() {
                    const t = this[St];
                    if (e.usingBufferFallback()) {
                        const n = t.buffer[ie];
                        void 0 !== n && e.syncExternalBuffer(t.buffer, n, !1);
                    }
                    return t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new an("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), rn({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), rn({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), rn({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return Gn(e, {
                get(t) {
                    return this[At][t].string;
                },
                set: un
            });
        }
    }), rn({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: un
        })
    }), rn({
        defineMemberObject: t => Gn(t.slot, {
            get: t.flags & Y ? Xn : t.structure.flags & h ? Hn : Yn,
            set: t.flags & q ? un : Kn
        })
    }), rn({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: i} = t, s = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return s.call(this[St], t, n);
                        },
                        set: function(e) {
                            return o.call(this[St], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return s.call(this[St], e * i, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[St], t * i, e, n);
                    }
                };
            }
        }
    }), rn({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: i}} = t, {get: s} = this.defineMember(r), {get: o} = this.defineMember(n), a = s.call(i, 0), c = !!(r.flags & Z), {runtimeSafety: l} = this;
            return Se({
                value: a,
                bytes: i[St],
                validateValue(e, n, r) {
                    if (c) {
                        if (l && e === a && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== a && n === r - 1) throw new MissingSentinel(t, a, r);
                    }
                },
                validateData(n, r) {
                    if (c) if (l) for (let e = 0; e < r; e++) {
                        const i = o.call(n, e);
                        if (i === a && e !== r - 1) throw new MisplacedSentinel(t, a, e, r);
                        if (i !== a && e === r - 1) throw new MissingSentinel(t, a, r);
                    } else if (r > 0 && r * e === n[St].byteLength) {
                        if (o.call(n, r - 1) !== a) throw new MissingSentinel(t, a, r);
                    }
                },
                isRequired: c
            });
        },
        imports: {
            findSentinel: null
        }
    }), rn({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return We({
                get() {
                    let t = xe(this.typedArray, r);
                    const e = this.constructor[kt]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, i) {
                    if ("string" != typeof n) throw new an("string", n);
                    const s = this.constructor[kt]?.value;
                    void 0 !== s && n.charCodeAt(n.length - 1) !== s && (n += String.fromCharCode(s));
                    const o = Me(n, r), a = new DataView(o.buffer);
                    e.assignView(this, a, t, !1, i);
                }
            });
        }
    }), rn({
        defineValueOf: () => ({
            value() {
                return er(this, !1);
            }
        })
    });
    const Qn = BigInt(Number.MAX_SAFE_INTEGER), tr = BigInt(Number.MIN_SAFE_INTEGER);
    function er(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, i = Ae(r), s = new Map, o = function(t) {
            const a = "function" == typeof t ? e.Struct : t?.constructor?.[Et];
            if (void 0 === a) {
                if (n) {
                    if ("bigint" == typeof t && tr <= t && t <= Qn) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let c = s.get(t);
            if (void 0 === c) {
                let n;
                switch (a) {
                  case e.Struct:
                    n = t[Tt](r), c = t.constructor[Vt] & S.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[Tt](r), c = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[Tt](), c = [];
                    break;

                  case e.Pointer:
                    try {
                        c = t["*"];
                    } catch (t) {
                        c = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    c = i((() => String(t)));
                    break;

                  case e.Opaque:
                    c = {};
                    break;

                  default:
                    c = i((() => t.$));
                }
                if (c = o(c), s.set(t, c), n) for (const [t, e] of n) c[t] = o(e);
            }
            return c;
        };
        return o(t);
    }
    rn({
        defineToJSON: () => ({
            value() {
                return er(this, !0);
            }
        })
    }), rn({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return Gn(n, {
                get(t) {
                    const e = this[At][t];
                    return e?.constructor;
                },
                set: un
            });
        }
    }), rn({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return We({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, i) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new an(n.name, r);
                    const s = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, s, t, !0, i);
                }
            });
        }
    }), rn({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), rn({
        defineMemberUndefined: t => ({
            get: function() {},
            set: un
        })
    }), rn({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), rn({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), rn({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${f[e]}`], i = [], s = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [Jt]: {
                    value: null
                },
                [Kt]: Se(s),
                [jt]: Se(i),
                [fe]: this.defineCopier(n)
            }, a = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !s[t] && "$" !== t && (s[t] = n, i.push(t));
            }
            return ve(a.prototype, o), a;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: i, align: s, byteSize: o, flags: a, signature: c, static: {members: l, template: u}} = t, h = [], d = {
                name: Se(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [se]: Se(c),
                [Gt]: Se(this),
                [qt]: Se(s),
                [Wt]: Se(o),
                [Et]: Se(r),
                [Vt]: Se(a),
                [Bt]: Se(h),
                [Qt]: Se(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [Tt]: this.defineStructEntries(),
                [Bt]: Se(h)
            }, g = {
                [Symbol.toStringTag]: Se(n)
            };
            for (const t of l) {
                const {name: n, slot: r, flags: i} = t;
                if (t.structure.type === e.Function) {
                    let e = u[At][r];
                    i & Y && (e[oe] = !0), d[n] = Se(e), e.name || we(e, "name", Se(n));
                    const [s, o] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], a = "get" === s ? 0 : 1;
                    if (s && e.length === a) {
                        d[o] ||= {};
                        d[o][s] = e;
                    }
                    if (t.flags & G) {
                        const t = function(...t) {
                            try {
                                return e(this, ...t);
                            } catch (t) {
                                throw t[ae]?.(1), t;
                            }
                        };
                        if (ve(t, {
                            name: Se(n),
                            length: Se(e.length - 1)
                        }), g[n] = Se(t), s && t.length === a) {
                            (g[o] ||= {})[s] = t;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[At] = h.length > 0 && Se(u[At]);
            const p = this[`finalize${f[r]}`];
            !1 !== p?.call(this, t, d, g) && (ve(i.prototype, g), ve(i, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: i, align: s, flags: o, instance: {members: a, template: c}} = t, {onCastError: l} = n;
            let u;
            if (c?.[At]) {
                const t = a.filter((t => t.flags & q));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, d = function(n, a = {}) {
                const {allocator: g} = a, y = this instanceof d;
                let m, b;
                if (y) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (m = this, o & p && (m[At] = {}), he in m) m[de](n, g), b = m[St]; else {
                        const t = r !== e.Pointer ? g : null;
                        m[St] = b = h.allocateMemory(i, s, t);
                    }
                } else {
                    if (ye in d && (m = d[ye].call(this, n, a), !1 !== m)) return m;
                    if (b = h.extractView(t, n, l), m = f.find(b)) return m;
                    m = Object.create(d.prototype), he in m ? h.assignView(m, b, t, !1, !1) : m[St] = b, 
                    o & p && (m[At] = {});
                }
                if (u) for (const t of u) m[At][t] = c[At][t];
                return m[ge]?.(), y && (he in m || m[de](n, g)), pe in m && (m = m[pe]()), f.save(b, m);
            };
            return we(d, Rt, Se(f)), d;
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const i = Object.keys(n), s = this[jt], o = this[Kt];
                for (const e of i) if (!(e in o)) throw new NoProperty(t, e);
                let a = 0, c = 0, l = 0, u = 0;
                for (const t of s) {
                    const e = o[t];
                    e.special ? t in n && u++ : (a++, t in n ? c++ : e.required && l++);
                }
                if (0 !== l && 0 === u) {
                    const e = s.filter((t => o[t].required && !(t in n)));
                    throw new MissingInitializers(t, e);
                }
                if (u + c > i.length) for (const t of s) t in n && (i.includes(t) || i.push(t));
                c < a && 0 === u && e && e[St] && this[fe](e);
                for (const t of i) {
                    o[t].call(this, n[t], r);
                }
                return i.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) {
                const [t] = r.members;
                switch (n) {
                  case e.Enum:
                  case e.ErrorSet:
                  case e.Primitive:
                    {
                        const {byteSize: e, type: n} = t;
                        return globalThis[(e > 4 && n !== R.Float ? "Big" : "") + (n === R.Float ? "Float" : n === R.Int ? "Int" : "Uint") + 8 * e + "Array"];
                    }

                  case e.Array:
                  case e.Slice:
                  case e.Vector:
                    return this.getTypedArray(t.structure);
                }
            }
        }
    }), rn({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: i, length: s, instance: {members: o}} = t, a = this, c = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = a.allocateMemory(r, i)) : (u = Object.create(l.prototype), 
                f = t), u[St] = f, n & p && (u[At] = {}), !o) return u;
                {
                    let r;
                    if (n & P && t.length === s + 1 && (r = t.pop()), t.length !== s) throw new ArgumentCountMismatch(s, t.length);
                    n & D && (u[pe] = null), a.copyArguments(u, t, c, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = Se(c.length), e[le] = n & d && this.defineVivificatorStruct(t), 
            e[ue] = n & g && this.defineVisitorArgStruct(o), e[me] = Se((function(t) {
                u.call(this, t, this[re]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(c), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[te] = Se(!!(n & _));
        }
    }), rn({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                const n = new Proxy(this, nr);
                return ve(this, {
                    [Dt]: {
                        value: n
                    },
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), n;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, i = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, s = this[St], o = s.byteOffset + n * t, a = i.obtainView(s.buffer, o, n);
                    return this[At][t] = e.call(It, a);
                }
            };
        }
    });
    const nr = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : e === Ct ? t : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length", Dt), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    };
    rn({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: i} = t, s = this.createApplier(t), o = this.defineMember(r), {set: a} = o, c = this.createConstructor(t), l = function(e, r) {
                if (Ne(e, c)) this[fe](e), i & g && this[ue]("copy", tt.Vivificate, e); else if ("string" == typeof e && i & b && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = Te(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) a.call(this, i++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            };
            return e.$ = {
                get: Je,
                set: l
            }, e.length = Se(n), e.entries = e[Tt] = this.defineArrayEntries(), i & w && (e.typedArray = this.defineTypedArray(t), 
            i & b && (e.string = this.defineString(t)), i & v && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[de] = Se(l), e[pe] = this.defineFinalizerArray(o), 
            e[le] = i & d && this.defineVivificatorArray(t), e[ue] = i & g && this.defineVisitorArray(), 
            c;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = Se(r.structure.constructor), e[kt] = n & m && this.defineSentinel(t);
        }
    }), rn({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: i, set: s} = r, {get: o} = this.defineMember(n, !1), a = this.createApplier(t), c = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return e.$ = r, e.toString = Se(Ge), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[Mt];

                      default:
                        return o.call(this);
                    }
                }
            }, e[de] = Se((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === a.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && s.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [i]}, static: {members: s, template: o}} = t, a = o[At], {get: c, set: l} = this.defineMember(i, !1), u = {};
            for (const {name: t, flags: n, slot: r} of s) if (n & J) {
                const n = a[r];
                we(n, Mt, Se(t));
                const i = c.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[i] = n;
            }
            e[ye] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & M) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            we(e, Mt, Se(n)), we(r, n, Se(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[Ot] instanceof r && t[Ot];
                }
            }, e[Qt] = Se(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === R.Object) return t;
            const i = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    t = i(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), rn({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: i, flags: s} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: j,
                    byteSize: i,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && s & j) return this.globalErrorSet;
            const o = this.defineMember(r), {set: a} = o, c = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return n.$ = o, n[de] = Se((function(e) {
                if (e instanceof u[Ut]) a.call(this, e); else if (e && "object" == typeof e && !gn(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && a.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [i]}, static: {members: s, template: o}} = t;
            if (this.globalErrorSet && r & j) return !1;
            const a = o?.[At] ?? {}, c = r & j ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(i, !1);
            for (const {name: t, slot: n} of s) {
                const r = a[n], i = l.call(r);
                let s = this.globalItemsByIndex[i];
                const o = !!s;
                s || (s = new this.ZigError(t, i));
                const u = Se(s);
                e[t] = u;
                const f = `${s}`;
                e[f] = u, c[i] = s, o || (ve(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[Bt].push(t), this.globalItemsByIndex[i] = s);
            }
            e[ye] = {
                value: t => "number" == typeof t ? c[t] : "string" == typeof t ? n[t] : t instanceof n[Ut] ? c[Number(t)] : gn(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[Ut] = Se(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === R.Object) return t;
            const i = t => {
                const {constructor: e, flags: n} = r, i = e(t);
                if (!i) {
                    if (n & j && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, we(this.globalErrorSet, `${e}`, Se(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r) : new ErrorExpected(r, t);
                }
                return i;
            }, {get: s, set: o} = t;
            return {
                get: 0 === s.length ? function() {
                    const t = s.call(this);
                    return i(t);
                } : function(t) {
                    const e = s.call(this, t);
                    return i(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = i(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = i(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function rr(t, e) {
        return Le(t?.constructor?.child, e) && t["*"];
    }
    function ir(t, e, n) {
        if (n & U) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & O && rr(t, e.child)) return !0;
        }
        return !1;
    }
    rn({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), f = n.type === R.Void, h = r.structure.constructor, p = function() {
                this[ce](), this[ue]?.("clear");
            }, y = this.createApplier(t), m = function(t, e) {
                if (Ne(t, v)) this[fe](t), i & g && (l.call(this) || this[ue]("copy", 0, t)); else if (t instanceof h[Ut] && h(t)) c.call(this, t), 
                p.call(this); else if (void 0 !== t || f) try {
                    o.call(this, t, e), u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = h(t) ?? h.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure);
                        c.call(this, e), p.call(this);
                    } else if (gn(t)) c.call(this, t), p.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === y.call(this, t)) throw e;
                    }
                }
            }, {bitOffset: b, byteSize: w} = n, v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw a.call(this);
                    return s.call(this);
                },
                set: m
            }, e[de] = Se(m), e[le] = i & d && this.defineVivificatorStruct(t), e[ce] = this.defineResetter(b / 8, w), 
            e[ue] = i & g && this.defineVisitorErrorUnion(n, l), v;
        }
    }), rn({
        defineFunction(t, n) {
            const {instance: {members: [r], template: i}, static: {template: s}} = t, o = new ObjectCache, {structure: {constructor: a}} = r, c = this, l = function(n) {
                const r = this instanceof l;
                let u, f;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new an("function", n);
                    if (a[Et] === e.VariadicStruct || !s) throw new Unsupported;
                    u = c.getFunctionThunk(n, s);
                } else {
                    if (this !== Gt) throw new NoCastingToFunction;
                    u = n;
                }
                if (f = o.find(u)) return f;
                const h = a.prototype.length, d = r ? c.createInboundCaller(n, a) : c.createOutboundCaller(i, a);
                return ve(d, {
                    length: Se(h),
                    name: Se(r ? n.name : "")
                }), Object.setPrototypeOf(d, l.prototype), d[St] = u, o.save(u, d), d;
            };
            return Object.setPrototypeOf(l.prototype, Function.prototype), n.valueOf = n.toJSON = Se(qe), 
            l;
        },
        finalizeFunction(t, e, n) {
            n[Symbol.toStringTag] = void 0;
        }
    }), rn({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, i = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[de] = Se((() => {
                throw new CreatingOpaque(t);
            })), i;
        }
    }), rn({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: i} = t, {get: s, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), l = n.type === R.Void, u = function(t, e) {
                Ne(t, f) ? (this[fe](t), i & g && a.call(this) && this[ue]("copy", tt.Vivificate, t)) : null === t ? (c.call(this, 0), 
                this[ce]?.(), this[ue]?.("clear")) : (void 0 !== t || l) && (o.call(this, t, e), 
                i & E ? c.call(this, 1) : i & g && (a.call(this) || c.call(this, 13)));
            }, f = t.constructor = this.createConstructor(t), {bitOffset: h, byteSize: p} = n;
            return e.$ = {
                get: function() {
                    return a.call(this) ? s.call(this) : (this[ue]?.("clear"), null);
                },
                set: u
            }, e[de] = Se(u), e[ce] = i & E && this.defineResetter(h / 8, p), e[le] = i & d && this.defineVivificatorStruct(t), 
            e[ue] = i & g && this.defineVisitorOptional(n, a), f;
        }
    }), rn({
        definePointer(t, n) {
            const {flags: r, byteSize: i, instance: {members: [s]}} = t, {structure: o} = s, {type: a, flags: c, byteSize: l = 1} = o, u = r & V ? i / 2 : i, {get: f, set: d} = this.defineMember({
                type: R.Uint,
                bitOffset: 0,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    byteSize: u
                }
            }), {get: g, set: p} = r & V ? this.defineMember({
                type: R.Uint,
                bitOffset: 8 * u,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    flags: y,
                    byteSize: u
                }
            }) : {}, m = function(t, n = !0, i = !0) {
                if (n || this[St][xt]) {
                    if (!i) return this[At][0] = void 0;
                    {
                        const n = E.child, i = f.call(this), s = r & V ? g.call(this) : a === e.Slice && c & k ? x.findSentinel(i, n[kt].bytes) + 1 : 1;
                        if (i !== this[Pt] || s !== this[_t]) {
                            const e = x.findMemory(t, i, s, n[Wt]), o = e ? n.call(Gt, e) : null;
                            return this[At][0] = o, this[Pt] = i, this[_t] = s, r & V && (this[Ft] = null), 
                            o;
                        }
                    }
                }
                return this[At][0];
            }, b = function(t) {
                d.call(this, t), this[Pt] = t;
            }, w = c & k ? 1 : 0, v = r & V || c & k ? function(t) {
                p?.call?.(this, t - w), this[_t] = t;
            } : null, S = function() {
                const t = this[$t] ?? this, e = !t[At][0], n = m.call(t, null, e);
                if (!n) {
                    if (r & $) return null;
                    throw new NullPointer;
                }
                return r & B ? or(n) : n;
            }, A = c & h ? function() {
                return S.call(this).$;
            } : S, I = r & B ? un : function(t) {
                return S.call(this).$ = t;
            }, x = this, M = function(n, i) {
                const s = o.constructor;
                if (rr(n, s)) {
                    if (!(r & B) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[At][0];
                } else if (r & U) ir(n, s, r) && (n = s(n[At][0][St])); else if (a === e.Slice && c & F && n) if (n.constructor[Et] === e.Pointer) n = n[zt]?.[St]; else if (n[St]) n = n[St]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof s) {
                    const e = n[Jt];
                    if (e) {
                        if (!(r & B)) throw new ReadOnlyTarget(t);
                        n = e;
                    }
                } else if (Ne(n, s)) n = s.call(Gt, n[St]); else if (r & O && r & U && n instanceof s.child) n = s(n[St]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[Qt];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== Fe(t, e.child)) return !0;
                    }
                    return !1;
                }(n, s)) {
                    n = s(x.extractView(o, n));
                } else if (null == n || n[St]) {
                    if (!(void 0 === n || r & $ && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & O && r & U && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = s.prototype[Kt];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (Qt in s && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    n = new s(n, {
                        allocator: i
                    });
                }
                const l = n?.[St]?.[xt];
                if (l?.address === ke) throw new PreviouslyFreed(n);
                this[zt] = n;
            }, E = this.createConstructor(t);
            return n["*"] = {
                get: A,
                set: I
            }, n.$ = {
                get: Je,
                set: M
            }, n.length = {
                get: function() {
                    const t = S.call(this);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = S.call(this);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[St], i = n[xt];
                    let s;
                    if (!i) if (r & V) this[Ft] ||= e.length, s = this[Ft]; else {
                        s = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > s) throw new InvalidSliceLength(t, s);
                    const a = t * l, c = i ? x.obtainZigView(i.address, a) : x.obtainView(n.buffer, n.byteOffset, a), u = o.constructor;
                    this[At][0] = u.call(Gt, c), v?.call?.(this, t);
                }
            }, n.slice = a === e.Slice && {
                value(t, e) {
                    const n = this[zt].slice(t, e);
                    return new E(n);
                }
            }, n.subarray = a === e.Slice && {
                value(t, e, n) {
                    const r = this[zt].subarray(t, e, n);
                    return new E(r);
                }
            }, n[Symbol.toPrimitive] = a === e.Primitive && {
                value(t) {
                    return this[zt][Symbol.toPrimitive](t);
                }
            }, n[de] = Se(M), n[pe] = {
                value() {
                    const t = a !== e.Pointer ? ar : {};
                    let n;
                    a === e.Function ? (n = function() {}, n[St] = this[St], n[At] = this[At], Object.setPrototypeOf(n, E.prototype)) : n = this;
                    const r = new Proxy(n, t);
                    return Object.defineProperty(n, Dt, {
                        value: r
                    }), r;
                }
            }, n[zt] = {
                get: S,
                set: function(t) {
                    if (void 0 === t) return;
                    const e = this[$t] ?? this;
                    if (t) {
                        const n = t[St][xt];
                        if (n) {
                            const {address: e, js: r} = n;
                            b.call(this, e), v?.call?.(this, t.length), r && (t[St][xt] = void 0);
                        } else if (e[St][xt]) throw new ZigMemoryTargetRequired;
                    } else e[St][xt] && (b.call(this, 0), v?.call?.(this, 0));
                    e[At][0] = t ?? null, r & V && (e[Ft] = null);
                }
            }, n[ae] = Se(m), n[Lt] = {
                set: b
            }, n[Nt] = {
                set: v
            }, n[ue] = this.defineVisitor(), n[Pt] = Se(0), n[_t] = Se(0), n[Ft] = r & V && Se(null), 
            n.dataView = n.base64 = void 0, E;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: i, instance: {members: [s]}} = t, {structure: o} = s, {type: a, constructor: c} = o;
            n.child = c ? Se(c) : {
                get: () => o.constructor
            }, n.const = Se(!!(r & B)), n[ye] = {
                value(n, s) {
                    if (this === Gt || this === It || n instanceof i) return !1;
                    if (rr(n, c)) return new i(c(n["*"]), s);
                    if (ir(n, c, r)) return new i(n);
                    if (a === e.Slice) return new i(c(n), s);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    });
    const sr = new WeakMap;
    function or(t) {
        let e = sr.get(t);
        if (!e) {
            const n = t[$t];
            e = n ? new Proxy(n, cr) : new Proxy(t, lr), sr.set(t, e);
        }
        return e;
    }
    const ar = {
        get(t, e) {
            if (e === $t) return t;
            if (e in t) return t[e];
            return t[zt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[zt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[zt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[zt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, cr = {
        ...ar,
        set(t, e, n) {
            if (e in t) un(); else {
                t[zt][e] = n;
            }
            return !0;
        }
    }, lr = {
        get(t, e) {
            if (e === Jt) return t;
            {
                const n = t[e];
                return n?.[St] ? or(n) : n;
            }
        },
        set(t, e, n) {
            un();
        }
    };
    function ur() {
        return this[Nt];
    }
    function fr(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function hr() {
        throw new InaccessiblePointer;
    }
    function dr() {
        const t = {
            get: hr,
            set: hr
        };
        ve(this[$t], {
            "*": t,
            $: t,
            [$t]: t,
            [zt]: t
        });
    }
    function gr(t, e, n, r) {
        let i, s = this[At][t];
        if (!s) {
            if (n & tt.IgnoreUncreated) return;
            s = this[le](t);
        }
        r && (i = r[At][t], !i) || s[ue](e, n, i);
    }
    rn({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: i, set: s} = this.defineMember(n), o = function(e) {
                if (Ne(e, a)) this[fe](e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = Ie(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && s.call(this, e);
            }, a = this.createConstructor(t);
            return e.$ = {
                get: i,
                set: o
            }, e[de] = Se(o), e[Symbol.toPrimitive] = Se(i), a;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[Zt] = Se(n.bitSize), e[Yt] = Se(n.type);
        }
    }), rn({
        defineSlice(t, e) {
            const {align: n, flags: r, byteSize: i, name: s, instance: {members: [o]}} = t, {byteSize: a, structure: c} = o, l = this, u = function(t, e, r) {
                t || (t = l.allocateMemory(e * a, n, r)), this[St] = t, this[Nt] = e;
            }, f = function(e, n) {
                if (n !== this[Nt]) throw new ArrayLengthMismatch(t, this, e);
            }, h = this.defineMember(o), {set: p} = h, y = this.createApplier(t), m = function(e, n) {
                if (Ne(e, w)) this[St] ? f.call(this, e, e.length) : u.call(this, null, e.length, n), 
                this[fe](e), r & g && this[ue]("copy", tt.Vivificate, e); else if ("string" == typeof e && r & C) m.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = Te(e), this[St] ? f.call(this, e, e.length) : u.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) w[kt]?.validateValue(r, t, e.length), p.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[St] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[St]);
                    u.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === y.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, b = function(t, e) {
                const n = this[Nt], r = this[St];
                t = void 0 === t ? 0 : fr(t, n), e = void 0 === e ? n : fr(e, n);
                const i = t * a, s = e * a - i;
                return l.obtainView(r.buffer, r.byteOffset + i, s);
            }, w = this.createConstructor(t);
            return e.$ = {
                get: Je,
                set: m
            }, e.length = {
                get: ur
            }, r & z && (e.typedArray = this.defineTypedArray(t), r & C && (e.string = this.defineString(t)), 
            r & T && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[Tt] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = b.call(this, t, e);
                    return w(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: i = !1} = r, s = b.call(this, t, e), o = l.allocateMemory(s.byteLength, n, i), a = w(o);
                    return a[fe]({
                        [St]: s
                    }), a;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[he] = Se(u), e[fe] = this.defineCopier(i, !0), 
            e[de] = Se(m), e[pe] = this.defineFinalizerArray(h), e[le] = r & d && this.defineVivificatorArray(t), 
            e[ue] = r & g && this.defineVisitorArray(), w;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = Se(r.structure.constructor), e[kt] = n & k && this.defineSentinel(t);
        }
    }), rn({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === R.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: i, byteSize: s, structure: {constructor: o}} = e, a = this[St], c = a.byteOffset + (i >> 3);
                    let l = s;
                    if (void 0 === l) {
                        if (7 & i) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(a.buffer, c, l);
                    return this[At][t] = o.call(It, u);
                }
            };
        }
    }), rn({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: i, instance: {members: a}} = t, c = a.find((t => t.flags & H)), l = c && this.defineMember(c), u = this.createApplier(t), f = function(e, n) {
                if (Ne(e, h)) this[fe](e), r & g && this[ue]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            }, h = this.createConstructor(t), p = e[Kt].value, y = e[jt].value, m = [];
            for (const t of a.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: i} = e[n] = this.defineMember(t);
                i && (r & Z && (i.required = !0), p[n] = i, y.push(n)), m.push(n);
            }
            return e.$ = {
                get: qe,
                set: f
            }, e.length = Se(i), e.entries = r & S.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & S.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[de] = Se(f), e[le] = r & d && this.defineVivificatorStruct(t), e[ue] = r & g && this.defineVisitorStruct(a), 
            e[Tt] = r & S.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[Bt] = Se(m), n === s && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), h;
        }
    }), rn({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: i}} = t, s = !!(r & A), a = s ? i.slice(0, -1) : i, c = s ? i[i.length - 1] : null, {get: l, set: u} = this.defineMember(c), {get: f} = this.defineMember(c, !1), h = r & I ? function() {
                return l.call(this)[Mt];
            } : function() {
                const t = l.call(this);
                return a[t].name;
            }, p = r & I ? function(t) {
                const {constructor: e} = c.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = a.findIndex((e => e.name === t));
                u.call(this, e);
            }, y = this.createApplier(t), m = function(e, n) {
                if (Ne(e, b)) this[fe](e), r & g && this[ue]("copy", tt.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of M) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === y.call(this, e, n)) throw new MissingUnionInitializer(t, e, s);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            }, b = this.createConstructor(t), w = {}, v = e[Kt].value, S = e[jt].value, M = [];
            for (const n of a) {
                const {name: i} = n, {get: o, set: a} = this.defineMember(n), c = s ? function() {
                    const e = h.call(this);
                    if (i !== e) {
                        if (r & I) return null;
                        throw new InactiveUnionProperty(t, i, e);
                    }
                    return this[ue]?.("clear"), o.call(this);
                } : o, l = s && a ? function(e) {
                    const n = h.call(this);
                    if (i !== n) throw new InactiveUnionProperty(t, i, n);
                    a.call(this, e);
                } : a, u = s && a ? function(t) {
                    p.call(this, i), a.call(this, t), this[ue]?.("clear");
                } : a;
                e[i] = {
                    get: c,
                    set: l
                }, v[i] = u, w[i] = o, S.push(i), M.push(i);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: m
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & I && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return h.call(this);

                      default:
                        return f.call(this);
                    }
                }
            };
            const {comptime: E} = this;
            return e[ge] = r & x && {
                value() {
                    return E || this[ue](dr), this[ue] = He, this;
                }
            }, e[de] = Se(m), e[Ot] = r & I && {
                get: l,
                set: u
            }, e[le] = r & d && this.defineVivificatorStruct(t), e[ue] = r & g && this.defineVisitorUnion(a, r & I ? f : null), 
            e[Tt] = this.defineUnionEntries(), e[Bt] = r & I ? {
                get() {
                    return [ h.call(this) ];
                }
            } : Se(M), e[Xt] = Se(w), b;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & I && (e.tag = Se(r[r.length - 1].structure.constructor));
        }
    }), rn({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: i, length: s, instance: {members: o}} = t, a = this, c = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[St] = a.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = a.littleEndian;
            };
            return ve(u, {
                [qt]: {
                    value: 4
                }
            }), ve(u.prototype, {
                set: Se((function(t, e, n, r, i) {
                    const s = this[St], o = a.littleEndian;
                    s.setUint16(8 * t, e, o), s.setUint16(8 * t + 2, n, o), s.setUint16(8 * t + 4, r, o), 
                    s.setUint8(8 * t + 6, i == R.Float), s.setUint8(8 * t + 7, i == R.Int || i == R.Float);
                }))
            }), e[le] = i & d && this.defineVivificatorStruct(t), e[ue] = this.defineVisitorVariadicStruct(o), 
            e[me] = Se((function(t) {
                l.call(this, t, this[re]);
            })), function(t) {
                if (t.length < s) throw new ArgumentCountMismatch(s, t.length, !0);
                let e = n, i = r;
                const o = t.slice(s), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[St], o = n?.constructor?.[qt];
                    if (!r || !o) {
                        throw cn(new InvalidVariadicArgument, s + t);
                    }
                    o > i && (i = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = a.allocateMemory(e, i);
                h[qt] = i, this[St] = h, this[At] = {}, a.copyArguments(this, t, c);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: i, structure: {align: s}}] of c.entries()) f.set(t, e / 8, n, s, r), 
                i > d && (d = i);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[St], i = l[t], o = a.obtainView(h.buffer, i, r), c = this[At][n] = e.constructor.call(It, o), u = e.constructor[Zt] ?? 8 * r, g = e.constructor[qt], p = e.constructor[Yt];
                    c.$ = e, f.set(s + t, i, u, g, p);
                }
                this[Ht] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[te] = Se(!!(n & _)), e[qt] = Se(void 0);
        }
    }), rn({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [i]}} = t, s = this.createApplier(t), o = function(e) {
                if (Ne(e, a)) this[fe](e), n & g && this[ue]("copy", tt.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let i = 0;
                    for (const t of e) this[i++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === s.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, a = this.createConstructor(t, {
                initializer: o
            }), {bitSize: c} = i;
            for (let t = 0, s = 0; t < r; t++, s += c) e[t] = n & g ? this.defineMember({
                ...i,
                slot: t
            }) : this.defineMember({
                ...i,
                bitOffset: s
            });
            return e.$ = {
                get: qe,
                set: o
            }, e.length = Se(r), n & L && (e.typedArray = this.defineTypedArray(t), n & N && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[Tt] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[de] = Se(o), e[le] = n & d && this.defineVivificatorArray(t), e[ue] = n & g && this.defineVisitorArray(), 
            a;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = Se(n.structure.constructor);
        }
    }), rn({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? pr[t] : t, r.call(this, e, n);
            }
        })
    });
    const pr = {
        copy(t, e) {
            const n = e[At][0];
            if (this[St][xt] && n && !n[St][xt]) throw new ZigMemoryTargetRequired;
            this[At][0] = n;
        },
        clear(t) {
            t & tt.IsInactive && (this[At][0] = void 0);
        },
        reset() {
            this[At][0] = void 0, this[Pt] = void 0;
        }
    };
    return rn({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: i, structure: s}] of t.entries()) s.flags & g && (0 === r ? n = i : e.push(i));
            return {
                value(t, r, i) {
                    if (!(r & tt.IgnoreArguments) && e.length > 0) for (const n of e) gr.call(this, n, t, r | tt.IsImmutable, i);
                    r & tt.IgnoreRetval || void 0 === n || gr.call(this, n, t, r, i);
                }
            };
        }
    }), rn({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, i = this.length; r < i; r++) gr.call(this, r, t, e, n);
            }
        })
    }), rn({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) && (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || gr.call(this, n, t, r, i);
                }
            };
        }
    }), rn({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, i) {
                    e.call(this) || (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || gr.call(this, n, t, r, i);
                }
            };
        }
    }), rn({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & g)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const i of e) gr.call(this, i, t, n, r);
                }
            };
        }
    }), rn({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: i}] of t.entries()) i?.flags & g && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, i) {
                    const s = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== s && (n |= tt.IsInactive), n & tt.IsInactive && n & tt.IgnoreInactive || gr.call(this, o, t, n, i);
                    }
                }
            };
        }
    }), rn({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & g ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & tt.IgnoreArguments)) for (const [i, s] of Object.entries(this[At])) i !== n && ue in s && gr.call(this, i, t, e | tt.IsImmutable, r);
                    e & tt.IgnoreRetval || void 0 === n || gr.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (sn());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
