(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, s = 3, i = 4, o = 5, a = 6, c = 7, l = 8, u = 9, f = Object.keys(e), h = 1, d = 2, g = 4, p = 8, y = 16, m = 16, b = 32, w = 64, v = 128, S = {
        IsExtern: 16,
        IsPacked: 32,
        IsTuple: 64,
        IsOptional: 128
    }, I = 16, A = 32, x = 64, E = 16, M = 16, U = 16, k = 32, V = 64, O = 128, B = 256, $ = 16, C = 32, _ = 64, T = 128, z = 256, F = 16, j = 16, L = 32, N = 16, P = 32, R = 64, D = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, W = Object.keys(D), Z = 1, q = 2, G = 4, J = 16, H = 64, Y = 128, X = 256, K = 1, Q = 2, tt = 4, et = 8, nt = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, rt = 0, st = 2, it = 6, ot = 8, at = 16, ct = 20, lt = 21, ut = 28, ft = 29, ht = 44, dt = 58, gt = 63, pt = 76, yt = {
        unknown: 0,
        blockDevice: 1,
        characterDevice: 2,
        directory: 3,
        file: 4,
        socketDgram: 5,
        socketStream: 6,
        symbolicLink: 7
    }, mt = {
        create: 1,
        directory: 2,
        exclusive: 4,
        truncate: 8
    }, bt = {
        symlinkFollow: 1
    }, wt = {
        fd_datasync: 1,
        fd_read: 2,
        fd_seek: 4,
        fd_fdstat_set_flags: 8,
        fd_sync: 16,
        fd_tell: 32,
        fd_write: 64,
        fd_advise: 128,
        fd_allocate: 256,
        path_create_directory: 512,
        path_create_file: 1024,
        path_link_source: 2048,
        path_link_target: 4096,
        path_open: 8192,
        fd_readdir: 16384,
        path_readlink: 32768,
        path_rename_source: 65536,
        path_rename_target: 1 << 17,
        path_filestat_get: 1 << 18,
        path_filestat_set_size: 1 << 19,
        path_filestat_set_times: 1 << 20,
        fd_filestat_get: 1 << 21,
        fd_filestat_set_size: 1 << 22,
        fd_filestat_set_times: 1 << 23,
        path_symlink: 1 << 24,
        path_remove_directory: 1 << 25,
        path_unlink_file: 1 << 26,
        poll_fd_readwrite: 1 << 27,
        sock_shutdown: 1 << 28,
        sock_accept: 1 << 29
    }, vt = {
        append: 1,
        dsync: 2,
        nonblock: 4,
        rsync: 8,
        sync: 16
    }, St = 0, It = 1, At = 2, xt = -1, Et = 1048575, Mt = 0, Ut = 1, kt = 2, Vt = globalThis[Symbol.for("ZIGAR")] ||= {};
    function Ot(t) {
        return Vt[t] ||= Symbol(t);
    }
    function Bt(t) {
        return Ot(t);
    }
    const $t = Bt("memory"), Ct = Bt("slots"), _t = Bt("parent"), Tt = Bt("zig"), zt = Bt("name"), Ft = Bt("type"), jt = Bt("flags"), Lt = Bt("class"), Nt = Bt("tag"), Pt = Bt("props"), Rt = Bt("pointer"), Dt = Bt("sentinel"), Wt = Bt("array"), Zt = Bt("target"), qt = Bt("entries"), Gt = Bt("max length"), Jt = Bt("keys"), Ht = Bt("address"), Yt = Bt("length"), Xt = Bt("last address"), Kt = Bt("last length"), Qt = Bt("proxy"), te = Bt("cache"), ee = Bt("size"), ne = Bt("bit size"), re = Bt("align"), se = Bt("const target"), ie = Bt("environment"), oe = Bt("attributes"), ae = Bt("primitive"), ce = Bt("getters"), le = Bt("setters"), ue = Bt("typed array"), fe = Bt("throwing"), he = Bt("promise"), de = Bt("generator"), ge = Bt("allocator"), pe = Bt("fallback"), ye = Bt("signature"), me = Bt("controller"), be = Bt("update"), we = Bt("reset"), ve = Bt("vivificate"), Se = Bt("visit"), Ie = Bt("copy"), Ae = Bt("shape"), xe = Bt("initialize"), Ee = Bt("restrict"), Me = Bt("finalize"), Ue = Bt("cast"), ke = Bt("return"), Ve = Bt("yield"), Oe = Bt("transform");
    function Be(t, e, n) {
        if (n) {
            const {set: r, get: s, value: i, enumerable: o, configurable: a = !0, writable: c = !0} = n;
            Object.defineProperty(t, e, s || r ? {
                get: s,
                set: r,
                configurable: a,
                enumerable: o
            } : {
                value: i,
                configurable: a,
                enumerable: o,
                writable: c
            });
        }
        return t;
    }
    function $e(t, e) {
        for (const [n, r] of Object.entries(e)) Be(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            Be(t, n, e[n]);
        }
        return t;
    }
    function Ce(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function _e(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function Te({type: t, bitSize: e}) {
        switch (t) {
          case D.Bool:
            return "boolean";

          case D.Int:
          case D.Uint:
            if (e > 32) return "bigint";

          case D.Float:
            return "number";
        }
    }
    function ze(t, e = "utf-8") {
        const n = je[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let s = 0;
            for (const e of t) r.set(e, s), s += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function Fe(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (Le[e] ||= new TextEncoder).encode(t);
    }
    const je = {}, Le = {};
    function Ne(t, e, n) {
        let r = 0, s = t.length;
        if (0 === s) return 0;
        for (;r < s; ) {
            const i = Math.floor((r + s) / 2);
            n(t[i]) <= e ? r = i + 1 : s = i;
        }
        return s;
    }
    function Pe(t, e) {
        return !!e && !!(t & BigInt(e - 1));
    }
    function Re(t, e) {
        return t + BigInt(e - 1) & ~BigInt(e - 1);
    }
    const De = 0xFFFFFFFFFFFFFFFFn, We = -1n;
    function Ze(t) {
        return BigInt(t);
    }
    const qe = BigInt(Number.MAX_SAFE_INTEGER), Ge = BigInt(Number.MIN_SAFE_INTEGER);
    function Je(t) {
        if (t > qe || t < Ge) throw new RangeError("Number is too big/small");
        return Number(t);
    }
    function He(t, e, n) {
        return t.getBigUint64(e, n);
    }
    function Ye(t, e, n) {
        return Je(He(t, e, n));
    }
    function Xe(t, e) {
        return t + BigInt(e);
    }
    function Ke(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function Qe(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function tn(t, e) {
        const n = [], r = new Map, s = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) s(n);
        };
        for (const e of t) s(e.instance.template), s(e.static.template);
        return n;
    }
    function en(t, e) {
        return t === e || t?.[ye] === e[ye] && t?.[ie] !== e?.[ie];
    }
    function nn(t, e) {
        return t instanceof e || en(t?.constructor, e);
    }
    function rn(t, e) {
        return "function" == typeof t?.[e];
    }
    function sn(t) {
        return "function" == typeof t?.then;
    }
    function on(t, e) {
        const n = {};
        for (const [r, s] of Object.entries(e)) t & s && (n[r] = !0);
        return n;
    }
    function an(t, e) {
        for (const [n, r] of Object.entries(e)) if (n === t) return r;
    }
    function cn({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function ln(t) {
        return new DataView(new ArrayBuffer(t));
    }
    function un() {
        return this;
    }
    function fn() {
        return this[Qt];
    }
    function hn() {
        return String(this);
    }
    function dn() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return this.map.get(t);
        }
        save(t, e) {
            return this.map.set(t, e), e;
        }
    }
    const gn = 1, pn = 2, yn = 4, mn = 8, bn = () => 1e3 * new Date;
    function wn(t, e, n) {
        const r = {};
        return n & gn ? r.atime = t : n & pn && (r.atime = bn()), n & yn ? r.mtime = e : n & mn && (r.mtime = bn()), 
        r;
    }
    const vn = {
        name: "",
        mixins: []
    };
    function Sn(t) {
        return vn.mixins.includes(t) || vn.mixins.push(t), t;
    }
    function In() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: s} = r;
            Be(r, "name", Ce(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = s[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                Be(s, e, Ce(r));
            }
            return r;
        }(vn.name, vn.mixins);
    }
    function An(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, s) {
                const i = n.getUint8(s) >> t & r;
                e.setUint8(0, i);
            };
            {
                const e = 255 ^ r << t;
                return function(n, s, i) {
                    const o = s.getUint8(0), a = n.getUint8(i) & e | (o & r) << t;
                    n.setUint8(i, a);
                };
            }
        }
        {
            const r = 8 - t, s = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(i, o, a) {
                    let c, l = a, u = 0, f = o.getUint8(l++), h = f >> t & s, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), c = g >= 8 ? 255 & h : h & n, i.setUint8(u++, c), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, i = 255 ^ s << t, o = 255 ^ n;
                return function(r, s, a) {
                    let c, l, u = 0, f = a, h = r.getUint8(f), d = h & i, g = t, p = e + g;
                    do {
                        p > g && (c = s.getUint8(u++), d |= c << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    Sn({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: s, byteSize: i} = e, o = [], a = void 0 === i && (7 & r || 7 & s);
            a && o.push("Unaligned");
            let c = W[n];
            r > 32 && (n === D.Int || n === D.Uint) && (c = r <= 64 ? `Big${c}` : `Jumbo${c}`), 
            o.push(c, `${n === D.Bool && i ? 8 * i : r}`), a && o.push(`@${s}`);
            const l = t + o.join("");
            let u = DataView.prototype[l];
            if (u && this.usingBufferFallback()) {
                const e = this, s = u, i = function(t) {
                    const {buffer: e, byteOffset: n, byteLength: s} = this, i = e[pe];
                    if (i) {
                        if (t < 0 || t + r / 8 > s) throw new RangeError("Offset is outside the bounds of the DataView");
                        return i + Ze(n + t);
                    }
                };
                u = "get" === t ? function(t, o) {
                    const a = i.call(this, t);
                    return void 0 !== a ? e.getNumericValue(n, r, a) : s.call(this, t, o);
                } : function(t, o, a) {
                    const c = i.call(this, t);
                    return void 0 !== c ? e.setNumericValue(n, r, c, o) : s.call(this, t, o, a);
                };
            }
            if (u) return u;
            if (u = this.accessorCache.get(l), u) return u;
            for (;o.length > 0; ) {
                const n = `getAccessor${o.join("")}`;
                if (u = this[n]?.(t, e)) break;
                o.pop();
            }
            if (!u) throw new Error(`No accessor available: ${l}`);
            return Be(u, "name", Ce(l)), this.accessorCache.set(l, u), u;
        },
        imports: {
            getNumericValue: null,
            setNumericValue: null
        }
    }), Sn({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), s = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & s) - (n & r);
            } : function(t, e, n) {
                const i = e < 0 ? r | e & s : e & s;
                this.setBigUint64(t, i, n);
            };
        }
    }), Sn({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const s = e & r;
                this.setBigUint64(t, s, n);
            };
        }
    }), Sn({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, s = this.getAccessor(t, {
                type: D.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!s.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, i) {
                    s.call(this, n, r ? e : t, i);
                };
            }
        }
    }), Sn({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = ln(8), s = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, i = function(t, e, r) {
                const s = 0xffffffffn & e, i = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, a = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(s), r), this.setUint32(t + (r ? 4 : n - 8), Number(i), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(a), r);
            };
            return "get" === t ? function(t, e) {
                const n = s.call(this, t, e), i = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, a = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return i ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : i ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return i ? -t : t;
                }
                const l = i << 63n | c << 52n | (a >> 60n) + BigInt((a & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const s = r.getBigUint64(0, n), o = s >> 63n, a = (0x7ff0000000000000n & s) >> 52n, c = 0x000fffffffffffffn & s;
                let l;
                l = 0n === a ? o << 127n | c << 60n : 0x07ffn === a ? o << 127n | 0x7fffn << 112n | (c ? 1n : 0n) : o << 127n | a - 1023n + 16383n << 112n | c << 60n, 
                i.call(this, t, l, n);
            };
        }
    }), Sn({
        getAccessorFloat16(t, e) {
            const n = ln(4), r = DataView.prototype.setUint16, s = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = s.call(this, t, e), i = r >>> 15, o = (31744 & r) >> 10, a = 1023 & r;
                if (0 === o) return i ? -0 : 0;
                if (31 === o) return a ? NaN : i ? -1 / 0 : 1 / 0;
                const c = i << 31 | o - 15 + 127 << 23 | a << 13;
                return n.setUint32(0, c, e), n.getFloat32(0, e);
            } : function(t, e, s) {
                n.setFloat32(0, e, s);
                const i = n.getUint32(0, s), o = i >>> 31, a = (2139095040 & i) >> 23, c = 8388607 & i, l = a - 127 + 15;
                let u;
                u = 0 === a ? o << 15 : 255 === a ? o << 15 | 31744 | (c ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | c >> 13, 
                r.call(this, t, u, s);
            };
        }
    }), Sn({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = ln(8), s = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, i = function(t, e, r) {
                const s = 0xffffffffn & e, i = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(s), r), this.setUint32(t + (r ? 4 : n - 8), Number(i), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = s.call(this, t, e), i = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, a = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return i ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : i ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return i ? -t : t;
                }
                const l = i << 63n | c << 52n | (a >> 11n) + BigInt((a & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const s = r.getBigUint64(0, n), o = s >> 63n, a = (0x7ff0000000000000n & s) >> 52n, c = 0x000fffffffffffffn & s;
                let l;
                l = 0n === a ? o << 79n | c << 11n : 0x07ffn === a ? o << 79n | 0x7fffn << 64n | (c ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | a - 1023n + 16383n << 64n | c << 11n | 0x00008000000000000000n, 
                i.call(this, t, l, n);
            };
        }
    }), Sn({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: D.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), s = 2 ** (n - 1), i = s - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & i) - (r & s);
                } : function(t, n, r) {
                    const o = n < 0 ? s | n & i : n & i;
                    e.call(this, t, o, r);
                };
            }
        }
    }), Sn({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), s = 2n ** BigInt(n - 1), i = s - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & i) - (n & s);
            } : function(t, e, n) {
                const o = e < 0 ? s | e & i : e & i;
                r.call(this, t, o, n);
            };
        }
    }), Sn({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), s = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & s;
            } : function(t, e, n) {
                const i = e & s;
                r.call(this, t, i, n);
            };
        }
    }), Sn({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let s = 0, i = t + 8 * (n - 1); s < n; s++, i -= 8) {
                    r = r << 64n | this.getBigUint64(i, e);
                } else for (let s = 0, i = t; s < n; s++, i += 8) {
                    r = r << 64n | this.getBigUint64(i, e);
                }
                return r;
            } : function(t, e, r) {
                let s = e;
                const i = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = s & i;
                    this.setBigUint64(o, t, r), s >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = s & i;
                    this.setBigUint64(o, t, r), s >>= 64n;
                }
            };
        }
    }), Sn({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const s = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), i = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return s.call(this, t, e) & i;
                } : function(t, e, n) {
                    const r = e & i;
                    s.call(this, t, r, n);
                };
            }
        }
    }), Sn({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), s = e ? n | r : n & ~r;
                this.setInt8(t, s);
            };
        }
    }), Sn({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r;
            if (s + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> s;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << s;
                    return function(n, i) {
                        let o = this.getUint8(n);
                        o = o & t | (i < 0 ? e | i & r : i & r) << s, this.setUint8(n, o);
                    };
                }
            }
        }
    }), Sn({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r;
            if (s + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> s & e;
                };
                {
                    const t = 255 ^ e << s;
                    return function(n, r) {
                        const i = this.getUint8(n) & t | (r & e) << s;
                        this.setUint8(n, i);
                    };
                }
            }
        }
    }), Sn({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r, i = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = ln(i);
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: i
                }), r = An(s, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: i
                }), r = An(s, n, !1);
                return function(e, n, s) {
                    t.call(o, 0, n, s), r(this, o, e);
                };
            }
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        code=dt;
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: s, type: i, byteSize: o} = t, a = n.byteLength, c = 1 !== o ? "s" : "";
            let l;
            if (i !== e.Slice || r) {
                l = `${s} has ${i === e.Slice ? r.length * o : o} byte${c}, received ${a}`;
            } else l = `${s} has elements that are ${o} byte${c} in length, received ${a}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: s} = t, i = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(_n);
            let a;
            s && o.push(_n(s.name)), a = n === e.Slice ? `Expecting ${zn(o)} that can accommodate items ${r} byte${i} in length` : `Expecting ${zn(o)} that is ${r} byte${i} in length`, 
            super(a);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let s;
            "string" === r || "number" === r || $n(e) ? ($n(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            s = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : s = `Error of the type ${n} expected, received ${e}`, 
            super(s);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Error given is not a part of error set ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: s}} = t;
            super(`${r} needs an initializer for one of its union properties: ${s.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, s = [];
            if (Array.isArray(e)) for (const t of e) s.push(_n(t)); else s.push(_n(e));
            const i = Cn(n);
            super(`${r} expects ${zn(s)} as argument, received ${i}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [s]}, type: i, constructor: o} = t, a = [], c = Te(s);
            if (c) {
                let t;
                switch (s.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = c;
                }
                a.push(`array of ${t}s`);
            } else a.push("array of objects");
            o[ue] && a.push(o[ue].name), i === e.Slice && r && a.push("length"), super(t, a.join(" or "), n);
        }
    }
    class InvalidEnumValue extends TypeError {
        code=ut;
        constructor(t, e) {
            super(`Received '${e}', which is not among the following possible values:\n\n${Object.keys(t).map((t => `${t}\n`)).join("")}`);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: s, instance: {members: [i]}} = t, {structure: {constructor: o}} = i, {length: a, constructor: c} = n, l = e?.length ?? s, u = 1 !== l ? "s" : "";
            let f;
            f = c === o ? "only a single one" : c.child === o ? `a slice/array that has ${a}` : `${a} initializer${a > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let s;
            s = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(s);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const s = 1 !== (t -= r) ? "s" : "", i = n ? "at least " : "";
                this.message = `Expecting ${i}${t} argument${s}, received ${e}`, this.stack = En(this.stack, "new Arg(");
            };
            r(0), Be(this, be, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: s} = t;
            super(`${s} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = Cn(e);
            super(`Expected ${_n(t)}, received ${n}`);
        }
    }
    class InvalidStream extends TypeError {
        constructor(t, e) {
            const n = [];
            t & wt.fd_read && n.push("ReadableStreamDefaultReader", "ReadableStreamBYOBReader", "Blob", "Uint8Array"), 
            t & wt.fd_write && n.push("WritableStreamDefaultWriter", "array", "null"), t & wt.fd_readdir && n.push("Map");
            super(`Expected ${n.join(", ")}, or an object with the appropriate stream interface, received ${e}`);
        }
    }
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${Tn(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + W[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class InvalidFileDescriptor extends Error {
        code=ot;
        constructor() {
            super("Invalid file descriptor");
        }
    }
    class InvalidPath extends Error {
        code=ht;
        constructor(t) {
            super(`Invalid relative path '${t}'`);
        }
    }
    class MissingStreamMethod extends Error {
        code=gt;
        constructor(t) {
            super(`Missing stream method '${t}'`);
        }
    }
    class InvalidArgument extends Error {
        code=ut;
        constructor() {
            super("Invalid argument");
        }
    }
    class WouldBlock extends Error {
        code=it;
        constructor() {
            super("Would block");
        }
    }
    class Deadlock extends Error {
        code=at;
        constructor() {
            super("Unable to await promise");
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = En(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function xn(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = En(t.stack, "new Arg(");
        };
        return n(0), Be(t, be, {
            value: n,
            enumerable: !1
        }), t;
    }
    function En(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function Mn() {
        throw new ReadOnly;
    }
    function Un(t, e, n) {
        if (t.bytes += n, t.calls++, 100 === t.calls) {
            const n = t.bytes / t.calls;
            if (n < 8) {
                throw new Error(`Inefficient ${e} access. Each call is only ${"read" === e ? "reading" : "writing"} ${n} byte${1 !== n ? "s" : ""}. Please use std.io.Buffered${"read" === e ? "Reader" : "Writer"}.`);
            }
        }
    }
    function kn(t = !1, e, n, r, s) {
        const i = t => {
            let n;
            return s ? n = s(t) : t.code !== it && t.code !== dt && console.error(t), n ?? t.code ?? e;
        }, o = t => {
            const e = r?.(t);
            return e ?? rt;
        };
        try {
            const e = n();
            if (sn(e)) {
                if (!t) throw new Deadlock;
                return e.then(o).catch(i);
            }
            return o(e);
        } catch (t) {
            return i(t);
        }
    }
    function Vn(t, e) {
        if (!(t[0] & e)) throw new InvalidFileDescriptor;
    }
    function On(t, e) {
        if (!rn(t, e)) throw new MissingStreamMethod(e);
    }
    function Bn(t, e) {
        if (!0 === t) return rt;
        if (!1 === t) return e;
        throw new TypeMismatch("boolean", t);
    }
    function $n(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function Cn(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        _n(n);
    }
    function _n(t) {
        return `${Tn(t)} ${t}`;
    }
    function Tn(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function zn(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function Fn(t) {
        let n, r = 1, s = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[Tt]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[$t]) t.constructor[Ft] === e.Pointer && (t = t["*"]), 
        n = t[$t], s = t.constructor, r = s[re]; else {
            "string" == typeof t && (t = Fe(t));
            const {buffer: e, byteOffset: s, byteLength: i, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== s && void 0 !== i && (n = new DataView(e, s, i), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: s
        };
    }
    Sn({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: s}, ptr: i} = this, o = s(i, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const a = o["*"][$t];
                return a[Tt].align = e, a;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = Fn(e), s = n?.[Tt];
                    if (!s) throw new TypeMismatch("object containing allocated Zig memory", e);
                    const {address: i} = s;
                    if (i === We) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: a} = this;
                    o(a, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe() {
            const t = this.getCopyFunction();
            return {
                value(e) {
                    const {dv: n, align: r, constructor: s} = Fn(e);
                    if (!n) throw new TypeMismatch("string, DataView, typed array, or Zig object", e);
                    const i = this.alloc(n.byteLength, r);
                    return t(i, n), s ? s(i) : i;
                }
            };
        }
    }), Sn({
        init() {
            this.variables = [], this.listenerMap = new Map([ [ "log", t => console.log(t.message) ] ]), 
            this.lastEvent = "";
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: () => this.initPromise,
                abandon: () => this.abandonModule?.(),
                redirect: (t, e) => this.redirectStream(t, e),
                sizeOf: e => t(e?.[ee]),
                alignOf: e => t(e?.[re]),
                typeOf: e => jn[t(e?.[Ft])],
                on: (t, e) => this.addListener(t, e),
                wasi: void 0
            };
        },
        addListener(t, e) {
            [ "mkdir", "stat", "set_times", "open", "rmdir", "unlink", "syscall" ].includes(t) && this.setRedirectionMask(t, !!e), 
            this.listenerMap.set(t, e);
        },
        hasListener(t) {
            return this.listenerMap.get(t);
        },
        triggerEvent(t, e) {
            const n = this.listenerMap.get(t);
            this.lastEvent = t;
            const r = n?.(e);
            return this.lastEvent = null, r;
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = s(r);
                return t;
            }, r = t => t.length ? t.buffer : new ArrayBuffer(0), s = t => {
                const {memory: e, structure: s, actual: i} = t;
                if (e) {
                    if (i) return i;
                    {
                        const {array: i, offset: o, length: a} = e, c = this.obtainView(r(i), o, a), {handle: l, const: u} = t, f = s?.constructor, h = t.actual = f.call(ie, c);
                        return u && this.makeReadOnly(h), t.slots && n(h[Ct], t.slots), l && this.variables.push({
                            handle: l,
                            object: h
                        }), h;
                    }
                }
                return s;
            }, i = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: s} = t.template, o = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: i} = n;
                        o[$t] = this.obtainView(r(t), e, i), s && this.variables.push({
                            handle: s,
                            object: o
                        });
                    }
                    if (e) {
                        const t = o[Ct] = {};
                        i.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of i) n(t, e);
            for (const e of t) this.finalizeStructure(e);
        }
    });
    const jn = f.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    Sn({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[$t]), s = this.createJsThunk(t, n);
                if (!s) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(s, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                try {
                    const s = e(n);
                    if (Se in s) {
                        s[Se]("reset", nt.IgnoreUncreated);
                        const t = this.startContext();
                        this.updatePointerTargets(t, s, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const i = [ ...s ], o = s.hasOwnProperty(ke), a = kn(r || o, lt, (() => t(...i)), (t => {
                        if (t?.[Symbol.asyncIterator]) {
                            if (!s.hasOwnProperty(Ve)) throw new UnexpectedGenerator;
                            this.pipeContents(t, s);
                        } else s[ke](t);
                    }), (t => {
                        try {
                            if (e[fe] && t instanceof Error) return s[ke](t), rt;
                            throw t;
                        } catch (e) {
                            console.error(t);
                        }
                    }));
                    return o ? rt : a;
                } catch (t) {
                    return console.error(t), lt;
                }
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, a = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === i)).length;
            return {
                value() {
                    let c, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, y, m = this[d];
                        if (p === D.Object && m?.[$t]?.[Tt] && (m = new m.constructor(m)), g.type === e.Struct) switch (g.purpose) {
                          case i:
                            t = 1 === a ? "allocator" : "allocator" + ++l, y = this[ge] = m;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (y = o.createPromiseCallback(this, m));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (y = o.createGeneratorCallback(this, m));
                            break;

                          case s:
                            t = "signal", 1 == ++f && (y = o.createInboundSignal(m));
                        }
                        void 0 !== t ? void 0 !== y && (c ||= {}, c[t] = y) : h.push(m);
                    } catch (t) {
                        h.push(t);
                    }
                    return c && h.push(c), h[Symbol.iterator]();
                }
            };
        },
        handleJscall(t, e, n, r) {
            const s = this.obtainZigView(e, n, !1), i = this.jsFunctionCallerMap.get(t);
            return i ? i(s, r) : lt;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[$t]), s = this.getViewAddress(e);
                this.destroyJsThunk(r, s), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJscall: {
                async: !0
            },
            releaseFunction: {}
        },
        imports: {
            createJsThunk: {},
            destroyJsThunk: {},
            finalizeAsyncCall: {}
        }
    }), Sn({
        createOutboundCaller(t, e) {
            const n = this, r = function(...s) {
                const i = new e(s, this?.[ge]);
                return n.invokeThunk(t, r, i);
            };
            return r;
        },
        copyArguments(t, o, f, h, d) {
            let g = 0, p = 0, y = 0;
            const m = t[le];
            for (const {type: b, structure: w} of f) {
                let f, v, S, I;
                if (w.type === e.Struct) switch (w.purpose) {
                  case i:
                    f = (1 == ++y ? h?.allocator ?? h?.allocator1 : h?.[`allocator${y}`]) ?? this.createDefaultAllocator(t, w);
                    break;

                  case n:
                    v ||= this.createPromise(w, t, h?.callback), f = v;
                    break;

                  case r:
                    S ||= this.createGenerator(w, t, h?.callback), f = S;
                    break;

                  case s:
                    I ||= this.createSignal(w, h?.signal), f = I;
                    break;

                  case a:
                    f = this.createReader(o[p++]);
                    break;

                  case c:
                    f = this.createWriter(o[p++]);
                    break;

                  case l:
                    f = this.createFile(o[p++]);
                    break;

                  case u:
                    f = this.createDirectory(o[p++]);
                }
                if (void 0 === f && (f = o[p++], void 0 === f && b !== D.Void)) throw new UndefinedArgument;
                try {
                    m[g++].call(t, f, d);
                } catch (t) {
                    throw xn(t, g - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), s = n[oe], i = this.getViewAddress(t[$t]), o = this.getViewAddress(e[$t]), a = Me in n, c = Se in n;
            c && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[$t]), u = s ? this.getViewAddress(s[$t]) : 0;
            this.updateShadows(r);
            let f = !1;
            const h = () => {
                this.updateShadowTargets(r), c && this.updatePointerTargets(r, n), this.flushStreams?.(), 
                this.endContext(), f = !0;
            };
            a && (n[Me] = h);
            if (!(s ? this.runVariadicThunk(i, o, l, u, s.length) : this.runThunk(i, o, l))) throw f || h(), 
            new ZigError;
            const d = e[Oe];
            if (a) {
                let t = null;
                if (!f) try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (d && (t = d(t)), n[ke](t)) : d && (n[Oe] = d), n[he] ?? n[de];
            }
            h();
            try {
                const {retval: t} = n;
                return d ? d(t) : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    }), Sn({
        init() {
            const t = {
                type: D.Int,
                bitSize: 8,
                byteSize: 1
            }, e = {
                type: D.Int,
                bitSize: 16,
                byteSize: 2
            }, n = {
                type: D.Int,
                bitSize: 32,
                byteSize: 4
            }, r = this.getAccessor("get", t), s = this.getAccessor("set", t), i = this.getAccessor("get", e), o = this.getAccessor("set", e), a = this.getAccessor("get", n), c = this.getAccessor("set", n);
            this.copiers = {
                0: dn,
                1: function(t, e) {
                    s.call(t, 0, r.call(e, 0));
                },
                2: function(t, e) {
                    o.call(t, 0, i.call(e, 0, !0), !0);
                },
                4: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0);
                },
                8: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0), c.call(t, 4, a.call(e, 4, !0), !0);
                },
                16: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0), c.call(t, 4, a.call(e, 4, !0), !0), c.call(t, 8, a.call(e, 8, !0), !0), 
                    c.call(t, 12, a.call(e, 12, !0), !0);
                },
                any: function(t, e) {
                    let n = 0, i = t.byteLength;
                    for (;n + 4 <= i; ) c.call(t, n, a.call(e, n, !0), !0), n += 4;
                    for (;n + 1 <= i; ) s.call(t, n, r.call(e, n)), n++;
                }
            }, this.resetters = {
                0: dn,
                1: function(t, e) {
                    s.call(t, e, 0);
                },
                2: function(t, e) {
                    o.call(t, e, 0, !0);
                },
                4: function(t, e) {
                    c.call(t, e, 0, !0);
                },
                8: function(t, e) {
                    c.call(t, e + 0, 0, !0), c.call(t, e + 4, 0, !0);
                },
                16: function(t, e) {
                    c.call(t, e + 0, 0, !0), c.call(t, e + 4, 0, !0), c.call(t, e + 8, 0, !0), c.call(t, e + 12, 0, !0);
                },
                any: function(t, e, n) {
                    let r = e;
                    for (;r + 4 <= n; ) c.call(t, r, 0, !0), r += 4;
                    for (;r + 1 <= n; ) s.call(t, r, 0), r++;
                }
            };
        },
        defineCopier(t, e) {
            const n = this.getCopyFunction(t, e);
            return {
                value(t) {
                    const e = t[$t], r = this[$t];
                    n(r, e);
                }
            };
        },
        defineResetter(t, e) {
            const n = this.getResetFunction(e);
            return {
                value() {
                    const r = this[$t];
                    n(r, t, e);
                }
            };
        },
        getCopyFunction(t, e = !1) {
            return (e ? void 0 : this.copiers[t]) ?? this.copiers.any;
        },
        getResetFunction(t) {
            return this.resetters[t] ?? this.resetters.any;
        },
        imports: {
            moveExternBytes: {}
        }
    });
    class AsyncReader {
        bytes=null;
        promise=null;
        done=!1;
        readnb(t) {
            if ("number" != typeof this.poll()) throw new WouldBlock;
            return this.shift(t);
        }
        async read(t) {
            return await this.poll(), this.shift(t);
        }
        store({done: t, value: e}) {
            return t ? (this.done = !0, 0) : (e instanceof Uint8Array || (e = e instanceof ArrayBuffer ? new Uint8Array(e) : e.buffer instanceof ArrayBuffer ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : Fe(e + "")), 
            this.bytes = e, e.length);
        }
        shift(t) {
            let e;
            return this.bytes && (this.bytes.length > t ? (e = this.bytes.subarray(0, t), this.bytes = this.bytes.subarray(t)) : (e = this.bytes, 
            this.bytes = null)), e ?? new Uint8Array(0);
        }
        poll() {
            const t = this.bytes?.length;
            return t || (this.promise ??= this.fetch().then((t => (this.promise = null, this.store(t)))));
        }
    }
    class WebStreamReader extends AsyncReader {
        onClose=null;
        constructor(t) {
            super(), this.reader = t, t.close = () => this.onClose?.();
        }
        async fetch() {
            return this.reader.read();
        }
        destroy() {
            this.done || this.reader.cancel(), this.bytes = null;
        }
        valueOf() {
            return this.reader;
        }
    }
    class WebStreamReaderBYOB extends WebStreamReader {
        async fetch() {
            const t = new Uint8Array(Nn);
            return this.reader.read(t);
        }
    }
    class AsyncWriter {
        promise=null;
        writenb(t) {
            if ("number" != typeof this.poll()) throw new WouldBlock;
            this.queue(t);
        }
        async write(t) {
            await this.poll(), await this.queue(t);
        }
        queue(t) {
            return this.promise = this.send(t).then((() => {
                this.promise = null;
            }));
        }
        poll() {
            return this.promise?.then?.((() => Pn)) ?? Pn;
        }
    }
    class WebStreamWriter extends AsyncWriter {
        onClose=null;
        done=!1;
        constructor(t) {
            super(), this.writer = t, t.closed.catch(dn).then((() => {
                this.done = !0, this.onClose?.();
            }));
        }
        async send(t) {
            await this.writer.write(t);
        }
        destroy() {
            this.done || this.writer.close();
        }
        valueOf() {
            return this.writer;
        }
    }
    class BlobReader extends AsyncReader {
        pos=0;
        onClose=null;
        constructor(t) {
            super(), this.blob = t, this.size = t.size, t.close = () => this.onClose?.();
        }
        async fetch() {
            const t = await this.pread(Nn, this.pos), {length: e} = t;
            return {
                done: !e,
                value: e ? t : null
            };
        }
        async pread(t, e) {
            const n = this.blob.slice(e, e + t), r = new Response(n), s = await r.arrayBuffer();
            return new Uint8Array(s);
        }
        async read(t) {
            const e = await super.read(t);
            return this.pos += e.length, e;
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            return this.done = !1, this.bytes = null, this.pos = Ln(e, t, this.pos, this.size);
        }
        valueOf() {
            return this.blob;
        }
    }
    class Uint8ArrayReadWriter {
        pos=0;
        onClose=null;
        constructor(t) {
            this.array = t, this.size = t.length, t.close = () => this.onClose?.();
        }
        readnb(t) {
            return this.read(t);
        }
        read(t) {
            const e = this.pread(t, this.pos);
            return this.pos += e.length, e;
        }
        writenb(t) {
            return this.write(t);
        }
        write(t) {
            this.pwrite(t, this.pos), this.pos += t.length;
        }
        pread(t, e) {
            return this.array.subarray(e, e + t);
        }
        pwrite(t, e) {
            this.array.set(t, e);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            return this.pos = Ln(e, t, this.pos, this.size);
        }
        poll() {
            return this.size - this.pos;
        }
        valueOf() {
            return this.array;
        }
    }
    class ArrayWriter {
        constructor(t) {
            this.array = t, this.closeCB = null, t.close = () => this.onClose?.();
        }
        writenb(t) {
            this.write(t);
        }
        write(t) {
            this.array.push(t);
        }
        poll() {
            return Pn;
        }
        valueOf() {
            return this.array;
        }
    }
    class NullStream {
        read() {
            return this.pread();
        }
        pread() {
            return new Uint8Array(0);
        }
        write() {}
        pwrite() {}
        poll(t) {
            return t === Ut ? 0 : Pn;
        }
        valueOf() {
            return null;
        }
    }
    class MapDirectory {
        onClose=null;
        keys=null;
        cookie=0;
        constructor(t) {
            this.map = t, this.size = t.size, t.close = () => this.onClose?.();
        }
        readdir() {
            const t = this.cookie;
            let e;
            switch (t) {
              case 0:
              case 1:
                e = {
                    name: ".".repeat(t + 1),
                    type: "directory"
                };
                break;

              default:
                this.keys || (this.keys = [ ...this.map.keys() ]);
                const n = this.keys[t - 2];
                if (void 0 === n) return null;
                e = {
                    name: n,
                    ...this.map.get(n)
                };
            }
            return this.cookie++, e;
        }
        seek(t) {
            return this.cookie = t;
        }
        tell() {
            return this.cookie;
        }
        valueOf() {
            return this.map;
        }
    }
    function Ln(t, e, n, r) {
        let s = -1;
        switch (t) {
          case 0:
            s = e;
            break;

          case 1:
            s = n + e;
            break;

          case 2:
            s = r + e;
        }
        if (!(s >= 0 && s <= r)) throw new InvalidArgument;
        return s;
    }
    const Nn = 8192, Pn = 16777216;
    function Rn(t, e) {
        return Ne(t, e, (t => t.address));
    }
    Sn({
        convertDirectory: t => t instanceof Map ? new MapDirectory(t) : rn(t, "readdir") ? t : void 0
    }), Sn({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: s, bitSize: i} = n;
            if ("set" === e) return i > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const s = Number(e);
                if (!isFinite(s)) throw new InvalidIntConversion(e);
                r.call(this, t, s, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & y && i > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, s) {
                        const i = r.call(this, n, s);
                        return e <= i && i <= t ? Number(i) : i;
                    };
                }
            }
            return r;
        }
    }), Sn({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const s = e[$t];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: i, targets: o} = n;
                    let a, c = 0;
                    for (const t of o) {
                        const e = t[$t], n = e.byteOffset, r = t.constructor[re] ?? e[re];
                        (void 0 === c || r > c) && (c = r, a = n);
                    }
                    const l = i - e, u = this.allocateShadowMemory(l + c, 1), f = this.getViewAddress(u), h = Re(Xe(f, a - e), c), d = Xe(h, e - a);
                    for (const t of o) {
                        const n = t[$t], r = n.byteOffset;
                        if (r !== a) {
                            const s = t.constructor[re] ?? n[re];
                            if (Pe(Xe(d, r - e), s)) throw new AlignmentConflict(s, c);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), y = new DataView(s.buffer, Number(e), l), m = this.registerMemory(d, l, 1, r, y, p);
                    t.shadowList.push(m), n.address = d;
                }
                return Xe(n.address, s.byteOffset - n.start);
            }
            {
                const n = e.constructor[re] ?? s[re], i = s.byteLength, o = this.allocateShadowMemory(i, n), a = this.getViewAddress(o), c = this.registerMemory(a, i, 1, r, s, o);
                return t.shadowList.push(c), a;
            }
        },
        updateShadows(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r} of t.shadowList) e(r, n);
        },
        updateShadowTargets(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r, writable: s} of t.shadowList) s && e(n, r);
        },
        registerMemory(t, e, n, r, s, i) {
            const o = Rn(this.memoryList, t);
            let a = this.memoryList[o - 1];
            return a?.address === t && a.len === e ? a.writable ||= r : (a = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: s,
                shadowDV: i
            }, this.memoryList.splice(o, 0, a)), a;
        },
        unregisterMemory(t, e) {
            const n = Rn(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            let s = n * (r ?? 0);
            const i = Rn(this.memoryList, e), o = this.memoryList[i - 1];
            let a;
            if (o?.address === e && o.len === s) a = o.targetDV; else if (o?.address <= e && Xe(e, s) <= Xe(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: i} = o;
                n && (s = i.byteLength - t), a = this.obtainView(i.buffer, i.byteOffset + t, s), 
                n && (a[re] = o.align);
            }
            if (a) {
                let {targetDV: e, shadowDV: n} = o;
                if (n && t && !t.shadowList.includes(o)) {
                    this.getCopyFunction()(e, n);
                }
            } else a = this.obtainZigView(e, s);
            return a;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[Tt], n = e?.address;
            n && n !== We && (e.address = We, this.unregisterBuffer(Xe(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[Tt];
            if (e) return e.address;
            return Xe(this.getBufferAddress(t.buffer), t.byteOffset);
        },
        obtainZigArray(t, e) {
            const n = this.obtainZigView(t, e, !1);
            return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        },
        ...{
            imports: {
                getBufferAddress: {},
                obtainExternBuffer: {}
            },
            exports: {
                getViewAddress: {}
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (function(t) {
                    return 0xaaaaaaaaaaaaaaaan === t;
                }(t) && (t = e > 0 ? 0 : De), !t && e) return null;
                let r, s;
                if (n) {
                    const n = Rn(this.externBufferList, t), i = this.externBufferList[n - 1];
                    i?.address <= t && Xe(t, e) <= Xe(i.address, i.len) ? (r = i.buffer, s = Number(t - i.address)) : (r = e > 0 ? this.obtainExternBuffer(t, e, pe) : new ArrayBuffer(0), 
                    r[Tt] = {
                        address: t,
                        len: e
                    }, s = 0, this.externBufferList.splice(n, 0, {
                        address: t,
                        len: e,
                        buffer: r
                    }));
                } else r = e > 0 ? this.obtainExternBuffer(t, e, pe) : new ArrayBuffer(0), r[Tt] = {
                    address: t,
                    len: e
                }, s = 0;
                return this.obtainView(r, s, e);
            },
            unregisterBuffer(t) {
                const e = Rn(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const s = e[$t];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(s.buffer);
                        for (const e of n.targets) {
                            const r = e[$t].byteOffset, s = e.constructor[re];
                            if (Pe(Xe(t, r), s)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return Xe(n.address, s.byteOffset);
                } else {
                    const t = e.constructor[re], n = this.getViewAddress(s);
                    if (!Pe(n, t)) {
                        const e = s.byteLength;
                        return this.registerMemory(n, e, t, r, s), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), Sn({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: {}
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const {async: r = !1} = n;
                    let s = this[e];
                    s && (r && (s = this.addPromiseHandling(s)), t[e] = s.bind(this));
                }
                return t;
            },
            addPromiseHandling(t) {
                const e = t.length - 1;
                return function(...n) {
                    const r = n[e], s = !!r;
                    n[e] = s;
                    const i = t.call(this, ...n);
                    return s ? (sn(i) ? i.then((t => this.finalizeAsyncCall(r, t))) : this.finalizeAsyncCall(r, i), 
                    rt) : i;
                };
            },
            importFunctions(t) {
                for (const [e] of Object.entries(this.imports)) {
                    const n = t[e];
                    n && (Be(this, e, Ce(n)), this.destructors.push((() => this[e] = Dn)));
                }
            }
        }
    });
    const Dn = () => {
        throw new Error("Module was abandoned");
    };
    Sn({
        linkVariables(t) {
            const e = this.getCopyFunction();
            for (const {object: n, handle: r} of this.variables) {
                const s = n[$t], i = this.recreateAddress(r);
                let o = n[$t] = this.obtainZigView(i, s.byteLength);
                t && e(o, s), n.constructor[te]?.save?.(o, n), this.destructors.push((() => {
                    const t = n[$t] = this.allocateMemory(o.bytelength);
                    e(t, o);
                }));
                const a = t => {
                    const e = t[Ct];
                    if (e) {
                        const t = o.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[$t];
                            if (e.buffer === s.buffer) {
                                const r = t + e.byteOffset - s.byteOffset;
                                n[$t] = this.obtainView(o.buffer, r, e.byteLength), n.constructor[te]?.save?.(o, n), 
                                a(n);
                            }
                        }
                    }
                };
                a(n), n[Se]?.((function() {
                    this[be]();
                }), nt.IgnoreInactive);
            }
            this.createDeferredThunks?.();
        },
        imports: {
            recreateAddress: null
        }
    }), Sn({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, s = [], i = function(t) {
                const e = this[Rt];
                if (void 0 === n.get(e)) {
                    const t = e[Ct][0];
                    if (t) {
                        const o = {
                            target: t,
                            writable: !e.constructor.const
                        }, a = t[$t];
                        if (a[Tt]) n.set(e, null); else {
                            n.set(e, t);
                            const c = r.get(a.buffer);
                            if (c) {
                                const t = Array.isArray(c) ? c : [ c ], e = Ne(t, a.byteOffset, (t => t.target[$t].byteOffset));
                                t.splice(e, 0, o), Array.isArray(c) || (r.set(a.buffer, t), s.push(t));
                            } else r.set(a.buffer, o);
                            t[Se]?.(i, 0);
                        }
                    }
                }
            }, o = nt.IgnoreRetval | nt.IgnoreInactive;
            e[Se](i, o);
            const a = this.findTargetClusters(s), c = new Map;
            for (const t of a) for (const e of t.targets) c.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = c.get(r), s = n?.writable ?? !e.constructor.const;
                e[Ht] = this.getTargetAddress(t, r, n, s), Yt in e && (e[Yt] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, s = function(e) {
                const n = this[Rt];
                if (!r.get(n)) {
                    r.set(n, !0);
                    const i = n[Ct][0], o = i && e & nt.IsImmutable ? i : n[be](t, !0, !(e & nt.IsInactive)), a = n.constructor.const ? nt.IsImmutable : 0;
                    a & nt.IsImmutable || i && !i[$t][Tt] && i[Se]?.(s, a), o !== i && o && !o[$t][Tt] && o?.[Se]?.(s, a);
                }
            }, i = n ? nt.IgnoreRetval : 0;
            e[Se](s, i);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, s = 0, i = null;
                for (const {target: o, writable: a} of n) {
                    const n = o[$t], {byteOffset: c, byteLength: l} = n, u = c + l;
                    let f = !0;
                    t && (s > c ? (i ? i.writable ||= a : (i = {
                        targets: [ t ],
                        start: r,
                        end: s,
                        address: void 0,
                        misaligned: void 0,
                        writable: a
                    }, e.push(i)), i.targets.push(o), u > s ? i.end = u : f = !1) : i = null), f && (t = o, 
                    r = c, s = u);
                }
            }
            return e;
        }
    }), Sn({
        convertReader: t => t instanceof ReadableStreamDefaultReader ? new WebStreamReader(t) : t instanceof ReadableStreamBYOBReader ? new WebStreamReaderBYOB(t) : t instanceof Blob ? new BlobReader(t) : t instanceof Uint8Array ? new Uint8ArrayReadWriter(t) : null === t ? new NullStream : rn(t, "read") ? t : void 0
    }), Sn({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === D.Int;
                    let s = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** s) : 0,
                            max: 2 ** s - 1
                        };
                    }
                    s = BigInt(s);
                    return {
                        min: r ? -(2n ** s) : 0n,
                        max: 2n ** s - 1n
                    };
                }(n);
                return function(s, i, o) {
                    if (i < t || i > e) throw new Overflow(n, i);
                    r.call(this, s, i, o);
                };
            }
            return r;
        }
    }), Sn({
        init() {
            this.streamLocationMap = new Map([ [ xt, "" ] ]);
        },
        obtainStreamLocation(t, e, n) {
            let r = ze(this.obtainZigArray(e, n)).trim();
            r.endsWith("/") && (r = r.slice(0, -1));
            const s = r.trim().split("/"), i = [];
            for (const t of s) if (".." === t) {
                if (!(i.length > 0)) throw new InvalidPath(r);
                i.pop();
            } else "." !== t && "" != t && i.push(t);
            s[0] || (t = xt);
            const [o] = this.getStream(t);
            return {
                parent: o.valueOf(),
                path: i.join("/")
            };
        },
        getStreamLocation(t) {
            return this.streamLocationMap.get(t);
        },
        setStreamLocation(t, e) {
            const n = this.streamLocationMap;
            e ? n.set(t, e) : n.delete(t);
        }
    });
    const Wn = [ wt.fd_read, 0 ], Zn = [ wt.fd_write, 0 ], qn = wt.fd_seek | wt.fd_fdstat_set_flags | wt.fd_tell | wt.path_create_directory | wt.path_create_file | wt.path_open | wt.fd_readdir | wt.path_filestat_get | wt.path_filestat_set_size | wt.path_filestat_set_times | wt.fd_filestat_get | wt.fd_filestat_set_times | wt.path_remove_directory | wt.path_unlink_file, Gn = wt.fd_datasync | wt.fd_read | wt.fd_seek | wt.fd_sync | wt.fd_tell | wt.fd_write | wt.fd_advise | wt.fd_allocate | wt.fd_filestat_get | wt.fd_filestat_set_times | wt.fd_filestat_set_size;
    Sn({
        init() {
            const t = {
                cookie: 0n,
                readdir() {
                    const t = Number(this.cookie);
                    let e = null;
                    switch (t) {
                      case 0:
                      case 1:
                        e = {
                            name: ".".repeat(t + 1),
                            type: "directory"
                        };
                    }
                    return e;
                },
                seek(t) {
                    return this.cookie = t;
                },
                tell() {
                    return this.cookie;
                },
                valueOf: () => null
            };
            this.streamMap = new Map([ [ xt, [ t, this.getDefaultRights("dir"), 0 ] ], [ It, [ this.createLogWriter("stdout"), Zn, 0 ] ], [ At, [ this.createLogWriter("stderr"), Zn, 0 ] ] ]), 
            this.flushRequestMap = new Map, this.nextStreamHandle = Et;
        },
        getStream(t) {
            const e = this.streamMap.get(t);
            if (!e) {
                if (2 < t && t < Et) throw new Unsupported;
                throw new InvalidFileDescriptor;
            }
            return e;
        },
        createStreamHandle(t, e, n = 0) {
            const r = this.nextStreamHandle++;
            return this.streamMap.set(r, [ t, e, n ]), t.onClose = () => this.destroyStreamHandle(r), 
            4 === this.streamMap.size && this.setSyscallTrap(!0), r;
        },
        destroyStreamHandle(t) {
            const e = this.streamMap.get(t);
            if (e) {
                const [n] = e;
                n?.destroy?.(), this.streamMap.delete(t), 3 === this.streamMap.size && this.setSyscallTrap(!1);
            }
        },
        redirectStream(t, e) {
            const n = this.streamMap, r = -1 === t ? xt : t, s = n.get(r);
            if (void 0 !== e) {
                let s, i;
                if (t === St) s = this.convertReader(e), i = Wn; else if (t === It || t === At) s = this.convertWriter(e), 
                i = Zn; else {
                    if (t !== xt) throw new Error(`Expecting 0, 1, 2, or -1, received ${r}`);
                    s = this.convertDirectory(e), i = this.getDefaultRights("dir");
                }
                if (!s) throw new InvalidStream(i[0], e);
                n.set(r, [ s, i, 0 ]);
            } else n.delete(r);
            return s?.[0];
        },
        createLogWriter(t) {
            const e = this;
            return {
                pending: [],
                write(t) {
                    const n = t.lastIndexOf(10);
                    if (-1 === n) this.pending.push(t); else {
                        const e = t.subarray(0, n), r = t.subarray(n + 1);
                        this.dispatch([ ...this.pending, e ]), this.pending.splice(0), r.length > 0 && this.pending.push(r);
                    }
                    e.scheduleFlush(this, this.pending.length > 0, 250);
                },
                dispatch(n) {
                    const r = ze(n);
                    e.triggerEvent("log", {
                        source: t,
                        message: r
                    });
                },
                flush() {
                    this.pending.length > 0 && (this.dispatch(this.pending), this.pending.splice(0));
                }
            };
        },
        scheduleFlush(t, e, n) {
            const r = this.flushRequestMap, s = r.get(t);
            s && (clearTimeout(s), r.delete(t)), e && r.set(t, setTimeout((() => {
                t.flush(), r.delete(t);
            }), n));
        },
        flushStreams() {
            const t = this.flushRequestMap;
            if (t.size > 0) {
                for (const [e, n] of t) e.flush(), clearTimeout(n);
                t.clear();
            }
        },
        getDefaultRights: t => "dir" === t ? [ qn, qn | Gn ] : [ Gn, 0 ],
        imports: {
            setRedirectionMask: {},
            setSyscallTrap: {}
        }
    }), Sn({}), Sn({
        convertWriter: t => t instanceof WritableStreamDefaultWriter ? new WebStreamWriter(t) : Array.isArray(t) ? new ArrayWriter(t) : t instanceof Uint8Array ? new Uint8ArrayReadWriter(t) : null === t ? new NullStream : "function" == typeof t?.write ? t : void 0
    }), Sn({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), s = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: s
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    }), Sn({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = Ze(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let s = this.allocatorVtable;
            if (!s) {
                const {noResize: t, noRemap: e} = r;
                s = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (s.remap = e), this.destructors.push((() => this.freeFunction(s.alloc))), 
                this.destructors.push((() => this.freeFunction(s.free)));
            }
            let i = De;
            if (n) {
                const e = [];
                i = this.nextAllocatorContextId++, this.allocatorContextMap.set(i, e), t[we] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(i);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(i, 0),
                vtable: s
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][$t]), s = r != De ? this.allocatorContextMap.get(r) : null, i = 1 << n, o = this.allocateJSMemory(e, i);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, i, !0, o), Be(o, Tt, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), s?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][$t], s = this.getViewAddress(r), i = r.byteLength;
            this.unregisterMemory(s, i);
        }
    }), Sn({
        createDirectory(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return t;
            const e = this.convertDirectory(t);
            if (!e) throw new InvalidStream(wt.fd_readdir, t);
            let n = this.createStreamHandle(e, this.getDefaultRights("dir"));
            return "win32" === process.platform && (n = this.obtainZigView(Ze(n << 1), 0)), 
            {
                fd: n
            };
        }
    }), Sn({
        createFile(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return {
                handle: t.fd
            };
            if ("object" == typeof t && "number" == typeof t?.handle) return t;
            const e = this.convertReader(t) ?? this.convertWriter(t);
            if (!e) throw new InvalidStream(wt.fd_read | wt.fd_write, t);
            const n = this.getDefaultRights("file"), r = {
                read: wt.fd_read,
                write: wt.fd_write,
                seek: wt.fd_seek,
                tell: wt.fd_tell,
                allocate: wt.fd_allocate
            };
            for (const [t, s] of Object.entries(r)) rn(e, t) || (n[0] &= ~s);
            let s = this.createStreamHandle(e, n);
            return "win32" === process.platform && (s = this.obtainZigView(Ze(s << 1), 0)), 
            {
                handle: s
            };
        }
    }), Sn({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = Ze(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: s}} = t;
            if (n) {
                if ("function" != typeof n) throw new TypeMismatch("function", n);
            } else {
                const t = e[de] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const i = this.nextGeneratorContextId++, o = this.obtainZigView(i, 0, !1);
            this.generatorContextMap.set(i, {
                func: n,
                args: e
            });
            let a = this.generatorCallbackMap.get(r);
            a || (a = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][$t], r = this.getViewAddress(n), s = this.generatorContextMap.get(r);
                if (s) {
                    const {func: t, args: n} = s, i = e instanceof Error;
                    if (!i && e) {
                        const t = n[Oe];
                        t && (e = t(e));
                    }
                    const o = !1 === await (2 === t.length ? t(i ? e : null, i ? null : e) : t(e)) || i || null === e;
                    if (n[we]?.(o), !o) return !0;
                    n[Me](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, a), this.destructors.push((() => this.freeFunction(a)))), 
            e[ke] = t => a(o, t);
            const c = {
                ptr: o,
                callback: a
            }, l = s.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                c.allocator = this.createJsAllocator(e, t, !0);
            }
            return c;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, s = r["*"];
            return t[Ve] = e => s.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[Ve](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[Ve](t)) break;
                    e[Ve](null);
                } catch (t) {
                    if (!e.constructor[fe]) throw t;
                    e[Ve](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    Sn({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = Ze(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new TypeMismatch("function", n);
            } else e[he] = new Promise(((t, r) => {
                n = n => {
                    if (n?.[$t]?.[Tt] && (n = new n.constructor(n)), n instanceof Error) r(n); else {
                        if (n) {
                            const t = e[Oe];
                            t && (n = t(n));
                        }
                        t(n);
                    }
                };
            }));
            const s = this.nextPromiseContextId++, i = this.obtainZigView(s, 0, !1);
            this.promiseContextMap.set(s, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][$t], r = this.getViewAddress(n), s = this.promiseContextMap.get(r);
                if (s) {
                    const {func: t, args: n} = s;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[Me](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[ke] = t => o(i, t), {
                ptr: i,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, s = r["*"];
            return t[ke] = e => s.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[ke](n);
            };
        }
    }), Sn({
        init() {
            this.readerCallback = null, this.readerMap = new Map, this.nextReaderId = Ze(4096), 
            this.readerProgressMap = new Map;
        },
        createReader(t) {
            if ("object" == typeof t && t && "context" in t && "readFn" in t) return t;
            const e = this.convertReader(t);
            if (!e) throw new InvalidStream(wt.fd_read, t);
            const n = this.nextReaderId++, r = this.obtainZigView(n, 0, !1), s = e.onClose = () => {
                this.readerMap.delete(n), this.readerProgressMap.delete(n);
            };
            this.readerMap.set(n, e), this.readerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let i = this.readerCallback;
            if (!i) {
                const t = t => {
                    throw console.error(t), s(), t;
                };
                i = this.readerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][$t]), s = this.readerMap.get(r);
                    if (!s) return 0;
                    try {
                        const e = n["*"][$t].byteLength, i = t => {
                            const e = t.length, r = this.getViewAddress(n["*"][$t]);
                            return this.moveExternBytes(t, r, !0), e;
                        };
                        Un(this.readerProgressMap.get(r), "read", e);
                        const o = s.read(e);
                        return sn(o) ? o.then(i).catch(t) : i(o);
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(i)));
            }
            return {
                context: r,
                readFn: i
            };
        }
    }), Sn({
        init() {
            this.writerCallback = null, this.writerMap = new Map, this.nextWriterContextId = Ze(8192), 
            this.writerProgressMap = new Map;
        },
        createWriter(t) {
            if ("object" == typeof t && t && "context" in t && "writeFn" in t) return t;
            const e = this.convertWriter(t);
            if (!e) throw new InvalidStream(wt.fd_write, t);
            const n = this.nextWriterContextId++, r = this.obtainZigView(n, 0, !1), s = e.onClose = () => {
                this.writerMap.delete(n), this.writerProgressMap.delete(n);
            };
            this.writerMap.set(n, e), this.writerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let i = this.writerCallback;
            if (!i) {
                const t = t => {
                    throw console.error(t), s(), t;
                };
                i = this.writerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][$t]), s = this.writerMap.get(r);
                    if (!s) return 0;
                    try {
                        const e = n["*"][$t];
                        Un(this.writerProgressMap.get(r), "write", e.byteLength);
                        const i = e.byteLength, o = new Uint8Array(e.buffer, e.byteOffset, i), a = new Uint8Array(o), c = s.write(a);
                        return sn(c) ? c.then((() => i), t) : i;
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(i)));
            }
            return {
                context: r,
                writeFn: i
            };
        }
    }), Sn({
        environGet(t, e) {
            let n = 0, r = 0;
            for (const t of this.envVariables) n += t.length, r++;
            const s = ln(8 * r), i = new Uint8Array(n);
            let o = 0, a = 0, c = this.littleEndian;
            for (const t of this.envVariables) s.setBigUint64(o, e + BigInt(a), c), o += 8, 
            i.set(t, a), a += t.length;
            return this.moveExternBytes(s, t, !0), this.moveExternBytes(i, e, !0), 0;
        },
        exports: {
            environGet: {
                async: !0
            }
        }
    }), Sn({
        copyUint64(t, e) {
            const n = ln(8);
            n.setBigUint64(0, BigInt(e), this.littleEndian), this.moveExternBytes(n, t, !0);
        },
        copyUint32(t, e) {
            const n = ln(4);
            n.setUint32(0, e, this.littleEndian), this.moveExternBytes(n, t, !0);
        }
    }), Sn({
        environSizesGet(t, e) {
            const n = this.triggerEvent("env") ?? {};
            if ("object" != typeof n) return console.error(new TypeMismatch("object", n).message), 
            lt;
            const r = this.envVariables = [];
            for (const [t, e] of Object.entries(n)) {
                const n = Fe(`${t}=${e}\0`);
                r.push(n);
            }
            let s = 0;
            for (const t of r) s += t.length;
            return this.copyUint32(t, r.length), this.copyUint32(e, s), 0;
        },
        exports: {
            environSizesGet: {
                async: !0
            }
        }
    });
    const Jn = {
        normal: 0,
        sequential: 1,
        random: 2,
        willNeed: 3,
        dontNeed: 4,
        noReuse: 5
    };
    Sn({
        fdAdvise(t, e, n, r, s) {
            return kn(s, ot, (() => {
                const [s] = this.getStream(t);
                if (rn(s, "advise")) {
                    const t = Object.keys(Jn);
                    return s.advise?.(Je(e), Je(n), t[r]);
                }
            }));
        },
        exports: {
            fdAdvise: {
                async: !0
            }
        }
    }), Sn({
        fdAllocate(t, e, n, r) {
            return kn(r, ot, (() => {
                const [r] = this.getStream(t);
                return On(r, "allocate"), r.allocate(Je(e), Je(n));
            }));
        },
        exports: {
            fdAllocate: {
                async: !0
            }
        }
    }), Sn({
        fdClose(t, e) {
            return kn(e, ot, (() => (this.setStreamLocation?.(t), this.destroyStreamHandle(t))));
        },
        exports: {
            fdClose: {
                async: !0
            }
        }
    }), Sn({
        fdDatasync(t, e) {
            return kn(e, ot, (() => {
                const [e] = this.getStream(t);
                if (rn(e, "datasync")) return e.datasync?.();
            }));
        },
        exports: {
            fdDatasync: {
                async: !0
            }
        }
    }), Sn({
        fdFdstatGet(t, e, n) {
            return kn(n, ot, (() => {
                const [n, r, s] = this.getStream(t);
                let i;
                if (n.type) {
                    if (i = an(n.type, yt), void 0 === i) throw new InvalidEnumValue(yt, n.type);
                } else i = r[0] & (wt.fd_read | wt.fd_write) ? yt.file : yt.directory;
                const o = ln(24);
                o.setUint8(0, i), o.setUint16(2, s, !0), o.setBigUint64(8, BigInt(r[0]), !0), o.setBigUint64(16, BigInt(r[1]), !0), 
                this.moveExternBytes(o, e, !0);
            }));
        },
        exports: {
            fdFdstatGet: {
                async: !0
            }
        }
    }), Sn({
        fdFdstatSetFlags(t, e, n) {
            const r = vt.append | vt.nonblock;
            return kn(n, ot, (() => {
                const n = this.getStream(t), [s, i, o] = n;
                e & vt.nonblock && (i[0] & wt.fd_read && On(s, "readnb"), i[0] & wt.fd_write && On(s, "writenb")), 
                n[2] = o & ~r | e & r;
            }));
        },
        exports: {
            fdFdstatSetFlags: {
                async: !0
            }
        }
    }), Sn({
        fdFdstatSetRights(t, e, n) {
            return kn(n, ot, (() => {
                const n = this.getStream(t), [r, s] = n;
                if (e & ~s) throw new InvalidFileDescriptor;
                n[1] = s;
            }));
        },
        exports: {
            fdFdstatSetRights: {
                async: !0
            }
        }
    }), Sn({
        copyStat(t, e) {
            if (!1 === e) return ht;
            if ("object" != typeof e || !e) throw new TypeMismatch("object or false", e);
            const {ino: n = 1, type: r = "unknown", size: s = 0, atime: i = 0, mtime: o = 0, ctime: a = 0} = e, c = an(r, yt);
            if (void 0 === c) throw new InvalidEnumValue(yt, r);
            const l = this.littleEndian, u = ln(64);
            u.setBigUint64(0, 0n, l), u.setBigUint64(8, BigInt(n), l), u.setUint8(16, c), u.setBigUint64(24, 1n, l), 
            u.setBigUint64(32, BigInt(s), l), u.setBigUint64(40, BigInt(i), l), u.setBigUint64(48, BigInt(o), l), 
            u.setBigUint64(56, BigInt(a), l), this.moveExternBytes(u, t, l);
        },
        inferStat(t) {
            if (t) return {
                size: t.size,
                type: rn(t, "readdir") ? "directory" : "file"
            };
        }
    }), Sn({
        fdFilestatGet(t, e, n) {
            return kn(n, ot, (() => {
                const [e] = this.getStream(t);
                if (this.hasListener("stat")) {
                    const n = e.valueOf(), r = this.getStreamLocation?.(t);
                    return this.triggerEvent("stat", {
                        ...r,
                        target: n,
                        flags: {}
                    });
                }
                return this.inferStat(e);
            }), (t => this.copyStat(e, t)));
        },
        exports: {
            fdFilestatGet: {
                async: !0
            }
        }
    }), Sn({
        fdFilestatSetTimesEvent: "set_times",
        fdFilestatSetTimes(t, e, n, r, s) {
            return kn(s, ot, (() => {
                const [s] = this.getStream(t), i = s.valueOf(), o = this.getStreamLocation?.(t), a = wn(e, n, r);
                return this.triggerEvent("set_times", {
                    ...o,
                    target: i,
                    times: a,
                    flags: {}
                });
            }), (t => void 0 === t ? pt : Bn(t, ot)));
        },
        exports: {
            fdFilestatSetTimes: {
                async: !0
            }
        }
    }), Sn({
        fdPread(t, e, n, r, s, i) {
            const o = this.littleEndian, a = [];
            let c = 0;
            return kn(i, ft, (() => {
                const [s, i] = this.getStream(t);
                Vn(i, wt.fd_read);
                const l = ln(16 * n);
                this.moveExternBytes(l, e, !1);
                for (let t = 0; t < n; t++) {
                    const e = He(l, 16 * t, o), n = Ye(l, 16 * t + 8, o);
                    a.push({
                        ptr: e,
                        len: n
                    }), c += n;
                }
                return s.pread(c, Je(r));
            }), (t => {
                let {byteOffset: e, byteLength: n, buffer: r} = t;
                for (const {ptr: t, len: s} of a) if (n > 0) {
                    const i = new DataView(r, e, Math.min(n, s));
                    this.moveExternBytes(i, t, !0), e += s, n -= s;
                }
                this.copyUint32(s, t.length);
            }));
        },
        ...{
            exports: {
                fdPread: {
                    async: !0
                },
                fdPread1: {
                    async: !0
                }
            },
            fdPread1(t, e, n, r, s, i) {
                return kn(i, ft, (() => {
                    const [e, s] = this.getStream(t);
                    return Vn(s, wt.fd_read), e.pread(n, Je(r));
                }), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUint32(s, t.length);
                }));
            }
        }
    }), Sn({
        fdPwrite(t, e, n, r, s, i) {
            const o = this.littleEndian;
            let a = 0;
            return kn(i, ft, (() => {
                const [s, i] = this.getStream(t);
                Vn(i, wt.fd_write);
                const c = ln(16 * n);
                this.moveExternBytes(c, e, !1);
                const l = [];
                for (let t = 0; t < n; t++) {
                    const e = He(c, 16 * t, o), n = Ye(c, 16 * t + 8, o);
                    l.push({
                        ptr: e,
                        len: n
                    }), a += n;
                }
                const u = new ArrayBuffer(a);
                let f = 0;
                for (const {ptr: t, len: e} of l) {
                    const n = new DataView(u, f, e);
                    this.moveExternBytes(n, t, !1), f += e;
                }
                const h = new Uint8Array(u);
                return s.pwrite(h, Je(r));
            }), (() => this.copyUint32(s, a)));
        },
        ...{
            exports: {
                fdPwrite: {
                    async: !0
                },
                fdPwrite1: {
                    async: !0
                }
            },
            fdPwrite1(t, e, n, r, s, i) {
                return kn(i, ft, (() => {
                    const [s, i] = this.getStream(t);
                    Vn(i, wt.fd_write);
                    const o = new Uint8Array(n);
                    return this.moveExternBytes(o, e, !1), s.pwrite(o, Je(r));
                }), (() => this.copyUint32(s, n)));
            }
        }
    }), Sn({
        fdRead(t, e, n, r, s) {
            const i = this.littleEndian, o = [];
            let a = 0;
            return kn(s, ot, (() => {
                const [r, s, c] = this.getStream(t);
                Vn(s, wt.fd_read);
                const l = ln(16 * n);
                this.moveExternBytes(l, e, !1);
                for (let t = 0; t < n; t++) {
                    const e = He(l, 16 * t, i), n = Ye(l, 16 * t + 8, i);
                    o.push({
                        ptr: e,
                        len: n
                    }), a += n;
                }
                return (c & vt.nonblock ? r.readnb : r.read).call(r, a);
            }), (t => {
                let {byteOffset: e, byteLength: n, buffer: s} = t;
                for (const {ptr: t, len: r} of o) {
                    const i = Math.min(n, r);
                    if (i > 0) {
                        const r = new DataView(s, e, i);
                        this.moveExternBytes(r, t, !0), e += i, n -= i;
                    }
                }
                this.copyUint32(r, t.length);
            }));
        },
        ...{
            exports: {
                fdRead: {
                    async: !0
                },
                fdRead1: {
                    async: !0
                }
            },
            fdRead1(t, e, n, r, s) {
                return kn(s, ot, (() => {
                    const [e, r, s] = this.getStream(t);
                    Vn(r, wt.fd_read);
                    return (s & vt.nonblock ? e.readnb : e.read).call(e, n);
                }), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUint32(r, t.length);
                }));
            }
        }
    }), Sn({
        fdReaddir(t, e, n, r, s, i) {
            if (n < 24) return ut;
            let o, a;
            return kn(i, ot, (() => ([o] = this.getStream(t), o.tell())), (t => kn(i, ot, (() => {
                r = t;
                const e = o.readdir();
                return a = sn(e), e;
            }), (t => {
                const i = ln(n);
                let c = n, l = 0;
                for (;t; ) {
                    const {name: e, type: n = "unknown", ino: s = 1} = t, u = Fe(e), f = an(n, yt);
                    if (void 0 === f) throw new InvalidEnumValue(yt, n);
                    if (c < 24 + u.length) {
                        o.seek(Number(r));
                        break;
                    }
                    i.setBigUint64(l, BigInt(++r), !0), i.setBigUint64(l + 8, BigInt(s), !0), i.setUint32(l + 16, u.length, !0), 
                    i.setUint8(l + 20, f), l += 24, c -= 24;
                    for (let t = 0; t < u.length; t++, l++) i.setUint8(l, u[t]);
                    c -= u.length, t = c > 40 && !a ? o.readdir() : null;
                }
                this.moveExternBytes(i, e, !0), this.copyUint32(s, l);
            }))));
        },
        exports: {
            fdReaddir: {
                async: !0
            }
        }
    }), Sn({
        fdSeek(t, e, n, r, s) {
            return kn(s, ot, (() => {
                const [r] = this.getStream(t);
                return On(r, "seek"), r.seek(Je(e), n);
            }), (t => this.copyUint64(r, t)));
        },
        exports: {
            fdSeek: {
                async: !0
            }
        }
    }), Sn({
        fdSync(t, e) {
            return kn(e, ot, (() => {
                const [e] = this.getStream(t);
                if (rn(e, "sync")) return e.sync?.();
            }));
        },
        exports: {
            fdSync: {
                async: !0
            }
        }
    }), Sn({
        fdTell(t, e, n) {
            return kn(n, ot, (() => {
                const [e] = this.getStream(t);
                return On(e, "tell"), e.tell();
            }), (t => this.copyUint64(e, t)));
        },
        exports: {
            fdTell: {
                async: !0
            }
        }
    }), Sn({
        fdWrite(t, e, n, r, s) {
            const i = this.littleEndian;
            let o = 0;
            return kn(s, ot, (() => {
                const [r, s, a] = this.getStream(t);
                Vn(s, wt.fd_write);
                const c = ln(16 * n);
                this.moveExternBytes(c, e, !1);
                const l = [];
                for (let t = 0; t < n; t++) {
                    const e = He(c, 16 * t, i), n = Ye(c, 16 * t + 8, i);
                    l.push({
                        ptr: e,
                        len: n
                    }), o += n;
                }
                const u = new ArrayBuffer(o);
                let f = 0;
                for (const {ptr: t, len: e} of l) {
                    const n = new DataView(u, f, e);
                    this.moveExternBytes(n, t, !1), f += e;
                }
                const h = new Uint8Array(u);
                return (a & vt.nonblock ? r.writenb : r.write).call(r, h);
            }), (() => this.copyUint32(r, o)));
        },
        ...{
            exports: {
                fdWrite: {
                    async: !0
                },
                fdWrite1: {
                    async: !0
                }
            },
            fdWrite1(t, e, n, r, s) {
                return kn(s, ot, (() => {
                    const [r, s, i] = this.getStream(t);
                    Vn(s, wt.fd_write);
                    const o = i & vt.nonblock ? r.writenb : r.write, a = new Uint8Array(n);
                    return this.moveExternBytes(a, e, !1), o.call(r, a);
                }), (() => this.copyUint32(r, n)));
            }
        }
    }), Sn({
        pathCreateDirectoryEvent: "mkdir",
        pathCreateDirectory(t, e, n, r) {
            return kn(r, ht, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("mkdir", r, ht);
            }), (t => void 0 === t ? dt : t instanceof Map ? ct : Bn(t, ht)));
        },
        exports: {
            pathCreateDirectory: {
                async: !0
            }
        }
    }), Sn({
        pathFilestatGetEvent: "stat/open",
        pathFilestatGet(t, e, n, r, s, i) {
            let o = !1;
            return kn(i, ht, (() => {
                const s = this.obtainStreamLocation(t, n, r);
                let i = {
                    ...on(e, bt)
                };
                return this.hasListener("stat") ? this.triggerEvent("stat", {
                    ...s,
                    flags: i
                }) : (i = {
                    ...i,
                    dryrun: !0
                }, o = !0, this.triggerEvent("open", {
                    ...s,
                    rights: {},
                    flags: i
                }));
            }), (t => {
                if (void 0 === t) return dt;
                if (!1 === t) return ht;
                if (o) {
                    const e = this.convertReader(t) ?? this.convertWriter(t) ?? this.convertDirectory(t);
                    if (!e) throw new InvalidStream(wt.fd_read | wt.fd_write | wt.fd_readdir, t);
                    t = this.inferStat(e);
                }
                return this.copyStat(s, t);
            }));
        },
        exports: {
            pathFilestatGet: {
                async: !0
            }
        }
    }), Sn({
        pathFilestatSetTimesEvent: "set_times",
        pathFilestatSetTimes(t, e, n, r, s, i, o, a) {
            return kn(a, ht, (() => {
                const a = this.obtainStreamLocation(t, n, r), c = wn(s, i, o), l = on(e, bt);
                return this.triggerEvent("set_times", {
                    ...a,
                    times: c,
                    flags: l
                });
            }), (t => void 0 === t ? dt : Bn(t, ht)));
        },
        exports: {
            pathFilestatSetTimes: {
                async: !0
            }
        }
    });
    const Hn = {
        read: wt.fd_read,
        write: wt.fd_write,
        readdir: wt.fd_readdir
    };
    function Yn() {
        Object.assign(this, {
            resolved: !0
        });
    }
    function Xn(t) {
        Object.assign(this, {
            resolved: !0,
            length: t
        });
    }
    function Kn(t) {
        console.error(t), Object.assign(this, {
            resolved: !0,
            error: ot
        });
    }
    function Qn() {
        const t = er.toString(), e = t.indexOf("{") + 1, n = t.lastIndexOf("}");
        return t.slice(e, n);
    }
    let tr;
    function er() {
        let t, e;
        function n({executable: n, memory: s, options: i, tid: o, arg: a}) {
            const c = WebAssembly, l = {
                memory: s
            }, u = {}, f = {}, h = {
                env: l,
                wasi: u,
                wasi_snapshot_preview1: f
            };
            for (const {module: t, name: e, kind: s} of c.Module.imports(n)) if ("function" === s) {
                const n = r(t, e);
                "env" === t ? l[e] = n : "wasi_snapshot_preview1" === t ? f[e] = n : "wasi" === t && (u[e] = n);
            }
            const {tableInitial: d} = i;
            l.__indirect_function_table = new c.Table({
                initial: d,
                element: "anyfunc"
            });
            const {exports: g} = new c.Instance(n, h), {wasi_thread_start: p} = g;
            p(o, a), t({
                type: "exit"
            }), e();
        }
        function r(e, n) {
            const r = new Int32Array(new SharedArrayBuffer(8));
            return function(...s) {
                return r[0] = 0, t({
                    type: "call",
                    module: e,
                    name: n,
                    args: s,
                    array: r
                }), Atomics.wait(r, 0, 0), r[1];
            };
        }
        "object" == typeof self || "node" !== process.env.COMPAT ? (self.onmessage = t => n(t.data), 
        t = t => self.postMessage(t), e = () => self.close()) : "node" === process.env.COMPAT && import("worker_threads").then((({parentPort: r, workerData: s}) => {
            t = t => r.postMessage(t), e = () => process.exit(), n(s);
        }));
    }
    function nr(t, n) {
        const {byteSize: r, type: s} = n;
        if (!(s === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function rr(t) {
        throw new BufferExpected(t);
    }
    Sn({
        pathOpenEvent: "open",
        pathOpen(t, e, n, r, s, i, o, a, c, l) {
            const u = [ Number(i), Number(o) ];
            let f;
            return u[0] & (wt.fd_read | wt.fd_write | wt.fd_readdir) || (u[0] |= wt.fd_read), 
            kn(l, ht, (() => {
                f = this.obtainStreamLocation(t, n, r);
                const i = on(u[0], Hn), o = {
                    ...on(e, bt),
                    ...on(s, mt),
                    ...on(a, vt)
                };
                return this.triggerEvent("open", {
                    ...f,
                    rights: i,
                    flags: o
                });
            }), (t => {
                if (void 0 === t) return dt;
                if (!1 === t) return ht;
                const e = this.convertReader(t) ?? this.convertWriter(t) ?? this.convertDirectory(t);
                if (!e) throw new InvalidStream(u[0], t);
                const n = this.createStreamHandle(e, u, a);
                this.setStreamLocation?.(n, f), this.copyUint32(c, n);
            }));
        },
        exports: {
            pathOpen: {
                async: !0
            }
        }
    }), Sn({
        pathRemoveDirectory: "rmdir",
        pathRemoveDirectory(t, e, n, r) {
            return kn(r, ht, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("rmdir", r, ht);
            }), (t => void 0 === t ? dt : Bn(t, ht)));
        },
        exports: {
            pathRemoveDirectory: {
                async: !0
            }
        }
    }), Sn({
        pathUnlinkFileEvent: "unlink",
        pathUnlinkFile(t, e, n, r) {
            return kn(r, ht, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("unlink", r, ht);
            }), (t => void 0 === t ? dt : Bn(t, ht)));
        },
        exports: {
            pathUnlinkFile: {
                async: !0
            }
        }
    }), Sn({
        pollOneoff(t, e, n, r, s) {
            const i = [], o = [], a = this.littleEndian;
            return kn(s, ot, (() => {
                const e = ln(48 * n);
                this.moveExternBytes(e, t, !1);
                for (let t = 0; t < n; t++) {
                    const n = 48 * t, r = e.getBigUint64(n, a), s = e.getUint8(n + 8), c = {
                        tag: s,
                        userdata: r,
                        error: rt
                    };
                    let l;
                    switch (i.push(c), s) {
                      case Mt:
                        {
                            let t = e.getBigUint64(n + 24, a);
                            const r = new Int32Array(new SharedArrayBuffer(4)), s = Yn.bind(c);
                            if (0n === t) s(); else {
                                const e = Math.ceil(Number(t) / 1e6);
                                l = Atomics.waitAsync(r, 0, 0, e).value.then(s);
                            }
                        }
                        break;

                      case kt:
                      case Ut:
                        {
                            const t = e.getInt32(n + 16, a), r = Xn.bind(c), i = Kn.bind(c);
                            try {
                                const [e] = this.getStream(t);
                                On(e, "poll");
                                const n = e.poll(s);
                                sn(n) ? l = n.then(r, i) : r(n);
                            } catch (t) {
                                if (t.code === dt) throw t;
                                i(t);
                            }
                        }
                        break;

                      default:
                        throw new InvalidArgument;
                    }
                    l && o.push(l);
                }
                if (o.length === i.length) return Promise.any(o);
            }), (() => {
                let t = 0;
                for (const e of i) e.resolved && t++;
                const n = ln(32 * t);
                let s = 0;
                for (const t of i) if (t.resolved) {
                    const e = 32 * s;
                    n.setBigUint64(e, t.userdata, a), n.setUint16(e + 8, t.error, a), n.setUint8(e + 10, t.tag), 
                    void 0 !== t.length && (0 === t.length ? n.setUint16(e + 24, 1, a) : n.setBigUint64(e + 16, BigInt(t.length), a)), 
                    s++;
                }
                this.moveExternBytes(n, e, !0), this.copyUint32(r, t);
            }));
        },
        exports: {
            pollOneoff: {
                async: !0
            }
        }
    }), Sn({
        init() {
            this.nextThreadId = 1, this.workers = [];
        },
        getThreadHandler(t) {
            if ("thread-spawn" === t) return "object" != typeof window || window.crossOriginIsolated || console.warn("%cHTML document is not cross-origin isolated %c\n\nWebAssembly multithreading in the browser is only possibly when %cwindow.crossOriginIsolated%c = true. Visit https://developer.mozilla.org/en-US/docs/Web/API/Window/crossOriginIsolated for information on how to enable it.", "color: red;font-size: 200%;font-weight:bold", "", "background-color: lightgrey;font-weight:bold", ""), 
            this.spawnThread.bind(this);
        },
        spawnThread(t) {
            const e = this.nextThreadId;
            this.nextThreadId++;
            const {executable: n, memory: r, options: s} = this, i = {
                executable: n,
                memory: r,
                options: s,
                tid: e,
                arg: t
            }, o = (t, e) => {
                if ("call" === e.type) {
                    const {module: t, name: n, args: r, array: s} = e, i = this.exportedModules[t]?.[n], o = i?.(...r, !0), a = t => {
                        s && (s[1] = 0 | t, s[0] = 1, Atomics.notify(s, 0, 1));
                    };
                    sn(o) ? o.then(a) : a(o);
                } else if ("exit" === e.type) {
                    const e = this.workers.indexOf(t);
                    -1 !== e && (t.detach(), this.workers.splice(e, 1));
                }
            }, a = "message";
            if ("function" == typeof Worker || "node" !== process.env.COMPAT) {
                const t = function() {
                    if (!tr) {
                        const t = Qn();
                        tr = URL.createObjectURL(new Blob([ t ], {
                            type: "text/javascript"
                        }));
                    }
                    return tr;
                }(), e = new Worker(t, {
                    name: "zig"
                }), n = t => o(e, t.data);
                e.addEventListener(a, n), e.detach = () => e.removeEventListener(a, n), e.postMessage(i), 
                this.workers.push(e);
            } else "node" === process.env.COMPAT && import("worker_threads").then((({Worker: t}) => {
                const e = new t(Qn(), {
                    workerData: i,
                    eval: !0
                }), n = t => o(e, t);
                e.on(a, n), e.detach = () => e.off(a, n), this.workers.push(e);
            }));
            return e;
        }
    }), Sn({
        init() {
            this.comptime = !1, this.slots = {}, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.libc = !1;
        },
        createView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.moveExternBytes(n, t, !1), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[Tt].handle = r, n;
            }
        },
        createInstance(t, e, n) {
            const {constructor: r} = t, s = r.call(ie, e);
            return n && Object.assign(s[Ct], n), e[Tt] || this.makeReadOnly?.(s), s;
        },
        createTemplate: (t, e) => ({
            [$t]: t,
            [Ct]: e
        }),
        appendList(t, e) {
            t.push(e);
        },
        getSlotValue(t, e) {
            return t || (t = this.slots), t[e];
        },
        setSlotValue(t, e, n) {
            t || (t = this.slots), t[e] = n;
        },
        beginStructure(t) {
            this.defineStructure(t);
        },
        finishStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & K), this.runtimeSafety = !!(t & Q), this.ioRedirection = !!(t & et), 
            this.libc = !!(t & tt);
            const e = this.getFactoryThunk(), n = {
                [$t]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                for (const t of e[Pt]) try {
                    const n = e[t];
                    n?.[Se] && this.updatePointerTargets(null, n);
                } catch {}
                if (n & g && r && r[$t]) {
                    const t = Object.create(e.prototype);
                    t[$t] = r[$t], t[Ct] = r[Ct], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, libc: r} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    libc: r
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of tn(this.structures, Ct)) {
                const n = e[$t]?.[Tt];
                if (n) {
                    const {address: r, len: s, handle: i} = n, o = e[$t] = this.createView(r, s, !0, 0);
                    i && (o.handle = i), t.push({
                        address: r,
                        len: s,
                        owner: e,
                        replaced: !1,
                        handle: i
                    });
                }
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && Xe(n.address, n.len) <= Xe(e.address, e.len)) {
                const t = e.owner[$t], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[$t] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = tn(this.structures, Ct);
            for (const t of e) t[$t]?.[Tt] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${f[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, flags: n = 0} = t;
            switch (e.type) {
              case D.Bool:
                return "bool";

              case D.Int:
                return n & y ? "isize" : `i${e.bitSize}`;

              case D.Uint:
                return n & y ? "usize" : `u${e.bitSize}`;

              case D.Float:
                return `f${e.bitSize}`;

              case D.Void:
                return "void";

              case D.Literal:
                return "enum_literal";

              case D.Null:
                return "null";

              case D.Undefined:
                return "undefined";

              case D.Type:
                return "type";

              case D.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & S[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & F ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let s = "*", i = n.structure.name;
            if (n.structure.type === e.Slice && (i = i.slice(3)), r & k && (s = r & U ? "[]" : r & V ? "[*c]" : "[*]"), 
            !(r & V)) {
                const t = n.structure.constructor?.[Dt];
                t && (s = s.slice(0, -1) + `:${t.value}` + s.slice(-1));
            }
            return r & O && (s = `${s}const `), s + i;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & z ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), s = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${s})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), s = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${s})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t, n = e.structure.name;
            return n ? n.slice(4, -1) : "fn ()";
        },
        exports: {
            createView: {},
            createInstance: {},
            createTemplate: {},
            appendList: {},
            getSlotValue: {},
            setSlotValue: {},
            beginStructure: {},
            finishStructure: {}
        },
        imports: {
            getFactoryThunk: {},
            getModuleAttributes: {}
        }
    }), Sn({
        init() {
            this.viewMap = new WeakMap, this.needFallback = void 0;
        },
        extractView(t, n, r = rr) {
            const {type: s, byteSize: i, constructor: o} = t;
            let a;
            const c = n?.[Symbol.toStringTag];
            if (c && ("DataView" === c ? a = this.registerView(n) : "ArrayBuffer" === c ? a = this.obtainView(n, 0, n.byteLength) : (c && c === o[ue]?.name || "Uint8ClampedArray" === c && o[ue] === Uint8Array || "Uint8Array" === c && n instanceof Buffer) && (a = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !a) {
                const r = n?.[$t];
                if (r) {
                    const {constructor: o, instance: {members: [a]}} = t;
                    if (nn(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(s)) {
                        const {byteSize: o, structure: {constructor: c}} = a, l = Qe(n, c);
                        if (void 0 !== l) {
                            if (s === e.Slice || l * o === i) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return a ? void 0 !== i && nr(a, t) : r?.(t, n), a;
        },
        assignView(t, n, r, s, i) {
            const {byteSize: o, type: a} = r, c = o ?? 1;
            if (t[$t]) {
                const s = a === e.Slice ? c * t.length : c;
                if (n.byteLength !== s) throw new BufferSizeMismatch(r, n, t);
                const i = {
                    [$t]: n
                };
                t.constructor[Dt]?.validateData?.(i, t.length), t[Ie](i);
            } else {
                void 0 !== o && nr(n, r);
                const e = n.byteLength / c, a = {
                    [$t]: n
                };
                t.constructor[Dt]?.validateData?.(a, e), i && (s = !0), t[Ae](s ? null : n, e, i), 
                s && t[Ie](a);
            }
            if (this.usingBufferFallback()) {
                const e = t[$t], n = e.buffer[pe];
                void 0 !== n && this.syncExternalBuffer(e.buffer, n, !0);
            }
        },
        findViewAt(t, e, n) {
            let r, s = this.viewMap.get(t);
            if (s) if (s instanceof DataView) if (s.byteOffset === e && s.byteLength === n) r = s, 
            s = null; else {
                const e = s, n = `${e.byteOffset}:${e.byteLength}`;
                s = new Map([ [ n, e ] ]), this.viewMap.set(t, s);
            } else r = s.get(`${e}:${n}`);
            return {
                existing: r,
                entry: s
            };
        },
        obtainView(t, e, n) {
            const {existing: r, entry: s} = this.findViewAt(t, e, n);
            let i;
            if (r) return r;
            i = new DataView(t, e, n), s ? s.set(`${e}:${n}`, i) : this.viewMap.set(t, i);
            {
                const r = t[Tt];
                r && (i[Tt] = {
                    address: Xe(r.address, e),
                    len: n
                });
            }
            return i;
        },
        registerView(t) {
            if (!t[Tt]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: s, entry: i} = this.findViewAt(e, n, r);
                if (s) return s;
                i ? i.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: null,
                syncExternalBuffer: null
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > sr && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let s = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    s = Re(t, e) - t;
                }
                return this.obtainView(r, Number(s), t);
            }
        }
    });
    const sr = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8;
    Sn({
        makeReadOnly(t) {
            ar(t);
        }
    });
    const ir = Object.getOwnPropertyDescriptors, or = Object.defineProperty;
    function ar(t) {
        const e = t[Rt];
        if (e) cr(e, [ "length" ]); else {
            const e = t[Wt];
            e ? (cr(e), function(t) {
                or(t, "set", {
                    value: Mn
                });
                const e = t.get;
                or(t, "get", {
                    value: function(t) {
                        const n = e.call(this, t);
                        return null === n?.[se] && ar(n), n;
                    }
                });
            }(e)) : cr(t);
        }
    }
    function cr(t, e = []) {
        const n = ir(t.constructor.prototype);
        for (const [r, s] of Object.entries(n)) s.set && !e.includes(r) && (s.set = Mn, 
        or(t, r, s));
        or(t, se, {
            value: t
        });
    }
    function lr() {
        const t = this[Wt] ?? this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function ur(t) {
        const e = _e(t), n = this[Wt] ?? this, r = this.length;
        let s = 0;
        return {
            next() {
                let t, i;
                if (s < r) {
                    const r = s++;
                    t = [ r, e((() => n.get(r))) ], i = !1;
                } else i = !0;
                return {
                    value: t,
                    done: i
                };
            }
        };
    }
    function fr(t) {
        return {
            [Symbol.iterator]: ur.bind(this, t),
            length: this.length
        };
    }
    function hr(t) {
        return {
            [Symbol.iterator]: gr.bind(this, t),
            length: this[Pt].length
        };
    }
    function dr(t) {
        return hr.call(this, t)[Symbol.iterator]();
    }
    function gr(t) {
        const e = _e(t), n = this, r = this[Pt];
        let s = 0;
        return {
            next() {
                let t, i;
                if (s < r.length) {
                    const o = r[s++];
                    t = [ o, e((() => n[o])) ], i = !1;
                } else i = !0;
                return {
                    value: t,
                    done: i
                };
            }
        };
    }
    function pr(t) {
        return {
            [Symbol.iterator]: mr.bind(this, t),
            length: this[Pt].length
        };
    }
    function yr(t) {
        return pr.call(this, t)[Symbol.iterator]();
    }
    function mr(t) {
        const e = _e(t), n = this, r = this[Pt], s = this[ce];
        let i = 0;
        return {
            next() {
                let t, o;
                if (i < r.length) {
                    const a = r[i++];
                    t = [ a, e((() => s[a].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function br() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = t[e], s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function wr() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function vr() {
        return {
            [Symbol.iterator]: wr.bind(this),
            length: this.length
        };
    }
    function Sr(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function Ir(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function Ar(t) {
        return Er.call(this, t).$;
    }
    function xr(t) {
        const e = Er.call(this, t).$;
        return e ? e.valueOf() : e;
    }
    function Er(t) {
        return this[Ct][t] ?? this[ve](t);
    }
    function Mr(t) {
        const e = Er.call(this, t).$;
        return e ? e.string : e;
    }
    function Ur(t, e, n) {
        Er.call(this, t)[xe](e, n);
    }
    Sn({
        defineArrayEntries: () => Ce(fr),
        defineArrayIterator: () => Ce(lr)
    }), Sn({
        defineStructEntries: () => Ce(hr),
        defineStructIterator: () => Ce(dr)
    }), Sn({
        defineUnionEntries: () => Ce(pr),
        defineUnionIterator: () => Ce(yr)
    }), Sn({
        defineVectorEntries: () => Ce(vr),
        defineVectorIterator: () => Ce(br)
    }), Sn({
        defineZigIterator: () => Ce(Sr)
    }), Sn({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, s = this[`defineMember${W[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${f[e]}`];
                if (n) return n.call(this, s, t);
            }
            return s;
        }
    }), Sn({
        defineBase64(t) {
            const e = this;
            return cn({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new TypeMismatch("string", n);
                    const s = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, s, t, !1, r);
                }
            });
        }
    }), Sn({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), Sn({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return cn({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, s) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new TypeMismatch(n.name, r);
                    const i = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, i, t, !0, s);
                }
            });
        }
    }), Sn({
        defineDataView(t) {
            const e = this;
            return cn({
                get() {
                    const t = this[$t];
                    if (e.usingBufferFallback()) {
                        const n = t.buffer[pe];
                        void 0 !== n && e.syncExternalBuffer(t.buffer, n, !1);
                    }
                    return t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new TypeMismatch("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), Sn({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), Sn({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), Sn({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return Ir(e, {
                get(t) {
                    return this[Ct][t].string;
                },
                set: Mn
            });
        }
    }), Sn({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: Mn
        })
    }), Sn({
        defineMemberObject: t => Ir(t.slot, {
            get: t.flags & Y ? Mr : t.flags & X ? xr : t.structure.flags & h ? Ar : Er,
            set: t.flags & q ? Mn : Ur
        })
    }), Sn({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: s} = t, i = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return i.call(this[$t], t, n);
                        },
                        set: function(e) {
                            return o.call(this[$t], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return i.call(this[$t], e * s, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[$t], t * s, e, n);
                    }
                };
            }
        }
    }), Sn({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: s}} = t, {get: i} = this.defineMember(r), {get: o} = this.defineMember(n), a = i.call(s, 0), c = !!(r.flags & Z), {runtimeSafety: l} = this;
            return Ce({
                value: a,
                bytes: s[$t],
                validateValue(e, n, r) {
                    if (c) {
                        if (l && e === a && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== a && n === r - 1) throw new MissingSentinel(t, a, r);
                    }
                },
                validateData(n, r) {
                    if (c) if (l) for (let e = 0; e < r; e++) {
                        const s = o.call(n, e);
                        if (s === a && e !== r - 1) throw new MisplacedSentinel(t, a, e, r);
                        if (s !== a && e === r - 1) throw new MissingSentinel(t, a, r);
                    } else if (r > 0 && r * e === n[$t].byteLength) {
                        if (o.call(n, r - 1) !== a) throw new MissingSentinel(t, a, r);
                    }
                },
                isRequired: c
            });
        },
        imports: {
            findSentinel: null
        }
    }), Sn({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return cn({
                get() {
                    let t = ze(this.typedArray, r);
                    const e = this.constructor[Dt]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, s) {
                    if ("string" != typeof n) throw new TypeMismatch("string", n);
                    const i = this.constructor[Dt]?.value;
                    void 0 !== i && n.charCodeAt(n.length - 1) !== i && (n += String.fromCharCode(i));
                    const o = Fe(n, r), a = new DataView(o.buffer);
                    e.assignView(this, a, t, !1, s);
                }
            });
        }
    }), Sn({
        defineValueOf: () => ({
            value() {
                return Or(this, !1);
            }
        })
    });
    const kr = BigInt(Number.MAX_SAFE_INTEGER), Vr = BigInt(Number.MIN_SAFE_INTEGER);
    function Or(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, s = _e(r), i = new Map, o = function(t) {
            const a = "function" == typeof t ? e.Struct : t?.constructor?.[Ft];
            if (void 0 === a) {
                if (n) {
                    if ("bigint" == typeof t && Vr <= t && t <= kr) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let c = i.get(t);
            if (void 0 === c) {
                let n;
                switch (a) {
                  case e.Struct:
                    n = t[qt](r), c = t.constructor[jt] & S.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[qt](r), c = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[qt](), c = [];
                    break;

                  case e.Pointer:
                    try {
                        c = t["*"];
                    } catch (t) {
                        c = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    c = s((() => String(t)));
                    break;

                  case e.Opaque:
                    c = {};
                    break;

                  default:
                    c = s((() => t.$));
                }
                if (c = o(c), i.set(t, c), n) for (const [t, e] of n) c[t] = o(e);
            }
            return c;
        };
        return o(t);
    }
    Sn({
        defineToJSON: () => ({
            value() {
                return Or(this, !0);
            }
        })
    }), Sn({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return Ir(n, {
                get(t) {
                    const e = this[Ct][t];
                    return e?.constructor;
                },
                set: Mn
            });
        }
    }), Sn({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return cn({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, s) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new TypeMismatch(n.name, r);
                    const i = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, i, t, !0, s);
                }
            });
        }
    }), Sn({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), Sn({
        defineMemberUndefined: t => ({
            get: function() {},
            set: Mn
        })
    }), Sn({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), Sn({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), Sn({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${f[e]}`], s = [], i = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [se]: {
                    value: null
                },
                [le]: Ce(i),
                [Jt]: Ce(s),
                [Ie]: this.defineCopier(n)
            }, a = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !i[t] && "$" !== t && (i[t] = n, s.push(t));
            }
            return $e(a.prototype, o), a;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: s, align: i, byteSize: o, flags: a, signature: c, static: {members: l, template: u}} = t, h = [], d = {
                name: Ce(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [ye]: Ce(c),
                [ie]: Ce(this),
                [re]: Ce(i),
                [ee]: Ce(o),
                [Ft]: Ce(r),
                [jt]: Ce(a),
                [Pt]: Ce(h),
                [ue]: Ce(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [qt]: this.defineStructEntries(),
                [Pt]: Ce(h)
            }, g = {
                [Symbol.toStringTag]: Ce(n)
            };
            if (l) for (const t of l) {
                const {name: n, slot: r, flags: s} = t;
                if (t.structure.type === e.Function) {
                    let e = u[Ct][r];
                    s & Y ? e[Oe] = t => t.string : s & X && (e[Oe] = t => t.valueOf()), d[n] = Ce(e), 
                    e.name || Be(e, "name", Ce(n));
                    const [i, o] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], a = "get" === i ? 0 : 1;
                    if (i && e.length === a) {
                        d[o] ||= {};
                        d[o][i] = e;
                    }
                    if (t.flags & J) {
                        const t = function(...t) {
                            try {
                                return e(this, ...t);
                            } catch (t) {
                                throw t[be]?.(1), t;
                            }
                        };
                        if ($e(t, {
                            name: Ce(n),
                            length: Ce(e.length - 1)
                        }), g[n] = Ce(t), i && t.length === a) {
                            (g[o] ||= {})[i] = t;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[Ct] = h.length > 0 && Ce(u[Ct]);
            const p = this[`finalize${f[r]}`];
            !1 !== p?.call(this, t, d, g) && ($e(s.prototype, g), $e(s, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: s, align: i, flags: o, instance: {members: a, template: c}} = t, {onCastError: l} = n;
            let u;
            if (c?.[Ct]) {
                const t = a.filter((t => t.flags & q));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, d = function(n, a = {}) {
                const {allocator: g} = a, y = this instanceof d;
                let m, b;
                if (y) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (m = this, o & p && (m[Ct] = {}), Ae in m) m[xe](n, g), b = m[$t]; else {
                        const t = r !== e.Pointer ? g : null;
                        m[$t] = b = h.allocateMemory(s, i, t);
                    }
                } else {
                    if (Ue in d && (m = d[Ue].call(this, n, a), !1 !== m)) return m;
                    if (b = h.extractView(t, n, l), m = f.find(b)) return m;
                    m = Object.create(d.prototype), Ae in m ? h.assignView(m, b, t, !1, !1) : m[$t] = b, 
                    o & p && (m[Ct] = {});
                }
                if (u) for (const t of u) m[Ct][t] = c[Ct][t];
                return m[Ee]?.(), y && (Ae in m || m[xe](n, g)), Me in m && (m = m[Me]()), f.save(b, m);
            };
            return Be(d, te, Ce(f)), d;
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const s = Object.keys(n), i = this[Jt], o = this[le];
                for (const e of s) if (!(e in o)) throw new NoProperty(t, e);
                let a = 0, c = 0, l = 0, u = 0;
                for (const t of i) {
                    const e = o[t];
                    e.special ? t in n && u++ : (a++, t in n ? c++ : e.required && l++);
                }
                if (0 !== l && 0 === u) {
                    const e = i.filter((t => o[t].required && !(t in n)));
                    throw new MissingInitializers(t, e);
                }
                if (u + c > s.length) for (const t of i) t in n && (s.includes(t) || s.push(t));
                c < a && 0 === u && e && e[$t] && this[Ie](e);
                for (const t of s) {
                    o[t].call(this, n[t], r);
                }
                return s.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) switch (n) {
              case e.Enum:
              case e.ErrorSet:
              case e.Primitive:
                {
                    const {byteSize: t, type: e} = r.members[0];
                    return globalThis[(t > 4 && e !== D.Float ? "Big" : "") + (e === D.Float ? "Float" : e === D.Int ? "Int" : "Uint") + 8 * t + "Array"];
                }

              case e.Array:
              case e.Slice:
              case e.Vector:
                return this.getTypedArray(r.members[0].structure);
            }
        }
    }), Sn({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: s, length: i, instance: {members: o}} = t, a = this, c = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = a.allocateMemory(r, s)) : (u = Object.create(l.prototype), 
                f = t), u[$t] = f, n & p && (u[Ct] = {}), !o) return u;
                {
                    let r;
                    if (n & N && t.length === i + 1 && (r = t.pop()), t.length !== i) throw new ArgumentCountMismatch(i, t.length);
                    n & R && (u[Me] = null), a.copyArguments(u, t, c, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = Ce(c.length), e[ve] = n & d && this.defineVivificatorStruct(t), 
            e[Se] = n & g && this.defineVisitorArgStruct(o), e[ke] = Ce((function(t) {
                u.call(this, t, this[ge]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(c), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[fe] = Ce(!!(n & P));
        }
    }), Sn({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                const n = new Proxy(this, Br);
                return $e(this, {
                    [Qt]: {
                        value: n
                    },
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), n;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, s = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, i = this[$t], o = i.byteOffset + n * t, a = s.obtainView(i.buffer, o, n);
                    return this[Ct][t] = e.call(_t, a);
                }
            };
        }
    });
    const Br = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : e === Wt ? t : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length", Qt), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    };
    Sn({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: s} = t, i = this.createApplier(t), o = this.defineMember(r), {set: a} = o, c = this.createConstructor(t), l = function(e, r) {
                if (nn(e, c)) this[Ie](e), s & g && this[Se]("copy", nt.Vivificate, e); else if ("string" == typeof e && s & b && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = Ke(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let s = 0;
                    for (const t of e) a.call(this, s++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === i.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            };
            return e.$ = {
                get: fn,
                set: l
            }, e.length = Ce(n), e.entries = e[qt] = this.defineArrayEntries(), s & w && (e.typedArray = this.defineTypedArray(t), 
            s & b && (e.string = this.defineString(t)), s & v && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[xe] = Ce(l), e[Me] = this.defineFinalizerArray(o), 
            e[ve] = s & d && this.defineVivificatorArray(t), e[Se] = s & g && this.defineVisitorArray(), 
            c;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = Ce(r.structure.constructor), e[Dt] = n & m && this.defineSentinel(t);
        }
    }), Sn({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: s, set: i} = r, {get: o} = this.defineMember(n, !1), a = this.createApplier(t), c = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return e.$ = r, e.toString = Ce(hn), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[zt];

                      default:
                        return o.call(this);
                    }
                }
            }, e[xe] = Ce((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === a.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && i.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [s]}, static: {members: i, template: o}} = t, a = o[Ct], {get: c, set: l} = this.defineMember(s, !1), u = {};
            for (const {name: t, flags: n, slot: r} of i) if (n & G) {
                const n = a[r];
                Be(n, zt, Ce(t));
                const s = c.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[s] = n;
            }
            e[Ue] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & E) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            Be(e, zt, Ce(n)), Be(r, n, Ce(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[Nt] instanceof r && t[Nt];
                }
            }, e[ue] = Ce(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === D.Object) return t;
            const s = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: i, set: o} = t;
            return {
                get: 0 === i.length ? function() {
                    const t = i.call(this);
                    return s(t);
                } : function(t) {
                    const e = i.call(this, t);
                    return s(e);
                },
                set: 1 === o.length ? function(t) {
                    t = s(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = s(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), Sn({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: s, flags: i} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: F,
                    byteSize: s,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && i & F) return this.globalErrorSet;
            const o = this.defineMember(r), {set: a} = o, c = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return n.$ = o, n[xe] = Ce((function(e) {
                if (e instanceof u[Lt]) a.call(this, e); else if (e && "object" == typeof e && !$n(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && a.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [s]}, static: {members: i, template: o}} = t;
            if (this.globalErrorSet && r & F) return !1;
            const a = o?.[Ct] ?? {}, c = r & F ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(s, !1);
            for (const {name: t, slot: n} of i) {
                const r = a[n], s = l.call(r);
                let i = this.globalItemsByIndex[s];
                const o = !!i;
                i || (i = new this.ZigError(t, s));
                const u = Ce(i);
                e[t] = u;
                const f = `${i}`;
                e[f] = u, c[s] = i, o || ($e(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[Pt].push(t), this.globalItemsByIndex[s] = i);
            }
            e[Ue] = {
                value: t => "number" == typeof t ? c[t] : "string" == typeof t ? n[t] : t instanceof n[Lt] ? c[Number(t)] : $n(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[Lt] = Ce(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === D.Object) return t;
            const s = t => {
                const {constructor: e, flags: n} = r, s = e(t);
                if (!s) {
                    if (n & F && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, Be(this.globalErrorSet, `${e}`, Ce(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r) : new ErrorExpected(r, t);
                }
                return s;
            }, {get: i, set: o} = t;
            return {
                get: 0 === i.length ? function() {
                    const t = i.call(this);
                    return s(t);
                } : function(t) {
                    const e = i.call(this, t);
                    return s(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = s(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = s(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function $r(t, e) {
        return en(t?.constructor?.child, e) && t["*"];
    }
    function Cr(t, e, n) {
        if (n & k) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & V && $r(t, e.child)) return !0;
        }
        return !1;
    }
    Sn({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: s} = t, {get: i, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), f = n.type === D.Void, h = r.structure.constructor, p = function() {
                this[we](), this[Se]?.("clear", nt.IgnoreUncreated);
            }, y = this.createApplier(t), m = function(t, e) {
                if (nn(t, v)) this[Ie](t), s & g && (l.call(this) || this[Se]("copy", 0, t)); else if (t instanceof h[Lt] && h(t)) c.call(this, t), 
                p.call(this); else if (void 0 !== t || f) try {
                    o.call(this, t, e), u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = h(t) ?? h.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure);
                        c.call(this, e), p.call(this);
                    } else if ($n(t)) c.call(this, t), p.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === y.call(this, t)) throw e;
                    }
                }
            }, {bitOffset: b, byteSize: w} = n, v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw a.call(this);
                    return i.call(this);
                },
                set: m
            }, e[xe] = Ce(m), e[ve] = s & d && this.defineVivificatorStruct(t), e[we] = this.defineResetter(b / 8, w), 
            e[Se] = s & g && this.defineVisitorErrorUnion(n, l), v;
        }
    }), Sn({
        defineFunction(t, n) {
            const {instance: {members: [r], template: s}} = t, i = new ObjectCache, {structure: {constructor: o}} = r, a = this, c = function(n) {
                const r = this instanceof c;
                let l, u;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new TypeMismatch("function", n);
                    if (o[Ft] === e.VariadicStruct || !c[me]) throw new Unsupported;
                    l = a.getFunctionThunk(n, c[me]);
                } else {
                    if (this !== ie) throw new NoCastingToFunction;
                    l = n;
                }
                if (u = i.find(l)) return u;
                const f = o.prototype.length, h = r ? a.createInboundCaller(n, o) : a.createOutboundCaller(s, o);
                return $e(h, {
                    length: Ce(f),
                    name: Ce(r ? n.name : "")
                }), Object.setPrototypeOf(h, c.prototype), h[$t] = l, i.save(l, h), h;
            };
            return Object.setPrototypeOf(c.prototype, Function.prototype), n.valueOf = n.toJSON = Ce(un), 
            c;
        },
        finalizeFunction(t, e, n) {
            const {static: {template: r}} = t;
            e[me] = Ce(r), n[Symbol.toStringTag] = void 0;
        }
    }), Sn({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, s = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[xe] = Ce((() => {
                throw new CreatingOpaque(t);
            })), s;
        }
    }), Sn({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: s} = t, {get: i, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), l = n.type === D.Void, u = function(t, e) {
                nn(t, f) ? (this[Ie](t), s & g && a.call(this) && this[Se]("copy", nt.Vivificate, t)) : null === t ? (c.call(this, 0), 
                this[we]?.(), this[Se]?.("clear", nt.IgnoreUncreated)) : (void 0 !== t || l) && (o.call(this, t, e), 
                s & M ? c.call(this, 1) : s & g && (a.call(this) || c.call(this, 13)));
            }, f = t.constructor = this.createConstructor(t), {bitOffset: h, byteSize: p} = n;
            return e.$ = {
                get: function() {
                    return a.call(this) ? i.call(this) : (this[Se]?.("clear", nt.IgnoreUncreated), null);
                },
                set: u
            }, e[xe] = Ce(u), e[we] = s & M && this.defineResetter(h / 8, p), e[ve] = s & d && this.defineVivificatorStruct(t), 
            e[Se] = s & g && this.defineVisitorOptional(n, a), f;
        }
    }), Sn({
        definePointer(t, n) {
            const {flags: r, byteSize: s, instance: {members: [i]}} = t, {structure: o} = i, {type: a, flags: c, byteSize: l = 1} = o, u = r & U ? s / 2 : s, {get: f, set: d} = this.defineMember({
                type: D.Uint,
                bitOffset: 0,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    byteSize: u
                }
            }), {get: g, set: p} = r & U ? this.defineMember({
                type: D.Uint,
                bitOffset: 8 * u,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    flags: y,
                    byteSize: u
                }
            }) : {}, m = function(t, n = !0, s = !0) {
                if (n || this[$t][Tt]) {
                    if (!s) return this[Ct][0] = void 0;
                    {
                        const n = M.child, s = f.call(this), i = r & U ? g.call(this) : a === e.Slice && c & $ ? x.findSentinel(s, n[Dt].bytes) + 1 : 1;
                        if (s !== this[Xt] || i !== this[Kt]) {
                            const e = x.findMemory(t, s, i, n[ee]), o = e ? n.call(ie, e) : null;
                            return this[Ct][0] = o, this[Xt] = s, this[Kt] = i, r & U && (this[Gt] = null), 
                            o;
                        }
                    }
                }
                return this[Ct][0];
            }, b = function(t) {
                d.call(this, t), this[Xt] = t;
            }, w = c & $ ? 1 : 0, v = r & U || c & $ ? function(t) {
                p?.call?.(this, t - w), this[Kt] = t;
            } : null, S = function() {
                const t = this[Rt] ?? this, e = !t[Ct][0], n = m.call(t, null, e);
                if (!n) {
                    if (r & B) return null;
                    throw new NullPointer;
                }
                return r & O ? Tr(n) : n;
            }, I = c & h ? function() {
                return S.call(this).$;
            } : S, A = r & O ? Mn : function(t) {
                return S.call(this).$ = t;
            }, x = this, E = function(n, s) {
                const i = o.constructor;
                if ($r(n, i)) {
                    if (!(r & O) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[Ct][0];
                } else if (r & k) Cr(n, i, r) && (n = i(n[Ct][0][$t])); else if (a === e.Slice && c & z && n) if (n.constructor[Ft] === e.Pointer) n = n[Zt]?.[$t]; else if (n[$t]) n = n[$t]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof i) {
                    const e = n[se];
                    if (e) {
                        if (!(r & O)) throw new ReadOnlyTarget(t);
                        n = e;
                    }
                } else if (nn(n, i)) n = i.call(ie, n[$t]); else if (r & V && r & k && n instanceof i.child) n = i(n[$t]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[ue];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== Qe(t, e.child)) return !0;
                    }
                    return !1;
                }(n, i)) {
                    n = i(x.extractView(o, n));
                } else if (null == n || n[$t]) {
                    if (!(void 0 === n || r & B && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & V && r & k && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = i.prototype[le];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (ue in i && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    n = new i(n, {
                        allocator: s
                    });
                }
                const l = n?.[$t]?.[Tt];
                if (l?.address === We) throw new PreviouslyFreed(n);
                this[Zt] = n;
            }, M = this.createConstructor(t);
            return n["*"] = {
                get: I,
                set: A
            }, n.$ = {
                get: fn,
                set: E
            }, n.length = {
                get: function() {
                    const t = S.call(this);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = S.call(this);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[$t], s = n[Tt];
                    let i;
                    if (!s) if (r & U) this[Gt] ||= e.length, i = this[Gt]; else {
                        i = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > i) throw new InvalidSliceLength(t, i);
                    const a = t * l, c = s ? x.obtainZigView(s.address, a) : x.obtainView(n.buffer, n.byteOffset, a), u = o.constructor;
                    this[Ct][0] = u.call(ie, c), v?.call?.(this, t);
                }
            }, n.slice = a === e.Slice && {
                value(t, e) {
                    const n = this[Zt].slice(t, e);
                    return new M(n);
                }
            }, n.subarray = a === e.Slice && {
                value(t, e, n) {
                    const r = this[Zt].subarray(t, e, n);
                    return new M(r);
                }
            }, n[Symbol.toPrimitive] = a === e.Primitive && {
                value(t) {
                    return this[Zt][Symbol.toPrimitive](t);
                }
            }, n[xe] = Ce(E), n[Me] = {
                value() {
                    const t = a !== e.Pointer ? zr : {};
                    let n;
                    a === e.Function ? (n = function() {}, n[$t] = this[$t], n[Ct] = this[Ct], Object.setPrototypeOf(n, M.prototype)) : n = this;
                    const r = new Proxy(n, t);
                    return Object.defineProperty(n, Qt, {
                        value: r
                    }), r;
                }
            }, n[Zt] = {
                get: S,
                set: function(t) {
                    if (void 0 === t) return;
                    const e = this[Rt] ?? this;
                    if (t) {
                        const n = t[$t][Tt];
                        if (n) {
                            const {address: e, js: r} = n;
                            b.call(this, e), v?.call?.(this, t.length), r && (t[$t][Tt] = void 0);
                        } else if (e[$t][Tt]) throw new ZigMemoryTargetRequired;
                    } else e[$t][Tt] && (b.call(this, 0), v?.call?.(this, 0));
                    e[Ct][0] = t ?? null, r & U && (e[Gt] = null);
                }
            }, n[be] = Ce(m), n[Ht] = {
                set: b
            }, n[Yt] = {
                set: v
            }, n[Se] = this.defineVisitor(), n[Xt] = Ce(0), n[Kt] = Ce(0), n[Gt] = r & U && Ce(null), 
            n.dataView = n.base64 = void 0, M;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: s, instance: {members: [i]}} = t, {structure: o} = i, {type: a, constructor: c} = o;
            n.child = c !== Object ? Ce(c) : {
                get: () => o.constructor
            }, n.const = Ce(!!(r & O)), n[Ue] = {
                value(n, i) {
                    if (this === ie || this === _t || n instanceof s) return !1;
                    if ($r(n, c)) return new s(c(n["*"]), i);
                    if (Cr(n, c, r)) return new s(n);
                    if (a === e.Slice) return new s(c(n), i);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    });
    const _r = new WeakMap;
    function Tr(t) {
        let e = _r.get(t);
        if (!e) {
            const n = t[Rt];
            e = n ? new Proxy(n, Fr) : new Proxy(t, jr), _r.set(t, e);
        }
        return e;
    }
    const zr = {
        get(t, e) {
            if (e === Rt) return t;
            if (e in t) return t[e];
            return t[Zt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[Zt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[Zt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[Zt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, Fr = {
        ...zr,
        set(t, e, n) {
            if (e in t) Mn(); else {
                t[Zt][e] = n;
            }
            return !0;
        }
    }, jr = {
        get(t, e) {
            if (e === se) return t;
            {
                const n = t[e];
                return n?.[$t] ? Tr(n) : n;
            }
        },
        set(t, e, n) {
            Mn();
        }
    };
    function Lr() {
        return this[Yt];
    }
    function Nr(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function Pr() {
        throw new InaccessiblePointer;
    }
    function Rr() {
        const t = {
            get: Pr,
            set: Pr
        };
        $e(this[Rt], {
            "*": t,
            $: t,
            [Rt]: t,
            [Zt]: t
        });
    }
    function Dr(t, e, n, r) {
        let s, i = this[Ct][t];
        if (!i) {
            if (n & nt.IgnoreUncreated) return;
            i = this[ve](t);
        }
        r && (s = r[Ct][t], !s) || i[Se](e, n, s);
    }
    Sn({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: s, set: i} = this.defineMember(n), o = function(e) {
                if (nn(e, a)) this[Ie](e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = Te(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && i.call(this, e);
            }, a = this.createConstructor(t);
            return e.$ = {
                get: s,
                set: o
            }, e[xe] = Ce(o), e[Symbol.toPrimitive] = Ce(s), a;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[ne] = Ce(n.bitSize), e[ae] = Ce(n.type);
        }
    }), Sn({
        defineSlice(t, e) {
            const {align: n, flags: r, byteSize: s, instance: {members: [i]}} = t, {byteSize: o, structure: a} = i, c = this, l = function(t, e, r) {
                t || (t = c.allocateMemory(e * o, n, r)), this[$t] = t, this[Yt] = e;
            }, u = function(e, n) {
                if (n !== this[Yt]) throw new ArrayLengthMismatch(t, this, e);
            }, f = this.defineMember(i), {set: h} = f, p = this.createApplier(t), y = function(e, n) {
                if (nn(e, b)) this[$t] ? u.call(this, e, e.length) : l.call(this, null, e.length, n), 
                this[Ie](e), r & g && this[Se]("copy", nt.Vivificate, e); else if ("string" == typeof e && r & C) y.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = Ke(e), this[$t] ? u.call(this, e, e.length) : l.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) b[Dt]?.validateValue(r, t, e.length), h.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[$t] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[$t]);
                    l.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === p.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, m = function(t, e) {
                const n = this[Yt], r = this[$t];
                t = void 0 === t ? 0 : Nr(t, n), e = void 0 === e ? n : Nr(e, n);
                const s = t * o, i = e * o - s;
                return c.obtainView(r.buffer, r.byteOffset + s, i);
            }, b = this.createConstructor(t);
            return e.$ = {
                get: fn,
                set: y
            }, e.length = {
                get: Lr
            }, r & _ && (e.typedArray = this.defineTypedArray(t), r & C && (e.string = this.defineString(t)), 
            r & T && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[qt] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = m.call(this, t, e);
                    return b(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: s = !1} = r, i = m.call(this, t, e), o = c.allocateMemory(i.byteLength, n, s), a = b(o);
                    return a[Ie]({
                        [$t]: i
                    }), a;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[Ae] = Ce(l), e[Ie] = this.defineCopier(s, !0), 
            e[xe] = Ce(y), e[Me] = this.defineFinalizerArray(f), e[ve] = r & d && this.defineVivificatorArray(t), 
            e[Se] = r & g && this.defineVisitorArray(), b;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = Ce(r.structure.constructor), e[Dt] = n & $ && this.defineSentinel(t);
        }
    }), Sn({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === D.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: s, byteSize: i, structure: {constructor: o}} = e, a = this[$t], c = a.byteOffset + (s >> 3);
                    let l = i;
                    if (void 0 === l) {
                        if (7 & s) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(a.buffer, c, l);
                    return this[Ct][t] = o.call(_t, u);
                }
            };
        }
    }), Sn({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: s, instance: {members: a}} = t, c = a.find((t => t.flags & H)), l = c && this.defineMember(c), u = this.createApplier(t), f = function(e, n) {
                if (nn(e, h)) this[Ie](e), r & g && this[Se]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            }, h = this.createConstructor(t), p = e[le].value, y = e[Jt].value, m = [];
            for (const t of a.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: s} = e[n] = this.defineMember(t);
                s && (r & Z && (s.required = !0), p[n] = s, y.push(n)), m.push(n);
            }
            return e.$ = {
                get: un,
                set: f
            }, e.length = Ce(s), e.entries = r & S.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & S.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[xe] = Ce(f), e[ve] = r & d && this.defineVivificatorStruct(t), e[Se] = r & g && this.defineVisitorStruct(a), 
            e[qt] = r & S.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[Pt] = Ce(m), n === i && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), h;
        }
    }), Sn({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: s}} = t, i = !!(r & I), a = i ? s.slice(0, -1) : s, c = i ? s[s.length - 1] : null, {get: l, set: u} = this.defineMember(c), {get: f} = this.defineMember(c, !1), h = r & A ? function() {
                return l.call(this)[zt];
            } : function() {
                const t = l.call(this);
                return a[t].name;
            }, p = r & A ? function(t) {
                const {constructor: e} = c.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = a.findIndex((e => e.name === t));
                u.call(this, e);
            }, y = this.createApplier(t), m = function(e, n) {
                if (nn(e, b)) this[Ie](e), r & g && this[Se]("copy", nt.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of E) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === y.call(this, e, n)) throw new MissingUnionInitializer(t, e, i);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            }, b = this.createConstructor(t), w = {}, v = e[le].value, S = e[Jt].value, E = [];
            for (const n of a) {
                const {name: s} = n, {get: o, set: a} = this.defineMember(n), c = i ? function() {
                    const e = h.call(this);
                    if (s !== e) {
                        if (r & A) return null;
                        throw new InactiveUnionProperty(t, s, e);
                    }
                    return o.call(this);
                } : o, l = i && a ? function(e) {
                    const n = h.call(this);
                    if (s !== n) throw new InactiveUnionProperty(t, s, n);
                    a.call(this, e);
                } : a, u = i && a ? function(t) {
                    p.call(this, s), this[Se]?.("clear", nt.IgnoreUncreated), a.call(this, t);
                } : a;
                e[s] = {
                    get: c,
                    set: l
                }, v[s] = u, w[s] = o, S.push(s), E.push(s);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: m
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & A && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return h.call(this);

                      default:
                        return f.call(this);
                    }
                }
            };
            const {comptime: M} = this;
            return e[Ee] = r & x && {
                value() {
                    return M || this[Se](Rr), this[Se] = dn, this;
                }
            }, e[xe] = Ce(m), e[Nt] = r & A && {
                get: l,
                set: u
            }, e[ve] = r & d && this.defineVivificatorStruct(t), e[Se] = r & g && this.defineVisitorUnion(a, r & A ? f : null), 
            e[qt] = this.defineUnionEntries(), e[Pt] = r & A ? {
                get() {
                    return [ h.call(this) ];
                }
            } : Ce(E), e[ce] = Ce(w), b;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & A && (e.tag = Ce(r[r.length - 1].structure.constructor));
        }
    }), Sn({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: s, length: i, instance: {members: o}} = t, a = this, c = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[$t] = a.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = a.littleEndian;
            };
            return $e(u, {
                [re]: {
                    value: 4
                }
            }), $e(u.prototype, {
                set: Ce((function(t, e, n, r, s) {
                    const i = this[$t], o = a.littleEndian;
                    i.setUint16(8 * t, e, o), i.setUint16(8 * t + 2, n, o), i.setUint16(8 * t + 4, r, o), 
                    i.setUint8(8 * t + 6, s == D.Float), i.setUint8(8 * t + 7, s == D.Int || s == D.Float);
                }))
            }), e[ve] = s & d && this.defineVivificatorStruct(t), e[Se] = this.defineVisitorVariadicStruct(o), 
            e[ke] = Ce((function(t) {
                l.call(this, t, this[ge]);
            })), function(t) {
                if (t.length < i) throw new ArgumentCountMismatch(i, t.length, !0);
                let e = n, s = r;
                const o = t.slice(i), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[$t], o = n?.constructor?.[re];
                    if (!r || !o) {
                        throw xn(new InvalidVariadicArgument, i + t);
                    }
                    o > s && (s = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = a.allocateMemory(e, s);
                h[re] = s, this[$t] = h, this[Ct] = {}, a.copyArguments(this, t, c);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: s, structure: {align: i}}] of c.entries()) f.set(t, e / 8, n, i, r), 
                s > d && (d = s);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[$t], s = l[t], o = a.obtainView(h.buffer, s, r), c = this[Ct][n] = e.constructor.call(_t, o), u = e.constructor[ne] ?? 8 * r, g = e.constructor[re], p = e.constructor[ae];
                    c.$ = e, f.set(i + t, s, u, g, p);
                }
                this[oe] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[fe] = Ce(!!(n & P)), e[re] = Ce(void 0);
        }
    }), Sn({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [s]}} = t, i = this.createApplier(t), o = function(e) {
                if (nn(e, a)) this[Ie](e), n & g && this[Se]("copy", nt.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let s = 0;
                    for (const t of e) this[s++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === i.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, a = this.createConstructor(t, {
                initializer: o
            }), {bitSize: c} = s;
            for (let t = 0, i = 0; t < r; t++, i += c) e[t] = n & g ? this.defineMember({
                ...s,
                slot: t
            }) : this.defineMember({
                ...s,
                bitOffset: i
            });
            return e.$ = {
                get: un,
                set: o
            }, e.length = Ce(r), n & j && (e.typedArray = this.defineTypedArray(t), n & L && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[qt] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[xe] = Ce(o), e[ve] = n & d && this.defineVivificatorArray(t), e[Se] = n & g && this.defineVisitorArray(), 
            a;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = Ce(n.structure.constructor);
        }
    }), Sn({
        fdLockGet(t, e, n) {
            const r = this.littleEndian;
            return kn(n, st, (() => {
                const [n] = this.getStream(t);
                if (rn(n, "getlock")) {
                    const t = ln(24);
                    this.moveExternBytes(t, e, !1);
                    const s = t.getUint16(0, r), i = t.getUint16(2, r), o = t.getUint32(4, r), a = Je(t.getBigInt64(8, r)), c = Je(t.getBigUint64(16, r));
                    return n.getlock({
                        type: s,
                        whence: i,
                        start: a,
                        length: c,
                        pid: o
                    });
                }
            }), (t => {
                let n;
                t ? (n = ln(24), n.setUint16(0, t.type ?? 0, r), n.setUint16(2, t.whence ?? 0, r), 
                n.setUint32(4, t.pid ?? 0, r), n.setBigInt64(8, BigInt(t.start ?? 0), r), n.setBigUint64(16, BigInt(t.length ?? 0), r)) : (n = ln(2), 
                n.setUint16(0, 2, r)), this.moveExternBytes(n, e, !0);
            }));
        },
        exports: {
            fdLockGet: {
                async: !0
            }
        }
    }), Sn({
        fdLockSet(t, e, n, r) {
            const s = this.littleEndian;
            return kn(r, it, (() => {
                const [r] = this.getStream(t);
                if (rn(r, "setlock")) {
                    const t = ln(24);
                    this.moveExternBytes(t, e, !1);
                    const i = t.getUint16(0, s), o = t.getUint16(2, s), a = t.getUint32(4, s), c = Je(t.getBigUint64(8, s)), l = Je(t.getBigUint64(16, s));
                    return r.setlock({
                        type: i,
                        whence: o,
                        start: c,
                        len: l,
                        pid: a
                    }, n);
                }
                return !0;
            }), (t => Bn(t, it)));
        },
        exports: {
            fdLockSet: {
                async: !0
            }
        }
    }), Sn({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? Wr[t] : t, r.call(this, e, n);
            }
        })
    });
    const Wr = {
        copy(t, e) {
            const n = e[Ct][0];
            if (this[$t][Tt] && n && !n[$t][Tt]) throw new ZigMemoryTargetRequired;
            this[Ct][0] = n;
        },
        clear(t) {
            t & nt.IsInactive && (this[Ct][0] = void 0);
        },
        reset() {
            this[Ct][0] = void 0, this[Xt] = void 0;
        }
    };
    return Sn({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: s, structure: i}] of t.entries()) i.flags & g && (0 === r ? n = s : e.push(s));
            return {
                value(t, r, s) {
                    if (!(r & nt.IgnoreArguments) && e.length > 0) for (const n of e) Dr.call(this, n, t, r | nt.IsImmutable, s);
                    r & nt.IgnoreRetval || void 0 === n || Dr.call(this, n, t, r, s);
                }
            };
        }
    }), Sn({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, s = this.length; r < s; r++) Dr.call(this, r, t, e, n);
            }
        })
    }), Sn({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, s) {
                    e.call(this) && (r |= nt.IsInactive), r & nt.IsInactive && r & nt.IgnoreInactive || Dr.call(this, n, t, r, s);
                }
            };
        }
    }), Sn({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, s) {
                    e.call(this) || (r |= nt.IsInactive), r & nt.IsInactive && r & nt.IgnoreInactive || Dr.call(this, n, t, r, s);
                }
            };
        }
    }), Sn({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & g)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const s of e) Dr.call(this, s, t, n, r);
                }
            };
        }
    }), Sn({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: s}] of t.entries()) s?.flags & g && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, s) {
                    const i = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== i && (n |= nt.IsInactive), n & nt.IsInactive && n & nt.IgnoreInactive || Dr.call(this, o, t, n, s);
                    }
                }
            };
        }
    }), Sn({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & g ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & nt.IgnoreArguments)) for (const [s, i] of Object.entries(this[Ct])) s !== n && Se in i && Dr.call(this, s, t, e | nt.IsImmutable, r);
                    e & nt.IgnoreRetval || void 0 === n || Dr.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (In());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
