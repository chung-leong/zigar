(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, s = 3, i = 4, o = 5, a = 6, c = 7, l = 8, u = 9, f = Object.keys(e), h = 1, d = 2, g = 4, p = 8, y = 16, m = 16, b = 32, w = 64, v = 128, S = {
        IsExtern: 16,
        IsPacked: 32,
        IsTuple: 64,
        IsOptional: 128
    }, A = 16, x = 32, I = 64, E = 16, M = 16, U = 16, k = 32, V = 64, O = 128, B = 256, z = 16, $ = 32, _ = 64, C = 128, T = 256, F = 16, j = 16, L = 32, N = 16, P = 32, R = 64, D = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, W = Object.keys(D), Z = 1, q = 2, G = 4, J = 16, H = 64, Y = 128, X = 1, K = 2, Q = 4, tt = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, et = 0, nt = 2, rt = 6, st = 8, it = 16, ot = 20, at = 21, ct = 28, lt = 29, ut = 44, ft = {
        unknown: 0,
        blockDevice: 1,
        characterDevice: 2,
        directory: 3,
        file: 4,
        socketDgram: 5,
        socketStream: 6,
        symbolicLink: 7
    }, ht = {
        create: 1,
        directory: 2,
        exclusive: 4,
        truncate: 8
    }, dt = {
        symlinkFollow: 1
    }, gt = {
        fd_datasync: 1,
        fd_read: 2,
        fd_seek: 4,
        fd_fdstat_set_flags: 8,
        fd_sync: 16,
        fd_tell: 32,
        fd_write: 64,
        fd_advise: 128,
        fd_allocate: 256,
        path_create_directory: 512,
        path_create_file: 1024,
        path_link_source: 2048,
        path_link_target: 4096,
        path_open: 8192,
        fd_readdir: 16384,
        path_readlink: 32768,
        path_rename_source: 65536,
        path_rename_target: 1 << 17,
        path_filestat_get: 1 << 18,
        path_filestat_set_size: 1 << 19,
        path_filestat_set_times: 1 << 20,
        fd_filestat_get: 1 << 21,
        fd_filestat_set_size: 1 << 22,
        fd_filestat_set_times: 1 << 23,
        path_symlink: 1 << 24,
        path_remove_directory: 1 << 25,
        path_unlink_file: 1 << 26,
        poll_fd_readwrite: 1 << 27,
        sock_shutdown: 1 << 28,
        sock_accept: 1 << 29
    }, pt = {
        append: 1,
        dsync: 2,
        nonblock: 4,
        rsync: 8,
        sync: 16
    }, yt = 1, mt = 2, bt = -1, wt = 1048575, vt = globalThis[Symbol.for("ZIGAR")] ||= {};
    function St(t) {
        return vt[t] ||= Symbol(t);
    }
    function At(t) {
        return St(t);
    }
    const xt = At("memory"), It = At("slots"), Et = At("parent"), Mt = At("zig"), Ut = At("name"), kt = At("type"), Vt = At("flags"), Ot = At("class"), Bt = At("tag"), zt = At("props"), $t = At("pointer"), _t = At("sentinel"), Ct = At("array"), Tt = At("target"), Ft = At("entries"), jt = At("max length"), Lt = At("keys"), Nt = At("address"), Pt = At("length"), Rt = At("last address"), Dt = At("last length"), Wt = At("proxy"), Zt = At("cache"), qt = At("size"), Gt = At("bit size"), Jt = At("align"), Ht = At("const target"), Yt = At("environment"), Xt = At("attributes"), Kt = At("primitive"), Qt = At("getters"), te = At("setters"), ee = At("typed array"), ne = At("throwing"), re = At("promise"), se = At("generator"), ie = At("allocator"), oe = At("fallback"), ae = At("signature"), ce = At("string retval"), le = At("update"), ue = At("reset"), fe = At("vivificate"), he = At("visit"), de = At("copy"), ge = At("shape"), pe = At("initialize"), ye = At("restrict"), me = At("finalize"), be = At("cast"), we = At("return"), ve = At("yield");
    function Se(t, e, n) {
        if (n) {
            const {set: r, get: s, value: i, enumerable: o, configurable: a = !0, writable: c = !0} = n;
            Object.defineProperty(t, e, s || r ? {
                get: s,
                set: r,
                configurable: a,
                enumerable: o
            } : {
                value: i,
                configurable: a,
                enumerable: o,
                writable: c
            });
        }
        return t;
    }
    function Ae(t, e) {
        for (const [n, r] of Object.entries(e)) Se(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            Se(t, n, e[n]);
        }
        return t;
    }
    function xe(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function Ie(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function Ee({type: t, bitSize: e}) {
        switch (t) {
          case D.Bool:
            return "boolean";

          case D.Int:
          case D.Uint:
            if (e > 32) return "bigint";

          case D.Float:
            return "number";
        }
    }
    function Me(t, e = "utf-8") {
        const n = ke[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let s = 0;
            for (const e of t) r.set(e, s), s += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function Ue(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (Ve[e] ||= new TextEncoder).encode(t);
    }
    const ke = {}, Ve = {};
    function Oe(t, e, n) {
        let r = 0, s = t.length;
        if (0 === s) return 0;
        for (;r < s; ) {
            const i = Math.floor((r + s) / 2);
            n(t[i]) <= e ? r = i + 1 : s = i;
        }
        return s;
    }
    const Be = function(t, e) {
        return !!e && !!(t & e - 1);
    }, ze = function(t, e) {
        return t + (e - 1) & ~(e - 1);
    }, $e = 4294967295, _e = function(t) {
        return Number(t);
    }, Ce = function(t, e) {
        return t + e;
    };
    function Te(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function Fe(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function je(t, e) {
        const n = [], r = new Map, s = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) s(n);
        };
        for (const e of t) s(e.instance.template), s(e.static.template);
        return n;
    }
    function Le(t, e) {
        return t === e || t?.[ae] === e[ae] && t?.[Yt] !== e?.[Yt];
    }
    function Ne(t, e) {
        return t instanceof e || Le(t?.constructor, e);
    }
    function Pe(t, e) {
        return "function" == typeof t?.[e];
    }
    function Re(t) {
        return "function" == typeof t?.then;
    }
    function De(t, e) {
        const n = {};
        for (const [r, s] of Object.entries(e)) t & s && (n[r] = !0);
        return n;
    }
    function We(t, e) {
        for (const [n, r] of Object.entries(e)) if (n === t) return r;
    }
    function Ze({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function qe(t) {
        return new DataView(new ArrayBuffer(t));
    }
    function Ge() {
        return this;
    }
    function Je() {
        return this[Wt];
    }
    function He() {
        return String(this);
    }
    function Ye() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return this.map.get(t);
        }
        save(t, e) {
            return this.map.set(t, e), e;
        }
    }
    const Xe = 1, Ke = 2, Qe = 4, tn = 8, en = () => 1e3 * new Date;
    function nn(t, e, n) {
        const r = {};
        return n & Xe ? r.atime = t : n & Ke && (r.atime = en()), n & Qe ? r.mtime = e : n & tn && (r.mtime = en()), 
        r;
    }
    const rn = {
        name: "",
        mixins: []
    };
    function sn(t) {
        return rn.mixins.includes(t) || rn.mixins.push(t), t;
    }
    function on() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: s} = r;
            Se(r, "name", xe(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = s[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                Se(s, e, xe(r));
            }
            return r;
        }(rn.name, rn.mixins);
    }
    function an(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, s) {
                const i = n.getUint8(s) >> t & r;
                e.setUint8(0, i);
            };
            {
                const e = 255 ^ r << t;
                return function(n, s, i) {
                    const o = s.getUint8(0), a = n.getUint8(i) & e | (o & r) << t;
                    n.setUint8(i, a);
                };
            }
        }
        {
            const r = 8 - t, s = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(i, o, a) {
                    let c, l = a, u = 0, f = o.getUint8(l++), h = f >> t & s, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), c = g >= 8 ? 255 & h : h & n, i.setUint8(u++, c), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, i = 255 ^ s << t, o = 255 ^ n;
                return function(r, s, a) {
                    let c, l, u = 0, f = a, h = r.getUint8(f), d = h & i, g = t, p = e + g;
                    do {
                        p > g && (c = s.getUint8(u++), d |= c << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    sn({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: s, byteSize: i} = e, o = [], a = void 0 === i && (7 & r || 7 & s);
            a && o.push("Unaligned");
            let c = W[n];
            r > 32 && (n === D.Int || n === D.Uint) && (c = r <= 64 ? `Big${c}` : `Jumbo${c}`), 
            o.push(c, `${n === D.Bool && i ? 8 * i : r}`), a && o.push(`@${s}`);
            const l = t + o.join("");
            let u = DataView.prototype[l];
            if (u && this.usingBufferFallback()) {
                const e = this, s = u, i = function(t) {
                    const {buffer: e, byteOffset: n, byteLength: s} = this, i = e[oe];
                    if (i) {
                        if (t < 0 || t + r / 8 > s) throw new RangeError("Offset is outside the bounds of the DataView");
                        return i + _e(n + t);
                    }
                };
                u = "get" === t ? function(t, o) {
                    const a = i.call(this, t);
                    return void 0 !== a ? e.getNumericValue(n, r, a) : s.call(this, t, o);
                } : function(t, o, a) {
                    const c = i.call(this, t);
                    return void 0 !== c ? e.setNumericValue(n, r, c, o) : s.call(this, t, o, a);
                };
            }
            if (u) return u;
            if (u = this.accessorCache.get(l), u) return u;
            for (;o.length > 0; ) {
                const n = `getAccessor${o.join("")}`;
                if (u = this[n]?.(t, e)) break;
                o.pop();
            }
            if (!u) throw new Error(`No accessor available: ${l}`);
            return Se(u, "name", xe(l)), this.accessorCache.set(l, u), u;
        },
        imports: {
            getNumericValue: null,
            setNumericValue: null
        }
    }), sn({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), s = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & s) - (n & r);
            } : function(t, e, n) {
                const i = e < 0 ? r | e & s : e & s;
                this.setBigUint64(t, i, n);
            };
        }
    }), sn({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const s = e & r;
                this.setBigUint64(t, s, n);
            };
        }
    }), sn({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, s = this.getAccessor(t, {
                type: D.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!s.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, i) {
                    s.call(this, n, r ? e : t, i);
                };
            }
        }
    }), sn({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = qe(8), s = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, i = function(t, e, r) {
                const s = 0xffffffffn & e, i = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, a = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(s), r), this.setUint32(t + (r ? 4 : n - 8), Number(i), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(a), r);
            };
            return "get" === t ? function(t, e) {
                const n = s.call(this, t, e), i = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, a = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return i ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : i ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return i ? -t : t;
                }
                const l = i << 63n | c << 52n | (a >> 60n) + BigInt((a & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const s = r.getBigUint64(0, n), o = s >> 63n, a = (0x7ff0000000000000n & s) >> 52n, c = 0x000fffffffffffffn & s;
                let l;
                l = 0n === a ? o << 127n | c << 60n : 0x07ffn === a ? o << 127n | 0x7fffn << 112n | (c ? 1n : 0n) : o << 127n | a - 1023n + 16383n << 112n | c << 60n, 
                i.call(this, t, l, n);
            };
        }
    }), sn({
        getAccessorFloat16(t, e) {
            const n = qe(4), r = DataView.prototype.setUint16, s = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = s.call(this, t, e), i = r >>> 15, o = (31744 & r) >> 10, a = 1023 & r;
                if (0 === o) return i ? -0 : 0;
                if (31 === o) return a ? NaN : i ? -1 / 0 : 1 / 0;
                const c = i << 31 | o - 15 + 127 << 23 | a << 13;
                return n.setUint32(0, c, e), n.getFloat32(0, e);
            } : function(t, e, s) {
                n.setFloat32(0, e, s);
                const i = n.getUint32(0, s), o = i >>> 31, a = (2139095040 & i) >> 23, c = 8388607 & i, l = a - 127 + 15;
                let u;
                u = 0 === a ? o << 15 : 255 === a ? o << 15 | 31744 | (c ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | c >> 13, 
                r.call(this, t, u, s);
            };
        }
    }), sn({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = qe(8), s = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, i = function(t, e, r) {
                const s = 0xffffffffn & e, i = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(s), r), this.setUint32(t + (r ? 4 : n - 8), Number(i), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = s.call(this, t, e), i = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, a = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = a ? Number.MIN_VALUE : 0;
                    return i ? -t : t;
                }
                if (0x7fffn === o) return a ? NaN : i ? -1 / 0 : 1 / 0;
                const c = o - 16383n + 1023n;
                if (c >= 2047n) {
                    const t = 1 / 0;
                    return i ? -t : t;
                }
                const l = i << 63n | c << 52n | (a >> 11n) + BigInt((a & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const s = r.getBigUint64(0, n), o = s >> 63n, a = (0x7ff0000000000000n & s) >> 52n, c = 0x000fffffffffffffn & s;
                let l;
                l = 0n === a ? o << 79n | c << 11n : 0x07ffn === a ? o << 79n | 0x7fffn << 64n | (c ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | a - 1023n + 16383n << 64n | c << 11n | 0x00008000000000000000n, 
                i.call(this, t, l, n);
            };
        }
    }), sn({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: D.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), s = 2 ** (n - 1), i = s - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & i) - (r & s);
                } : function(t, n, r) {
                    const o = n < 0 ? s | n & i : n & i;
                    e.call(this, t, o, r);
                };
            }
        }
    }), sn({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), s = 2n ** BigInt(n - 1), i = s - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & i) - (n & s);
            } : function(t, e, n) {
                const o = e < 0 ? s | e & i : e & i;
                r.call(this, t, o, n);
            };
        }
    }), sn({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), s = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & s;
            } : function(t, e, n) {
                const i = e & s;
                r.call(this, t, i, n);
            };
        }
    }), sn({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let s = 0, i = t + 8 * (n - 1); s < n; s++, i -= 8) {
                    r = r << 64n | this.getBigUint64(i, e);
                } else for (let s = 0, i = t; s < n; s++, i += 8) {
                    r = r << 64n | this.getBigUint64(i, e);
                }
                return r;
            } : function(t, e, r) {
                let s = e;
                const i = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = s & i;
                    this.setBigUint64(o, t, r), s >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = s & i;
                    this.setBigUint64(o, t, r), s >>= 64n;
                }
            };
        }
    }), sn({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const s = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), i = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return s.call(this, t, e) & i;
                } : function(t, e, n) {
                    const r = e & i;
                    s.call(this, t, r, n);
                };
            }
        }
    }), sn({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), s = e ? n | r : n & ~r;
                this.setInt8(t, s);
            };
        }
    }), sn({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r;
            if (s + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> s;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << s;
                    return function(n, i) {
                        let o = this.getUint8(n);
                        o = o & t | (i < 0 ? e | i & r : i & r) << s, this.setUint8(n, o);
                    };
                }
            }
        }
    }), sn({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r;
            if (s + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> s & e;
                };
                {
                    const t = 255 ^ e << s;
                    return function(n, r) {
                        const i = this.getUint8(n) & t | (r & e) << s;
                        this.setUint8(n, i);
                    };
                }
            }
        }
    }), sn({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r, i = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = qe(i);
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: i
                }), r = an(s, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: i
                }), r = an(s, n, !1);
                return function(e, n, s) {
                    t.call(o, 0, n, s), r(this, o, e);
                };
            }
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: s, type: i, byteSize: o} = t, a = n.byteLength, c = 1 !== o ? "s" : "";
            let l;
            if (i !== e.Slice || r) {
                l = `${s} has ${i === e.Slice ? r.length * o : o} byte${c}, received ${a}`;
            } else l = `${s} has elements that are ${o} byte${c} in length, received ${a}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: s} = t, i = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(wn);
            let a;
            s && o.push(wn(s.name)), a = n === e.Slice ? `Expecting ${Sn(o)} that can accommodate items ${r} byte${i} in length` : `Expecting ${Sn(o)} that is ${r} byte${i} in length`, 
            super(a);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let s;
            "string" === r || "number" === r || mn(e) ? (mn(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            s = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : s = `Error of the type ${n} expected, received ${e}`, 
            super(s);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Error given is not a part of error set ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: s}} = t;
            super(`${r} needs an initializer for one of its union properties: ${s.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, s = [];
            if (Array.isArray(e)) for (const t of e) s.push(wn(t)); else s.push(wn(e));
            const i = bn(n);
            super(`${r} expects ${Sn(s)} as argument, received ${i}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [s]}, type: i, constructor: o} = t, a = [], c = Ee(s);
            if (c) {
                let t;
                switch (s.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = c;
                }
                a.push(`array of ${t}s`);
            } else a.push("array of objects");
            o[ee] && a.push(o[ee].name), i === e.Slice && r && a.push("length"), super(t, a.join(" or "), n);
        }
    }
    class InvalidEnumValue extends TypeError {
        code=ct;
        constructor(t, e) {
            super(`Received '${e}', which is not among the following possible values:\n\n${Object.keys(t).map((t => `${t}\n`)).join("")}`);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: s, instance: {members: [i]}} = t, {structure: {constructor: o}} = i, {length: a, constructor: c} = n, l = e?.length ?? s, u = 1 !== l ? "s" : "";
            let f;
            f = c === o ? "only a single one" : c.child === o ? `a slice/array that has ${a}` : `${a} initializer${a > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let s;
            s = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(s);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const s = 1 !== (t -= r) ? "s" : "", i = n ? "at least " : "";
                this.message = `Expecting ${i}${t} argument${s}, received ${e}`, this.stack = un(this.stack, "new Arg(");
            };
            r(0), Se(this, le, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: s} = t;
            super(`${s} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    let cn = class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = bn(e);
            super(`Expected ${wn(t)}, received ${n}`);
        }
    };
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${vn(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + W[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class InvalidFileDescriptor extends Error {
        code=st;
        constructor() {
            super("Invalid file descriptor");
        }
    }
    class MissingStreamMethod extends Error {
        code=st;
        constructor(t) {
            super(`Missing stream method '${t}'`);
        }
    }
    class InvalidArgument extends Error {
        code=ct;
        constructor() {
            super("Invalid argument");
        }
    }
    class WouldBlock extends Error {
        code=rt;
        constructor() {
            super("Would block");
        }
    }
    class Deadlock extends Error {
        code=it;
        constructor() {
            super("Unable to await promise");
        }
    }
    class MissingEventListener extends Error {
        constructor(t, e) {
            super(`Missing event listener: ${t}`), this.code = e;
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = un(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function ln(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = un(t.stack, "new Arg(");
        };
        return n(0), Se(t, le, {
            value: n,
            enumerable: !1
        }), t;
    }
    function un(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function fn() {
        throw new ReadOnly;
    }
    function hn(t, e, n) {
        if (t.bytes += n, t.calls++, 100 === t.calls) {
            const n = t.bytes / t.calls;
            if (n < 8) {
                throw new Error(`Inefficient ${e} access. Each call is only ${"read" === e ? "reading" : "writing"} ${n} byte${1 !== n ? "s" : ""}. Please use std.io.Buffered${"read" === e ? "Reader" : "Writer"}.`);
            }
        }
    }
    function dn(t = !1, e, n, r, s) {
        const i = t => {
            let n;
            return s ? n = s(t) : t.code !== rt && console.error(t), n ?? t.code ?? e;
        }, o = t => {
            const e = r?.(t);
            return e ?? et;
        };
        try {
            const e = n();
            if (Re(e)) {
                if (!t) throw new Deadlock;
                return e.then(o).catch(i);
            }
            return o(e);
        } catch (t) {
            return i(t);
        }
    }
    function gn(t, e) {
        if (!(t[0] & e)) throw new InvalidFileDescriptor;
    }
    function pn(t, e) {
        if (!Pe(t, e)) throw new MissingStreamMethod(e);
    }
    function yn(t, e) {
        if (!0 === t) return et;
        if (!1 === t) return e;
        throw new cn("boolean", t);
    }
    function mn(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function bn(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        wn(n);
    }
    function wn(t) {
        return `${vn(t)} ${t}`;
    }
    function vn(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function Sn(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function An(t) {
        let n, r = 1, s = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[Mt]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[xt]) t.constructor[kt] === e.Pointer && (t = t["*"]), 
        n = t[xt], s = t.constructor, r = s[Jt]; else {
            "string" == typeof t && (t = Ue(t));
            const {buffer: e, byteOffset: s, byteLength: i, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== s && void 0 !== i && (n = new DataView(e, s, i), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: s
        };
    }
    sn({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: s}, ptr: i} = this, o = s(i, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const a = o["*"][xt];
                return a[Mt].align = e, a;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = An(e), s = n?.[Mt];
                    if (!s) throw new cn("object containing allocated Zig memory", e);
                    const {address: i} = s;
                    if (-1 === i) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: a} = this;
                    o(a, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe() {
            const t = this.getCopyFunction();
            return {
                value(e) {
                    const {dv: n, align: r, constructor: s} = An(e);
                    if (!n) throw new cn("string, DataView, typed array, or Zig object", e);
                    const i = this.alloc(n.byteLength, r);
                    return t(i, n), s ? s(i) : i;
                }
            };
        }
    }), sn({
        init() {
            this.variables = [], this.listenerMap = new Map([ [ "log", t => console.log(t.message) ] ]);
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: (...t) => this.initialize?.(...t),
                abandon: () => this.abandonModule?.(),
                redirect: (t, e) => this.redirectStream(t, e),
                sizeOf: e => t(e?.[qt]),
                alignOf: e => t(e?.[Jt]),
                typeOf: e => xn[t(e?.[kt])],
                on: (t, e) => this.addListener(t, e)
            };
        },
        addListener(t, e) {
            this.listenerMap.set(t, e), [ "mkdir", "stat", "set_times", "open", "rmdir", "unlink" ].includes(t) && this.setRedirectionMask(t, !!e);
        },
        hasListener(t) {
            return this.listenerMap.get(t);
        },
        triggerEvent(t, e, n) {
            const r = this.listenerMap.get(t);
            if (r) return r(e);
            if (n) throw new MissingEventListener(t, n);
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = s(r);
                return t;
            }, r = t => t.length ? t.buffer : new ArrayBuffer(0), s = t => {
                const {memory: e, structure: s, actual: i} = t;
                if (e) {
                    if (i) return i;
                    {
                        const {array: i, offset: o, length: a} = e, c = this.obtainView(r(i), o, a), {handle: l, const: u} = t, f = s?.constructor, h = t.actual = f.call(Yt, c);
                        return u && this.makeReadOnly(h), t.slots && n(h[It], t.slots), l && this.variables.push({
                            handle: l,
                            object: h
                        }), h;
                    }
                }
                return s;
            }, i = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: s} = t.template, o = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: i} = n;
                        o[xt] = this.obtainView(r(t), e, i), s && this.variables.push({
                            handle: s,
                            object: o
                        });
                    }
                    if (e) {
                        const t = o[It] = {};
                        i.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of i) n(t, e);
            for (const e of t) this.finalizeStructure(e);
        }
    });
    const xn = f.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    sn({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[xt]), s = this.createJsThunk(t, n);
                if (!s) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(s, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                try {
                    const s = e(n);
                    if (he in s) {
                        s[he]("reset");
                        const t = this.startContext();
                        this.updatePointerTargets(t, s, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const i = s.hasOwnProperty(we), o = dn(r || i, at, (() => t(...s)), (t => {
                        if (t?.[Symbol.asyncIterator]) {
                            if (!s.hasOwnProperty(ve)) throw new UnexpectedGenerator;
                            this.pipeContents(t, s);
                        } else s[we](t);
                    }), (t => {
                        try {
                            if (e[ne] && t instanceof Error) return s[we](t), et;
                            throw t;
                        } catch (e) {
                            console.error(t);
                        }
                    }));
                    return i ? et : o;
                } catch (t) {
                    return console.error(t), at;
                }
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, a = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === i)).length;
            return {
                value() {
                    let c, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, y, m = this[d];
                        if (p === D.Object && m?.[xt]?.[Mt] && (m = new m.constructor(m)), g.type === e.Struct) switch (g.purpose) {
                          case i:
                            t = 1 === a ? "allocator" : "allocator" + ++l, y = this[ie] = m;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (y = o.createPromiseCallback(this, m));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (y = o.createGeneratorCallback(this, m));
                            break;

                          case s:
                            t = "signal", 1 == ++f && (y = o.createInboundSignal(m));
                        }
                        void 0 !== t ? void 0 !== y && (c ||= {}, c[t] = y) : h.push(m);
                    } catch (t) {
                        h.push(t);
                    }
                    return c && h.push(c), h[Symbol.iterator]();
                }
            };
        },
        handleJscall(t, e, n, r) {
            const s = this.obtainZigView(e, n, !1), i = this.jsFunctionCallerMap.get(t);
            return i ? i(s, r) : at;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[xt]), s = this.getViewAddress(e);
                this.destroyJsThunk(r, s), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJscall: {
                async: !0
            },
            releaseFunction: {}
        },
        imports: {
            createJsThunk: {},
            destroyJsThunk: {},
            finalizeAsyncCall: {}
        }
    }), sn({
        createOutboundCaller(t, e) {
            const n = this, r = function(...s) {
                const i = new e(s, this?.[ie]);
                return n.invokeThunk(t, r, i);
            };
            return r;
        },
        copyArguments(t, o, f, h, d) {
            let g = 0, p = 0, y = 0;
            const m = t[te];
            for (const {type: b, structure: w} of f) {
                let f, v, S, A;
                if (w.type === e.Struct) switch (w.purpose) {
                  case i:
                    f = (1 == ++y ? h?.allocator ?? h?.allocator1 : h?.[`allocator${y}`]) ?? this.createDefaultAllocator(t, w);
                    break;

                  case n:
                    v ||= this.createPromise(w, t, h?.callback), f = v;
                    break;

                  case r:
                    S ||= this.createGenerator(w, t, h?.callback), f = S;
                    break;

                  case s:
                    A ||= this.createSignal(w, h?.signal), f = A;
                    break;

                  case a:
                    f = this.createReader(o[p++]);
                    break;

                  case c:
                    f = this.createWriter(o[p++]);
                    break;

                  case l:
                    f = this.createFile(o[p++]);
                    break;

                  case u:
                    f = this.createDirectory(o[p++]);
                }
                if (void 0 === f && (f = o[p++], void 0 === f && b !== D.Void)) throw new UndefinedArgument;
                try {
                    m[g++].call(t, f, d);
                } catch (t) {
                    throw ln(t, g - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), s = n[Xt], i = this.getViewAddress(t[xt]), o = this.getViewAddress(e[xt]), a = me in n, c = he in n;
            c && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[xt]), u = s ? this.getViewAddress(s[xt]) : 0;
            this.updateShadows(r);
            const f = () => {
                this.updateShadowTargets(r), c && this.updatePointerTargets(r, n), this.flushStreams?.(), 
                this.endContext();
            };
            a && (n[me] = f);
            if (!(s ? this.runVariadicThunk(i, o, l, u, s.length) : this.runThunk(i, o, l))) throw f(), 
            new ZigError;
            if (a) {
                let t = null;
                try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (e[ce] && t && (t = t.string), n[we](t)) : e[ce] && (n[ce] = !0), 
                n[re] ?? n[se];
            }
            f();
            try {
                const {retval: t} = n;
                return e[ce] && t ? t.string : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    }), sn({
        init() {
            const t = {
                type: D.Int,
                bitSize: 8,
                byteSize: 1
            }, e = {
                type: D.Int,
                bitSize: 16,
                byteSize: 2
            }, n = {
                type: D.Int,
                bitSize: 32,
                byteSize: 4
            }, r = this.getAccessor("get", t), s = this.getAccessor("set", t), i = this.getAccessor("get", e), o = this.getAccessor("set", e), a = this.getAccessor("get", n), c = this.getAccessor("set", n);
            this.copiers = {
                0: Ye,
                1: function(t, e) {
                    s.call(t, 0, r.call(e, 0));
                },
                2: function(t, e) {
                    o.call(t, 0, i.call(e, 0, !0), !0);
                },
                4: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0);
                },
                8: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0), c.call(t, 4, a.call(e, 4, !0), !0);
                },
                16: function(t, e) {
                    c.call(t, 0, a.call(e, 0, !0), !0), c.call(t, 4, a.call(e, 4, !0), !0), c.call(t, 8, a.call(e, 8, !0), !0), 
                    c.call(t, 12, a.call(e, 12, !0), !0);
                },
                any: function(t, e) {
                    let n = 0, i = t.byteLength;
                    for (;n + 4 <= i; ) c.call(t, n, a.call(e, n, !0), !0), n += 4;
                    for (;n + 1 <= i; ) s.call(t, n, r.call(e, n)), n++;
                }
            }, this.resetters = {
                0: Ye,
                1: function(t, e) {
                    s.call(t, e, 0);
                },
                2: function(t, e) {
                    o.call(t, e, 0, !0);
                },
                4: function(t, e) {
                    c.call(t, e, 0, !0);
                },
                8: function(t, e) {
                    c.call(t, e + 0, 0, !0), c.call(t, e + 4, 0, !0);
                },
                16: function(t, e) {
                    c.call(t, e + 0, 0, !0), c.call(t, e + 4, 0, !0), c.call(t, e + 8, 0, !0), c.call(t, e + 12, 0, !0);
                },
                any: function(t, e, n) {
                    let r = e;
                    for (;r + 4 <= n; ) c.call(t, r, 0, !0), r += 4;
                    for (;r + 1 <= n; ) s.call(t, r, 0), r++;
                }
            };
        },
        defineCopier(t, e) {
            const n = this.getCopyFunction(t, e);
            return {
                value(t) {
                    const e = t[xt], r = this[xt];
                    n(r, e);
                }
            };
        },
        defineResetter(t, e) {
            const n = this.getResetFunction(e);
            return {
                value() {
                    const r = this[xt];
                    n(r, t, e);
                }
            };
        },
        getCopyFunction(t, e = !1) {
            return (e ? void 0 : this.copiers[t]) ?? this.copiers.any;
        },
        getResetFunction(t) {
            return this.resetters[t] ?? this.resetters.any;
        },
        imports: {
            moveExternBytes: {}
        }
    });
    class AsyncReader {
        bytes=null;
        promise=null;
        done=!1;
        readnb(t) {
            if (!this.bytes) throw this.promise || (this.promise = this.fetch(t).then((() => this.promise = null))), 
            new WouldBlock;
            return this.shift(t);
        }
        async read(t) {
            for (this.promise && await this.promise; (!this.bytes || this.bytes.length < t) && !this.done; ) await this.fetch(t - (this.bytes?.length ?? 0));
            return this.shift(t);
        }
        store(t) {
            if (t) {
                if (!(t instanceof Uint8Array)) if (t instanceof ArrayBuffer) t = new Uint8Array(t); else {
                    if (!(value.buffer instanceof ArrayBuffer)) return;
                    t = new Uint8Array(t.buffer, t.byteOffset, t.byteLength);
                }
                if (this.bytes) {
                    const e = this.bytes.length, n = t.length, r = new Uint8Array(e + n);
                    r.set(this.bytes), r.set(t, e), this.bytes = r;
                } else this.bytes = t;
            } else this.done = !0;
        }
        shift(t) {
            let e;
            return this.bytes && (this.bytes.length > t ? (e = this.bytes.subarray(0, t), this.bytes = this.bytes.subarray(t)) : (e = this.bytes, 
            this.bytes = null)), e ?? new Uint8Array(0);
        }
    }
    class WebStreamReader extends AsyncReader {
        onClose=null;
        constructor(t) {
            super(), this.reader = t, t.close = () => this.onClose?.();
        }
        async fetch() {
            const {value: t} = await this.reader.read();
            this.store(t);
        }
        destroy() {
            this.done || this.reader.cancel(), this.bytes = null;
        }
        valueOf() {
            return this.reader;
        }
    }
    class WebStreamReaderBYOB extends WebStreamReader {
        buffer=null;
        async fetch(t) {
            const e = new Uint8Array(t), {value: n} = await this.reader.read(e);
            this.store(n);
        }
    }
    class AsyncWriter {
        promise=null;
        writenb(t) {
            if (this.promise) throw new WouldBlock;
            this.promise = this.send(t).then((() => {
                this.promise = null;
            }));
        }
        async write(t) {
            this.promise && await this.promise, await this.send(t);
        }
    }
    class WebStreamWriter extends AsyncWriter {
        onClose=null;
        done=!1;
        constructor(t) {
            super(), this.writer = t, t.closed.catch(Ye).then((() => {
                this.done = !0, this.onClose?.();
            }));
        }
        async send(t) {
            await this.writer.write(t);
        }
        destroy() {
            this.done || this.writer.close();
        }
    }
    class BlobReader extends AsyncReader {
        pos=0n;
        onClose=null;
        constructor(t) {
            super(), this.blob = t, this.size = BigInt(t.size), t.close = () => this.onClose?.();
        }
        async fetch(t) {
            const e = await this.pread(t, this.pos);
            this.pos += BigInt(e.length), this.store(e.length > 0 ? e : null);
        }
        async pread(t, e) {
            const n = Number(e), r = this.blob.slice(n, n + t), s = new Response(r), i = await s.arrayBuffer();
            return new Uint8Array(i);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            return this.done = !1, this.pos = In(e, t, this.pos, this.size);
        }
        valueOf() {
            return this.blob;
        }
    }
    class Uint8ArrayReadWriter {
        pos=0n;
        onClose=null;
        constructor(t) {
            this.array = t, this.size = BigInt(t.length), t.close = () => this.onClose?.();
        }
        readnb(t) {
            return this.read(t);
        }
        read(t) {
            const e = this.pread(t, this.pos);
            return this.pos += BigInt(e.length), e;
        }
        writenb(t) {
            return this.write(t);
        }
        write(t) {
            this.pwrite(t, this.pos), this.pos += BigInt(t.length);
        }
        pread(t, e) {
            const n = Number(e), r = n + t;
            return this.array.subarray(n, r);
        }
        pwrite(t, e) {
            const n = Number(e);
            this.array.set(t, n);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            return this.pos = In(e, t, this.pos, this.size);
        }
        valueOf() {
            return this.array;
        }
    }
    class ArrayWriter {
        constructor(t) {
            this.array = t, this.closeCB = null, t.close = () => this.onClose?.();
        }
        writenb(t) {
            this.write(t);
        }
        write(t) {
            this.array.push(t);
        }
    }
    class NullStream {
        read() {
            return this.pread();
        }
        pread() {
            return new Uint8Array(0);
        }
        write() {}
        pwrite() {}
    }
    class MapDirectory {
        onClose=null;
        keys=null;
        cookie=0n;
        constructor(t) {
            this.map = t, t.close = () => this.onClose?.();
        }
        readdir() {
            const t = Number(this.cookie);
            let e;
            switch (t) {
              case 0:
              case 1:
                e = {
                    name: ".".repeat(t + 1),
                    type: "directory"
                };
                break;

              default:
                this.keys || (this.keys = [ ...this.map.keys() ]);
                const n = this.keys[t - 2];
                if (void 0 === n) return null;
                e = {
                    name: n,
                    ...this.map.get(n)
                };
            }
            return this.cookie++, e;
        }
        seek(t) {
            return this.cookie = t;
        }
        tell() {
            return this.cookie;
        }
        valueOf() {
            return this.map;
        }
    }
    function In(t, e, n, r) {
        let s = -1n;
        switch (t) {
          case 0:
            s = e;
            break;

          case 1:
            s = n + e;
            break;

          case 2:
            s = r + e;
        }
        if (!(s >= 0n && s <= r)) throw new InvalidArgument;
        return s;
    }
    function En(t, e) {
        return Oe(t, e, (t => t.address));
    }
    sn({
        convertDirectory(t) {
            if (t instanceof Map) return new MapDirectory(t);
            if (Pe(t, "readdir")) return t;
            throw new cn("map or object with directory interface", t);
        }
    }), sn({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: s, bitSize: i} = n;
            if ("set" === e) return i > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const s = Number(e);
                if (!isFinite(s)) throw new InvalidIntConversion(e);
                r.call(this, t, s, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & y && i > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, s) {
                        const i = r.call(this, n, s);
                        return e <= i && i <= t ? Number(i) : i;
                    };
                }
            }
            return r;
        }
    }), sn({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const s = e[xt];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: i, targets: o} = n;
                    let a, c = 0;
                    for (const t of o) {
                        const e = t[xt], n = e.byteOffset, r = t.constructor[Jt] ?? e[Jt];
                        (void 0 === c || r > c) && (c = r, a = n);
                    }
                    const l = i - e, u = this.allocateShadowMemory(l + c, 1), f = this.getViewAddress(u), h = ze(Ce(f, a - e), c), d = Ce(h, e - a);
                    for (const t of o) {
                        const n = t[xt], r = n.byteOffset;
                        if (r !== a) {
                            const s = t.constructor[Jt] ?? n[Jt];
                            if (Be(Ce(d, r - e), s)) throw new AlignmentConflict(s, c);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), y = new DataView(s.buffer, Number(e), l), m = this.registerMemory(d, l, 1, r, y, p);
                    t.shadowList.push(m), n.address = d;
                }
                return Ce(n.address, s.byteOffset - n.start);
            }
            {
                const n = e.constructor[Jt] ?? s[Jt], i = s.byteLength, o = this.allocateShadowMemory(i, n), a = this.getViewAddress(o), c = this.registerMemory(a, i, 1, r, s, o);
                return t.shadowList.push(c), a;
            }
        },
        updateShadows(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r} of t.shadowList) e(r, n);
        },
        updateShadowTargets(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r, writable: s} of t.shadowList) s && e(n, r);
        },
        registerMemory(t, e, n, r, s, i) {
            const o = En(this.memoryList, t);
            let a = this.memoryList[o - 1];
            return a?.address === t && a.len === e ? a.writable ||= r : (a = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: s,
                shadowDV: i
            }, this.memoryList.splice(o, 0, a)), a;
        },
        unregisterMemory(t, e) {
            const n = En(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            let s = n * (r ?? 0);
            const i = En(this.memoryList, e), o = this.memoryList[i - 1];
            let a;
            if (o?.address === e && o.len === s) a = o.targetDV; else if (o?.address <= e && Ce(e, s) <= Ce(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: i} = o;
                n && (s = i.byteLength - t), a = this.obtainView(i.buffer, i.byteOffset + t, s), 
                n && (a[Jt] = o.align);
            }
            if (a) {
                let {targetDV: e, shadowDV: n} = o;
                if (n && t && !t.shadowList.includes(o)) {
                    this.getCopyFunction()(e, n);
                }
            } else a = this.obtainZigView(e, s);
            return a;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[Mt], n = e?.address;
            n && -1 !== n && (e.address = -1, this.unregisterBuffer(Ce(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[Mt];
            if (e) return e.address;
            {
                const e = this.getBufferAddress(t.buffer);
                return Ce(e, t.byteOffset);
            }
        },
        obtainZigArray(t, e) {
            const n = this.obtainZigView(t, e, !1);
            return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        },
        ...{
            imports: {
                getBufferAddress: {},
                obtainExternBuffer: {}
            },
            exports: {
                getViewAddress: {}
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (function(t) {
                    return 2863311530 === t || -1431655766 === t;
                }(t) && (t = e > 0 ? 0 : $e), !t && e) return null;
                let r, s;
                if (n) {
                    const n = En(this.externBufferList, t), i = this.externBufferList[n - 1];
                    i?.address <= t && Ce(t, e) <= Ce(i.address, i.len) ? (r = i.buffer, s = Number(t - i.address)) : (r = e > 0 ? this.obtainExternBuffer(t, e, oe) : new ArrayBuffer(0), 
                    this.externBufferList.splice(n, 0, {
                        address: t,
                        len: e,
                        buffer: r
                    }), s = 0);
                } else r = e > 0 ? this.obtainExternBuffer(t, e, oe) : new ArrayBuffer(0), s = 0;
                return r[Mt] = {
                    address: t,
                    len: e
                }, this.obtainView(r, s, e);
            },
            unregisterBuffer(t) {
                const e = En(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const s = e[xt];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(s.buffer);
                        for (const e of n.targets) {
                            const r = e[xt].byteOffset, s = e.constructor[Jt], i = Ce(t, r);
                            if (Be(i, s)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return Ce(n.address, s.byteOffset);
                } else {
                    const t = e.constructor[Jt], n = this.getViewAddress(s);
                    if (!Be(n, t)) {
                        const e = s.byteLength;
                        return this.registerMemory(n, e, t, r, s), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), sn({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: {}
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const {async: r = !1} = n;
                    let s = this[e];
                    s && (r && (s = this.addPromiseHandling(s)), t[e] = s.bind(this));
                }
                return t;
            },
            addPromiseHandling(t) {
                const e = t.length - 1;
                return function(...n) {
                    const r = n[e], s = !!r;
                    n[e] = s;
                    const i = t.call(this, ...n);
                    return s ? (Re(i) ? i.then((t => this.finalizeAsyncCall(r, t))) : this.finalizeAsyncCall(r, i), 
                    et) : i;
                };
            },
            importFunctions(t) {
                for (const [e] of Object.entries(this.imports)) {
                    const n = t[e];
                    n && (Se(this, e, xe(n)), this.destructors.push((() => this[e] = Mn)));
                }
            }
        }
    });
    const Mn = () => {
        throw new Error("Module was abandoned");
    };
    sn({
        linkVariables(t) {
            const e = this.getCopyFunction();
            for (const {object: n, handle: r} of this.variables) {
                const s = n[xt], i = this.recreateAddress(r);
                let o = n[xt] = this.obtainZigView(i, s.byteLength);
                t && e(o, s), n.constructor[Zt]?.save?.(o, n), this.destructors.push((() => {
                    const t = n[xt] = this.allocateMemory(o.bytelength);
                    e(t, o);
                }));
                const a = t => {
                    const e = t[It];
                    if (e) {
                        const t = o.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[xt];
                            if (e.buffer === s.buffer) {
                                const r = t + e.byteOffset - s.byteOffset;
                                n[xt] = this.obtainView(o.buffer, r, e.byteLength), n.constructor[Zt]?.save?.(o, n), 
                                a(n);
                            }
                        }
                    }
                };
                a(n), n[he]?.((function() {
                    this[le]();
                }), tt.IgnoreInactive);
            }
        },
        imports: {
            recreateAddress: null
        }
    }), sn({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, s = [], i = function(t) {
                const e = this[$t];
                if (void 0 === n.get(e)) {
                    const t = e[It][0];
                    if (t) {
                        const o = {
                            target: t,
                            writable: !e.constructor.const
                        }, a = t[xt];
                        if (a[Mt]) n.set(e, null); else {
                            n.set(e, t);
                            const c = r.get(a.buffer);
                            if (c) {
                                const t = Array.isArray(c) ? c : [ c ], e = Oe(t, a.byteOffset, (t => t.target[xt].byteOffset));
                                t.splice(e, 0, o), Array.isArray(c) || (r.set(a.buffer, t), s.push(t));
                            } else r.set(a.buffer, o);
                            t[he]?.(i, 0);
                        }
                    }
                }
            }, o = tt.IgnoreRetval | tt.IgnoreInactive;
            e[he](i, o);
            const a = this.findTargetClusters(s), c = new Map;
            for (const t of a) for (const e of t.targets) c.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = c.get(r), s = n?.writable ?? !e.constructor.const;
                e[Nt] = this.getTargetAddress(t, r, n, s), Pt in e && (e[Pt] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, s = function(e) {
                const n = this[$t];
                if (!r.get(n)) {
                    r.set(n, !0);
                    const i = n[It][0], o = i && e & tt.IsImmutable ? i : n[le](t, !0, !(e & tt.IsInactive)), a = n.constructor.const ? tt.IsImmutable : 0;
                    a & tt.IsImmutable || i && !i[xt][Mt] && i[he]?.(s, a), o !== i && o && !o[xt][Mt] && o?.[he]?.(s, a);
                }
            }, i = n ? tt.IgnoreRetval : 0;
            e[he](s, i);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, s = 0, i = null;
                for (const {target: o, writable: a} of n) {
                    const n = o[xt], {byteOffset: c, byteLength: l} = n, u = c + l;
                    let f = !0;
                    t && (s > c ? (i ? i.writable ||= a : (i = {
                        targets: [ t ],
                        start: r,
                        end: s,
                        address: void 0,
                        misaligned: void 0,
                        writable: a
                    }, e.push(i)), i.targets.push(o), u > s ? i.end = u : f = !1) : i = null), f && (t = o, 
                    r = c, s = u);
                }
            }
            return e;
        }
    }), sn({
        convertReader(t) {
            if (t instanceof ReadableStreamDefaultReader) return new WebStreamReader(t);
            if (t instanceof ReadableStreamBYOBReader) return new WebStreamReaderBYOB(t);
            if (t instanceof Blob) return new BlobReader(t);
            if (t instanceof Uint8Array) return new Uint8ArrayReadWriter(t);
            if (null === t) return new NullStream;
            if (Pe(t, "read")) return t;
            throw new cn("ReadableStreamDefaultReader, ReadableStreamBYOBReader, Blob, Uint8Array, or object with reader interface", t);
        }
    }), sn({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === D.Int;
                    let s = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** s) : 0,
                            max: 2 ** s - 1
                        };
                    }
                    s = BigInt(s);
                    return {
                        min: r ? -(2n ** s) : 0n,
                        max: 2n ** s - 1n
                    };
                }(n);
                return function(s, i, o) {
                    if (i < t || i > e) throw new Overflow(n, i);
                    r.call(this, s, i, o);
                };
            }
            return r;
        }
    }), sn({
        init() {
            this.streamLocationMap = new Map([ [ bt, "" ] ]);
        },
        obtainStreamLocation(t, e, n) {
            let r = Me(this.obtainZigArray(e, n)).trim();
            r.endsWith("/") && (r = r.slice(0, -1));
            const s = r.trim().split("/"), i = [];
            for (const t of s) ".." === t ? i.pop() : "." !== t && "" != t && i.push(t);
            const [o] = this.getStream(t);
            return {
                parent: o.valueOf(),
                path: i.join("/")
            };
        },
        getStreamLocation(t) {
            return this.streamLocationMap.get(t);
        },
        setStreamLocation(t, e) {
            const n = this.streamLocationMap;
            e ? n.set(t, e) : n.delete(t);
        }
    }), sn({
        init() {
            const t = {
                cookie: 0n,
                readdir() {
                    const t = Number(this.cookie);
                    let e = null;
                    switch (t) {
                      case 0:
                      case 1:
                        e = {
                            name: ".".repeat(t + 1),
                            type: "directory"
                        };
                    }
                    return e;
                },
                seek(t) {
                    return this.cookie = t;
                },
                tell() {
                    return this.cookie;
                },
                valueOf: () => null
            }, e = gt.fd_seek | gt.fd_fdstat_set_flags | gt.fd_tell | gt.path_create_directory | gt.path_create_file | gt.path_open | gt.fd_readdir | gt.path_filestat_get | gt.path_filestat_set_size | gt.path_filestat_set_times | gt.fd_filestat_get | gt.fd_filestat_set_times | gt.path_remove_directory | gt.path_unlink_file, n = e | gt.fd_datasync | gt.fd_read | gt.fd_seek | gt.fd_sync | gt.fd_write | gt.fd_advise | gt.fd_allocate | gt.fd_filestat_get | gt.fd_filestat_set_size;
            this.streamMap = new Map([ [ yt, [ this.createLogWriter("stdout"), [ gt.fd_write, 0 ], 0 ] ], [ mt, [ this.createLogWriter("stderr"), [ gt.fd_write, 0 ], 0 ] ], [ bt, [ t, [ e, n ], 0 ] ] ]), 
            this.flushRequestMap = new Map, this.nextStreamHandle = wt;
        },
        getStream(t) {
            const e = this.streamMap.get(t);
            if (!e) throw new InvalidFileDescriptor;
            return e;
        },
        createStreamHandle(t, e, n = 0) {
            const r = this.nextStreamHandle++;
            return this.streamMap.set(r, [ t, e, n ]), t.onClose = () => this.destroyStreamHandle(r), 
            4 === this.streamMap.size && this.setSyscallTrap(!0), r;
        },
        destroyStreamHandle(t) {
            const e = this.streamMap.get(t);
            if (e) {
                const [n] = e;
                n?.destroy?.(), this.streamMap.delete(t), 3 === this.streamMap.size && this.setSyscallTrap(!1);
            }
        },
        redirectStream(t, e) {
            const n = this.streamMap, r = 3 === t ? bt : t, s = n.get(r);
            if (void 0 !== e) {
                let s, i;
                if (0 === t) s = this.convertReader(e), i = gt.fd_read; else if (1 === t || 2 === t) s = this.convertWriter(e), 
                i = gt.fd_write; else {
                    if (3 !== t) throw new Error(`Expecting 0, 1, 2, or 3, received ${r}`);
                    s = this.convertDirectory(e), i = gt.fd_readdir;
                }
                n.set(r, [ s, i, 0 ]);
            } else n.delete(r);
            return s;
        },
        createLogWriter(t) {
            const e = this;
            return {
                pending: [],
                write(t) {
                    const n = t.lastIndexOf(10);
                    if (-1 === n) this.pending.push(t); else {
                        const e = t.subarray(0, n), r = t.subarray(n + 1);
                        this.dispatch([ ...this.pending, e ]), this.pending.splice(0), r.length > 0 && this.pending.push(r);
                    }
                    e.scheduleFlush(this, this.pending.length > 0, 250);
                },
                dispatch(n) {
                    const r = Me(n);
                    e.triggerEvent("log", {
                        source: t,
                        message: r
                    });
                },
                flush() {
                    this.pending.length > 0 && (this.dispatch(this.pending), this.pending.splice(0));
                }
            };
        },
        scheduleFlush(t, e, n) {
            const r = this.flushRequestMap, s = r.get(t);
            s && (clearTimeout(s), r.delete(t)), e && r.set(t, setTimeout((() => {
                t.flush(), r.delete(t);
            }), n));
        },
        flushStreams() {
            const t = this.flushRequestMap;
            if (t.size > 0) {
                for (const [e, n] of t) e.flush(), clearTimeout(n);
                t.clear();
            }
        },
        imports: {
            setRedirectionMask: {},
            setSyscallTrap: {}
        }
    }), sn({}), sn({
        convertWriter(t) {
            if (t instanceof WritableStreamDefaultWriter) return new WebStreamWriter(t);
            if (Array.isArray(t)) return new ArrayWriter(t);
            if (t instanceof Uint8Array) return new Uint8ArrayReadWriter(t);
            if (null === t) return new NullStream;
            if ("function" == typeof t?.write) return t;
            throw new cn("WritableStreamDefaultWriter, array, null, or object with writer interface", t);
        }
    }), sn({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), s = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: s
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    }), sn({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = _e(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let s = this.allocatorVtable;
            if (!s) {
                const {noResize: t, noRemap: e} = r;
                s = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (s.remap = e), this.destructors.push((() => this.freeFunction(s.alloc))), 
                this.destructors.push((() => this.freeFunction(s.free)));
            }
            let i = $e;
            if (n) {
                const e = [];
                i = this.nextAllocatorContextId++, this.allocatorContextMap.set(i, e), t[ue] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(i);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(i, 0),
                vtable: s
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][xt]), s = r != $e ? this.allocatorContextMap.get(r) : null, i = 1 << n, o = this.allocateJSMemory(e, i);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, i, !0, o), Se(o, Mt, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), s?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][xt], s = this.getViewAddress(r), i = r.byteLength;
            this.unregisterMemory(s, i);
        }
    }), sn({
        createDirectory(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return t;
            const e = this.convertDirectory(t), n = gt.fd_readdir | gt.fd_seek | gt.fd_tell | gt.fd_filestat_get | gt.fd_filestat_set_times;
            return {
                fd: this.createStreamHandle(e, n)
            };
        }
    }), sn({
        createFile(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return {
                handle: t.fd
            };
            if ("object" == typeof t && "number" == typeof t?.handle) return t;
            let e, n = gt.fd_filestat_get | gt.fd_seek | gt.fd_tell | gt.fd_advise | gt.fd_filestat_set_times;
            try {
                e = this.convertReader(t), n |= gt.fd_read;
            } catch (r) {
                try {
                    e = this.convertWriter(t), n |= gt.fd_write | gt.fd_sync | gt.fd_datasync | gt.fd_allocate | gt.fd_filestat_set_size;
                } catch {
                    throw r;
                }
            }
            return {
                handle: this.createStreamHandle(e, n)
            };
        }
    }), sn({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = _e(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: s}} = t;
            if (n) {
                if ("function" != typeof n) throw new cn("function", n);
            } else {
                const t = e[se] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const i = this.nextGeneratorContextId++, o = this.obtainZigView(i, 0, !1);
            this.generatorContextMap.set(i, {
                func: n,
                args: e
            });
            let a = this.generatorCallbackMap.get(r);
            a || (a = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][xt], r = this.getViewAddress(n), s = this.generatorContextMap.get(r);
                if (s) {
                    const {func: t, args: n} = s, i = e instanceof Error;
                    !i && n[ce] && e && (e = e.string);
                    const o = !1 === await (2 === t.length ? t(i ? e : null, i ? null : e) : t(e)) || i || null === e;
                    if (n[ue]?.(o), !o) return !0;
                    n[me](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, a), this.destructors.push((() => this.freeFunction(a)))), 
            e[we] = t => a(o, t);
            const c = {
                ptr: o,
                callback: a
            }, l = s.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                c.allocator = this.createJsAllocator(e, t, !0);
            }
            return c;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, s = r["*"];
            return t[ve] = e => s.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[ve](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[ve](t)) break;
                    e[ve](null);
                } catch (t) {
                    if (!e.constructor[ne]) throw t;
                    e[ve](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    sn({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = _e(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new cn("function", n);
            } else e[re] = new Promise(((t, r) => {
                n = n => {
                    n?.[xt]?.[Mt] && (n = new n.constructor(n)), n instanceof Error ? r(n) : (e[ce] && n && (n = n.string), 
                    t(n));
                };
            }));
            const s = this.nextPromiseContextId++, i = this.obtainZigView(s, 0, !1);
            this.promiseContextMap.set(s, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][xt], r = this.getViewAddress(n), s = this.promiseContextMap.get(r);
                if (s) {
                    const {func: t, args: n} = s;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[me](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[we] = t => o(i, t), {
                ptr: i,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, s = r["*"];
            return t[we] = e => s.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[we](n);
            };
        }
    }), sn({
        init() {
            this.readerCallback = null, this.readerMap = new Map, this.nextReaderId = _e(4096), 
            this.readerProgressMap = new Map;
        },
        createReader(t) {
            if ("object" == typeof t && t && "context" in t && "readFn" in t) return t;
            const e = this.convertReader(t), n = this.nextReaderId++, r = this.obtainZigView(n, 0, !1), s = e.onClose = () => {
                this.readerMap.delete(n), this.readerProgressMap.delete(n);
            };
            this.readerMap.set(n, e), this.readerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let i = this.readerCallback;
            if (!i) {
                const t = t => {
                    throw console.error(t), s(), t;
                };
                i = this.readerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][xt]), s = this.readerMap.get(r);
                    if (!s) return 0;
                    try {
                        const e = n["*"][xt].byteLength, i = t => {
                            const e = t.length, r = this.getViewAddress(n["*"][xt]);
                            return this.moveExternBytes(t, r, !0), e;
                        };
                        hn(this.readerProgressMap.get(r), "read", e);
                        const o = s.read(e);
                        return Re(o) ? o.then(i).catch(t) : i(o);
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(i)));
            }
            return {
                context: r,
                readFn: i
            };
        }
    }), sn({
        init() {
            this.writerCallback = null, this.writerMap = new Map, this.nextWriterContextId = _e(8192), 
            this.writerProgressMap = new Map;
        },
        createWriter(t) {
            if ("object" == typeof t && t && "context" in t && "writeFn" in t) return t;
            const e = this.convertWriter(t), n = this.nextWriterContextId++, r = this.obtainZigView(n, 0, !1), s = e.onClose = () => {
                this.writerMap.delete(n), this.writerProgressMap.delete(n);
            };
            this.writerMap.set(n, e), this.writerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let i = this.writerCallback;
            if (!i) {
                const t = t => {
                    throw console.error(t), s(), t;
                };
                i = this.writerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][xt]), s = this.writerMap.get(r);
                    if (!s) return 0;
                    try {
                        const e = n["*"][xt];
                        hn(this.writerProgressMap.get(r), "write", e.byteLength);
                        const i = e.byteLength, o = new Uint8Array(e.buffer, e.byteOffset, i), a = new Uint8Array(o), c = s.write(a);
                        return Re(c) ? c.then((() => i), t) : i;
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(i)));
            }
            return {
                context: r,
                writeFn: i
            };
        }
    }), sn({
        environGet(t, e) {
            let n = 0, r = 0;
            for (const t of this.envVariables) n += t.length, r++;
            const s = qe(4 * r), i = new Uint8Array(n);
            let o = 0, a = 0, c = this.littleEndian;
            for (const t of this.envVariables) s.setUint32(o, e + a, c), o += 4, i.set(t, a), 
            a += t.length;
            return this.moveExternBytes(s, t, !0), this.moveExternBytes(i, e, !0), et;
        },
        exports: {
            environGet: {
                async: !0
            }
        }
    }), sn({
        copyUsize(t, e) {
            this.copyUint32(t, e);
        },
        copyUint64(t, e) {
            const n = qe(8);
            n.setBigUint64(0, BigInt(e), this.littleEndian), this.moveExternBytes(n, t, !0);
        },
        copyUint32(t, e) {
            const n = qe(4);
            n.setUint32(0, e, this.littleEndian), this.moveExternBytes(n, t, !0);
        }
    }), sn({
        environSizesGet(t, e) {
            const n = this.listenerMap.get("env"), r = n?.() ?? {};
            if ("object" != typeof r) throw new TypeMismatch("object", r);
            const s = this.envVariables = [];
            for (const [t, e] of Object.entries(r)) {
                const n = Ue(`${t}=${e}\0`);
                s.push(n);
            }
            let i = 0;
            for (const t of s) i += t.length;
            return this.copyUsize(t, s.length), this.copyUsize(e, i), et;
        },
        exports: {
            environSizesGet: {
                async: !0
            }
        }
    });
    const Un = {
        normal: 0,
        sequential: 1,
        random: 2,
        willNeed: 3,
        dontNeed: 4,
        noReuse: 5
    };
    sn({
        fdAdvise(t, e, n, r, s) {
            return dn(s, st, (() => {
                const [s] = this.getStream(t);
                if (Pe(s, "advise")) {
                    const t = Object.keys(Un);
                    return s.advise?.(e, n, t[r]);
                }
            }));
        },
        exports: {
            fdAdvise: {
                async: !0
            }
        }
    }), sn({
        fdAllocate(t, e, n, r) {
            return dn(r, st, (() => {
                const [r] = this.getStream(t);
                return pn(r, "allocate"), r.allocate(e, n);
            }));
        },
        exports: {
            fdAllocate: {
                async: !0
            }
        }
    }), sn({
        fdClose(t, e) {
            return dn(e, st, (() => (this.setStreamLocation?.(t), this.destroyStreamHandle(t))));
        },
        exports: {
            fdClose: {
                async: !0
            }
        }
    }), sn({
        fdDatasync(t, e) {
            return dn(e, st, (() => {
                const [e] = this.getStream(t);
                if (Pe(e, "datasync")) return e.datasync?.();
            }));
        },
        exports: {
            fdDatasync: {
                async: !0
            }
        }
    }), sn({
        fdFdstatGet(t, e, n) {
            return dn(n, st, (() => {
                const [n, r, s] = this.getStream(t);
                let i;
                if (n.type) {
                    if (i = We(n.type, ft), void 0 === i) throw new InvalidEnumValue(ft, n.type);
                } else i = r & (gt.fd_read | gt.fd_write) ? ft.file : ft.directory;
                const o = qe(24);
                o.setUint8(0, i), o.setUint16(2, s, !0), o.setBigUint64(8, BigInt(r[0]), !0), o.setBigUint64(16, BigInt(r[1]), !0), 
                this.moveExternBytes(o, e, !0);
            }));
        },
        exports: {
            fdFdstatGet: {
                async: !0
            }
        }
    }), sn({
        fdFdstatSetFlags(t, e, n) {
            const r = pt.append | pt.nonblock;
            return dn(n, st, (() => {
                const n = this.getStream(t), [s, i, o] = n;
                e & pt.nonblock && (i & gt.fd_read && pn(s, "readnb"), i & gt.fd_write && pn(s, "writenb")), 
                n[2] = o & ~r | e & r;
            }));
        },
        exports: {
            fdFdstatSetFlags: {
                async: !0
            }
        }
    }), sn({
        fdFdstatSetRights(t, e, n) {
            return dn(n, st, (() => {
                const n = this.getStream(t), [r, s] = n;
                if (e & ~s) throw new InvalidFileDescriptor;
                s & gt.fd_write && pn(r, "write"), s & gt.fd_read && pn(r, "read"), s & gt.fd_readdir && pn(r, "readdir"), 
                n[1] = s;
            }));
        },
        exports: {
            fdFdstatSetRights: {
                async: !0
            }
        }
    }), sn({
        copyStat(t, e) {
            if (!1 === e) return ut;
            if ("object" != typeof e || !e) throw new cn("object or false", e);
            let n = We(e.type, ft);
            if (void 0 === n) {
                if (e.type) throw new InvalidEnumValue(ft, e.type);
                n = ft.unknown;
            }
            const r = this.littleEndian, s = qe(64);
            s.setBigUint64(0, 0n, r), s.setBigUint64(8, 0n, r), s.setUint8(16, n), s.setBigUint64(24, 1n, r), 
            s.setBigUint64(32, BigInt(e.size ?? 0), r), s.setBigUint64(40, BigInt(e.atime ?? 0), r), 
            s.setBigUint64(48, BigInt(e.mtime ?? 0), r), s.setBigUint64(56, BigInt(e.ctime ?? 0), r), 
            this.moveExternBytes(s, t, r);
        },
        inferStat(t) {
            if (t) return {
                size: t.size,
                type: Pe(t, "readdir") ? "directory" : "file"
            };
        }
    }), sn({
        fdFilestatGet(t, e, n) {
            return dn(n, st, (() => {
                const [e] = this.getStream(t);
                if (this.hasListener("stat")) {
                    const n = e.valueOf(), r = this.getStreamLocation?.(t);
                    return this.triggerEvent("stat", {
                        ...r,
                        target: n,
                        flags: {}
                    }, ut);
                }
                return this.inferStat(e);
            }), (t => this.copyStat(e, t)));
        },
        exports: {
            fdFilestatGet: {
                async: !0
            }
        }
    }), sn({
        fdFilestatSetTimes(t, e, n, r, s) {
            return dn(s, st, (() => {
                const [s] = this.getStream(t), i = s.valueOf(), o = this.getStreamLocation?.(t), a = nn(e, n, r);
                return this.triggerEvent("set_times", {
                    ...o,
                    target: i,
                    times: a,
                    flags: {}
                }, st);
            }), (t => yn(t, st)));
        },
        exports: {
            fdFilestatSetTimes: {
                async: !0
            }
        }
    }), sn({
        fdPread(t, e, n, r, s, i) {
            const o = this.littleEndian;
            let a, c, l, u, f, h = 0, d = 0;
            const g = () => dn(i, lt, (() => (a || ([c, l] = this.getStream(t), gn(l, gt.fd_read), 
            a = qe(8 * n), this.moveExternBytes(a, e, !1)), f = a.getUint32(8 * h + 4, o), c.pread(f, r))), (t => {
                u = a.getUint32(8 * h, o), this.moveExternBytes(t, u, !0);
                const e = t.length;
                if (d += e, ++h < n && e === f) return r += e, g();
                this.copyUsize(s, d);
            }));
            return g();
        },
        ...{
            exports: {
                fdPread: {
                    async: !0
                },
                fdPread1: {
                    async: !0
                }
            },
            fdPread1(t, e, n, r, s, i) {
                return dn(i, lt, (() => {
                    const [e, s] = this.getStream(t);
                    return gn(s, gt.fd_read), e.pread(n, r);
                }), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUsize(s, t.length);
                }));
            }
        }
    }), sn({
        fdPwrite(t, e, n, r, s, i) {
            const o = this.littleEndian;
            let a, c, l, u, f, h = 0, d = 0;
            const g = () => dn(i, lt, (() => {
                a || ([c, l] = this.getStream(t, "write"), gn(l, gt.fd_write), a = qe(8 * n), this.moveExternBytes(a, e, !1)), 
                u = a.getUint32(8 * h, o), f = a.getUint32(8 * h + 4, o);
                const s = new Uint8Array(f), i = r;
                return this.moveExternBytes(s, u, !1), d += f, r += f, c.pwrite(s, i);
            }), (() => {
                if (++h < n) return g();
                this.copyUsize(s, d);
            }));
            return g();
        },
        ...{
            exports: {
                fdPwrite: {
                    async: !0
                },
                fdPwrite1: {
                    async: !0
                }
            },
            fdPwrite1(t, e, n, r, s, i) {
                return dn(i, lt, (() => {
                    const [s, i] = this.getStream(t);
                    gn(i, gt.fd_write);
                    const o = new Uint8Array(n);
                    return this.moveExternBytes(o, e, !1), s.pwrite(o, r);
                }), (() => this.copyUsize(s, n)));
            }
        }
    }), sn({
        fdRead(t, e, n, r, s) {
            const i = this.littleEndian;
            let o, a, c, l, u, f, h, d = 0;
            const g = () => dn(s, lt, (() => (o || ([a, l, c] = this.getStream(t), gn(l, gt.fd_read), 
            u = c & pt.nonblock ? a.readnb : a.read, o = qe(8 * n), this.moveExternBytes(o, e, !1)), 
            h = o.getUint32(8 * d + 4, i), u.call(a, h))), (t => {
                f = o.getUint32(8 * d, i), this.moveExternBytes(t, f, !0);
                const e = t.length;
                if (++d < n && e === h) return g();
                this.copyUsize(r, e);
            }));
            return g();
        },
        ...{
            exports: {
                fdRead: {
                    async: !0
                },
                fdRead1: {
                    async: !0
                }
            },
            fdRead1(t, e, n, r, s) {
                return dn(s, lt, (() => {
                    const [e, r, s] = this.getStream(t);
                    gn(r, gt.fd_read);
                    return (s & pt.nonblock ? e.readnb : e.read).call(e, n);
                }), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUsize(r, t.length);
                }));
            }
        }
    }), sn({
        fdReaddir(t, e, n, r, s, i) {
            return n < 24 ? ct : dn(i, st, (() => {
                const [e] = this.getStream(t);
                0n === r && (r = e.tell());
                const n = e.readdir();
                return Re(n) ? n.then((t => [ t ])) : [ n, e ];
            }), (([t, i]) => {
                const o = qe(n);
                let a = n, c = 0;
                for (;t; ) {
                    const {name: e, type: n = "unknown", ino: s = 0} = t, l = Ue(e), u = We(n, ft);
                    if (void 0 === u) throw new InvalidEnumValue(ft, n);
                    if (a < 24 + l.length) {
                        i.seek(r);
                        break;
                    }
                    o.setBigUint64(c, ++r, !0), o.setBigUint64(c + 8, BigInt(s), !0), o.setUint32(c + 16, l.length, !0), 
                    o.setUint8(c + 20, u), c += 24, a -= 24;
                    for (let t = 0; t < l.length; t++, c++) o.setUint8(c, l[t]);
                    a -= l.length, t = a > 40 && i ? i.readdir() : null;
                }
                this.moveExternBytes(o, e, !0), this.copyUsize(s, c);
            }));
        },
        exports: {
            fdReaddir: {
                async: !0
            }
        }
    }), sn({
        fdSeek(t, e, n, r, s) {
            return dn(s, st, (() => {
                const [r] = this.getStream(t);
                return pn(r, "seek"), r.seek(e, n);
            }), (t => {
                const e = qe(8);
                e.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(e, r, !0);
            }));
        },
        exports: {
            fdSeek: {
                async: !0
            }
        }
    }), sn({
        fdSync(t, e) {
            return dn(e, st, (() => {
                const [e] = this.getStream(t);
                if (Pe(e, "sync")) return e.sync?.();
            }));
        },
        exports: {
            fdSync: {
                async: !0
            }
        }
    }), sn({
        fdTell(t, e, n) {
            return dn(n, st, (() => {
                const [e] = this.getStream(t);
                return pn(e, "tell"), e.tell();
            }), (t => {
                const n = qe(8);
                n.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(n, e, !0);
            }));
        },
        exports: {
            fdTell: {
                async: !0
            }
        }
    }), sn({
        fdWrite(t, e, n, r, s) {
            const i = this.littleEndian;
            let o, a, c, l, u, f = 0, h = 0;
            const d = () => dn(s, lt, (() => {
                o || ([a, l, c] = this.getStream(t, "write"), gn(l, gt.fd_write), u = c & pt.nonblock ? a.writenb : a.write, 
                o = qe(8 * n), this.moveExternBytes(o, e, !1));
                const r = o.getUint32(8 * f, i), s = o.getUint32(8 * f + 4, i), d = new Uint8Array(s);
                return this.moveExternBytes(d, r, !1), h += s, u.call(a, d);
            }), (() => {
                if (++f < n) return d();
                this.copyUsize(r, h);
            }));
            return d();
        },
        ...{
            exports: {
                fdWrite: {
                    async: !0
                },
                fdWrite1: {
                    async: !0
                }
            },
            fdWrite1(t, e, n, r, s) {
                return dn(s, lt, (() => {
                    const [r, s, i] = this.getStream(t);
                    gn(s, gt.fd_write);
                    const o = i & pt.nonblock ? r.writenb : r.write, a = new Uint8Array(n);
                    return this.moveExternBytes(a, e, !1), o.call(r, a);
                }), (() => this.copyUsize(r, n)));
            }
        }
    }), sn({
        pathCreateDirectory(t, e, n, r) {
            return dn(r, ut, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("mkdir", r, ut);
            }), (t => t instanceof Map ? ot : yn(t, ut)));
        },
        exports: {
            pathCreateDirectory: {
                async: !0
            }
        }
    }), sn({
        pathFilestatGet(t, e, n, r, s, i) {
            let o = !1;
            return dn(i, ut, (() => {
                const s = this.obtainStreamLocation(t, n, r), i = {
                    ...De(e, dt),
                    dryrun: !0
                };
                return this.hasListener("stat") ? this.triggerEvent("stat", {
                    ...s,
                    flags: i
                }, ut) : (o = !0, this.triggerEvent("open", {
                    ...s,
                    rights: {},
                    flags: i
                }, ut));
            }), (t => {
                let e;
                if (o) {
                    let n;
                    try {
                        n = this.convertReader(t);
                    } catch {
                        try {
                            n = this.convertWriter(t);
                        } catch {
                            n = this.convertDirectory(t);
                        }
                    }
                    e = this.inferStat(n);
                } else e = t;
                return this.copyStat(s, e);
            }));
        },
        exports: {
            pathFilestatGet: {
                async: !0
            }
        }
    }), sn({
        pathFilestatSetTimes(t, e, n, r, s, i, o, a) {
            return dn(a, ut, (() => {
                const a = this.obtainStreamLocation(t, n, r), c = nn(s, i, o), l = De(e, dt);
                return this.triggerEvent("set_times", {
                    ...a,
                    times: c,
                    flags: l
                }, ut);
            }), (t => yn(t, ut)));
        },
        exports: {
            pathFilestatSetTimes: {
                async: !0
            }
        }
    });
    const kn = {
        read: gt.fd_read,
        write: gt.fd_write,
        readdir: gt.fd_readdir
    };
    function Vn() {
        const t = Bn.toString(), e = t.indexOf("{") + 1, n = t.lastIndexOf("}");
        return t.slice(e, n);
    }
    let On;
    function Bn() {
        let t, e;
        function n({executable: n, memory: s, options: i, tid: o, arg: a}) {
            const c = WebAssembly, l = {
                memory: s
            }, u = {}, f = {}, h = {
                env: l,
                wasi: u,
                wasi_snapshot_preview1: f
            };
            for (const {module: t, name: e, kind: s} of c.Module.imports(n)) if ("function" === s) {
                const n = r(t, e);
                "env" === t ? l[e] = n : "wasi_snapshot_preview1" === t ? f[e] = n : "wasi" === t && (u[e] = n);
            }
            const {tableInitial: d} = i;
            l.__indirect_function_table = new c.Table({
                initial: d,
                element: "anyfunc"
            });
            const {exports: g} = new c.Instance(n, h), {wasi_thread_start: p} = g;
            p(o, a), t({
                type: "exit"
            }), e();
        }
        function r(e, n) {
            const r = new Int32Array(new SharedArrayBuffer(8));
            return function(...s) {
                return r[0] = 0, t({
                    type: "call",
                    module: e,
                    name: n,
                    args: s,
                    array: r
                }), Atomics.wait(r, 0, 0), r[1];
            };
        }
        "object" == typeof self || "node" !== process.env.COMPAT ? (self.onmessage = t => n(t.data), 
        t = t => self.postMessage(t), e = () => self.close()) : "node" === process.env.COMPAT && import("worker_threads").then((({parentPort: r, workerData: s}) => {
            t = t => r.postMessage(t), e = () => process.exit(), n(s);
        }));
    }
    function zn(t, n) {
        const {byteSize: r, type: s} = n;
        if (!(s === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function $n(t) {
        throw new BufferExpected(t);
    }
    sn({
        pathOpen(t, e, n, r, s, i, o, a, c, l) {
            const u = [ Number(i), Number(o) ];
            u[0] & gt.fd_read | gt.fd_write | gt.fd_readdir || (u[0] |= gt.fd_read);
            const f = De(u[0], kn), h = {
                ...De(e, dt),
                ...De(s, ht),
                ...De(a, pt)
            };
            let d;
            return dn(l, ut, (() => (d = this.obtainStreamLocation(t, n, r), this.triggerEvent("open", {
                ...d,
                rights: f,
                flags: h
            }, ut))), (t => {
                if (!1 === t) return ut;
                let e;
                f.read ? e = this.convertReader(t) : f.write ? e = this.convertWriter(t) : f.readdir && (e = this.convertDirectory(t));
                const n = this.createStreamHandle(e, u, a);
                this.setStreamLocation?.(n, d), this.copyUint32(c, n);
            }));
        },
        exports: {
            pathOpen: {
                async: !0
            }
        }
    }), sn({
        pathRemoveDirectory(t, e, n, r) {
            return dn(r, ut, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("rmdir", r, ut);
            }), (t => yn(t, ut)));
        },
        exports: {
            pathRemoveDirectory: {
                async: !0
            }
        }
    }), sn({
        pathUnlinkFile(t, e, n, r) {
            return dn(r, ut, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("unlink", r, ut);
            }), (t => yn(t, ut)));
        },
        exports: {
            pathUnlinkFile: {
                async: !0
            }
        }
    }), sn({
        init() {
            this.nextThreadId = 1, this.workers = [];
        },
        getThreadHandler(t) {
            if ("thread-spawn" === t) return "object" != typeof window || window.crossOriginIsolated || console.warn("%cHTML document is not cross-origin isolated %c\n\nWebAssembly multithreading in the browser is only possibly when %cwindow.crossOriginIsolated%c = true. Visit https://developer.mozilla.org/en-US/docs/Web/API/Window/crossOriginIsolated for information on how to enable it.", "color: red;font-size: 200%;font-weight:bold", "", "background-color: lightgrey;font-weight:bold", ""), 
            this.spawnThread.bind(this);
        },
        spawnThread(t) {
            const e = this.nextThreadId;
            this.nextThreadId++;
            const {executable: n, memory: r, options: s} = this, i = {
                executable: n,
                memory: r,
                options: s,
                tid: e,
                arg: t
            }, o = (t, e) => {
                if ("call" === e.type) {
                    const {module: t, name: n, args: r, array: s} = e, i = this.exportedModules[t]?.[n], o = i?.(...r, !0), a = t => {
                        s && (s[1] = 0 | t, s[0] = 1, Atomics.notify(s, 0, 1));
                    };
                    Re(o) ? o.then(a) : a(o);
                } else if ("exit" === e.type) {
                    const e = this.workers.indexOf(t);
                    -1 !== e && (t.detach(), this.workers.splice(e, 1));
                }
            }, a = "message";
            if ("function" == typeof Worker || "node" !== process.env.COMPAT) {
                const t = function() {
                    if (!On) {
                        const t = Vn();
                        On = URL.createObjectURL(new Blob([ t ], {
                            type: "text/javascript"
                        }));
                    }
                    return On;
                }(), e = new Worker(t, {
                    name: "zig"
                }), n = t => o(e, t.data);
                e.addEventListener(a, n), e.detach = () => e.removeEventListener(a, n), e.postMessage(i), 
                this.workers.push(e);
            } else "node" === process.env.COMPAT && import("worker_threads").then((({Worker: t}) => {
                const e = new t(Vn(), {
                    workerData: i,
                    eval: !0
                }), n = t => o(e, t);
                e.on(a, n), e.detach = () => e.off(a, n), this.workers.push(e);
            }));
            return e;
        }
    }), sn({
        init() {
            this.comptime = !1, this.slots = {}, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.libc = !1;
        },
        createView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.moveExternBytes(n, t, !1), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[Mt].handle = r, n;
            }
        },
        createInstance(t, e, n) {
            const {constructor: r, flags: s} = t, i = r.call(Yt, e);
            return s & g && this.updatePointerTargets(null, i), n && Object.assign(i[It], n), 
            e[Mt] || this.makeReadOnly?.(i), i;
        },
        createTemplate: (t, e) => ({
            [xt]: t,
            [It]: e
        }),
        appendList(t, e) {
            t.push(e);
        },
        getSlotValue(t, e) {
            return t || (t = this.slots), t[e];
        },
        setSlotValue(t, e, n) {
            t || (t = this.slots), t[e] = n;
        },
        beginStructure(t) {
            this.defineStructure(t);
        },
        finishStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & X), this.runtimeSafety = !!(t & K), this.libc = !!(t & Q);
            const e = this.getFactoryThunk(), n = {
                [xt]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                if (n & g && r && r[xt]) {
                    const t = Object.create(e.prototype);
                    t[xt] = r[xt], t[It] = r[It], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, libc: r} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    libc: r
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of je(this.structures, It)) {
                const n = e[xt]?.[Mt];
                if (n) {
                    const {address: r, len: s, handle: i} = n, o = e[xt] = this.createView(r, s, !0, 0);
                    i && (o.handle = i), t.push({
                        address: r,
                        len: s,
                        owner: e,
                        replaced: !1,
                        handle: i
                    });
                }
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && Ce(n.address, n.len) <= Ce(e.address, e.len)) {
                const t = e.owner[xt], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[xt] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = je(this.structures, It);
            for (const t of e) t[xt]?.[Mt] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${f[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, flags: n = 0} = t;
            switch (e.type) {
              case D.Bool:
                return "bool";

              case D.Int:
                return n & y ? "isize" : `i${e.bitSize}`;

              case D.Uint:
                return n & y ? "usize" : `u${e.bitSize}`;

              case D.Float:
                return `f${e.bitSize}`;

              case D.Void:
                return "void";

              case D.Literal:
                return "enum_literal";

              case D.Null:
                return "null";

              case D.Undefined:
                return "undefined";

              case D.Type:
                return "type";

              case D.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & S[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & F ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let s = "*", i = n.structure.name;
            if (n.structure.type === e.Slice && (i = i.slice(3)), r & k && (s = r & U ? "[]" : r & V ? "[*c]" : "[*]"), 
            !(r & V)) {
                const t = n.structure.constructor?.[_t];
                t && (s = s.slice(0, -1) + `:${t.value}` + s.slice(-1));
            }
            return r & O && (s = `${s}const `), s + i;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & T ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), s = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${s})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), s = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${s})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t, n = e.structure.name;
            return n ? n.slice(4, -1) : "fn ()";
        },
        exports: {
            createView: {},
            createInstance: {},
            createTemplate: {},
            appendList: {},
            getSlotValue: {},
            setSlotValue: {},
            beginStructure: {},
            finishStructure: {}
        },
        imports: {
            getFactoryThunk: {},
            getModuleAttributes: {}
        }
    }), sn({
        init() {
            this.viewMap = new WeakMap, this.needFallback = void 0;
        },
        extractView(t, n, r = $n) {
            const {type: s, byteSize: i, constructor: o} = t;
            let a;
            const c = n?.[Symbol.toStringTag];
            if (c && ("DataView" === c ? a = this.registerView(n) : "ArrayBuffer" === c ? a = this.obtainView(n, 0, n.byteLength) : (c && c === o[ee]?.name || "Uint8ClampedArray" === c && o[ee] === Uint8Array || "Uint8Array" === c && n instanceof Buffer) && (a = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !a) {
                const r = n?.[xt];
                if (r) {
                    const {constructor: o, instance: {members: [a]}} = t;
                    if (Ne(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(s)) {
                        const {byteSize: o, structure: {constructor: c}} = a, l = Fe(n, c);
                        if (void 0 !== l) {
                            if (s === e.Slice || l * o === i) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return a ? void 0 !== i && zn(a, t) : r?.(t, n), a;
        },
        assignView(t, n, r, s, i) {
            const {byteSize: o, type: a} = r, c = o ?? 1;
            if (t[xt]) {
                const s = a === e.Slice ? c * t.length : c;
                if (n.byteLength !== s) throw new BufferSizeMismatch(r, n, t);
                const i = {
                    [xt]: n
                };
                t.constructor[_t]?.validateData?.(i, t.length), t[de](i);
            } else {
                void 0 !== o && zn(n, r);
                const e = n.byteLength / c, a = {
                    [xt]: n
                };
                t.constructor[_t]?.validateData?.(a, e), i && (s = !0), t[ge](s ? null : n, e, i), 
                s && t[de](a);
            }
            if (this.usingBufferFallback()) {
                const e = t[xt], n = e.buffer[oe];
                void 0 !== n && this.syncExternalBuffer(e.buffer, n, !0);
            }
        },
        findViewAt(t, e, n) {
            let r, s = this.viewMap.get(t);
            if (s) if (s instanceof DataView) if (s.byteOffset === e && s.byteLength === n) r = s, 
            s = null; else {
                const e = s, n = `${e.byteOffset}:${e.byteLength}`;
                s = new Map([ [ n, e ] ]), this.viewMap.set(t, s);
            } else r = s.get(`${e}:${n}`);
            return {
                existing: r,
                entry: s
            };
        },
        obtainView(t, e, n) {
            const {existing: r, entry: s} = this.findViewAt(t, e, n);
            let i;
            if (r) return r;
            i = new DataView(t, e, n), s ? s.set(`${e}:${n}`, i) : this.viewMap.set(t, i);
            {
                const r = t[Mt];
                r && (i[Mt] = {
                    address: Ce(r.address, e),
                    len: n
                });
            }
            return i;
        },
        registerView(t) {
            if (!t[Mt]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: s, entry: i} = this.findViewAt(e, n, r);
                if (s) return s;
                i ? i.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: null,
                syncExternalBuffer: null
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > _n && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let s = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    s = ze(t, e) - t;
                }
                return this.obtainView(r, Number(s), t);
            }
        }
    });
    const _n = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8;
    sn({
        makeReadOnly(t) {
            Fn(t);
        }
    });
    const Cn = Object.getOwnPropertyDescriptors, Tn = Object.defineProperty;
    function Fn(t) {
        const e = t[$t];
        if (e) jn(e, [ "length" ]); else {
            const e = t[Ct];
            e ? (jn(e), function(t) {
                Tn(t, "set", {
                    value: fn
                });
                const e = t.get;
                Tn(t, "get", {
                    value: function(t) {
                        const n = e.call(this, t);
                        return null === n?.[Ht] && Fn(n), n;
                    }
                });
            }(e)) : jn(t);
        }
    }
    function jn(t, e = []) {
        const n = Cn(t.constructor.prototype);
        for (const [r, s] of Object.entries(n)) s.set && !e.includes(r) && (s.set = fn, 
        Tn(t, r, s));
        Tn(t, Ht, {
            value: t
        });
    }
    function Ln() {
        const t = this[Ct] ?? this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function Nn(t) {
        const e = Ie(t), n = this[Ct] ?? this, r = this.length;
        let s = 0;
        return {
            next() {
                let t, i;
                if (s < r) {
                    const r = s++;
                    t = [ r, e((() => n.get(r))) ], i = !1;
                } else i = !0;
                return {
                    value: t,
                    done: i
                };
            }
        };
    }
    function Pn(t) {
        return {
            [Symbol.iterator]: Nn.bind(this, t),
            length: this.length
        };
    }
    function Rn(t) {
        return {
            [Symbol.iterator]: Wn.bind(this, t),
            length: this[zt].length
        };
    }
    function Dn(t) {
        return Rn.call(this, t)[Symbol.iterator]();
    }
    function Wn(t) {
        const e = Ie(t), n = this, r = this[zt];
        let s = 0;
        return {
            next() {
                let t, i;
                if (s < r.length) {
                    const o = r[s++];
                    t = [ o, e((() => n[o])) ], i = !1;
                } else i = !0;
                return {
                    value: t,
                    done: i
                };
            }
        };
    }
    function Zn(t) {
        return {
            [Symbol.iterator]: Gn.bind(this, t),
            length: this[zt].length
        };
    }
    function qn(t) {
        return Zn.call(this, t)[Symbol.iterator]();
    }
    function Gn(t) {
        const e = Ie(t), n = this, r = this[zt], s = this[Qt];
        let i = 0;
        return {
            next() {
                let t, o;
                if (i < r.length) {
                    const a = r[i++];
                    t = [ a, e((() => s[a].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function Jn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = t[e], s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function Hn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function Yn() {
        return {
            [Symbol.iterator]: Hn.bind(this),
            length: this.length
        };
    }
    function Xn(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function Kn(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function Qn(t) {
        return tr.call(this, t).$;
    }
    function tr(t) {
        return this[It][t] ?? this[fe](t);
    }
    function er(t) {
        const e = tr.call(this, t).$;
        return e ? e.string : e;
    }
    function nr(t, e, n) {
        tr.call(this, t)[pe](e, n);
    }
    sn({
        defineArrayEntries: () => xe(Pn),
        defineArrayIterator: () => xe(Ln)
    }), sn({
        defineStructEntries: () => xe(Rn),
        defineStructIterator: () => xe(Dn)
    }), sn({
        defineUnionEntries: () => xe(Zn),
        defineUnionIterator: () => xe(qn)
    }), sn({
        defineVectorEntries: () => xe(Yn),
        defineVectorIterator: () => xe(Jn)
    }), sn({
        defineZigIterator: () => xe(Xn)
    }), sn({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, s = this[`defineMember${W[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${f[e]}`];
                if (n) return n.call(this, s, t);
            }
            return s;
        }
    }), sn({
        defineBase64(t) {
            const e = this;
            return Ze({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new cn("string", n);
                    const s = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, s, t, !1, r);
                }
            });
        }
    }), sn({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), sn({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return Ze({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, s) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new cn(n.name, r);
                    const i = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, i, t, !0, s);
                }
            });
        }
    }), sn({
        defineDataView(t) {
            const e = this;
            return Ze({
                get() {
                    const t = this[xt];
                    if (e.usingBufferFallback()) {
                        const n = t.buffer[oe];
                        void 0 !== n && e.syncExternalBuffer(t.buffer, n, !1);
                    }
                    return t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new cn("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), sn({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), sn({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), sn({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return Kn(e, {
                get(t) {
                    return this[It][t].string;
                },
                set: fn
            });
        }
    }), sn({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: fn
        })
    }), sn({
        defineMemberObject: t => Kn(t.slot, {
            get: t.flags & Y ? er : t.structure.flags & h ? Qn : tr,
            set: t.flags & q ? fn : nr
        })
    }), sn({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: s} = t, i = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return i.call(this[xt], t, n);
                        },
                        set: function(e) {
                            return o.call(this[xt], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return i.call(this[xt], e * s, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[xt], t * s, e, n);
                    }
                };
            }
        }
    }), sn({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: s}} = t, {get: i} = this.defineMember(r), {get: o} = this.defineMember(n), a = i.call(s, 0), c = !!(r.flags & Z), {runtimeSafety: l} = this;
            return xe({
                value: a,
                bytes: s[xt],
                validateValue(e, n, r) {
                    if (c) {
                        if (l && e === a && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== a && n === r - 1) throw new MissingSentinel(t, a, r);
                    }
                },
                validateData(n, r) {
                    if (c) if (l) for (let e = 0; e < r; e++) {
                        const s = o.call(n, e);
                        if (s === a && e !== r - 1) throw new MisplacedSentinel(t, a, e, r);
                        if (s !== a && e === r - 1) throw new MissingSentinel(t, a, r);
                    } else if (r > 0 && r * e === n[xt].byteLength) {
                        if (o.call(n, r - 1) !== a) throw new MissingSentinel(t, a, r);
                    }
                },
                isRequired: c
            });
        },
        imports: {
            findSentinel: null
        }
    }), sn({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return Ze({
                get() {
                    let t = Me(this.typedArray, r);
                    const e = this.constructor[_t]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, s) {
                    if ("string" != typeof n) throw new cn("string", n);
                    const i = this.constructor[_t]?.value;
                    void 0 !== i && n.charCodeAt(n.length - 1) !== i && (n += String.fromCharCode(i));
                    const o = Ue(n, r), a = new DataView(o.buffer);
                    e.assignView(this, a, t, !1, s);
                }
            });
        }
    }), sn({
        defineValueOf: () => ({
            value() {
                return ir(this, !1);
            }
        })
    });
    const rr = BigInt(Number.MAX_SAFE_INTEGER), sr = BigInt(Number.MIN_SAFE_INTEGER);
    function ir(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, s = Ie(r), i = new Map, o = function(t) {
            const a = "function" == typeof t ? e.Struct : t?.constructor?.[kt];
            if (void 0 === a) {
                if (n) {
                    if ("bigint" == typeof t && sr <= t && t <= rr) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let c = i.get(t);
            if (void 0 === c) {
                let n;
                switch (a) {
                  case e.Struct:
                    n = t[Ft](r), c = t.constructor[Vt] & S.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[Ft](r), c = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[Ft](), c = [];
                    break;

                  case e.Pointer:
                    try {
                        c = t["*"];
                    } catch (t) {
                        c = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    c = s((() => String(t)));
                    break;

                  case e.Opaque:
                    c = {};
                    break;

                  default:
                    c = s((() => t.$));
                }
                if (c = o(c), i.set(t, c), n) for (const [t, e] of n) c[t] = o(e);
            }
            return c;
        };
        return o(t);
    }
    sn({
        defineToJSON: () => ({
            value() {
                return ir(this, !0);
            }
        })
    }), sn({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return Kn(n, {
                get(t) {
                    const e = this[It][t];
                    return e?.constructor;
                },
                set: fn
            });
        }
    }), sn({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return Ze({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, s) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new cn(n.name, r);
                    const i = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, i, t, !0, s);
                }
            });
        }
    }), sn({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), sn({
        defineMemberUndefined: t => ({
            get: function() {},
            set: fn
        })
    }), sn({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), sn({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), sn({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${f[e]}`], s = [], i = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [Ht]: {
                    value: null
                },
                [te]: xe(i),
                [Lt]: xe(s),
                [de]: this.defineCopier(n)
            }, a = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !i[t] && "$" !== t && (i[t] = n, s.push(t));
            }
            return Ae(a.prototype, o), a;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: s, align: i, byteSize: o, flags: a, signature: c, static: {members: l, template: u}} = t, h = [], d = {
                name: xe(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [ae]: xe(c),
                [Yt]: xe(this),
                [Jt]: xe(i),
                [qt]: xe(o),
                [kt]: xe(r),
                [Vt]: xe(a),
                [zt]: xe(h),
                [ee]: xe(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [Ft]: this.defineStructEntries(),
                [zt]: xe(h)
            }, g = {
                [Symbol.toStringTag]: xe(n)
            };
            if (l) for (const t of l) {
                const {name: n, slot: r, flags: s} = t;
                if (t.structure.type === e.Function) {
                    let e = u[It][r];
                    s & Y && (e[ce] = !0), d[n] = xe(e), e.name || Se(e, "name", xe(n));
                    const [i, o] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], a = "get" === i ? 0 : 1;
                    if (i && e.length === a) {
                        d[o] ||= {};
                        d[o][i] = e;
                    }
                    if (t.flags & J) {
                        const t = function(...t) {
                            try {
                                return e(this, ...t);
                            } catch (t) {
                                throw t[le]?.(1), t;
                            }
                        };
                        if (Ae(t, {
                            name: xe(n),
                            length: xe(e.length - 1)
                        }), g[n] = xe(t), i && t.length === a) {
                            (g[o] ||= {})[i] = t;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[It] = h.length > 0 && xe(u[It]);
            const p = this[`finalize${f[r]}`];
            !1 !== p?.call(this, t, d, g) && (Ae(s.prototype, g), Ae(s, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: s, align: i, flags: o, instance: {members: a, template: c}} = t, {onCastError: l} = n;
            let u;
            if (c?.[It]) {
                const t = a.filter((t => t.flags & q));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, d = function(n, a = {}) {
                const {allocator: g} = a, y = this instanceof d;
                let m, b;
                if (y) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (m = this, o & p && (m[It] = {}), ge in m) m[pe](n, g), b = m[xt]; else {
                        const t = r !== e.Pointer ? g : null;
                        m[xt] = b = h.allocateMemory(s, i, t);
                    }
                } else {
                    if (be in d && (m = d[be].call(this, n, a), !1 !== m)) return m;
                    if (b = h.extractView(t, n, l), m = f.find(b)) return m;
                    m = Object.create(d.prototype), ge in m ? h.assignView(m, b, t, !1, !1) : m[xt] = b, 
                    o & p && (m[It] = {});
                }
                if (u) for (const t of u) m[It][t] = c[It][t];
                return m[ye]?.(), y && (ge in m || m[pe](n, g)), me in m && (m = m[me]()), f.save(b, m);
            };
            return Se(d, Zt, xe(f)), d;
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const s = Object.keys(n), i = this[Lt], o = this[te];
                for (const e of s) if (!(e in o)) throw new NoProperty(t, e);
                let a = 0, c = 0, l = 0, u = 0;
                for (const t of i) {
                    const e = o[t];
                    e.special ? t in n && u++ : (a++, t in n ? c++ : e.required && l++);
                }
                if (0 !== l && 0 === u) {
                    const e = i.filter((t => o[t].required && !(t in n)));
                    throw new MissingInitializers(t, e);
                }
                if (u + c > s.length) for (const t of i) t in n && (s.includes(t) || s.push(t));
                c < a && 0 === u && e && e[xt] && this[de](e);
                for (const t of s) {
                    o[t].call(this, n[t], r);
                }
                return s.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) {
                const [t] = r.members;
                switch (n) {
                  case e.Enum:
                  case e.ErrorSet:
                  case e.Primitive:
                    {
                        const {byteSize: e, type: n} = t;
                        return globalThis[(e > 4 && n !== D.Float ? "Big" : "") + (n === D.Float ? "Float" : n === D.Int ? "Int" : "Uint") + 8 * e + "Array"];
                    }

                  case e.Array:
                  case e.Slice:
                  case e.Vector:
                    return this.getTypedArray(t.structure);
                }
            }
        }
    }), sn({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: s, length: i, instance: {members: o}} = t, a = this, c = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = a.allocateMemory(r, s)) : (u = Object.create(l.prototype), 
                f = t), u[xt] = f, n & p && (u[It] = {}), !o) return u;
                {
                    let r;
                    if (n & N && t.length === i + 1 && (r = t.pop()), t.length !== i) throw new ArgumentCountMismatch(i, t.length);
                    n & R && (u[me] = null), a.copyArguments(u, t, c, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = xe(c.length), e[fe] = n & d && this.defineVivificatorStruct(t), 
            e[he] = n & g && this.defineVisitorArgStruct(o), e[we] = xe((function(t) {
                u.call(this, t, this[ie]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(c), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[ne] = xe(!!(n & P));
        }
    }), sn({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                const n = new Proxy(this, or);
                return Ae(this, {
                    [Wt]: {
                        value: n
                    },
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), n;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, s = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, i = this[xt], o = i.byteOffset + n * t, a = s.obtainView(i.buffer, o, n);
                    return this[It][t] = e.call(Et, a);
                }
            };
        }
    });
    const or = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : e === Ct ? t : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length", Wt), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    };
    sn({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: s} = t, i = this.createApplier(t), o = this.defineMember(r), {set: a} = o, c = this.createConstructor(t), l = function(e, r) {
                if (Ne(e, c)) this[de](e), s & g && this[he]("copy", tt.Vivificate, e); else if ("string" == typeof e && s & b && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = Te(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let s = 0;
                    for (const t of e) a.call(this, s++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === i.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            };
            return e.$ = {
                get: Je,
                set: l
            }, e.length = xe(n), e.entries = e[Ft] = this.defineArrayEntries(), s & w && (e.typedArray = this.defineTypedArray(t), 
            s & b && (e.string = this.defineString(t)), s & v && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[pe] = xe(l), e[me] = this.defineFinalizerArray(o), 
            e[fe] = s & d && this.defineVivificatorArray(t), e[he] = s & g && this.defineVisitorArray(), 
            c;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = xe(r.structure.constructor), e[_t] = n & m && this.defineSentinel(t);
        }
    }), sn({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: s, set: i} = r, {get: o} = this.defineMember(n, !1), a = this.createApplier(t), c = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return e.$ = r, e.toString = xe(He), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[Ut];

                      default:
                        return o.call(this);
                    }
                }
            }, e[pe] = xe((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === a.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && i.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [s]}, static: {members: i, template: o}} = t, a = o[It], {get: c, set: l} = this.defineMember(s, !1), u = {};
            for (const {name: t, flags: n, slot: r} of i) if (n & G) {
                const n = a[r];
                Se(n, Ut, xe(t));
                const s = c.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[s] = n;
            }
            e[be] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & E) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            Se(e, Ut, xe(n)), Se(r, n, xe(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[Bt] instanceof r && t[Bt];
                }
            }, e[ee] = xe(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === D.Object) return t;
            const s = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: i, set: o} = t;
            return {
                get: 0 === i.length ? function() {
                    const t = i.call(this);
                    return s(t);
                } : function(t) {
                    const e = i.call(this, t);
                    return s(e);
                },
                set: 1 === o.length ? function(t) {
                    t = s(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = s(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), sn({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: s, flags: i} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: F,
                    byteSize: s,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && i & F) return this.globalErrorSet;
            const o = this.defineMember(r), {set: a} = o, c = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, c, e);
                }
            });
            return n.$ = o, n[pe] = xe((function(e) {
                if (e instanceof u[Ot]) a.call(this, e); else if (e && "object" == typeof e && !mn(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, c, e);
                } else void 0 !== e && a.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [s]}, static: {members: i, template: o}} = t;
            if (this.globalErrorSet && r & F) return !1;
            const a = o?.[It] ?? {}, c = r & F ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(s, !1);
            for (const {name: t, slot: n} of i) {
                const r = a[n], s = l.call(r);
                let i = this.globalItemsByIndex[s];
                const o = !!i;
                i || (i = new this.ZigError(t, s));
                const u = xe(i);
                e[t] = u;
                const f = `${i}`;
                e[f] = u, c[s] = i, o || (Ae(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[zt].push(t), this.globalItemsByIndex[s] = i);
            }
            e[be] = {
                value: t => "number" == typeof t ? c[t] : "string" == typeof t ? n[t] : t instanceof n[Ot] ? c[Number(t)] : mn(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[Ot] = xe(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === D.Object) return t;
            const s = t => {
                const {constructor: e, flags: n} = r, s = e(t);
                if (!s) {
                    if (n & F && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, Se(this.globalErrorSet, `${e}`, xe(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r) : new ErrorExpected(r, t);
                }
                return s;
            }, {get: i, set: o} = t;
            return {
                get: 0 === i.length ? function() {
                    const t = i.call(this);
                    return s(t);
                } : function(t) {
                    const e = i.call(this, t);
                    return s(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = s(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = s(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function ar(t, e) {
        return Le(t?.constructor?.child, e) && t["*"];
    }
    function cr(t, e, n) {
        if (n & k) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & V && ar(t, e.child)) return !0;
        }
        return !1;
    }
    sn({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: s} = t, {get: i, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), f = n.type === D.Void, h = r.structure.constructor, p = function() {
                this[ue](), this[he]?.("clear");
            }, y = this.createApplier(t), m = function(t, e) {
                if (Ne(t, v)) this[de](t), s & g && (l.call(this) || this[he]("copy", 0, t)); else if (t instanceof h[Ot] && h(t)) c.call(this, t), 
                p.call(this); else if (void 0 !== t || f) try {
                    o.call(this, t, e), u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = h(t) ?? h.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure);
                        c.call(this, e), p.call(this);
                    } else if (mn(t)) c.call(this, t), p.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === y.call(this, t)) throw e;
                    }
                }
            }, {bitOffset: b, byteSize: w} = n, v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw a.call(this);
                    return i.call(this);
                },
                set: m
            }, e[pe] = xe(m), e[fe] = s & d && this.defineVivificatorStruct(t), e[ue] = this.defineResetter(b / 8, w), 
            e[he] = s & g && this.defineVisitorErrorUnion(n, l), v;
        }
    }), sn({
        defineFunction(t, n) {
            const {instance: {members: [r], template: s}, static: {template: i}} = t, o = new ObjectCache, {structure: {constructor: a}} = r, c = this, l = function(n) {
                const r = this instanceof l;
                let u, f;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new cn("function", n);
                    if (a[kt] === e.VariadicStruct || !i) throw new Unsupported;
                    u = c.getFunctionThunk(n, i);
                } else {
                    if (this !== Yt) throw new NoCastingToFunction;
                    u = n;
                }
                if (f = o.find(u)) return f;
                const h = a.prototype.length, d = r ? c.createInboundCaller(n, a) : c.createOutboundCaller(s, a);
                return Ae(d, {
                    length: xe(h),
                    name: xe(r ? n.name : "")
                }), Object.setPrototypeOf(d, l.prototype), d[xt] = u, o.save(u, d), d;
            };
            return Object.setPrototypeOf(l.prototype, Function.prototype), n.valueOf = n.toJSON = xe(Ge), 
            l;
        },
        finalizeFunction(t, e, n) {
            n[Symbol.toStringTag] = void 0;
        }
    }), sn({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, s = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[pe] = xe((() => {
                throw new CreatingOpaque(t);
            })), s;
        }
    }), sn({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: s} = t, {get: i, set: o} = this.defineMember(n), {get: a, set: c} = this.defineMember(r), l = n.type === D.Void, u = function(t, e) {
                Ne(t, f) ? (this[de](t), s & g && a.call(this) && this[he]("copy", tt.Vivificate, t)) : null === t ? (c.call(this, 0), 
                this[ue]?.(), this[he]?.("clear")) : (void 0 !== t || l) && (o.call(this, t, e), 
                s & M ? c.call(this, 1) : s & g && (a.call(this) || c.call(this, 13)));
            }, f = t.constructor = this.createConstructor(t), {bitOffset: h, byteSize: p} = n;
            return e.$ = {
                get: function() {
                    return a.call(this) ? i.call(this) : (this[he]?.("clear"), null);
                },
                set: u
            }, e[pe] = xe(u), e[ue] = s & M && this.defineResetter(h / 8, p), e[fe] = s & d && this.defineVivificatorStruct(t), 
            e[he] = s & g && this.defineVisitorOptional(n, a), f;
        }
    }), sn({
        definePointer(t, n) {
            const {flags: r, byteSize: s, instance: {members: [i]}} = t, {structure: o} = i, {type: a, flags: c, byteSize: l = 1} = o, u = r & U ? s / 2 : s, {get: f, set: d} = this.defineMember({
                type: D.Uint,
                bitOffset: 0,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    byteSize: u
                }
            }), {get: g, set: p} = r & U ? this.defineMember({
                type: D.Uint,
                bitOffset: 8 * u,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    flags: y,
                    byteSize: u
                }
            }) : {}, m = function(t, n = !0, s = !0) {
                if (n || this[xt][Mt]) {
                    if (!s) return this[It][0] = void 0;
                    {
                        const n = M.child, s = f.call(this), i = r & U ? g.call(this) : a === e.Slice && c & z ? I.findSentinel(s, n[_t].bytes) + 1 : 1;
                        if (s !== this[Rt] || i !== this[Dt]) {
                            const e = I.findMemory(t, s, i, n[qt]), o = e ? n.call(Yt, e) : null;
                            return this[It][0] = o, this[Rt] = s, this[Dt] = i, r & U && (this[jt] = null), 
                            o;
                        }
                    }
                }
                return this[It][0];
            }, b = function(t) {
                d.call(this, t), this[Rt] = t;
            }, w = c & z ? 1 : 0, v = r & U || c & z ? function(t) {
                p?.call?.(this, t - w), this[Dt] = t;
            } : null, S = function() {
                const t = this[$t] ?? this, e = !t[It][0], n = m.call(t, null, e);
                if (!n) {
                    if (r & B) return null;
                    throw new NullPointer;
                }
                return r & O ? ur(n) : n;
            }, A = c & h ? function() {
                return S.call(this).$;
            } : S, x = r & O ? fn : function(t) {
                return S.call(this).$ = t;
            }, I = this, E = function(n, s) {
                const i = o.constructor;
                if (ar(n, i)) {
                    if (!(r & O) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[It][0];
                } else if (r & k) cr(n, i, r) && (n = i(n[It][0][xt])); else if (a === e.Slice && c & T && n) if (n.constructor[kt] === e.Pointer) n = n[Tt]?.[xt]; else if (n[xt]) n = n[xt]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof i) {
                    const e = n[Ht];
                    if (e) {
                        if (!(r & O)) throw new ReadOnlyTarget(t);
                        n = e;
                    }
                } else if (Ne(n, i)) n = i.call(Yt, n[xt]); else if (r & V && r & k && n instanceof i.child) n = i(n[xt]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[ee];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== Fe(t, e.child)) return !0;
                    }
                    return !1;
                }(n, i)) {
                    n = i(I.extractView(o, n));
                } else if (null == n || n[xt]) {
                    if (!(void 0 === n || r & B && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & V && r & k && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = i.prototype[te];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (ee in i && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    n = new i(n, {
                        allocator: s
                    });
                }
                const l = n?.[xt]?.[Mt];
                if (-1 === l?.address) throw new PreviouslyFreed(n);
                this[Tt] = n;
            }, M = this.createConstructor(t);
            return n["*"] = {
                get: A,
                set: x
            }, n.$ = {
                get: Je,
                set: E
            }, n.length = {
                get: function() {
                    const t = S.call(this);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = S.call(this);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[xt], s = n[Mt];
                    let i;
                    if (!s) if (r & U) this[jt] ||= e.length, i = this[jt]; else {
                        i = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > i) throw new InvalidSliceLength(t, i);
                    const a = t * l, c = s ? I.obtainZigView(s.address, a) : I.obtainView(n.buffer, n.byteOffset, a), u = o.constructor;
                    this[It][0] = u.call(Yt, c), v?.call?.(this, t);
                }
            }, n.slice = a === e.Slice && {
                value(t, e) {
                    const n = this[Tt].slice(t, e);
                    return new M(n);
                }
            }, n.subarray = a === e.Slice && {
                value(t, e, n) {
                    const r = this[Tt].subarray(t, e, n);
                    return new M(r);
                }
            }, n[Symbol.toPrimitive] = a === e.Primitive && {
                value(t) {
                    return this[Tt][Symbol.toPrimitive](t);
                }
            }, n[pe] = xe(E), n[me] = {
                value() {
                    const t = a !== e.Pointer ? fr : {};
                    let n;
                    a === e.Function ? (n = function() {}, n[xt] = this[xt], n[It] = this[It], Object.setPrototypeOf(n, M.prototype)) : n = this;
                    const r = new Proxy(n, t);
                    return Object.defineProperty(n, Wt, {
                        value: r
                    }), r;
                }
            }, n[Tt] = {
                get: S,
                set: function(t) {
                    if (void 0 === t) return;
                    const e = this[$t] ?? this;
                    if (t) {
                        const n = t[xt][Mt];
                        if (n) {
                            const {address: e, js: r} = n;
                            b.call(this, e), v?.call?.(this, t.length), r && (t[xt][Mt] = void 0);
                        } else if (e[xt][Mt]) throw new ZigMemoryTargetRequired;
                    } else e[xt][Mt] && (b.call(this, 0), v?.call?.(this, 0));
                    e[It][0] = t ?? null, r & U && (e[jt] = null);
                }
            }, n[le] = xe(m), n[Nt] = {
                set: b
            }, n[Pt] = {
                set: v
            }, n[he] = this.defineVisitor(), n[Rt] = xe(0), n[Dt] = xe(0), n[jt] = r & U && xe(null), 
            n.dataView = n.base64 = void 0, M;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: s, instance: {members: [i]}} = t, {structure: o} = i, {type: a, constructor: c} = o;
            n.child = c ? xe(c) : {
                get: () => o.constructor
            }, n.const = xe(!!(r & O)), n[be] = {
                value(n, i) {
                    if (this === Yt || this === Et || n instanceof s) return !1;
                    if (ar(n, c)) return new s(c(n["*"]), i);
                    if (cr(n, c, r)) return new s(n);
                    if (a === e.Slice) return new s(c(n), i);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    });
    const lr = new WeakMap;
    function ur(t) {
        let e = lr.get(t);
        if (!e) {
            const n = t[$t];
            e = n ? new Proxy(n, hr) : new Proxy(t, dr), lr.set(t, e);
        }
        return e;
    }
    const fr = {
        get(t, e) {
            if (e === $t) return t;
            if (e in t) return t[e];
            return t[Tt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[Tt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[Tt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[Tt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, hr = {
        ...fr,
        set(t, e, n) {
            if (e in t) fn(); else {
                t[Tt][e] = n;
            }
            return !0;
        }
    }, dr = {
        get(t, e) {
            if (e === Ht) return t;
            {
                const n = t[e];
                return n?.[xt] ? ur(n) : n;
            }
        },
        set(t, e, n) {
            fn();
        }
    };
    function gr() {
        return this[Pt];
    }
    function pr(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function yr() {
        throw new InaccessiblePointer;
    }
    function mr() {
        const t = {
            get: yr,
            set: yr
        };
        Ae(this[$t], {
            "*": t,
            $: t,
            [$t]: t,
            [Tt]: t
        });
    }
    function br(t, e, n, r) {
        let s, i = this[It][t];
        if (!i) {
            if (n & tt.IgnoreUncreated) return;
            i = this[fe](t);
        }
        r && (s = r[It][t], !s) || i[he](e, n, s);
    }
    sn({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: s, set: i} = this.defineMember(n), o = function(e) {
                if (Ne(e, a)) this[de](e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = Ee(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && i.call(this, e);
            }, a = this.createConstructor(t);
            return e.$ = {
                get: s,
                set: o
            }, e[pe] = xe(o), e[Symbol.toPrimitive] = xe(s), a;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[Gt] = xe(n.bitSize), e[Kt] = xe(n.type);
        }
    }), sn({
        defineSlice(t, e) {
            const {align: n, flags: r, byteSize: s, name: i, instance: {members: [o]}} = t, {byteSize: a, structure: c} = o, l = this, u = function(t, e, r) {
                t || (t = l.allocateMemory(e * a, n, r)), this[xt] = t, this[Pt] = e;
            }, f = function(e, n) {
                if (n !== this[Pt]) throw new ArrayLengthMismatch(t, this, e);
            }, h = this.defineMember(o), {set: p} = h, y = this.createApplier(t), m = function(e, n) {
                if (Ne(e, w)) this[xt] ? f.call(this, e, e.length) : u.call(this, null, e.length, n), 
                this[de](e), r & g && this[he]("copy", tt.Vivificate, e); else if ("string" == typeof e && r & $) m.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = Te(e), this[xt] ? f.call(this, e, e.length) : u.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) w[_t]?.validateValue(r, t, e.length), p.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[xt] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[xt]);
                    u.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === y.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, b = function(t, e) {
                const n = this[Pt], r = this[xt];
                t = void 0 === t ? 0 : pr(t, n), e = void 0 === e ? n : pr(e, n);
                const s = t * a, i = e * a - s;
                return l.obtainView(r.buffer, r.byteOffset + s, i);
            }, w = this.createConstructor(t);
            return e.$ = {
                get: Je,
                set: m
            }, e.length = {
                get: gr
            }, r & _ && (e.typedArray = this.defineTypedArray(t), r & $ && (e.string = this.defineString(t)), 
            r & C && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[Ft] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = b.call(this, t, e);
                    return w(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: s = !1} = r, i = b.call(this, t, e), o = l.allocateMemory(i.byteLength, n, s), a = w(o);
                    return a[de]({
                        [xt]: i
                    }), a;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[ge] = xe(u), e[de] = this.defineCopier(s, !0), 
            e[pe] = xe(m), e[me] = this.defineFinalizerArray(h), e[fe] = r & d && this.defineVivificatorArray(t), 
            e[he] = r & g && this.defineVisitorArray(), w;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = xe(r.structure.constructor), e[_t] = n & z && this.defineSentinel(t);
        }
    }), sn({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === D.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: s, byteSize: i, structure: {constructor: o}} = e, a = this[xt], c = a.byteOffset + (s >> 3);
                    let l = i;
                    if (void 0 === l) {
                        if (7 & s) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(a.buffer, c, l);
                    return this[It][t] = o.call(Et, u);
                }
            };
        }
    }), sn({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: s, instance: {members: a}} = t, c = a.find((t => t.flags & H)), l = c && this.defineMember(c), u = this.createApplier(t), f = function(e, n) {
                if (Ne(e, h)) this[de](e), r & g && this[he]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            }, h = this.createConstructor(t), p = e[te].value, y = e[Lt].value, m = [];
            for (const t of a.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: s} = e[n] = this.defineMember(t);
                s && (r & Z && (s.required = !0), p[n] = s, y.push(n)), m.push(n);
            }
            return e.$ = {
                get: Ge,
                set: f
            }, e.length = xe(s), e.entries = r & S.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & S.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[pe] = xe(f), e[fe] = r & d && this.defineVivificatorStruct(t), e[he] = r & g && this.defineVisitorStruct(a), 
            e[Ft] = r & S.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[zt] = xe(m), n === i && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), h;
        }
    }), sn({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: s}} = t, i = !!(r & A), a = i ? s.slice(0, -1) : s, c = i ? s[s.length - 1] : null, {get: l, set: u} = this.defineMember(c), {get: f} = this.defineMember(c, !1), h = r & x ? function() {
                return l.call(this)[Ut];
            } : function() {
                const t = l.call(this);
                return a[t].name;
            }, p = r & x ? function(t) {
                const {constructor: e} = c.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = a.findIndex((e => e.name === t));
                u.call(this, e);
            }, y = this.createApplier(t), m = function(e, n) {
                if (Ne(e, b)) this[de](e), r & g && this[he]("copy", tt.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of E) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === y.call(this, e, n)) throw new MissingUnionInitializer(t, e, i);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            }, b = this.createConstructor(t), w = {}, v = e[te].value, S = e[Lt].value, E = [];
            for (const n of a) {
                const {name: s} = n, {get: o, set: a} = this.defineMember(n), c = i ? function() {
                    const e = h.call(this);
                    if (s !== e) {
                        if (r & x) return null;
                        throw new InactiveUnionProperty(t, s, e);
                    }
                    return this[he]?.("clear"), o.call(this);
                } : o, l = i && a ? function(e) {
                    const n = h.call(this);
                    if (s !== n) throw new InactiveUnionProperty(t, s, n);
                    a.call(this, e);
                } : a, u = i && a ? function(t) {
                    p.call(this, s), a.call(this, t), this[he]?.("clear");
                } : a;
                e[s] = {
                    get: c,
                    set: l
                }, v[s] = u, w[s] = o, S.push(s), E.push(s);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: m
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & x && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return h.call(this);

                      default:
                        return f.call(this);
                    }
                }
            };
            const {comptime: M} = this;
            return e[ye] = r & I && {
                value() {
                    return M || this[he](mr), this[he] = Ye, this;
                }
            }, e[pe] = xe(m), e[Bt] = r & x && {
                get: l,
                set: u
            }, e[fe] = r & d && this.defineVivificatorStruct(t), e[he] = r & g && this.defineVisitorUnion(a, r & x ? f : null), 
            e[Ft] = this.defineUnionEntries(), e[zt] = r & x ? {
                get() {
                    return [ h.call(this) ];
                }
            } : xe(E), e[Qt] = xe(w), b;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & x && (e.tag = xe(r[r.length - 1].structure.constructor));
        }
    }), sn({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: s, length: i, instance: {members: o}} = t, a = this, c = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[xt] = a.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = a.littleEndian;
            };
            return Ae(u, {
                [Jt]: {
                    value: 4
                }
            }), Ae(u.prototype, {
                set: xe((function(t, e, n, r, s) {
                    const i = this[xt], o = a.littleEndian;
                    i.setUint16(8 * t, e, o), i.setUint16(8 * t + 2, n, o), i.setUint16(8 * t + 4, r, o), 
                    i.setUint8(8 * t + 6, s == D.Float), i.setUint8(8 * t + 7, s == D.Int || s == D.Float);
                }))
            }), e[fe] = s & d && this.defineVivificatorStruct(t), e[he] = this.defineVisitorVariadicStruct(o), 
            e[we] = xe((function(t) {
                l.call(this, t, this[ie]);
            })), function(t) {
                if (t.length < i) throw new ArgumentCountMismatch(i, t.length, !0);
                let e = n, s = r;
                const o = t.slice(i), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[xt], o = n?.constructor?.[Jt];
                    if (!r || !o) {
                        throw ln(new InvalidVariadicArgument, i + t);
                    }
                    o > s && (s = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = a.allocateMemory(e, s);
                h[Jt] = s, this[xt] = h, this[It] = {}, a.copyArguments(this, t, c);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: s, structure: {align: i}}] of c.entries()) f.set(t, e / 8, n, i, r), 
                s > d && (d = s);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[xt], s = l[t], o = a.obtainView(h.buffer, s, r), c = this[It][n] = e.constructor.call(Et, o), u = e.constructor[Gt] ?? 8 * r, g = e.constructor[Jt], p = e.constructor[Kt];
                    c.$ = e, f.set(i + t, s, u, g, p);
                }
                this[Xt] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[ne] = xe(!!(n & P)), e[Jt] = xe(void 0);
        }
    }), sn({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [s]}} = t, i = this.createApplier(t), o = function(e) {
                if (Ne(e, a)) this[de](e), n & g && this[he]("copy", tt.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let s = 0;
                    for (const t of e) this[s++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === i.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, a = this.createConstructor(t, {
                initializer: o
            }), {bitSize: c} = s;
            for (let t = 0, i = 0; t < r; t++, i += c) e[t] = n & g ? this.defineMember({
                ...s,
                slot: t
            }) : this.defineMember({
                ...s,
                bitOffset: i
            });
            return e.$ = {
                get: Ge,
                set: o
            }, e.length = xe(r), n & j && (e.typedArray = this.defineTypedArray(t), n & L && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[Ft] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[pe] = xe(o), e[fe] = n & d && this.defineVivificatorArray(t), e[he] = n & g && this.defineVisitorArray(), 
            a;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = xe(n.structure.constructor);
        }
    }), sn({
        fdLockGet(t, e, n) {
            const r = this.littleEndian;
            return dn(n, nt, (() => {
                const [n] = this.getStream(t);
                if (Pe(n, "getlock")) {
                    const t = qe(24);
                    this.moveExternBytes(t, e, !1);
                    const s = t.getUint16(0, r), i = t.getUint16(2, r), o = t.getUint32(4, r), a = t.getBigInt64(8, r), c = t.getBigUint64(16, r);
                    return n.getlock({
                        type: s,
                        whence: i,
                        start: a,
                        length: c,
                        pid: o
                    });
                }
            }), (t => {
                let n;
                t ? (n = qe(24), n.setUint16(0, t.type ?? 0, r), n.setUint16(2, t.whence ?? 0, r), 
                n.setUint32(4, t.pid ?? 0, r), n.setBigInt64(8, t.start ?? 0n, r), n.setBigUint64(16, t.length ?? 0n, r)) : (n = qe(2), 
                n.setUint16(0, 2, r)), this.moveExternBytes(n, e, !0);
            }));
        },
        exports: {
            fdLockGet: {
                async: !0
            }
        }
    }), sn({
        fdLockSet(t, e, n, r) {
            const s = this.littleEndian;
            return dn(r, rt, (() => {
                const [r] = this.getStream(t);
                if (Pe(r, "setlock")) {
                    const t = qe(24);
                    this.moveExternBytes(t, e, !1);
                    const i = t.getUint16(0, s), o = t.getUint16(2, s), a = t.getUint32(4, s), c = t.getBigUint64(8, s), l = t.getBigUint64(16, s);
                    return r.setlock({
                        type: i,
                        whence: o,
                        start: c,
                        len: l,
                        pid: a
                    }, n);
                }
                return !0;
            }), (t => yn(t, rt)));
        },
        exports: {
            fdLockSet: {
                async: !0
            }
        }
    }), sn({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? wr[t] : t, r.call(this, e, n);
            }
        })
    });
    const wr = {
        copy(t, e) {
            const n = e[It][0];
            if (this[xt][Mt] && n && !n[xt][Mt]) throw new ZigMemoryTargetRequired;
            this[It][0] = n;
        },
        clear(t) {
            t & tt.IsInactive && (this[It][0] = void 0);
        },
        reset() {
            this[It][0] = void 0, this[Rt] = void 0;
        }
    };
    return sn({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: s, structure: i}] of t.entries()) i.flags & g && (0 === r ? n = s : e.push(s));
            return {
                value(t, r, s) {
                    if (!(r & tt.IgnoreArguments) && e.length > 0) for (const n of e) br.call(this, n, t, r | tt.IsImmutable, s);
                    r & tt.IgnoreRetval || void 0 === n || br.call(this, n, t, r, s);
                }
            };
        }
    }), sn({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, s = this.length; r < s; r++) br.call(this, r, t, e, n);
            }
        })
    }), sn({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, s) {
                    e.call(this) && (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || br.call(this, n, t, r, s);
                }
            };
        }
    }), sn({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, s) {
                    e.call(this) || (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || br.call(this, n, t, r, s);
                }
            };
        }
    }), sn({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & g)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const s of e) br.call(this, s, t, n, r);
                }
            };
        }
    }), sn({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: s}] of t.entries()) s?.flags & g && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, s) {
                    const i = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== i && (n |= tt.IsInactive), n & tt.IsInactive && n & tt.IgnoreInactive || br.call(this, o, t, n, s);
                    }
                }
            };
        }
    }), sn({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & g ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & tt.IgnoreArguments)) for (const [s, i] of Object.entries(this[It])) s !== n && he in i && br.call(this, s, t, e | tt.IsImmutable, r);
                    e & tt.IgnoreRetval || void 0 === n || br.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (on());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
