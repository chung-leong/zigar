(function(t) {
    "use strict";
    const e = {
        Primitive: 0,
        Array: 1,
        Struct: 2,
        Union: 3,
        ErrorUnion: 4,
        ErrorSet: 5,
        Enum: 6,
        Optional: 7,
        Pointer: 8,
        Slice: 9,
        Vector: 10,
        Opaque: 11,
        ArgStruct: 12,
        VariadicStruct: 13,
        Function: 14
    }, n = 1, r = 2, s = 3, i = 4, o = 5, c = 6, a = 7, l = 8, u = 9, f = Object.keys(e), h = 1, d = 2, g = 4, p = 8, y = 16, b = 16, m = 32, w = 64, v = 128, S = {
        IsExtern: 16,
        IsPacked: 32,
        IsTuple: 64,
        IsOptional: 128
    }, A = 16, I = 32, x = 64, M = 16, E = 16, V = 16, U = 32, O = 64, k = 128, B = 256, $ = 16, C = 32, z = 64, T = 128, j = 256, F = 16, L = 16, N = 32, _ = 16, P = 32, D = 64, R = {
        Void: 0,
        Bool: 1,
        Int: 2,
        Uint: 3,
        Float: 4,
        Object: 5,
        Type: 6,
        Literal: 7,
        Null: 8,
        Undefined: 9,
        Unsupported: 10
    }, W = Object.keys(R), Z = 1, q = 2, J = 4, G = 16, H = 64, Y = 128, X = 1, K = 2, Q = 4, tt = {
        IsInactive: 1,
        IsImmutable: 2,
        IgnoreUncreated: 4,
        IgnoreInactive: 8,
        IgnoreArguments: 16,
        IgnoreRetval: 32
    }, et = 0, nt = 2, rt = 8, st = 16, it = 20, ot = 21, ct = 28, at = 29, lt = 44, ut = {
        unknown: 0,
        blockDevice: 1,
        characterDevice: 2,
        directory: 3,
        file: 4,
        socketDgram: 5,
        socketStream: 6,
        symbolicLink: 7
    }, ft = {
        create: 1,
        directory: 2,
        exclusive: 4,
        truncate: 8
    }, ht = {
        symlinkFollow: 1
    }, dt = {
        fd_datasync: 1,
        fd_read: 2,
        fd_seek: 4,
        fd_fdstat_set_flags: 8,
        fd_sync: 16,
        fd_tell: 32,
        fd_write: 64,
        fd_advise: 128,
        fd_allocate: 256,
        path_create_directory: 512,
        path_create_file: 1024,
        path_link_source: 2048,
        path_link_target: 4096,
        path_open: 8192,
        fd_readdir: 16384,
        path_readlink: 32768,
        path_rename_source: 65536,
        path_rename_target: 1 << 17,
        path_filestat_get: 1 << 18,
        path_filestat_set_size: 1 << 19,
        path_filestat_set_times: 1 << 20,
        fd_filestat_get: 1 << 21,
        fd_filestat_set_size: 1 << 22,
        fd_filestat_set_times: 1 << 23,
        path_symlink: 1 << 24,
        path_remove_directory: 1 << 25,
        path_unlink_file: 1 << 26,
        poll_fd_readwrite: 1 << 27,
        sock_shutdown: 1 << 28,
        sock_accept: 1 << 29
    }, gt = {
        append: 1,
        dsync: 2,
        nonblock: 4,
        rsync: 8,
        sync: 16
    }, pt = 1, yt = 2, bt = -1, mt = 1048575, wt = globalThis[Symbol.for("ZIGAR")] ||= {};
    function vt(t) {
        return wt[t] ||= Symbol(t);
    }
    function St(t) {
        return vt(t);
    }
    const At = St("memory"), It = St("slots"), xt = St("parent"), Mt = St("zig"), Et = St("name"), Vt = St("type"), Ut = St("flags"), Ot = St("class"), kt = St("tag"), Bt = St("props"), $t = St("pointer"), Ct = St("sentinel"), zt = St("array"), Tt = St("target"), jt = St("entries"), Ft = St("max length"), Lt = St("keys"), Nt = St("address"), _t = St("length"), Pt = St("last address"), Dt = St("last length"), Rt = St("proxy"), Wt = St("cache"), Zt = St("size"), qt = St("bit size"), Jt = St("align"), Gt = St("const target"), Ht = St("environment"), Yt = St("attributes"), Xt = St("primitive"), Kt = St("getters"), Qt = St("setters"), te = St("typed array"), ee = St("throwing"), ne = St("promise"), re = St("generator"), se = St("allocator"), ie = St("fallback"), oe = St("signature"), ce = St("string retval"), ae = St("update"), le = St("reset"), ue = St("vivificate"), fe = St("visit"), he = St("copy"), de = St("shape"), ge = St("initialize"), pe = St("restrict"), ye = St("finalize"), be = St("cast"), me = St("return"), we = St("yield");
    function ve(t, e, n) {
        if (n) {
            const {set: r, get: s, value: i, enumerable: o, configurable: c = !0, writable: a = !0} = n;
            Object.defineProperty(t, e, s || r ? {
                get: s,
                set: r,
                configurable: c,
                enumerable: o
            } : {
                value: i,
                configurable: c,
                enumerable: o,
                writable: a
            });
        }
        return t;
    }
    function Se(t, e) {
        for (const [n, r] of Object.entries(e)) ve(t, n, r);
        for (const n of Object.getOwnPropertySymbols(e)) {
            ve(t, n, e[n]);
        }
        return t;
    }
    function Ae(t) {
        return void 0 !== t ? {
            value: t
        } : void 0;
    }
    function Ie(t) {
        return "return" === t?.error ? t => {
            try {
                return t();
            } catch (t) {
                return t;
            }
        } : t => t();
    }
    function xe({type: t, bitSize: e}) {
        switch (t) {
          case R.Bool:
            return "boolean";

          case R.Int:
          case R.Uint:
            if (e > 32) return "bigint";

          case R.Float:
            return "number";
        }
    }
    function Me(t, e = "utf-8") {
        const n = Ve[e] ||= new TextDecoder(e);
        let r;
        if (Array.isArray(t)) if (1 === t.length) r = t[0]; else {
            let e = 0;
            for (const n of t) e += n.length;
            const {constructor: n} = t[0];
            r = new n(e);
            let s = 0;
            for (const e of t) r.set(e, s), s += e.length;
        } else r = t;
        return "SharedArrayBuffer" === r.buffer[Symbol.toStringTag] && (r = new r.constructor(r)), 
        n.decode(r);
    }
    function Ee(t, e = "utf-8") {
        if ("utf-16" === e) {
            const {length: e} = t, n = new Uint16Array(e);
            for (let r = 0; r < e; r++) n[r] = t.charCodeAt(r);
            return n;
        }
        return (Ue[e] ||= new TextEncoder).encode(t);
    }
    const Ve = {}, Ue = {};
    function Oe(t, e, n) {
        let r = 0, s = t.length;
        if (0 === s) return 0;
        for (;r < s; ) {
            const i = Math.floor((r + s) / 2);
            n(t[i]) <= e ? r = i + 1 : s = i;
        }
        return s;
    }
    const ke = function(t, e) {
        return !!e && !!(t & e - 1);
    }, Be = function(t, e) {
        return t + (e - 1) & ~(e - 1);
    }, $e = 4294967295, Ce = function(t) {
        return Number(t);
    }, ze = function(t, e) {
        return t + e;
    };
    function Te(t) {
        if ("number" == typeof t.length) return t;
        const e = t[Symbol.iterator](), n = e.next(), r = n.value?.length;
        if ("number" == typeof r && "length" === Object.keys(n.value).join()) return Object.assign(function*() {
            let t;
            for (;!(t = e.next()).done; ) yield t.value;
        }(), {
            length: r
        });
        {
            const t = [];
            let r = n;
            for (;!r.done; ) t.push(r.value), r = e.next();
            return t;
        }
    }
    function je(t, e) {
        const {constructor: n} = t;
        return n === e ? 1 : n.child === e ? t.length : void 0;
    }
    function Fe(t, e) {
        const n = [], r = new Map, s = t => {
            if (t && !r.get(t) && (r.set(t, !0), n.push(t), t[e])) for (const n of Object.values(t[e])) s(n);
        };
        for (const e of t) s(e.instance.template), s(e.static.template);
        return n;
    }
    function Le(t, e) {
        return t === e || t?.[oe] === e[oe] && t?.[Ht] !== e?.[Ht];
    }
    function Ne(t, e) {
        return t instanceof e || Le(t?.constructor, e);
    }
    function _e(t, e) {
        return "function" == typeof t?.[e];
    }
    function Pe(t) {
        return "function" == typeof t?.then;
    }
    function De(t, e) {
        const n = {};
        for (const [r, s] of Object.entries(e)) t & s && (n[r] = !0);
        return n;
    }
    function Re(t, e) {
        for (const [n, r] of Object.entries(e)) if (n === t) return r;
    }
    function We({get: t, set: e}) {
        return t.special = e.special = !0, {
            get: t,
            set: e
        };
    }
    function Ze(t) {
        return new DataView(new ArrayBuffer(t));
    }
    function qe() {
        return this;
    }
    function Je() {
        return this[Rt];
    }
    function Ge() {
        return String(this);
    }
    function He() {}
    class ObjectCache {
        map=new WeakMap;
        find(t) {
            return this.map.get(t);
        }
        save(t, e) {
            return this.map.set(t, e), e;
        }
    }
    const Ye = 1, Xe = 2, Ke = 4, Qe = 8, tn = () => 1e3 * new Date;
    function en(t, e, n) {
        const r = {};
        return n & Ye ? r.atime = t : n & Xe && (r.atime = tn()), n & Ke ? r.mtime = e : n & Qe && (r.mtime = tn()), 
        r;
    }
    const nn = {
        name: "",
        mixins: []
    };
    function rn(t) {
        return nn.mixins.includes(t) || nn.mixins.push(t), t;
    }
    function sn() {
        return function(t, e) {
            const n = [], r = function() {
                for (const t of n) t.call(this);
            }, {prototype: s} = r;
            ve(r, "name", Ae(t));
            for (const t of e) for (let [e, r] of Object.entries(t)) if ("init" === e) n.push(r); else {
                if ("function" == typeof r) ; else {
                    let t = s[e];
                    if (void 0 !== t) if (t?.constructor === Object) r = Object.assign({
                        ...t
                    }, r); else if (t !== r) throw new Error(`Duplicate property: ${e}`);
                }
                ve(s, e, Ae(r));
            }
            return r;
        }(nn.name, nn.mixins);
    }
    function on(t, e, n) {
        if (t + e <= 8) {
            const r = 2 ** e - 1;
            if (n) return function(e, n, s) {
                const i = n.getUint8(s) >> t & r;
                e.setUint8(0, i);
            };
            {
                const e = 255 ^ r << t;
                return function(n, s, i) {
                    const o = s.getUint8(0), c = n.getUint8(i) & e | (o & r) << t;
                    n.setUint8(i, c);
                };
            }
        }
        {
            const r = 8 - t, s = 2 ** r - 1;
            if (n) {
                const n = 2 ** (e % 8) - 1;
                return function(i, o, c) {
                    let a, l = c, u = 0, f = o.getUint8(l++), h = f >> t & s, d = r, g = e;
                    do {
                        g > d && (f = o.getUint8(l++), h |= f << d), a = g >= 8 ? 255 & h : h & n, i.setUint8(u++, a), 
                        h >>= 8, g -= 8;
                    } while (g > 0);
                };
            }
            {
                const n = 2 ** ((e - r) % 8) - 1, i = 255 ^ s << t, o = 255 ^ n;
                return function(r, s, c) {
                    let a, l, u = 0, f = c, h = r.getUint8(f), d = h & i, g = t, p = e + g;
                    do {
                        p > g && (a = s.getUint8(u++), d |= a << g, g += 8), p >= 8 ? l = 255 & d : (h = r.getUint8(f), 
                        l = h & o | d & n), r.setUint8(f++, l), d >>= 8, g -= 8, p -= 8;
                    } while (p > 0);
                };
            }
        }
    }
    rn({
        init() {
            this.accessorCache = new Map;
        },
        getAccessor(t, e) {
            const {type: n, bitSize: r, bitOffset: s, byteSize: i} = e, o = [], c = void 0 === i && (7 & r || 7 & s);
            c && o.push("Unaligned");
            let a = W[n];
            r > 32 && (n === R.Int || n === R.Uint) && (a = r <= 64 ? `Big${a}` : `Jumbo${a}`), 
            o.push(a, `${n === R.Bool && i ? 8 * i : r}`), c && o.push(`@${s}`);
            const l = t + o.join("");
            let u = DataView.prototype[l];
            if (u && this.usingBufferFallback()) {
                const e = this, s = u, i = function(t) {
                    const {buffer: e, byteOffset: n, byteLength: s} = this, i = e[ie];
                    if (i) {
                        if (t < 0 || t + r / 8 > s) throw new RangeError("Offset is outside the bounds of the DataView");
                        return i + Ce(n + t);
                    }
                };
                u = "get" === t ? function(t, o) {
                    const c = i.call(this, t);
                    return void 0 !== c ? e.getNumericValue(n, r, c) : s.call(this, t, o);
                } : function(t, o, c) {
                    const a = i.call(this, t);
                    return void 0 !== a ? e.setNumericValue(n, r, a, o) : s.call(this, t, o, c);
                };
            }
            if (u) return u;
            if (u = this.accessorCache.get(l), u) return u;
            for (;o.length > 0; ) {
                const n = `getAccessor${o.join("")}`;
                if (u = this[n]?.(t, e)) break;
                o.pop();
            }
            if (!u) throw new Error(`No accessor available: ${l}`);
            return ve(u, "name", Ae(l)), this.accessorCache.set(l, u), u;
        },
        imports: {
            getNumericValue: null,
            setNumericValue: null
        }
    }), rn({
        getAccessorBigInt(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n - 1), s = r - 1n;
            return "get" === t ? function(t, e) {
                const n = this.getBigUint64(t, e);
                return (n & s) - (n & r);
            } : function(t, e, n) {
                const i = e < 0 ? r | e & s : e & s;
                this.setBigUint64(t, i, n);
            };
        }
    }), rn({
        getAccessorBigUint(t, e) {
            const {bitSize: n} = e, r = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return this.getBigInt64(t, e) & r;
            } : function(t, e, n) {
                const s = e & r;
                this.setBigUint64(t, s, n);
            };
        }
    }), rn({
        getAccessorBool(t, e) {
            const {byteSize: n} = e, r = 8 * n, s = this.getAccessor(t, {
                type: R.Uint,
                bitSize: r,
                byteSize: n
            });
            if ("get" === t) return function(t, e) {
                return !!s.call(this, t, e);
            };
            {
                const t = r <= 32 ? 0 : 0n, e = r <= 32 ? 1 : 1n;
                return function(n, r, i) {
                    s.call(this, n, r ? e : t, i);
                };
            }
        }
    }), rn({
        getAccessorFloat128(t, e) {
            const {byteSize: n} = e, r = Ze(8), s = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n | BigInt(this.getUint32(t + (e ? 12 : n - 16), e)) << 96n;
            }, i = function(t, e, r) {
                const s = 0xffffffffn & e, i = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn, c = e >> 96n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(s), r), this.setUint32(t + (r ? 4 : n - 8), Number(i), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r), this.setUint32(t + (r ? 12 : n - 16), Number(c), r);
            };
            return "get" === t ? function(t, e) {
                const n = s.call(this, t, e), i = n >> 127n, o = (0x7fff0000000000000000000000000000n & n) >> 112n, c = 0x0000ffffffffffffffffffffffffffffn & n;
                if (0n === o) {
                    const t = c ? Number.MIN_VALUE : 0;
                    return i ? -t : t;
                }
                if (0x7fffn === o) return c ? NaN : i ? -1 / 0 : 1 / 0;
                const a = o - 16383n + 1023n;
                if (a >= 2047n) {
                    const t = 1 / 0;
                    return i ? -t : t;
                }
                const l = i << 63n | a << 52n | (c >> 60n) + BigInt((c & 2n ** 60n - 1n) >= 2n ** 59n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const s = r.getBigUint64(0, n), o = s >> 63n, c = (0x7ff0000000000000n & s) >> 52n, a = 0x000fffffffffffffn & s;
                let l;
                l = 0n === c ? o << 127n | a << 60n : 0x07ffn === c ? o << 127n | 0x7fffn << 112n | (a ? 1n : 0n) : o << 127n | c - 1023n + 16383n << 112n | a << 60n, 
                i.call(this, t, l, n);
            };
        }
    }), rn({
        getAccessorFloat16(t, e) {
            const n = Ze(4), r = DataView.prototype.setUint16, s = DataView.prototype.getUint16;
            return "get" === t ? function(t, e) {
                const r = s.call(this, t, e), i = r >>> 15, o = (31744 & r) >> 10, c = 1023 & r;
                if (0 === o) return i ? -0 : 0;
                if (31 === o) return c ? NaN : i ? -1 / 0 : 1 / 0;
                const a = i << 31 | o - 15 + 127 << 23 | c << 13;
                return n.setUint32(0, a, e), n.getFloat32(0, e);
            } : function(t, e, s) {
                n.setFloat32(0, e, s);
                const i = n.getUint32(0, s), o = i >>> 31, c = (2139095040 & i) >> 23, a = 8388607 & i, l = c - 127 + 15;
                let u;
                u = 0 === c ? o << 15 : 255 === c ? o << 15 | 31744 | (a ? 1 : 0) : l >= 31 ? o << 15 | 31744 : o << 15 | l << 10 | a >> 13, 
                r.call(this, t, u, s);
            };
        }
    }), rn({
        getAccessorFloat80(t, e) {
            const {byteSize: n} = e, r = Ze(8), s = function(t, e) {
                return BigInt(this.getUint32(t + (e ? 0 : n - 4), e)) | BigInt(this.getUint32(t + (e ? 4 : n - 8), e)) << 32n | BigInt(this.getUint32(t + (e ? 8 : n - 12), e)) << 64n;
            }, i = function(t, e, r) {
                const s = 0xffffffffn & e, i = e >> 32n & 0xffffffffn, o = e >> 64n & 0xffffffffn;
                this.setUint32(t + (r ? 0 : n - 4), Number(s), r), this.setUint32(t + (r ? 4 : n - 8), Number(i), r), 
                this.setUint32(t + (r ? 8 : n - 12), Number(o), r);
            };
            return "get" === t ? function(t, e) {
                const n = s.call(this, t, e), i = n >> 79n, o = (0x7fff0000000000000000n & n) >> 64n, c = 0x00007fffffffffffffffn & n;
                if (0n === o) {
                    const t = c ? Number.MIN_VALUE : 0;
                    return i ? -t : t;
                }
                if (0x7fffn === o) return c ? NaN : i ? -1 / 0 : 1 / 0;
                const a = o - 16383n + 1023n;
                if (a >= 2047n) {
                    const t = 1 / 0;
                    return i ? -t : t;
                }
                const l = i << 63n | a << 52n | (c >> 11n) + BigInt((c & 2n ** 11n - 1n) >= 2n ** 10n);
                return r.setBigUint64(0, l, e), r.getFloat64(0, e);
            } : function(t, e, n) {
                r.setFloat64(0, e, n);
                const s = r.getBigUint64(0, n), o = s >> 63n, c = (0x7ff0000000000000n & s) >> 52n, a = 0x000fffffffffffffn & s;
                let l;
                l = 0n === c ? o << 79n | a << 11n : 0x07ffn === c ? o << 79n | 0x7fffn << 64n | (a ? 0x00002000000000000000n : 0n) | 0x00008000000000000000n : o << 79n | c - 1023n + 16383n << 64n | a << 11n | 0x00008000000000000000n, 
                i.call(this, t, l, n);
            };
        }
    }), rn({
        getAccessorInt(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const e = this.getAccessor(t, {
                    type: R.Uint,
                    bitSize: 8 * r,
                    byteSize: r
                }), s = 2 ** (n - 1), i = s - 1;
                return "get" === t ? function(t, n) {
                    const r = e.call(this, t, n);
                    return (r & i) - (r & s);
                } : function(t, n, r) {
                    const o = n < 0 ? s | n & i : n & i;
                    e.call(this, t, o, r);
                };
            }
        }
    }), rn({
        getAccessorJumboInt(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), s = 2n ** BigInt(n - 1), i = s - 1n;
            return "get" === t ? function(t, e) {
                const n = r.call(this, t, e);
                return (n & i) - (n & s);
            } : function(t, e, n) {
                const o = e < 0 ? s | e & i : e & i;
                r.call(this, t, o, n);
            };
        }
    }), rn({
        getAccessorJumboUint(t, e) {
            const {bitSize: n} = e, r = this.getJumboAccessor(t, n), s = 2n ** BigInt(n) - 1n;
            return "get" === t ? function(t, e) {
                return r.call(this, t, e) & s;
            } : function(t, e, n) {
                const i = e & s;
                r.call(this, t, i, n);
            };
        }
    }), rn({
        getJumboAccessor(t, e) {
            const n = e + 63 >> 6;
            return "get" === t ? function(t, e) {
                let r = 0n;
                if (e) for (let s = 0, i = t + 8 * (n - 1); s < n; s++, i -= 8) {
                    r = r << 64n | this.getBigUint64(i, e);
                } else for (let s = 0, i = t; s < n; s++, i += 8) {
                    r = r << 64n | this.getBigUint64(i, e);
                }
                return r;
            } : function(t, e, r) {
                let s = e;
                const i = 0xffffffffffffffffn;
                if (r) for (let e = 0, o = t; e < n; e++, o += 8) {
                    const t = s & i;
                    this.setBigUint64(o, t, r), s >>= 64n;
                } else for (let e = 0, o = t + 8 * (n - 1); e < n; e++, o -= 8) {
                    const t = s & i;
                    this.setBigUint64(o, t, r), s >>= 64n;
                }
            };
        }
    }), rn({
        getAccessorUint(t, e) {
            const {bitSize: n, byteSize: r} = e;
            if (r) {
                const s = this.getAccessor(t, {
                    ...e,
                    bitSize: 8 * r
                }), i = 2 ** n - 1;
                return "get" === t ? function(t, e) {
                    return s.call(this, t, e) & i;
                } : function(t, e, n) {
                    const r = e & i;
                    s.call(this, t, r, n);
                };
            }
        }
    }), rn({
        getAccessorUnalignedBool1(t, e) {
            const {bitOffset: n} = e, r = 1 << (7 & n);
            return "get" === t ? function(t) {
                return !!(this.getInt8(t) & r);
            } : function(t, e) {
                const n = this.getInt8(t), s = e ? n | r : n & ~r;
                this.setInt8(t, s);
            };
        }
    }), rn({
        getAccessorUnalignedInt(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r;
            if (s + n <= 8) {
                const e = 2 ** (n - 1), r = e - 1;
                if ("get" === t) return function(t) {
                    const n = this.getUint8(t) >>> s;
                    return (n & r) - (n & e);
                };
                {
                    const t = 255 ^ (r | e) << s;
                    return function(n, i) {
                        let o = this.getUint8(n);
                        o = o & t | (i < 0 ? e | i & r : i & r) << s, this.setUint8(n, o);
                    };
                }
            }
        }
    }), rn({
        getAccessorUnalignedUint(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r;
            if (s + n <= 8) {
                const e = 2 ** n - 1;
                if ("get" === t) return function(t) {
                    return this.getUint8(t) >>> s & e;
                };
                {
                    const t = 255 ^ e << s;
                    return function(n, r) {
                        const i = this.getUint8(n) & t | (r & e) << s;
                        this.setUint8(n, i);
                    };
                }
            }
        }
    }), rn({
        getAccessorUnaligned(t, e) {
            const {bitSize: n, bitOffset: r} = e, s = 7 & r, i = [ 1, 2, 4, 8 ].find((t => 8 * t >= n)) ?? 64 * Math.ceil(n / 64), o = Ze(i);
            if ("get" === t) {
                const t = this.getAccessor("get", {
                    ...e,
                    byteSize: i
                }), r = on(s, n, !0);
                return function(e, n) {
                    return r(o, this, e), t.call(o, 0, n);
                };
            }
            {
                const t = this.getAccessor("set", {
                    ...e,
                    byteSize: i
                }), r = on(s, n, !1);
                return function(e, n, s) {
                    t.call(o, 0, n, s), r(this, o, e);
                };
            }
        }
    });
    class InvalidIntConversion extends SyntaxError {
        constructor(t) {
            super(`Cannot convert ${t} to an Int`);
        }
    }
    class Unsupported extends TypeError {
        constructor() {
            super("Unsupported");
        }
    }
    class NoInitializer extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`An initializer must be provided to the constructor of ${e}, even when the intended value is undefined`);
        }
    }
    class BufferSizeMismatch extends TypeError {
        constructor(t, n, r = null) {
            const {name: s, type: i, byteSize: o} = t, c = n.byteLength, a = 1 !== o ? "s" : "";
            let l;
            if (i !== e.Slice || r) {
                l = `${s} has ${i === e.Slice ? r.length * o : o} byte${a}, received ${c}`;
            } else l = `${s} has elements that are ${o} byte${a} in length, received ${c}`;
            super(l);
        }
    }
    class BufferExpected extends TypeError {
        constructor(t) {
            const {type: n, byteSize: r, typedArray: s} = t, i = 1 !== r ? "s" : "", o = [ "ArrayBuffer", "DataView" ].map(yn);
            let c;
            s && o.push(yn(s.name)), c = n === e.Slice ? `Expecting ${mn(o)} that can accommodate items ${r} byte${i} in length` : `Expecting ${mn(o)} that is ${r} byte${i} in length`, 
            super(c);
        }
    }
    class EnumExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            r = "number" == typeof e || "bigint" == typeof e ? `Value given does not correspond to an item of enum ${n}: ${e}` : `Enum item of the type ${n} expected, received ${e}`, 
            super(r);
        }
    }
    class ErrorExpected extends TypeError {
        constructor(t, e) {
            const {name: n} = t, r = typeof e;
            let s;
            "string" === r || "number" === r || gn(e) ? (gn(e) && (e = `{ error: ${JSON.stringify(e.error)} }`), 
            s = `Error ${r} does not corresponds to any error in error set ${n}: ${e}`) : s = `Error of the type ${n} expected, received ${e}`, 
            super(s);
        }
    }
    class NotInErrorSet extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Error given is not a part of error set ${e}`);
        }
    }
    class MultipleUnionInitializers extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Only one property of ${e} can be given a value`);
        }
    }
    class InactiveUnionProperty extends TypeError {
        constructor(t, e, n) {
            super(`Accessing property ${e} when ${n} is active`);
        }
    }
    class MissingUnionInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r, instance: {members: s}} = t;
            super(`${r} needs an initializer for one of its union properties: ${s.slice(0, n ? -1 : void 0).map((t => t.name)).join(", ")}`);
        }
    }
    class InvalidInitializer extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t, s = [];
            if (Array.isArray(e)) for (const t of e) s.push(yn(t)); else s.push(yn(e));
            const i = pn(n);
            super(`${r} expects ${mn(s)} as argument, received ${i}`);
        }
    }
    class InvalidArrayInitializer extends InvalidInitializer {
        constructor(t, n, r = !1) {
            const {instance: {members: [s]}, type: i, constructor: o} = t, c = [], a = xe(s);
            if (a) {
                let t;
                switch (s.structure?.type) {
                  case e.Enum:
                    t = "enum item";
                    break;

                  case e.ErrorSet:
                    t = "error";
                    break;

                  default:
                    t = a;
                }
                c.push(`array of ${t}s`);
            } else c.push("array of objects");
            o[te] && c.push(o[te].name), i === e.Slice && r && c.push("length"), super(t, c.join(" or "), n);
        }
    }
    class InvalidEnumValue extends TypeError {
        code=ct;
        constructor(t, e) {
            super(`Received '${e}', which is not among the following possible values:\n\n${Object.keys(t).map((t => `${t}\n`)).join("")}`);
        }
    }
    class ArrayLengthMismatch extends TypeError {
        constructor(t, e, n) {
            const {name: r, length: s, instance: {members: [i]}} = t, {structure: {constructor: o}} = i, {length: c, constructor: a} = n, l = e?.length ?? s, u = 1 !== l ? "s" : "";
            let f;
            f = a === o ? "only a single one" : a.child === o ? `a slice/array that has ${c}` : `${c} initializer${c > 1 ? "s" : ""}`, 
            super(`${r} has ${l} element${u}, received ${f}`);
        }
    }
    class InvalidSliceLength extends TypeError {
        constructor(t, e) {
            super(t < 0 ? "Length of slice cannot be negative" : `Length of slice can be ${e} or less, received ${t}`);
        }
    }
    class MissingInitializers extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Missing initializers for ${n}: ${e.join(", ")}`);
        }
    }
    class NoProperty extends TypeError {
        constructor(t, e) {
            const {name: n, instance: {members: r}} = t;
            let s;
            s = r.find((t => t.name === e)) ? `Comptime value cannot be changed: ${e}` : `${n} does not have a property with that name: ${e}`, 
            super(s);
        }
    }
    class ArgumentCountMismatch extends Error {
        constructor(t, e, n = !1) {
            super();
            const r = r => {
                e -= r;
                const s = 1 !== (t -= r) ? "s" : "", i = n ? "at least " : "";
                this.message = `Expecting ${i}${t} argument${s}, received ${e}`, this.stack = ln(this.stack, "new Arg(");
            };
            r(0), ve(this, ae, {
                value: r,
                enumerable: !1
            });
        }
    }
    class UndefinedArgument extends Error {
        constructor() {
            super("Undefined argument");
        }
    }
    class NoCastingToPointer extends TypeError {
        constructor() {
            super("Non-slice pointers can only be created with the help of the new operator");
        }
    }
    class NoCastingToFunction extends TypeError {
        constructor() {
            super("Casting to function is not allowed");
        }
    }
    class ConstantConstraint extends TypeError {
        constructor(t, e) {
            const {name: n} = t, {constructor: {name: r}} = e;
            super(`Conversion of ${r} to ${n} requires an explicit cast`);
        }
    }
    class MisplacedSentinel extends TypeError {
        constructor(t, e, n, r) {
            const {name: s} = t;
            super(`${s} expects the sentinel value ${e} at ${r - 1}, found at ${n}`);
        }
    }
    class MissingSentinel extends TypeError {
        constructor(t, e, n) {
            const {name: r} = t;
            super(`${r} expects the sentinel value ${e} at ${n - 1}`);
        }
    }
    class AlignmentConflict extends TypeError {
        constructor(t, e) {
            super(`Unable to simultaneously align memory to ${e}-byte and ${t}-byte boundary`);
        }
    }
    let cn = class TypeMismatch extends TypeError {
        constructor(t, e) {
            const n = pn(e);
            super(`Expected ${yn(t)}, received ${n}`);
        }
    };
    class InaccessiblePointer extends TypeError {
        constructor() {
            super("Pointers within an untagged union are not accessible");
        }
    }
    class NullPointer extends TypeError {
        constructor() {
            super("Null pointer");
        }
    }
    class PreviouslyFreed extends TypeError {
        constructor(t) {
            super(`Object has been freed already: ${t.constructor.name}`);
        }
    }
    class InvalidPointerTarget extends TypeError {
        constructor(t, e) {
            const {name: n} = t;
            let r;
            if (null != e) {
                const t = e instanceof Object && e.constructor !== Object ? `${e.constructor.name} object` : typeof e;
                r = `${bn(t)} ${t}`;
            } else r = e + "";
            super(`${n} cannot point to ${r}`);
        }
    }
    class ZigMemoryTargetRequired extends TypeError {
        constructor() {
            super("Pointers in Zig memory cannot point to garbage-collected object");
        }
    }
    class Overflow extends TypeError {
        constructor(t, e) {
            const {type: n, bitSize: r} = t;
            super(`${(r > 32 ? "Big" : "") + W[n] + r} cannot represent the value given: ${e}`);
        }
    }
    class OutOfBound extends RangeError {
        constructor(t, e) {
            const {name: n} = t;
            super(`Index exceeds the size of ${n ?? "array"}: ${e}`);
        }
    }
    class NotUndefined extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${void 0 !== e ? `Property ${e}` : "Element"} can only be undefined`);
        }
    }
    class NotOnByteBoundary extends TypeError {
        constructor(t) {
            const {name: e, structure: {name: n}} = t;
            super(`Unable to create ${n} as it is not situated on a byte boundary: ${e}`);
        }
    }
    class ReadOnly extends TypeError {
        constructor() {
            super("Unable to modify read-only object");
        }
    }
    class ReadOnlyTarget extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`${e} cannot point to a read-only object`);
        }
    }
    class AccessingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to access opaque structure ${e}`);
        }
    }
    class CreatingOpaque extends TypeError {
        constructor(t) {
            const {name: e} = t;
            super(`Unable to create instance of ${e}, as it is opaque`);
        }
    }
    class InvalidVariadicArgument extends TypeError {
        constructor() {
            super("Arguments passed to variadic function must be casted to a Zig type");
        }
    }
    class UnexpectedGenerator extends TypeError {
        constructor() {
            super("Unexpected async generator");
        }
    }
    class InvalidFileDescriptor extends Error {
        code=rt;
        constructor() {
            super("Invalid file descriptor");
        }
    }
    class InvalidArgument extends Error {
        code=ct;
        constructor() {
            super("Invalid argument");
        }
    }
    class Deadlock extends Error {
        code=st;
        constructor() {
            super("Unable to await promise");
        }
    }
    class MissingEventListener extends Error {
        constructor(t, e) {
            super(`Missing event listener: ${t}`), this.code = e;
        }
    }
    class ZigError extends Error {
        constructor(t, e = 0) {
            if (t instanceof Error) return super(t.message), t.stack = ln(this.stack, e), t;
            super(t ?? "Error encountered in Zig code");
        }
    }
    function an(t, e) {
        const n = n => {
            e -= n, t.message = `args[${e}]: ${t.message}`, t.stack = ln(t.stack, "new Arg(");
        };
        return n(0), ve(t, ae, {
            value: n,
            enumerable: !1
        }), t;
    }
    function ln(t, e) {
        if ("string" == typeof t) {
            const n = t.split("\n"), r = n.findIndex((t => t.includes(e)));
            -1 !== r && (n.splice(1, r), t = n.join("\n"));
        }
        return t;
    }
    function un() {
        throw new ReadOnly;
    }
    function fn(t, e, n) {
        if (t.bytes += n, t.calls++, 100 === t.calls) {
            const n = t.bytes / t.calls;
            if (n < 8) {
                throw new Error(`Inefficient ${e} access. Each call is only ${"read" === e ? "reading" : "writing"} ${n} byte${1 !== n ? "s" : ""}. Please use std.io.Buffered${"read" === e ? "Reader" : "Writer"}.`);
            }
        }
    }
    function hn(t = !1, e, n, r, s) {
        const i = t => (s ? s(t) : console.error(t)) ?? t.code ?? e, o = t => {
            const e = r?.(t);
            return e ?? et;
        };
        try {
            const e = n();
            if (Pe(e)) {
                if (!t) throw new Deadlock;
                return e.then(o).catch(i);
            }
            return o(e);
        } catch (t) {
            return i(t);
        }
    }
    function dn(t, e) {
        if (!0 === t) return et;
        if (!1 === t) return e;
        throw new cn("boolean", t);
    }
    function gn(t) {
        return "object" == typeof t && "string" == typeof t.error && 1 === Object.keys(t).length;
    }
    function pn(t) {
        const e = typeof t;
        let n;
        return n = "object" === e ? t ? Object.prototype.toString.call(t) : "null" : e, 
        yn(n);
    }
    function yn(t) {
        return `${bn(t)} ${t}`;
    }
    function bn(t) {
        return /^\W*[aeiou]/i.test(t) ? "an" : "a";
    }
    function mn(t, e = "or") {
        const n = ` ${e} `;
        return t.length > 2 ? t.slice(0, -1).join(", ") + n + t[t.length - 1] : t.join(n);
    }
    function wn(t) {
        let n, r = 1, s = null;
        if (t instanceof DataView) {
            n = t;
            const e = n?.[Mt]?.align;
            e && (r = e);
        } else if (t instanceof ArrayBuffer) n = new DataView(t); else if (t) if (t[At]) t.constructor[Vt] === e.Pointer && (t = t["*"]), 
        n = t[At], s = t.constructor, r = s[Jt]; else {
            "string" == typeof t && (t = Ee(t));
            const {buffer: e, byteOffset: s, byteLength: i, BYTES_PER_ELEMENT: o} = t;
            e && void 0 !== s && void 0 !== i && (n = new DataView(e, s, i), r = o);
        }
        return {
            dv: n,
            align: r,
            constructor: s
        };
    }
    rn({
        defineAlloc: () => ({
            value(t, e = 1) {
                const n = Math.clz32(e);
                if (e !== 1 << 31 - n) throw new Error(`Invalid alignment: ${e}`);
                const r = 31 - n, {vtable: {alloc: s}, ptr: i} = this, o = s(i, t, r, 0);
                if (!o) throw new Error("Out of memory");
                o.length = t;
                const c = o["*"][At];
                return c[Mt].align = e, c;
            }
        }),
        defineFree() {
            const t = this;
            return {
                value(e) {
                    const {dv: n, align: r} = wn(e), s = n?.[Mt];
                    if (!s) throw new cn("object containing allocated Zig memory", e);
                    const {address: i} = s;
                    if (-1 === i) throw new PreviouslyFreed(e);
                    const {vtable: {free: o}, ptr: c} = this;
                    o(c, n, 31 - Math.clz32(r), 0), t.releaseZigView(n);
                }
            };
        },
        defineDupe() {
            const t = this.getCopyFunction();
            return {
                value(e) {
                    const {dv: n, align: r, constructor: s} = wn(e);
                    if (!n) throw new cn("string, DataView, typed array, or Zig object", e);
                    const i = this.alloc(n.byteLength, r);
                    return t(i, n), s ? s(i) : i;
                }
            };
        }
    }), rn({
        init() {
            this.variables = [], this.listenerMap = new Map([ [ "log", t => console.log(t.message) ] ]);
        },
        getSpecialExports() {
            const t = t => {
                if (void 0 === t) throw new Error("Not a Zig type");
                return t;
            };
            return {
                init: (...t) => this.initialize?.(...t),
                abandon: () => this.abandonModule?.(),
                redirect: (t, e) => this.redirectStream(t, e),
                sizeOf: e => t(e?.[Zt]),
                alignOf: e => t(e?.[Jt]),
                typeOf: e => vn[t(e?.[Vt])],
                on: (t, e) => this.addListener(t, e)
            };
        },
        addListener(t, e) {
            this.listenerMap.set(t, e), [ "mkdir", "stat", "set_times", "open", "rmdir", "unlink" ].includes(t) && this.setRedirectionMask(t, !!e);
        },
        triggerEvent(t, e, n) {
            const r = this.listenerMap.get(t);
            if (r) return r(e);
            if (n) throw new MissingEventListener(t, n);
        },
        recreateStructures(t, e) {
            Object.assign(this, e);
            const n = (t, e) => {
                for (const [n, r] of Object.entries(e)) t[n] = s(r);
                return t;
            }, r = t => t.length ? t.buffer : new ArrayBuffer(0), s = t => {
                const {memory: e, structure: s, actual: i} = t;
                if (e) {
                    if (i) return i;
                    {
                        const {array: i, offset: o, length: c} = e, a = this.obtainView(r(i), o, c), {handle: l, const: u} = t, f = s?.constructor, h = t.actual = f.call(Ht, a);
                        return u && this.makeReadOnly(h), t.slots && n(h[It], t.slots), l && this.variables.push({
                            handle: l,
                            object: h
                        }), h;
                    }
                }
                return s;
            }, i = new Map;
            for (const e of t) {
                for (const t of [ e.instance, e.static ]) if (t.template) {
                    const {slots: e, memory: n, handle: s} = t.template, o = t.template = {};
                    if (n) {
                        const {array: t, offset: e, length: i} = n;
                        o[At] = this.obtainView(r(t), e, i), s && this.variables.push({
                            handle: s,
                            object: o
                        });
                    }
                    if (e) {
                        const t = o[It] = {};
                        i.set(t, e);
                    }
                }
                this.defineStructure(e);
            }
            for (const [t, e] of i) n(t, e);
            for (const e of t) this.finalizeStructure(e);
        }
    });
    const vn = f.map((t => t.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase()));
    rn({
        init() {
            this.jsFunctionThunkMap = new Map, this.jsFunctionCallerMap = new Map, this.jsFunctionControllerMap = new Map, 
            this.jsFunctionIdMap = new WeakMap, this.jsFunctionNextId = 1;
        },
        getFunctionId(t) {
            let e = this.jsFunctionIdMap.get(t);
            return void 0 === e && (e = this.jsFunctionNextId++, this.jsFunctionIdMap.set(t, e)), 
            e;
        },
        getFunctionThunk(t, e) {
            const n = this.getFunctionId(t);
            let r = this.jsFunctionThunkMap.get(n);
            if (void 0 === r) {
                const t = this.getViewAddress(e[At]), s = this.createJsThunk(t, n);
                if (!s) throw new Error("Unable to create function thunk");
                r = this.obtainZigView(s, 0), this.jsFunctionThunkMap.set(n, r), this.jsFunctionControllerMap.set(n, e);
            }
            return r;
        },
        createInboundCaller(t, e) {
            const n = this.getFunctionId(t);
            return this.jsFunctionCallerMap.set(n, ((n, r) => {
                try {
                    const s = e(n);
                    if (fe in s) {
                        s[fe]("reset");
                        const t = this.startContext();
                        this.updatePointerTargets(t, s, !0), this.updateShadowTargets(t), this.endContext();
                    }
                    const i = s.hasOwnProperty(me), o = hn(r || i, ot, (() => t(...s)), (t => {
                        if (t?.[Symbol.asyncIterator]) {
                            if (!s.hasOwnProperty(we)) throw new UnexpectedGenerator;
                            this.pipeContents(t, s);
                        } else s[me](t);
                    }), (t => {
                        try {
                            if (e[ee] && t instanceof Error) return s[me](t), et;
                            throw t;
                        } catch (e) {
                            console.error(t);
                        }
                    }));
                    return i ? et : o;
                } catch (t) {
                    return console.error(t), ot;
                }
            })), function(...e) {
                return t(...e);
            };
        },
        defineArgIterator(t) {
            const o = this, c = t.filter((({structure: t}) => t.type === e.Struct && t.purpose === i)).length;
            return {
                value() {
                    let a, l = 0, u = 0, f = 0;
                    const h = [];
                    for (const [d, {structure: g, type: p}] of t.entries()) try {
                        let t, y, b = this[d];
                        if (p === R.Object && b?.[At]?.[Mt] && (b = new b.constructor(b)), g.type === e.Struct) switch (g.purpose) {
                          case i:
                            t = 1 === c ? "allocator" : "allocator" + ++l, y = this[se] = b;
                            break;

                          case n:
                            t = "callback", 1 == ++u && (y = o.createPromiseCallback(this, b));
                            break;

                          case r:
                            t = "callback", 1 == ++u && (y = o.createGeneratorCallback(this, b));
                            break;

                          case s:
                            t = "signal", 1 == ++f && (y = o.createInboundSignal(b));
                        }
                        void 0 !== t ? void 0 !== y && (a ||= {}, a[t] = y) : h.push(b);
                    } catch (t) {
                        h.push(t);
                    }
                    return a && h.push(a), h[Symbol.iterator]();
                }
            };
        },
        handleJscall(t, e, n, r) {
            const s = this.obtainZigView(e, n, !1), i = this.jsFunctionCallerMap.get(t);
            return i ? i(s, r) : ot;
        },
        releaseFunction(t) {
            const e = this.jsFunctionThunkMap.get(t), n = this.jsFunctionControllerMap.get(t);
            if (e && n) {
                const r = this.getViewAddress(n[At]), s = this.getViewAddress(e);
                this.destroyJsThunk(r, s), this.releaseZigView(e), t && (this.jsFunctionThunkMap.delete(t), 
                this.jsFunctionCallerMap.delete(t), this.jsFunctionControllerMap.delete(t));
            }
        },
        freeFunction(t) {
            this.releaseFunction(this.getFunctionId(t));
        },
        exports: {
            handleJscall: {
                async: !0
            },
            releaseFunction: {}
        },
        imports: {
            createJsThunk: {},
            destroyJsThunk: {},
            finalizeAsyncCall: {}
        }
    }), rn({
        createOutboundCaller(t, e) {
            const n = this, r = function(...s) {
                const i = new e(s, this?.[se]);
                return n.invokeThunk(t, r, i);
            };
            return r;
        },
        copyArguments(t, o, f, h, d) {
            let g = 0, p = 0, y = 0;
            const b = t[Qt];
            for (const {type: m, structure: w} of f) {
                let f, v, S, A;
                if (w.type === e.Struct) switch (w.purpose) {
                  case i:
                    f = (1 == ++y ? h?.allocator ?? h?.allocator1 : h?.[`allocator${y}`]) ?? this.createDefaultAllocator(t, w);
                    break;

                  case n:
                    v ||= this.createPromise(w, t, h?.callback), f = v;
                    break;

                  case r:
                    S ||= this.createGenerator(w, t, h?.callback), f = S;
                    break;

                  case s:
                    A ||= this.createSignal(w, h?.signal), f = A;
                    break;

                  case c:
                    f = this.createReader(o[p++]);
                    break;

                  case a:
                    f = this.createWriter(o[p++]);
                    break;

                  case l:
                    f = this.createFile(o[p++]);
                    break;

                  case u:
                    f = this.createDirectory(o[p++]);
                }
                if (void 0 === f && (f = o[p++], void 0 === f && m !== R.Void)) throw new UndefinedArgument;
                try {
                    b[g++].call(t, f, d);
                } catch (t) {
                    throw an(t, g - 1);
                }
            }
        },
        invokeThunk(t, e, n) {
            const r = this.startContext(), s = n[Yt], i = this.getViewAddress(t[At]), o = this.getViewAddress(e[At]), c = ye in n, a = fe in n;
            a && this.updatePointerAddresses(r, n);
            const l = this.getViewAddress(n[At]), u = s ? this.getViewAddress(s[At]) : 0;
            this.updateShadows(r);
            const f = () => {
                this.updateShadowTargets(r), a && this.updatePointerTargets(r, n), this.flushStreams?.(), 
                this.endContext();
            };
            c && (n[ye] = f);
            if (!(s ? this.runVariadicThunk(i, o, l, u, s.length) : this.runThunk(i, o, l))) throw f(), 
            new ZigError;
            if (c) {
                let t = null;
                try {
                    t = n.retval;
                } catch (e) {
                    t = new ZigError(e, 1);
                }
                return null != t ? (e[ce] && t && (t = t.string), n[me](t)) : e[ce] && (n[ce] = !0), 
                n[ne] ?? n[re];
            }
            f();
            try {
                const {retval: t} = n;
                return e[ce] && t ? t.string : t;
            } catch (t) {
                throw new ZigError(t, 1);
            }
        },
        imports: {
            runThunk: null,
            runVariadicThunk: null
        }
    }), rn({
        init() {
            const t = {
                type: R.Int,
                bitSize: 8,
                byteSize: 1
            }, e = {
                type: R.Int,
                bitSize: 16,
                byteSize: 2
            }, n = {
                type: R.Int,
                bitSize: 32,
                byteSize: 4
            }, r = this.getAccessor("get", t), s = this.getAccessor("set", t), i = this.getAccessor("get", e), o = this.getAccessor("set", e), c = this.getAccessor("get", n), a = this.getAccessor("set", n);
            this.copiers = {
                0: He,
                1: function(t, e) {
                    s.call(t, 0, r.call(e, 0));
                },
                2: function(t, e) {
                    o.call(t, 0, i.call(e, 0, !0), !0);
                },
                4: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0);
                },
                8: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0), a.call(t, 4, c.call(e, 4, !0), !0);
                },
                16: function(t, e) {
                    a.call(t, 0, c.call(e, 0, !0), !0), a.call(t, 4, c.call(e, 4, !0), !0), a.call(t, 8, c.call(e, 8, !0), !0), 
                    a.call(t, 12, c.call(e, 12, !0), !0);
                },
                any: function(t, e) {
                    let n = 0, i = t.byteLength;
                    for (;n + 4 <= i; ) a.call(t, n, c.call(e, n, !0), !0), n += 4;
                    for (;n + 1 <= i; ) s.call(t, n, r.call(e, n)), n++;
                }
            }, this.resetters = {
                0: He,
                1: function(t, e) {
                    s.call(t, e, 0);
                },
                2: function(t, e) {
                    o.call(t, e, 0, !0);
                },
                4: function(t, e) {
                    a.call(t, e, 0, !0);
                },
                8: function(t, e) {
                    a.call(t, e + 0, 0, !0), a.call(t, e + 4, 0, !0);
                },
                16: function(t, e) {
                    a.call(t, e + 0, 0, !0), a.call(t, e + 4, 0, !0), a.call(t, e + 8, 0, !0), a.call(t, e + 12, 0, !0);
                },
                any: function(t, e, n) {
                    let r = e;
                    for (;r + 4 <= n; ) a.call(t, r, 0, !0), r += 4;
                    for (;r + 1 <= n; ) s.call(t, r, 0), r++;
                }
            };
        },
        defineCopier(t, e) {
            const n = this.getCopyFunction(t, e);
            return {
                value(t) {
                    const e = t[At], r = this[At];
                    n(r, e);
                }
            };
        },
        defineResetter(t, e) {
            const n = this.getResetFunction(e);
            return {
                value() {
                    const r = this[At];
                    n(r, t, e);
                }
            };
        },
        getCopyFunction(t, e = !1) {
            return (e ? void 0 : this.copiers[t]) ?? this.copiers.any;
        },
        getResetFunction(t) {
            return this.resetters[t] ?? this.resetters.any;
        },
        imports: {
            moveExternBytes: {}
        }
    }), rn({
        convertDirectory(t) {
            if (t instanceof Map) return new MapDirectory(t);
            if (_e(t, "readdir")) return t;
            throw new cn("map or object with directory interface", t);
        }
    });
    class MapDirectory {
        onClose=null;
        keys=null;
        cookie=0n;
        constructor(t) {
            this.map = t, t.close = () => this.onClose?.();
        }
        readdir() {
            const t = Number(this.cookie);
            let e;
            switch (t) {
              case 0:
              case 1:
                e = {
                    name: ".".repeat(t + 1),
                    type: "directory"
                };
                break;

              default:
                this.keys || (this.keys = [ ...this.map.keys() ]);
                const n = this.keys[t - 2];
                if (void 0 === n) return null;
                e = {
                    name: n,
                    ...this.map.get(n)
                };
            }
            return this.cookie++, e;
        }
        seek(t) {
            return this.cookie = t;
        }
        tell() {
            return this.cookie;
        }
        valueOf() {
            return this.map;
        }
    }
    function Sn(t, e) {
        return Oe(t, e, (t => t.address));
    }
    rn({
        addIntConversion: t => function(e, n) {
            const r = t.call(this, e, n), {flags: s, bitSize: i} = n;
            if ("set" === e) return i > 32 ? function(t, e, n) {
                r.call(this, t, BigInt(e), n);
            } : function(t, e, n) {
                const s = Number(e);
                if (!isFinite(s)) throw new InvalidIntConversion(e);
                r.call(this, t, s, n);
            };
            {
                const {flags: t} = n.structure;
                if (t & y && i > 32) {
                    const t = BigInt(Number.MAX_SAFE_INTEGER), e = BigInt(Number.MIN_SAFE_INTEGER);
                    return function(n, s) {
                        const i = r.call(this, n, s);
                        return e <= i && i <= t ? Number(i) : i;
                    };
                }
            }
            return r;
        }
    }), rn({
        init() {
            this.isMemoryMapping = !0, this.memoryList = [], this.contextCount = 0, this.externBufferList = [];
        },
        startContext() {
            return ++this.contextCount, {
                shadowList: []
            };
        },
        endContext() {
            if (0 == --this.contextCount) {
                for (const {shadowDV: t} of this.memoryList) t && this.freeShadowMemory(t);
                this.memoryList.splice(0);
            }
        },
        getShadowAddress(t, e, n, r) {
            const s = e[At];
            if (n) {
                if (void 0 === n.address) {
                    const {start: e, end: i, targets: o} = n;
                    let c, a = 0;
                    for (const t of o) {
                        const e = t[At], n = e.byteOffset, r = t.constructor[Jt] ?? e[Jt];
                        (void 0 === a || r > a) && (a = r, c = n);
                    }
                    const l = i - e, u = this.allocateShadowMemory(l + a, 1), f = this.getViewAddress(u), h = Be(ze(f, c - e), a), d = ze(h, e - c);
                    for (const t of o) {
                        const n = t[At], r = n.byteOffset;
                        if (r !== c) {
                            const s = t.constructor[Jt] ?? n[Jt];
                            if (ke(ze(d, r - e), s)) throw new AlignmentConflict(s, a);
                        }
                    }
                    const g = u.byteOffset + Number(d - f), p = new DataView(u.buffer, g, l), y = new DataView(s.buffer, Number(e), l), b = this.registerMemory(d, l, 1, r, y, p);
                    t.shadowList.push(b), n.address = d;
                }
                return ze(n.address, s.byteOffset - n.start);
            }
            {
                const n = e.constructor[Jt] ?? s[Jt], i = s.byteLength, o = this.allocateShadowMemory(i, n), c = this.getViewAddress(o), a = this.registerMemory(c, i, 1, r, s, o);
                return t.shadowList.push(a), c;
            }
        },
        updateShadows(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r} of t.shadowList) e(r, n);
        },
        updateShadowTargets(t) {
            const e = this.getCopyFunction();
            for (let {targetDV: n, shadowDV: r, writable: s} of t.shadowList) s && e(n, r);
        },
        registerMemory(t, e, n, r, s, i) {
            const o = Sn(this.memoryList, t);
            let c = this.memoryList[o - 1];
            return c?.address === t && c.len === e ? c.writable ||= r : (c = {
                address: t,
                len: e,
                align: n,
                writable: r,
                targetDV: s,
                shadowDV: i
            }, this.memoryList.splice(o, 0, c)), c;
        },
        unregisterMemory(t, e) {
            const n = Sn(this.memoryList, t), r = this.memoryList[n - 1];
            if (r?.address === t && r.len === e) return this.memoryList.splice(n - 1, 1), r;
        },
        findMemory(t, e, n, r) {
            let s = n * (r ?? 0);
            const i = Sn(this.memoryList, e), o = this.memoryList[i - 1];
            let c;
            if (o?.address === e && o.len === s) c = o.targetDV; else if (o?.address <= e && ze(e, s) <= ze(o.address, o.len)) {
                const t = Number(e - o.address), n = void 0 === r, {targetDV: i} = o;
                n && (s = i.byteLength - t), c = this.obtainView(i.buffer, i.byteOffset + t, s), 
                n && (c[Jt] = o.align);
            }
            if (c) {
                let {targetDV: e, shadowDV: n} = o;
                if (n && t && !t.shadowList.includes(o)) {
                    this.getCopyFunction()(e, n);
                }
            } else c = this.obtainZigView(e, s);
            return c;
        },
        findShadowView(t) {
            for (const {shadowDV: e, targetDV: n} of this.memoryList) if (n === t) return e;
        },
        releaseZigView(t) {
            const e = t[Mt], n = e?.address;
            n && -1 !== n && (e.address = -1, this.unregisterBuffer(ze(n, -t.byteOffset)));
        },
        getViewAddress(t) {
            const e = t[Mt];
            if (e) return e.address;
            {
                const e = this.getBufferAddress(t.buffer);
                return ze(e, t.byteOffset);
            }
        },
        obtainZigArray(t, e) {
            const n = this.obtainZigView(t, e, !1);
            return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        },
        ...{
            imports: {
                getBufferAddress: {},
                obtainExternBuffer: {}
            },
            exports: {
                getViewAddress: {}
            },
            allocateShadowMemory(t, e) {
                return this.allocateJSMemory(t, e);
            },
            freeShadowMemory(t) {},
            obtainZigView(t, e, n = !0) {
                if (function(t) {
                    return 2863311530 === t || -1431655766 === t;
                }(t) && (t = e > 0 ? 0 : $e), !t && e) return null;
                let r, s;
                if (n) {
                    const n = Sn(this.externBufferList, t), i = this.externBufferList[n - 1];
                    i?.address <= t && ze(t, e) <= ze(i.address, i.len) ? (r = i.buffer, s = Number(t - i.address)) : (r = e > 0 ? this.obtainExternBuffer(t, e, ie) : new ArrayBuffer(0), 
                    this.externBufferList.splice(n, 0, {
                        address: t,
                        len: e,
                        buffer: r
                    }), s = 0);
                } else r = e > 0 ? this.obtainExternBuffer(t, e, ie) : new ArrayBuffer(0), s = 0;
                return r[Mt] = {
                    address: t,
                    len: e
                }, this.obtainView(r, s, e);
            },
            unregisterBuffer(t) {
                const e = Sn(this.externBufferList, t), n = this.externBufferList[e - 1];
                n?.address === t && this.externBufferList.splice(e - 1, 1);
            },
            getTargetAddress(t, e, n, r) {
                const s = e[At];
                if (n) {
                    if (void 0 === n.misaligned) {
                        const t = this.getBufferAddress(s.buffer);
                        for (const e of n.targets) {
                            const r = e[At].byteOffset, s = e.constructor[Jt], i = ze(t, r);
                            if (ke(i, s)) {
                                n.misaligned = !0;
                                break;
                            }
                        }
                        void 0 === n.misaligned && (n.misaligned = !1, n.address = t);
                    }
                    if (!n.misaligned) return ze(n.address, s.byteOffset);
                } else {
                    const t = e.constructor[Jt], n = this.getViewAddress(s);
                    if (!ke(n, t)) {
                        const e = s.byteLength;
                        return this.registerMemory(n, e, t, r, s), n;
                    }
                }
                return this.getShadowAddress(t, e, n, r);
            }
        }
    }), rn({
        init() {
            this.abandoned = !1, this.destructors = [];
        },
        abandonModule() {
            if (!this.abandoned) {
                for (const t of this.destructors.reverse()) t();
                this.abandoned = !0;
            }
        },
        ...{
            imports: {
                loadModule: {}
            },
            exportFunctions() {
                const t = {};
                for (const [e, n] of Object.entries(this.exports)) {
                    const {async: r = !1} = n;
                    let s = this[e];
                    s && (r && (s = this.addPromiseHandling(s)), t[e] = s.bind(this));
                }
                return t;
            },
            addPromiseHandling(t) {
                const e = t.length - 1;
                return function(...n) {
                    const r = n[e], s = !!r;
                    n[e] = s;
                    const i = t.call(this, ...n);
                    return s ? (Pe(i) ? i.then((t => this.finalizeAsyncCall(r, t))) : this.finalizeAsyncCall(r, i), 
                    et) : i;
                };
            },
            importFunctions(t) {
                for (const [e] of Object.entries(this.imports)) {
                    const n = t[e];
                    n && (ve(this, e, Ae(n)), this.destructors.push((() => this[e] = An)));
                }
            }
        }
    });
    const An = () => {
        throw new Error("Module was abandoned");
    };
    rn({
        linkVariables(t) {
            const e = this.getCopyFunction();
            for (const {object: n, handle: r} of this.variables) {
                const s = n[At], i = this.recreateAddress(r);
                let o = n[At] = this.obtainZigView(i, s.byteLength);
                t && e(o, s), n.constructor[Wt]?.save?.(o, n), this.destructors.push((() => {
                    const t = n[At] = this.allocateMemory(o.bytelength);
                    e(t, o);
                }));
                const c = t => {
                    const e = t[It];
                    if (e) {
                        const t = o.byteOffset;
                        for (const n of Object.values(e)) if (n) {
                            const e = n[At];
                            if (e.buffer === s.buffer) {
                                const r = t + e.byteOffset - s.byteOffset;
                                n[At] = this.obtainView(o.buffer, r, e.byteLength), n.constructor[Wt]?.save?.(o, n), 
                                c(n);
                            }
                        }
                    }
                };
                c(n), n[fe]?.((function() {
                    this[ae]();
                }), tt.IgnoreInactive);
            }
        },
        imports: {
            recreateAddress: null
        }
    }), rn({
        updatePointerAddresses(t, e) {
            const n = new Map, r = new Map, s = [], i = function(t) {
                const e = this[$t];
                if (void 0 === n.get(e)) {
                    const t = e[It][0];
                    if (t) {
                        const o = {
                            target: t,
                            writable: !e.constructor.const
                        }, c = t[At];
                        if (c[Mt]) n.set(e, null); else {
                            n.set(e, t);
                            const a = r.get(c.buffer);
                            if (a) {
                                const t = Array.isArray(a) ? a : [ a ], e = Oe(t, c.byteOffset, (t => t.target[At].byteOffset));
                                t.splice(e, 0, o), Array.isArray(a) || (r.set(c.buffer, t), s.push(t));
                            } else r.set(c.buffer, o);
                            t[fe]?.(i, 0);
                        }
                    }
                }
            }, o = tt.IgnoreRetval | tt.IgnoreInactive;
            e[fe](i, o);
            const c = this.findTargetClusters(s), a = new Map;
            for (const t of c) for (const e of t.targets) a.set(e, t);
            for (const [e, r] of n) if (r) {
                const n = a.get(r), s = n?.writable ?? !e.constructor.const;
                e[Nt] = this.getTargetAddress(t, r, n, s), _t in e && (e[_t] = r.length);
            }
        },
        updatePointerTargets(t, e, n = !1) {
            const r = new Map, s = function(e) {
                const n = this[$t];
                if (!r.get(n)) {
                    r.set(n, !0);
                    const i = n[It][0], o = i && e & tt.IsImmutable ? i : n[ae](t, !0, !(e & tt.IsInactive)), c = n.constructor.const ? tt.IsImmutable : 0;
                    c & tt.IsImmutable || i && !i[At][Mt] && i[fe]?.(s, c), o !== i && o && !o[At][Mt] && o?.[fe]?.(s, c);
                }
            }, i = n ? tt.IgnoreRetval : 0;
            e[fe](s, i);
        },
        findTargetClusters(t) {
            const e = [];
            for (const n of t) {
                let t = null, r = 0, s = 0, i = null;
                for (const {target: o, writable: c} of n) {
                    const n = o[At], {byteOffset: a, byteLength: l} = n, u = a + l;
                    let f = !0;
                    t && (s > a ? (i ? i.writable ||= c : (i = {
                        targets: [ t ],
                        start: r,
                        end: s,
                        address: void 0,
                        misaligned: void 0,
                        writable: c
                    }, e.push(i)), i.targets.push(o), u > s ? i.end = u : f = !1) : i = null), f && (t = o, 
                    r = a, s = u);
                }
            }
            return e;
        }
    }), rn({
        convertReader(t) {
            if (t instanceof ReadableStreamDefaultReader) return new WebStreamReader(t);
            if (t instanceof ReadableStreamBYOBReader) return new WebStreamReaderBYOB(t);
            if (t instanceof Blob) return new BlobReader(t);
            if (t instanceof Uint8Array) return new Uint8ArrayReader(t);
            if (null === t) return new NullStream;
            if (_e(t, "read")) return t;
            throw new cn("ReadableStreamDefaultReader, ReadableStreamBYOBReader, Blob, Uint8Array, or object with reader interface", t);
        }
    });
    class WebStreamReader {
        done=!1;
        bytes=null;
        onClose=null;
        constructor(t) {
            this.reader = t, t.close = () => this.onClose?.();
        }
        async read(t) {
            for (;(!this.bytes || this.bytes.length < t) && !this.done; ) {
                let {value: t} = await this.reader.read();
                if (t) if (t instanceof Uint8Array || (t instanceof ArrayBuffer ? t = new Uint8Array(t) : t.buffer instanceof ArrayBuffer && (t = new Uint8Array(t.buffer, t.byteOffset, t.byteLength))), 
                this.bytes) {
                    const e = this.bytes.length, n = t.length, r = new Uint8Array(e + n);
                    r.set(this.bytes), r.set(t, e), this.bytes = r;
                } else this.bytes = t; else this.done = !0;
            }
            let e;
            return this.bytes && (this.bytes.length > t ? (e = this.bytes.subarray(0, t), this.bytes = this.bytes.subarray(t)) : (e = this.bytes, 
            this.bytes = null)), e ?? new Uint8Array(0);
        }
        destroy() {
            this.done || this.reader.cancel(), this.bytes = null;
        }
        valueOf() {
            return this.reader;
        }
    }
    class WebStreamReaderBYOB extends WebStreamReader {
        bytes=null;
        async read(t) {
            let e;
            if ((!this.bytes || this.bytes.length < t) && (this.bytes = new Uint8Array(t)), 
            !this.done) {
                const {value: t} = await this.reader.read(this.bytes);
                t ? e = t : this.done = !0;
            }
            return e ?? new Uint8Array(0);
        }
    }
    class BlobReader {
        pos=0n;
        onClose=null;
        constructor(t) {
            this.blob = t, this.size = BigInt(t.size ?? t.length), t.close = () => this.onClose?.();
        }
        async read(t) {
            const e = Number(this.pos), n = e + t, r = this.blob.slice(e, n), s = new Response(r), i = await s.arrayBuffer();
            return this.pos = BigInt(n), new Uint8Array(i);
        }
        tell() {
            return this.pos;
        }
        seek(t, e) {
            const {size: n} = this;
            let r = -1n;
            switch (e) {
              case 0:
                r = t;
                break;

              case 1:
                r = this.pos + t;
                break;

              case 2:
                r = n + t;
            }
            if (!(r >= 0n && r <= n)) throw new InvalidArgument;
            return this.pos = r;
        }
        valueOf() {
            return this.blob;
        }
    }
    class Uint8ArrayReader extends BlobReader {
        read(t) {
            const e = Number(this.pos), n = e + t;
            return this.pos = BigInt(n), this.blob.subarray(e, n);
        }
    }
    class NullStream {
        read() {
            return 0;
        }
        write() {}
    }
    rn({
        addRuntimeCheck: t => function(e, n) {
            const r = t.call(this, e, n);
            if ("set" === e) {
                const {min: t, max: e} = function(t) {
                    const {type: e, bitSize: n} = t, r = e === R.Int;
                    let s = r ? n - 1 : n;
                    if (n <= 32) {
                        return {
                            min: r ? -(2 ** s) : 0,
                            max: 2 ** s - 1
                        };
                    }
                    s = BigInt(s);
                    return {
                        min: r ? -(2n ** s) : 0n,
                        max: 2n ** s - 1n
                    };
                }(n);
                return function(s, i, o) {
                    if (i < t || i > e) throw new Overflow(n, i);
                    r.call(this, s, i, o);
                };
            }
            return r;
        }
    }), rn({
        init() {
            this.streamLocationMap = new Map([ [ bt, "" ] ]);
        },
        obtainStreamLocation(t, e, n) {
            let r = Me(this.obtainZigArray(e, n)).trim();
            r.endsWith("/") && (r = r.slice(0, -1));
            const s = r.trim().split("/"), i = [];
            for (const t of s) ".." === t ? i.pop() : "." !== t && "" != t && i.push(t);
            return {
                parent: this.getStream(t).valueOf(),
                path: i.join("/")
            };
        },
        getStreamLocation(t) {
            return this.streamLocationMap.get(t);
        },
        setStreamLocation(t, e) {
            const n = this.streamLocationMap;
            e ? n.set(t, e) : n.delete(t);
        }
    }), rn({
        init() {
            const t = {
                * readdir() {},
                valueOf: () => null
            };
            this.streamMap = new Map([ [ pt, this.createLogWriter("stdout") ], [ yt, this.createLogWriter("stderr") ], [ bt, t ] ]), 
            this.flushRequestMap = new Map, this.nextStreamHandle = mt;
        },
        getStream(t, e) {
            const n = this.streamMap.get(t);
            if (!n || e && !_e(n, e)) throw new InvalidFileDescriptor;
            return n;
        },
        createStreamHandle(t) {
            const e = this.nextStreamHandle++;
            return this.streamMap.set(e, t), t.onClose = () => this.destroyStreamHandle(e), 
            e;
        },
        destroyStreamHandle(t) {
            const e = this.streamMap.get(t);
            e?.destroy?.(), this.streamMap.delete(t);
        },
        redirectStream(t, e) {
            const n = this.streamMap, r = 3 === t ? bt : t, s = n.get(r);
            if (void 0 !== e) {
                let s;
                if (0 === t) s = this.convertReader(e); else if (1 === t || 2 === t) s = this.convertWriter(e); else {
                    if (3 !== t) throw new Error(`Expecting 0, 1, 2, or 3, received ${r}`);
                    s = this.convertDirectory(e);
                }
                n.set(r, s);
            } else n.delete(r);
            return s;
        },
        createLogWriter(t) {
            const e = this;
            return {
                pending: [],
                write(t) {
                    const n = t.lastIndexOf(10);
                    if (-1 === n) this.pending.push(t); else {
                        const e = t.subarray(0, n), r = t.subarray(n + 1);
                        this.dispatch([ ...this.pending, e ]), this.pending.splice(0), r.length > 0 && this.pending.push(r);
                    }
                    e.scheduleFlush(this, this.pending.length > 0, 250);
                },
                dispatch(n) {
                    const r = Me(n);
                    e.triggerEvent("log", {
                        source: t,
                        message: r
                    });
                },
                flush() {
                    this.pending.length > 0 && (this.dispatch(this.pending), this.pending.splice(0));
                }
            };
        },
        scheduleFlush(t, e, n) {
            const r = this.flushRequestMap, s = r.get(t);
            s && (clearTimeout(s), r.delete(t)), e && r.set(t, setTimeout((() => {
                t.flush(), r.delete(t);
            }), n));
        },
        flushStreams() {
            this.libc && this.flushStdout?.();
            const t = this.flushRequestMap;
            if (t.size > 0) {
                for (const [e, n] of t) e.flush(), clearTimeout(n);
                t.clear();
            }
        },
        imports: {
            flushStdout: {},
            setRedirectionMask: {}
        }
    }), rn({}), rn({
        convertWriter(t) {
            if (t instanceof WritableStreamDefaultWriter) return new WebStreamWriter(t);
            if (Array.isArray(t)) return new ArrayWriter(t);
            if (null === t) return new NullStream;
            if ("function" == typeof t?.write) return t;
            throw new cn("WritableStreamDefaultWriter, array, null, or object with writer interface", t);
        }
    });
    class WebStreamWriter {
        onClose=null;
        done=!1;
        constructor(t) {
            this.writer = t, t.closed.catch(He).then((() => {
                this.done = !0, this.onClose?.();
            }));
        }
        async write(t) {
            await this.writer.write(t);
        }
        destroy() {
            this.done || this.writer.close();
        }
    }
    class ArrayWriter {
        constructor(t) {
            this.array = t, this.closeCB = null, t.close = () => this.onClose?.();
        }
        write(t) {
            this.array.push(t);
        }
    }
    rn({
        createSignal(t, e) {
            const {constructor: {child: n}} = t.instance.members[0].structure, r = new Int32Array([ e?.aborted ? 1 : 0 ]), s = n(r);
            return e && e.addEventListener("abort", (() => {
                Atomics.store(r, 0, 1);
            }), {
                once: !0
            }), {
                ptr: s
            };
        },
        createInboundSignal(t) {
            const e = new AbortController;
            if (t.ptr["*"]) e.abort(); else {
                const n = setInterval((() => {
                    t.ptr["*"] && (e.abort(), clearInterval(n));
                }), 50);
            }
            return e.signal;
        }
    }), rn({
        init() {
            this.defaultAllocator = null, this.allocatorVtable = null, this.allocatorContextMap = new Map, 
            this.nextAllocatorContextId = Ce(4096);
        },
        createDefaultAllocator(t, e) {
            let n = this.defaultAllocator;
            return n || (n = this.defaultAllocator = this.createJsAllocator(t, e, !1)), n;
        },
        createJsAllocator(t, e, n) {
            const {constructor: r} = e;
            let s = this.allocatorVtable;
            if (!s) {
                const {noResize: t, noRemap: e} = r;
                s = this.allocatorVtable = {
                    alloc: this.allocateHostMemory.bind(this),
                    free: this.freeHostMemory.bind(this),
                    resize: t
                }, e && (s.remap = e), this.destructors.push((() => this.freeFunction(s.alloc))), 
                this.destructors.push((() => this.freeFunction(s.free)));
            }
            let i = $e;
            if (n) {
                const e = [];
                i = this.nextAllocatorContextId++, this.allocatorContextMap.set(i, e), t[le] = t => {
                    for (const {address: n, len: r} of e) this.unregisterMemory(n, r), t && this.allocatorContextMap.delete(i);
                    e.splice(0);
                };
            }
            return new r({
                ptr: this.obtainZigView(i, 0),
                vtable: s
            });
        },
        allocateHostMemory(t, e, n) {
            const r = this.getViewAddress(t["*"][At]), s = r != $e ? this.allocatorContextMap.get(r) : null, i = 1 << n, o = this.allocateJSMemory(e, i);
            {
                const t = this.getViewAddress(o);
                return this.registerMemory(t, e, i, !0, o), ve(o, Mt, {
                    value: {
                        address: t,
                        len: e,
                        js: !0
                    },
                    enumerable: !1
                }), s?.push({
                    address: t,
                    len: e
                }), o;
            }
        },
        freeHostMemory(t, e, n) {
            const r = e["*"][At], s = this.getViewAddress(r), i = r.byteLength;
            this.unregisterMemory(s, i);
        }
    }), rn({
        createDirectory(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return t;
            const e = this.convertDirectory(t);
            return {
                fd: this.createStreamHandle(e)
            };
        }
    }), rn({
        createFile(t) {
            if ("object" == typeof t && "number" == typeof t?.fd) return {
                handle: t.fd
            };
            if ("object" == typeof t && "number" == typeof t?.handle) return t;
            let e;
            try {
                e = this.convertReader(t);
            } catch (n) {
                try {
                    e = this.convertWriter(t);
                } catch {
                    throw n;
                }
            }
            return {
                handle: this.createStreamHandle(e)
            };
        }
    }), rn({
        init() {
            this.generatorCallbackMap = new Map, this.generatorContextMap = new Map, this.nextGeneratorContextId = Ce(8192);
        },
        createGenerator(t, e, n) {
            const {constructor: r, instance: {members: s}} = t;
            if (n) {
                if ("function" != typeof n) throw new cn("function", n);
            } else {
                const t = e[re] = new AsyncGenerator;
                n = t.push.bind(t);
            }
            const i = this.nextGeneratorContextId++, o = this.obtainZigView(i, 0, !1);
            this.generatorContextMap.set(i, {
                func: n,
                args: e
            });
            let c = this.generatorCallbackMap.get(r);
            c || (c = async (t, e) => {
                const n = t instanceof DataView ? t : t["*"][At], r = this.getViewAddress(n), s = this.generatorContextMap.get(r);
                if (s) {
                    const {func: t, args: n} = s, i = e instanceof Error;
                    !i && n[ce] && e && (e = e.string);
                    const o = !1 === await (2 === t.length ? t(i ? e : null, i ? null : e) : t(e)) || i || null === e;
                    if (n[le]?.(o), !o) return !0;
                    n[ye](), this.generatorContextMap.delete(r);
                }
                return !1;
            }, this.generatorCallbackMap.set(r, c), this.destructors.push((() => this.freeFunction(c)))), 
            e[me] = t => c(o, t);
            const a = {
                ptr: o,
                callback: c
            }, l = s.find((t => "allocator" === t.name));
            if (l) {
                const {structure: t} = l;
                a.allocator = this.createJsAllocator(e, t, !0);
            }
            return a;
        },
        createGeneratorCallback(t, e) {
            const {ptr: n, callback: r} = e, s = r["*"];
            return t[we] = e => s.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[we](n);
            };
        },
        async pipeContents(t, e) {
            try {
                try {
                    const n = t[Symbol.asyncIterator]();
                    for await (const t of n) if (null !== t && !e[we](t)) break;
                    e[we](null);
                } catch (t) {
                    if (!e.constructor[ee]) throw t;
                    e[we](t);
                }
            } catch (t) {
                console.error(t);
            }
        }
    });
    class AsyncGenerator {
        result=null;
        stopped=!1;
        finished=!1;
        promises={};
        async next() {
            if (this.stopped) return {
                done: !0
            };
            for (;;) {
                const t = this.result;
                if (null !== t) return this.result = null, this.wake("space"), {
                    value: t,
                    done: !1
                };
                if (this.error) throw this.error;
                if (this.finished) return {
                    done: !0
                };
                await this.sleep("content");
            }
        }
        async return(t) {
            return await this.break(), {
                value: t,
                done: !0
            };
        }
        async throw(t) {
            throw await this.break(), t;
        }
        async break() {
            this.finished || (this.stopped = !0, await this.sleep("break"));
        }
        async push(t) {
            return this.stopped ? (this.wake("break"), !1) : (t instanceof Error ? (this.error = t, 
            this.finished = !0) : null === t ? this.finished = !0 : (null !== this.result && await this.sleep("space"), 
            this.result = t), this.wake("content"), !this.finished);
        }
        sleep(t) {
            let e;
            const n = this.promises[t] ||= new Promise((t => e = t));
            return e && (n.resolve = e), n;
        }
        wake(t) {
            const e = this.promises[t];
            e && (this.promises[t] = null, this.finished || this.stopped ? setImmediate(e.resolve) : e.resolve());
        }
        [Symbol.asyncIterator]() {
            return this;
        }
    }
    rn({
        init() {
            this.promiseCallbackMap = new Map, this.promiseContextMap = new Map, this.nextPromiseContextId = Ce(4096);
        },
        createPromise(t, e, n) {
            const {constructor: r} = t;
            if (n) {
                if ("function" != typeof n) throw new cn("function", n);
            } else e[ne] = new Promise(((t, r) => {
                n = n => {
                    n?.[At]?.[Mt] && (n = new n.constructor(n)), n instanceof Error ? r(n) : (e[ce] && n && (n = n.string), 
                    t(n));
                };
            }));
            const s = this.nextPromiseContextId++, i = this.obtainZigView(s, 0, !1);
            this.promiseContextMap.set(s, {
                func: n,
                args: e
            });
            let o = this.promiseCallbackMap.get(r);
            return o || (o = (t, e) => {
                const n = t instanceof DataView ? t : t["*"][At], r = this.getViewAddress(n), s = this.promiseContextMap.get(r);
                if (s) {
                    const {func: t, args: n} = s;
                    if (2 === t.length) {
                        const n = e instanceof Error;
                        t(n ? e : null, n ? null : e);
                    } else t(e);
                    n[ye](), this.promiseContextMap.delete(r);
                }
            }, this.promiseCallbackMap.set(r, o), this.destructors.push((() => this.freeFunction(o)))), 
            e[me] = t => o(i, t), {
                ptr: i,
                callback: o
            };
        },
        createPromiseCallback(t, e) {
            const {ptr: n, callback: r} = e, s = r["*"];
            return t[me] = e => s.call(t, n, e), (...e) => {
                const n = 2 === e.length ? e[0] ?? e[1] : e[0];
                return t[me](n);
            };
        }
    }), rn({
        init() {
            this.readerCallback = null, this.readerMap = new Map, this.nextReaderId = Ce(4096), 
            this.readerProgressMap = new Map;
        },
        createReader(t) {
            if ("object" == typeof t && t && "context" in t && "readFn" in t) return t;
            const e = this.convertReader(t), n = this.nextReaderId++, r = this.obtainZigView(n, 0, !1), s = e.onClose = () => {
                this.readerMap.delete(n), this.readerProgressMap.delete(n);
            };
            this.readerMap.set(n, e), this.readerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let i = this.readerCallback;
            if (!i) {
                const t = t => {
                    throw console.error(t), s(), t;
                };
                i = this.readerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][At]), s = this.readerMap.get(r);
                    if (!s) return 0;
                    try {
                        const e = n["*"][At].byteLength, i = t => {
                            const e = t.length, r = this.getViewAddress(n["*"][At]);
                            return this.moveExternBytes(t, r, !0), e;
                        };
                        fn(this.readerProgressMap.get(r), "read", e);
                        const o = s.read(e);
                        return Pe(o) ? o.then(i).catch(t) : i(o);
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(i)));
            }
            return {
                context: r,
                readFn: i
            };
        }
    }), rn({
        init() {
            this.writerCallback = null, this.writerMap = new Map, this.nextWriterContextId = Ce(8192), 
            this.writerProgressMap = new Map;
        },
        createWriter(t) {
            if ("object" == typeof t && t && "context" in t && "writeFn" in t) return t;
            const e = this.convertWriter(t), n = this.nextWriterContextId++, r = this.obtainZigView(n, 0, !1), s = e.onClose = () => {
                this.writerMap.delete(n), this.writerProgressMap.delete(n);
            };
            this.writerMap.set(n, e), this.writerProgressMap.set(n, {
                bytes: 0,
                calls: 0
            });
            let i = this.writerCallback;
            if (!i) {
                const t = t => {
                    throw console.error(t), s(), t;
                };
                i = this.writerCallback = (e, n) => {
                    const r = this.getViewAddress(e["*"][At]), s = this.writerMap.get(r);
                    if (!s) return 0;
                    try {
                        const e = n["*"][At];
                        fn(this.writerProgressMap.get(r), "write", e.byteLength);
                        const i = e.byteLength, o = new Uint8Array(e.buffer, e.byteOffset, i), c = new Uint8Array(o), a = s.write(c);
                        return Pe(a) ? a.then((() => i), t) : i;
                    } catch (e) {
                        t(e);
                    }
                }, this.destructors.push((() => this.freeFunction(i)));
            }
            return {
                context: r,
                writeFn: i
            };
        }
    }), rn({
        environGet(t, e) {
            let n = 0, r = 0;
            for (const t of this.envVariables) n += t.length, r++;
            const s = Ze(4 * r), i = new Uint8Array(n);
            let o = 0, c = 0, a = this.littleEndian;
            for (const t of this.envVariables) s.setUint32(o, e + c, a), o += 4, i.set(t, c), 
            c += t.length;
            return this.moveExternBytes(s, t, !0), this.moveExternBytes(i, e, !0), et;
        },
        exports: {
            environGet: {
                async: !0
            }
        }
    }), rn({
        copyUsize(t, e) {
            this.copyUint32(t, e);
        },
        copyUint64(t, e) {
            const n = Ze(8);
            n.setBigUint64(0, BigInt(e), this.littleEndian), this.moveExternBytes(n, t, !0);
        },
        copyUint32(t, e) {
            const n = Ze(4);
            n.setUint32(0, e, this.littleEndian), this.moveExternBytes(n, t, !0);
        }
    }), rn({
        environSizesGet(t, e) {
            const n = this.listenerMap.get("env"), r = n?.() ?? {};
            if ("object" != typeof r) throw new TypeMismatch("object", r);
            const s = this.envVariables = [];
            for (const [t, e] of Object.entries(r)) {
                const n = Ee(`${t}=${e}\0`);
                s.push(n);
            }
            let i = 0;
            for (const t of s) i += t.length;
            return this.copyUsize(t, s.length), this.copyUsize(e, i), et;
        },
        exports: {
            environSizesGet: {
                async: !0
            }
        }
    });
    const In = {
        normal: 0,
        sequential: 1,
        random: 2,
        willNeed: 3,
        dontNeed: 4,
        noReuse: 5
    };
    rn({
        fdAdvise(t, e, n, r, s) {
            return hn(s, rt, (() => {
                const s = this.getStream(t), i = Object.keys(In);
                return s.advise?.(e, n, i[r]);
            }));
        },
        exports: {
            fdAdvise: {
                async: !0
            }
        }
    }), rn({
        fdAllocate(t, e, n, r) {
            return hn(r, rt, (() => this.getStream(t).allocate(e, n)));
        },
        exports: {
            fdAllocate: {
                async: !0
            }
        }
    }), rn({
        fdClose(t, e) {
            return hn(e, rt, (() => (this.setStreamLocation?.(t), this.destroyStreamHandle(t))));
        },
        exports: {
            fdClose: {
                async: !0
            }
        }
    }), rn({
        fdDatasync(t, e) {
            return hn(e, rt, (() => {
                const e = this.getStream(t);
                return e.datasync?.();
            }));
        },
        exports: {
            fdDatasync: {
                async: !0
            }
        }
    }), rn({
        fdFdstatGet(t, e, n) {
            return hn(n, rt, (() => {
                const n = this.getStream(t);
                let r, s = 0;
                s = dt.fd_filestat_get, this.listenerMap.get("set_times") && this.getStreamLocation?.(t) && (s |= dt.fd_filestat_set_times);
                for (const t of [ "read", "write", "seek", "tell", "advise", "allocate", "datasync", "sync", "readdir" ]) _e(n, t) && (s |= dt[`fd_${t}`]);
                if (n.type) {
                    if (r = Re(n.type, ut), void 0 === r) throw new InvalidEnumValue(ut, n.type);
                } else r = s & (dt.fd_read | dt.fd_write) ? ut.file : ut.directory;
                r === ut.directory && (s |= dt.path_open | dt.path_filestat_get);
                const i = Ze(24);
                i.setUint8(0, r), i.setUint16(2, 0, !0), i.setBigUint64(8, BigInt(s), !0), i.setBigUint64(16, 0n, !0), 
                this.moveExternBytes(i, e, !0);
            }));
        },
        exports: {
            fdFdstatGet: {
                async: !0
            }
        }
    }), rn({
        copyStat(t, e) {
            if (!1 === e) return lt;
            if ("object" != typeof e || !e) throw new cn("object or false", e);
            let n = Re(e.type, ut);
            if (void 0 === n) {
                if (e.type) throw new InvalidEnumValue(ut, e.type);
                n = ut.unknown;
            }
            const r = this.littleEndian, s = Ze(64);
            s.setBigUint64(0, 0n, r), s.setBigUint64(8, 0n, r), s.setUint8(16, n), s.setBigUint64(24, 0n, r), 
            s.setBigUint64(32, BigInt(e.size ?? 0), r), s.setBigUint64(40, BigInt(e.atime ?? 0), r), 
            s.setBigUint64(48, BigInt(e.mtime ?? 0), r), s.setBigUint64(56, BigInt(e.ctime ?? 0), r), 
            this.moveExternBytes(s, t, r);
        }
    }), rn({
        fdFilestatGet(t, e, n) {
            return hn(n, rt, (() => {
                const e = this.getStream(t), n = e.valueOf(), r = this.getStreamLocation?.(t);
                try {
                    return this.triggerEvent("stat", {
                        ...r,
                        target: n,
                        flags: {}
                    }, lt);
                } catch (t) {
                    if (t.code !== lt) throw t;
                }
                return {
                    size: e.size,
                    type: "file"
                };
            }), (t => this.copyStat(e, t)));
        },
        exports: {
            fdFilestatGet: {
                async: !0
            }
        }
    }), rn({
        fdFilestatSetTimes(t, e, n, r, s) {
            return hn(s, rt, (() => {
                const s = this.getStream(t).valueOf(), i = this.getStreamLocation?.(t), o = en(e, n, r);
                return this.triggerEvent("set_times", {
                    ...i,
                    target: s,
                    times: o,
                    flags: {}
                }, rt);
            }), (t => dn(t, rt)));
        },
        exports: {
            fdFilestatSetTimes: {
                async: !0
            }
        }
    }), rn({
        fdRead(t, e, n, r, s) {
            let i, o, c = 0, a = 0;
            const l = () => hn(s, at, (() => {
                i || (i = Ze(8 * n), this.moveExternBytes(i, e, !1), o = this.getStream(t));
                const r = i.getUint32(8 * a + 4, !0);
                return o.read(r);
            }), (t => {
                const e = i.getUint32(8 * a, !0);
                if (this.moveExternBytes(t, e, !0), c += t.byteLength, ++a < n) return l();
                this.copyUsize(r, c);
            }));
            return l();
        },
        ...{
            exports: {
                fdRead: {
                    async: !0
                },
                fdRead1: {
                    async: !0
                }
            },
            fdRead1(t, e, n, r, s) {
                return hn(s, at, (() => this.getStream(t).read(n)), (t => {
                    this.moveExternBytes(t, e, !0), this.copyUsize(r, t.length);
                }));
            }
        }
    }), rn({
        fdReaddir(t, e, n, r, s, i) {
            return n < 24 ? ct : hn(i, rt, (() => {
                const e = this.getStream(t);
                0n === r && (r = e.tell());
                const n = e.readdir();
                return Pe(n) ? n.then((t => [ t ])) : [ n, e ];
            }), (([t, i]) => {
                const o = Ze(n);
                let c = n, a = 0;
                for (;t; ) {
                    const {name: e, type: n = "unknown", ino: s = 0} = t, l = Ee(e), u = Re(n, ut);
                    if (void 0 === u) throw new InvalidEnumValue(ut, n);
                    if (c < 24 + l.length) break;
                    o.setBigUint64(a, ++r, !0), o.setBigUint64(a + 8, BigInt(s), !0), o.setUint32(a + 16, l.length, !0), 
                    o.setUint8(a + 20, u), a += 24, c -= 24;
                    for (let t = 0; t < l.length; t++, a++) o.setUint8(a, l[t]);
                    c -= l.length, t = c > 40 && i ? i.readdir() : null;
                }
                this.moveExternBytes(o, e, !0), this.copyUsize(s, a);
            }));
        },
        exports: {
            fdReaddir: {
                async: !0
            }
        }
    }), rn({
        fdSeek(t, e, n, r, s) {
            return hn(s, rt, (() => this.getStream(t, "seek").seek(e, n)), (t => {
                const e = Ze(8);
                e.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(e, r, !0);
            }));
        },
        exports: {
            fdSeek: {
                async: !0
            }
        }
    }), rn({
        fdSync(t, e) {
            return hn(e, rt, (() => {
                const e = this.getStream(t);
                return e.sync?.();
            }));
        },
        exports: {
            fdSync: {
                async: !0
            }
        }
    }), rn({
        fdTell(t, e, n) {
            return hn(n, rt, (() => this.getStream(t, "tell").tell()), (t => {
                const n = Ze(8);
                n.setBigUint64(0, BigInt(t), this.littleEndian), this.moveExternBytes(n, e, !0);
            }));
        },
        exports: {
            fdTell: {
                async: !0
            }
        }
    }), rn({
        fdWrite(t, e, n, r, s) {
            let i, o, c = 0, a = 0;
            const l = () => hn(s, at, (() => {
                i || (i = Ze(8 * n), this.moveExternBytes(i, e, !1), o = this.getStream(t, "write"));
                const r = this.littleEndian, s = i.getUint32(8 * c, r), l = i.getUint32(8 * c + 4, r), u = new Uint8Array(l);
                return this.moveExternBytes(u, s, !1), a += l, o.write(u);
            }), (() => {
                if (++c < n) return l();
                this.copyUsize(r, a);
            }));
            return l();
        },
        ...{
            exports: {
                fdWrite: {
                    async: !0
                },
                fdWrite1: {
                    async: !0
                }
            },
            fdWrite1(t, e, n, r, s) {
                return hn(s, at, (() => {
                    const r = this.getStream(t), s = new Uint8Array(n);
                    return this.moveExternBytes(s, e, !1), r.write(s);
                }), (() => this.copyUsize(r, n)));
            }
        }
    }), rn({
        pathCreateDirectory(t, e, n, r) {
            return hn(r, lt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("mkdir", r, lt);
            }), (t => t instanceof Map ? it : dn(t, lt)));
        },
        exports: {
            pathCreateDirectory: {
                async: !0
            }
        }
    }), rn({
        pathFilestatGet(t, e, n, r, s, i) {
            return hn(i, lt, (() => {
                const s = this.obtainStreamLocation(t, n, r), i = De(e, ht);
                return this.triggerEvent("stat", {
                    ...s,
                    flags: i
                }, lt);
            }), (t => this.copyStat(s, t)));
        },
        exports: {
            pathFilestatGet: {
                async: !0
            }
        }
    }), rn({
        pathFilestatSetTimes(t, e, n, r, s, i, o, c) {
            return hn(c, lt, (() => {
                const c = this.obtainStreamLocation(t, n, r), a = en(s, i, o), l = De(e, ht);
                return this.triggerEvent("set_times", {
                    ...c,
                    times: a,
                    flags: l
                }, lt);
            }), (t => dn(t, lt)));
        },
        exports: {
            pathFilestatSetTimes: {
                async: !0
            }
        }
    });
    const xn = {
        read: BigInt(dt.fd_read),
        write: BigInt(dt.fd_write),
        readdir: BigInt(dt.fd_readdir)
    };
    function Mn() {
        const t = Vn.toString(), e = t.indexOf("{") + 1, n = t.lastIndexOf("}");
        return t.slice(e, n);
    }
    let En;
    function Vn() {
        let t, e;
        function n({executable: n, memory: s, options: i, tid: o, arg: c}) {
            const a = WebAssembly, l = {
                memory: s
            }, u = {}, f = {}, h = {
                env: l,
                wasi: u,
                wasi_snapshot_preview1: f
            };
            for (const {module: t, name: e, kind: s} of a.Module.imports(n)) if ("function" === s) {
                const n = r(t, e);
                "env" === t ? l[e] = n : "wasi_snapshot_preview1" === t ? f[e] = n : "wasi" === t && (u[e] = n);
            }
            const {tableInitial: d} = i;
            l.__indirect_function_table = new a.Table({
                initial: d,
                element: "anyfunc"
            });
            const {exports: g} = new a.Instance(n, h), {wasi_thread_start: p} = g;
            p(o, c), t({
                type: "exit"
            }), e();
        }
        function r(e, n) {
            const r = new Int32Array(new SharedArrayBuffer(8));
            return function(...s) {
                return r[0] = 0, t({
                    type: "call",
                    module: e,
                    name: n,
                    args: s,
                    array: r
                }), Atomics.wait(r, 0, 0), r[1];
            };
        }
        "object" == typeof self || "node" !== process.env.COMPAT ? (self.onmessage = t => n(t.data), 
        t = t => self.postMessage(t), e = () => self.close()) : "node" === process.env.COMPAT && import("worker_threads").then((({parentPort: r, workerData: s}) => {
            t = t => r.postMessage(t), e = () => process.exit(), n(s);
        }));
    }
    function Un(t, n) {
        const {byteSize: r, type: s} = n;
        if (!(s === e.Slice ? t.byteLength % r == 0 : t.byteLength === r)) throw new BufferSizeMismatch(n, t);
    }
    function On(t) {
        throw new BufferExpected(t);
    }
    rn({
        pathOpen(t, e, n, r, s, i, o, c, a, l) {
            const u = De(i | o, xn), f = {
                ...De(e, ht),
                ...De(s, ft),
                ...De(c, gt)
            };
            let h;
            return hn(l, lt, (() => (h = this.obtainStreamLocation(t, n, r), this.triggerEvent("open", {
                ...h,
                rights: u,
                flags: f
            }, lt))), (t => {
                if (!1 === t) return lt;
                let e;
                u.read || 0 === Object.values(u).length ? e = this.convertReader(t) : u.write ? e = this.convertWriter(t) : u.readdir && (e = this.convertDirectory(t));
                const n = this.createStreamHandle(e);
                this.setStreamLocation?.(n, h), this.copyUint32(a, n);
            }));
        },
        exports: {
            pathOpen: {
                async: !0
            }
        }
    }), rn({
        pathRemoveDirectory(t, e, n, r) {
            return hn(r, lt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("rmdir", r, lt);
            }), (t => dn(t, lt)));
        },
        exports: {
            pathRemoveDirectory: {
                async: !0
            }
        }
    }), rn({
        pathUnlinkFile(t, e, n, r) {
            return hn(r, lt, (() => {
                const r = this.obtainStreamLocation(t, e, n);
                return this.triggerEvent("unlink", r, lt);
            }), (t => dn(t, lt)));
        },
        exports: {
            pathUnlinkFile: {
                async: !0
            }
        }
    }), rn({
        init() {
            this.nextThreadId = 1, this.workers = [];
        },
        getThreadHandler(t) {
            if ("thread-spawn" === t) return "object" != typeof window || window.crossOriginIsolated || console.warn("%cHTML document is not cross-origin isolated %c\n\nWebAssembly multithreading in the browser is only possibly when %cwindow.crossOriginIsolated%c = true. Visit https://developer.mozilla.org/en-US/docs/Web/API/Window/crossOriginIsolated for information on how to enable it.", "color: red;font-size: 200%;font-weight:bold", "", "background-color: lightgrey;font-weight:bold", ""), 
            this.spawnThread.bind(this);
        },
        spawnThread(t) {
            const e = this.nextThreadId;
            this.nextThreadId++;
            const {executable: n, memory: r, options: s} = this, i = {
                executable: n,
                memory: r,
                options: s,
                tid: e,
                arg: t
            }, o = (t, e) => {
                if ("call" === e.type) {
                    const {module: t, name: n, args: r, array: s} = e, i = this.exportedModules[t]?.[n], o = i?.(...r, !0), c = t => {
                        s && (s[1] = 0 | t, s[0] = 1, Atomics.notify(s, 0, 1));
                    };
                    Pe(o) ? o.then(c) : c(o);
                } else if ("exit" === e.type) {
                    const e = this.workers.indexOf(t);
                    -1 !== e && (t.detach(), this.workers.splice(e, 1));
                }
            }, c = "message";
            if ("function" == typeof Worker || "node" !== process.env.COMPAT) {
                const t = function() {
                    if (!En) {
                        const t = Mn();
                        En = URL.createObjectURL(new Blob([ t ], {
                            type: "text/javascript"
                        }));
                    }
                    return En;
                }(), e = new Worker(t, {
                    name: "zig"
                }), n = t => o(e, t.data);
                e.addEventListener(c, n), e.detach = () => e.removeEventListener(c, n), e.postMessage(i), 
                this.workers.push(e);
            } else "node" === process.env.COMPAT && import("worker_threads").then((({Worker: t}) => {
                const e = new t(Mn(), {
                    workerData: i,
                    eval: !0
                }), n = t => o(e, t);
                e.on(c, n), e.detach = () => e.off(c, n), this.workers.push(e);
            }));
            return e;
        }
    }), rn({
        init() {
            this.comptime = !1, this.slots = {}, this.structures = [], this.structureCounters = {
                struct: 0,
                union: 0,
                errorSet: 0,
                enum: 0,
                opaque: 0
            }, this.littleEndian = !0, this.runtimeSafety = !1, this.libc = !1;
        },
        createView(t, e, n, r) {
            if (n) {
                const n = this.allocateJSMemory(e, 0);
                return e > 0 && this.moveExternBytes(n, t, !1), n;
            }
            {
                const n = this.obtainZigView(t, e);
                return n[Mt].handle = r, n;
            }
        },
        createInstance(t, e, n) {
            const {constructor: r, flags: s} = t, i = r.call(Ht, e);
            return s & g && this.updatePointerTargets(null, i), n && Object.assign(i[It], n), 
            e[Mt] || this.makeReadOnly?.(i), i;
        },
        createTemplate: (t, e) => ({
            [At]: t,
            [It]: e
        }),
        appendList(t, e) {
            t.push(e);
        },
        getSlotValue(t, e) {
            return t || (t = this.slots), t[e];
        },
        setSlotValue(t, e, n) {
            t || (t = this.slots), t[e] = n;
        },
        beginStructure(t) {
            this.defineStructure(t);
        },
        finishStructure(t) {
            t.name || this.inferTypeName(t), this.structures.push(t), this.finalizeStructure(t);
        },
        acquireStructures() {
            const t = this.getModuleAttributes();
            this.littleEndian = !!(t & X), this.runtimeSafety = !!(t & K), this.libc = !!(t & Q);
            const e = this.getFactoryThunk(), n = {
                [At]: this.obtainZigView(e, 0)
            };
            this.comptime = !0, this.mixinUsage = new Map, this.invokeThunk(n, n, n), this.comptime = !1;
            for (const t of this.structures) {
                const {constructor: e, flags: n, instance: {template: r}} = t;
                if (n & g && r && r[At]) {
                    const t = Object.create(e.prototype);
                    t[At] = r[At], t[It] = r[It], this.updatePointerTargets(null, t);
                }
            }
        },
        getRootModule() {
            return this.structures[this.structures.length - 1].constructor;
        },
        hasMethods() {
            return !!this.structures.find((t => t.type === e.Function));
        },
        exportStructures() {
            this.prepareObjectsForExport();
            const {structures: t, runtimeSafety: e, littleEndian: n, libc: r} = this;
            return {
                structures: t,
                settings: {
                    runtimeSafety: e,
                    littleEndian: n,
                    libc: r
                }
            };
        },
        prepareObjectsForExport() {
            const t = [];
            for (const e of Fe(this.structures, It)) {
                const n = e[At]?.[Mt];
                if (n) {
                    const {address: r, len: s, handle: i} = n, o = e[At] = this.createView(r, s, !0, 0);
                    i && (o.handle = i), t.push({
                        address: r,
                        len: s,
                        owner: e,
                        replaced: !1,
                        handle: i
                    });
                }
            }
            t.sort(((t, e) => e.len - t.len));
            for (const e of t) if (!e.replaced) for (const n of t) if (e !== n && !n.replaced && !n.handle && e.address <= n.address && ze(n.address, n.len) <= ze(e.address, e.len)) {
                const t = e.owner[At], r = Number(n.address - e.address) + t.byteOffset;
                n.owner[At] = this.obtainView(t.buffer, r, n.len), n.replaced = !0;
            }
        },
        useStructures() {
            const t = this.getRootModule(), e = Fe(this.structures, It);
            for (const t of e) t[At]?.[Mt] && this.variables.push({
                object: t
            });
            return this.slots = {}, this.structures = [], t.__zigar = this.getSpecialExports(), 
            t;
        },
        inferTypeName(t) {
            const e = this[`get${f[t.type]}Name`];
            t.name = e.call(this, t);
        },
        getPrimitiveName(t) {
            const {instance: {members: [e]}, flags: n = 0} = t;
            switch (e.type) {
              case R.Bool:
                return "bool";

              case R.Int:
                return n & y ? "isize" : `i${e.bitSize}`;

              case R.Uint:
                return n & y ? "usize" : `u${e.bitSize}`;

              case R.Float:
                return `f${e.bitSize}`;

              case R.Void:
                return "void";

              case R.Literal:
                return "enum_literal";

              case R.Null:
                return "null";

              case R.Undefined:
                return "undefined";

              case R.Type:
                return "type";

              case R.Object:
                return "comptime";

              default:
                return "unknown";
            }
        },
        getArrayName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `[${n}]${e.structure.name}`;
        },
        getStructName(t) {
            for (const e of [ "Allocator", "Promise", "Generator", "Read", "Writer" ]) if (t.flags & S[`Is${e}`]) return e;
            return "S" + this.structureCounters.struct++;
        },
        getUnionName(t) {
            return "U" + this.structureCounters.union++;
        },
        getErrorUnionName(t) {
            const {instance: {members: [e, n]}} = t;
            return `${n.structure.name}!${e.structure.name}`;
        },
        getErrorSetName(t) {
            return t.flags & F ? "anyerror" : "ES" + this.structureCounters.errorSet++;
        },
        getEnumName(t) {
            return "EN" + this.structureCounters.enum++;
        },
        getOptionalName(t) {
            const {instance: {members: [e]}} = t;
            return `?${e.structure.name}`;
        },
        getPointerName(t) {
            const {instance: {members: [n]}, flags: r} = t;
            let s = "*", i = n.structure.name;
            if (n.structure.type === e.Slice && (i = i.slice(3)), r & U && (s = r & V ? "[]" : r & O ? "[*c]" : "[*]"), 
            !(r & O)) {
                const t = n.structure.constructor?.[Ct];
                t && (s = s.slice(0, -1) + `:${t.value}` + s.slice(-1));
            }
            return r & k && (s = `${s}const `), s + i;
        },
        getSliceName(t) {
            const {instance: {members: [e]}, flags: n} = t;
            return n & j ? "anyopaque" : `[_]${e.structure.name}`;
        },
        getVectorName(t) {
            const {instance: {members: [e]}, length: n} = t;
            return `@Vector(${n}, ${e.structure.name})`;
        },
        getOpaqueName(t) {
            return "O" + this.structureCounters.opaque++;
        },
        getArgStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), s = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}) ${s})`;
        },
        getVariadicStructName(t) {
            const {instance: {members: e}} = t, n = e[0], r = e.slice(1), s = n.structure.name;
            return `Arg(fn (${r.map((t => t.structure.name)).join(", ")}, ...) ${s})`;
        },
        getFunctionName(t) {
            const {instance: {members: [e]}} = t;
            return e.structure.name.slice(4, -1);
        },
        exports: {
            createView: {},
            createInstance: {},
            createTemplate: {},
            appendList: {},
            getSlotValue: {},
            setSlotValue: {},
            beginStructure: {},
            finishStructure: {}
        },
        imports: {
            getFactoryThunk: {},
            getModuleAttributes: {}
        }
    }), rn({
        init() {
            this.viewMap = new WeakMap, this.needFallback = void 0;
        },
        extractView(t, n, r = On) {
            const {type: s, byteSize: i, constructor: o} = t;
            let c;
            const a = n?.[Symbol.toStringTag];
            if (a && ("DataView" === a ? c = this.registerView(n) : "ArrayBuffer" === a ? c = this.obtainView(n, 0, n.byteLength) : (a && a === o[te]?.name || "Uint8ClampedArray" === a && o[te] === Uint8Array || "Uint8Array" === a && n instanceof Buffer) && (c = this.obtainView(n.buffer, n.byteOffset, n.byteLength))), 
            !c) {
                const r = n?.[At];
                if (r) {
                    const {constructor: o, instance: {members: [c]}} = t;
                    if (Ne(n, o)) return r;
                    if (function(t) {
                        return t === e.Array || t === e.Vector || t === e.Slice;
                    }(s)) {
                        const {byteSize: o, structure: {constructor: a}} = c, l = je(n, a);
                        if (void 0 !== l) {
                            if (s === e.Slice || l * o === i) return r;
                            throw new ArrayLengthMismatch(t, null, n);
                        }
                    }
                }
            }
            return c ? void 0 !== i && Un(c, t) : r?.(t, n), c;
        },
        assignView(t, n, r, s, i) {
            const {byteSize: o, type: c} = r, a = o ?? 1;
            if (t[At]) {
                const s = c === e.Slice ? a * t.length : a;
                if (n.byteLength !== s) throw new BufferSizeMismatch(r, n, t);
                const i = {
                    [At]: n
                };
                t.constructor[Ct]?.validateData?.(i, t.length), t[he](i);
            } else {
                void 0 !== o && Un(n, r);
                const e = n.byteLength / a, c = {
                    [At]: n
                };
                t.constructor[Ct]?.validateData?.(c, e), i && (s = !0), t[de](s ? null : n, e, i), 
                s && t[he](c);
            }
            if (this.usingBufferFallback()) {
                const e = t[At], n = e.buffer[ie];
                void 0 !== n && this.syncExternalBuffer(e.buffer, n, !0);
            }
        },
        findViewAt(t, e, n) {
            let r, s = this.viewMap.get(t);
            if (s) if (s instanceof DataView) if (s.byteOffset === e && s.byteLength === n) r = s, 
            s = null; else {
                const e = s, n = `${e.byteOffset}:${e.byteLength}`;
                s = new Map([ [ n, e ] ]), this.viewMap.set(t, s);
            } else r = s.get(`${e}:${n}`);
            return {
                existing: r,
                entry: s
            };
        },
        obtainView(t, e, n) {
            const {existing: r, entry: s} = this.findViewAt(t, e, n);
            let i;
            if (r) return r;
            i = new DataView(t, e, n), s ? s.set(`${e}:${n}`, i) : this.viewMap.set(t, i);
            {
                const r = t[Mt];
                r && (i[Mt] = {
                    address: ze(r.address, e),
                    len: n
                });
            }
            return i;
        },
        registerView(t) {
            if (!t[Mt]) {
                const {buffer: e, byteOffset: n, byteLength: r} = t, {existing: s, entry: i} = this.findViewAt(e, n, r);
                if (s) return s;
                i ? i.set(`${n}:${r}`, t) : this.viewMap.set(e, t);
            }
            return t;
        },
        allocateMemory(t, e = 0, n = null) {
            return n?.alloc?.(t, e) ?? this.allocateJSMemory(t, e);
        },
        ...{
            imports: {
                requireBufferFallback: null,
                syncExternalBuffer: null
            },
            usingBufferFallback() {
                return void 0 === this.needFallback && (this.needFallback = this.requireBufferFallback?.()), 
                this.needFallback;
            },
            allocateJSMemory(t, e) {
                const n = e > kn && this.getBufferAddress ? e : 0, r = new ArrayBuffer(t + n);
                let s = 0;
                if (n) {
                    const t = this.getBufferAddress(r);
                    s = Be(t, e) - t;
                }
                return this.obtainView(r, Number(s), t);
            }
        }
    });
    const kn = [ "arm64", "ppc64", "x64", "s390x" ].includes(process.arch) ? 16 : 8;
    rn({
        makeReadOnly(t) {
            Cn(t);
        }
    });
    const Bn = Object.getOwnPropertyDescriptors, $n = Object.defineProperty;
    function Cn(t) {
        const e = t[$t];
        if (e) zn(e, [ "length" ]); else {
            const e = t[zt];
            e ? (zn(e), function(t) {
                $n(t, "set", {
                    value: un
                });
                const e = t.get;
                $n(t, "get", {
                    value: function(t) {
                        const n = e.call(this, t);
                        return null === n?.[Gt] && Cn(n), n;
                    }
                });
            }(e)) : zn(t);
        }
    }
    function zn(t, e = []) {
        const n = Bn(t.constructor.prototype);
        for (const [r, s] of Object.entries(n)) s.set && !e.includes(r) && (s.set = un, 
        $n(t, r, s));
        $n(t, Gt, {
            value: t
        });
    }
    function Tn() {
        const t = this[zt] ?? this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = t.get(e), s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function jn(t) {
        const e = Ie(t), n = this[zt] ?? this, r = this.length;
        let s = 0;
        return {
            next() {
                let t, i;
                if (s < r) {
                    const r = s++;
                    t = [ r, e((() => n.get(r))) ], i = !1;
                } else i = !0;
                return {
                    value: t,
                    done: i
                };
            }
        };
    }
    function Fn(t) {
        return {
            [Symbol.iterator]: jn.bind(this, t),
            length: this.length
        };
    }
    function Ln(t) {
        return {
            [Symbol.iterator]: _n.bind(this, t),
            length: this[Bt].length
        };
    }
    function Nn(t) {
        return Ln.call(this, t)[Symbol.iterator]();
    }
    function _n(t) {
        const e = Ie(t), n = this, r = this[Bt];
        let s = 0;
        return {
            next() {
                let t, i;
                if (s < r.length) {
                    const o = r[s++];
                    t = [ o, e((() => n[o])) ], i = !1;
                } else i = !0;
                return {
                    value: t,
                    done: i
                };
            }
        };
    }
    function Pn(t) {
        return {
            [Symbol.iterator]: Rn.bind(this, t),
            length: this[Bt].length
        };
    }
    function Dn(t) {
        return Pn.call(this, t)[Symbol.iterator]();
    }
    function Rn(t) {
        const e = Ie(t), n = this, r = this[Bt], s = this[Kt];
        let i = 0;
        return {
            next() {
                let t, o;
                if (i < r.length) {
                    const c = r[i++];
                    t = [ c, e((() => s[c].call(n))) ], o = !1;
                } else o = !0;
                return {
                    value: t,
                    done: o
                };
            }
        };
    }
    function Wn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = t[e], s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function Zn() {
        const t = this, e = this.length;
        let n = 0;
        return {
            next() {
                let r, s;
                if (n < e) {
                    const e = n++;
                    r = [ e, t[e] ], s = !1;
                } else s = !0;
                return {
                    value: r,
                    done: s
                };
            }
        };
    }
    function qn() {
        return {
            [Symbol.iterator]: Zn.bind(this),
            length: this.length
        };
    }
    function Jn(t = {}) {
        const e = this, n = 1 === e.next.length ? [ t ] : [];
        return {
            next() {
                const t = e.next(...n);
                return {
                    value: t,
                    done: null === t
                };
            }
        };
    }
    function Gn(t, {get: e, set: n}) {
        return void 0 !== t ? {
            get: function() {
                return e.call(this, t);
            },
            set: n ? function(e, r) {
                return n.call(this, t, e, r);
            } : void 0
        } : {
            get: e,
            set: n
        };
    }
    function Hn(t) {
        return Yn.call(this, t).$;
    }
    function Yn(t) {
        return this[It][t] ?? this[ue](t);
    }
    function Xn(t) {
        const e = Yn.call(this, t).$;
        return e ? e.string : e;
    }
    function Kn(t, e, n) {
        Yn.call(this, t)[ge](e, n);
    }
    rn({
        defineArrayEntries: () => Ae(Fn),
        defineArrayIterator: () => Ae(Tn)
    }), rn({
        defineStructEntries: () => Ae(Ln),
        defineStructIterator: () => Ae(Nn)
    }), rn({
        defineUnionEntries: () => Ae(Pn),
        defineUnionIterator: () => Ae(Dn)
    }), rn({
        defineVectorEntries: () => Ae(qn),
        defineVectorIterator: () => Ae(Wn)
    }), rn({
        defineZigIterator: () => Ae(Jn)
    }), rn({
        defineMember(t, e = !0) {
            if (!t) return {};
            const {type: n, structure: r} = t, s = this[`defineMember${W[n]}`].call(this, t);
            if (e && r) {
                const {type: e} = r, n = this[`transformDescriptor${f[e]}`];
                if (n) return n.call(this, s, t);
            }
            return s;
        }
    }), rn({
        defineBase64(t) {
            const e = this;
            return We({
                get() {
                    return function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) return Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64");
                        const e = new Uint8Array(t.buffer, t.byteOffset, t.byteLength), n = String.fromCharCode.apply(null, e);
                        return btoa(n);
                    }(this.dataView);
                },
                set(n, r) {
                    if ("string" != typeof n) throw new cn("string", n);
                    const s = function(t) {
                        if ("function" == typeof Buffer && Buffer.prototype instanceof Uint8Array) {
                            const e = Buffer.from(t, "base64");
                            return new DataView(e.buffer, e.byteOffset, e.byteLength);
                        }
                        const e = atob(t), n = new Uint8Array(e.length);
                        for (let t = 0; t < n.byteLength; t++) n[t] = e.charCodeAt(t);
                        return new DataView(n.buffer);
                    }(n);
                    e.assignView(this, s, t, !1, r);
                }
            });
        }
    }), rn({
        defineMemberBool(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), rn({
        defineClampedArray(t) {
            const e = this, n = Uint8ClampedArray;
            return We({
                get() {
                    const t = this.typedArray;
                    return new n(t.buffer, t.byteOffset, t.length);
                },
                set(r, s) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new cn(n.name, r);
                    const i = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, i, t, !0, s);
                }
            });
        }
    }), rn({
        defineDataView(t) {
            const e = this;
            return We({
                get() {
                    const t = this[At];
                    if (e.usingBufferFallback()) {
                        const n = t.buffer[ie];
                        void 0 !== n && e.syncExternalBuffer(t.buffer, n, !1);
                    }
                    return t;
                },
                set(n, r) {
                    if ("DataView" !== n?.[Symbol.toStringTag]) throw new cn("DataView", n);
                    e.assignView(this, n, t, !0, r);
                }
            });
        },
        imports: {
            syncExternalBuffer: null
        }
    }), rn({
        defineMemberFloat(t) {
            return this.defineMemberUsing(t, this.getAccessor);
        }
    }), rn({
        defineMemberInt(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), rn({
        defineMemberLiteral(t) {
            const {slot: e} = t;
            return Gn(e, {
                get(t) {
                    return this[It][t].string;
                },
                set: un
            });
        }
    }), rn({
        defineMemberNull: t => ({
            get: function() {
                return null;
            },
            set: un
        })
    }), rn({
        defineMemberObject: t => Gn(t.slot, {
            get: t.flags & Y ? Xn : t.structure.flags & h ? Hn : Yn,
            set: t.flags & q ? un : Kn
        })
    }), rn({
        ...{
            defineMemberUsing(t, e) {
                const {littleEndian: n} = this, {bitOffset: r, byteSize: s} = t, i = e.call(this, "get", t), o = e.call(this, "set", t);
                if (void 0 !== r) {
                    const t = r >> 3;
                    return {
                        get: function() {
                            return i.call(this[At], t, n);
                        },
                        set: function(e) {
                            return o.call(this[At], t, e, n);
                        }
                    };
                }
                return {
                    get: function(e) {
                        try {
                            return i.call(this[At], e * s, n);
                        } catch (n) {
                            throw function(t, e, n) {
                                return n instanceof RangeError && !(n instanceof OutOfBound) && (n = new OutOfBound(t, e)), 
                                n;
                            }(t, e, n);
                        }
                    },
                    set: function(t, e) {
                        return o.call(this[At], t * s, e, n);
                    }
                };
            }
        }
    }), rn({
        defineSentinel(t) {
            const {byteSize: e, instance: {members: [n, r], template: s}} = t, {get: i} = this.defineMember(r), {get: o} = this.defineMember(n), c = i.call(s, 0), a = !!(r.flags & Z), {runtimeSafety: l} = this;
            return Ae({
                value: c,
                bytes: s[At],
                validateValue(e, n, r) {
                    if (a) {
                        if (l && e === c && n !== r - 1) throw new MisplacedSentinel(t, e, n, r);
                        if (e !== c && n === r - 1) throw new MissingSentinel(t, c, r);
                    }
                },
                validateData(n, r) {
                    if (a) if (l) for (let e = 0; e < r; e++) {
                        const s = o.call(n, e);
                        if (s === c && e !== r - 1) throw new MisplacedSentinel(t, c, e, r);
                        if (s !== c && e === r - 1) throw new MissingSentinel(t, c, r);
                    } else if (r > 0 && r * e === n[At].byteLength) {
                        if (o.call(n, r - 1) !== c) throw new MissingSentinel(t, c, r);
                    }
                },
                isRequired: a
            });
        },
        imports: {
            findSentinel: null
        }
    }), rn({
        defineString(t) {
            const e = this, {byteSize: n} = t.instance.members[0], r = "utf-" + 8 * n;
            return We({
                get() {
                    let t = Me(this.typedArray, r);
                    const e = this.constructor[Ct]?.value;
                    return void 0 !== e && t.charCodeAt(t.length - 1) === e && (t = t.slice(0, -1)), 
                    t;
                },
                set(n, s) {
                    if ("string" != typeof n) throw new cn("string", n);
                    const i = this.constructor[Ct]?.value;
                    void 0 !== i && n.charCodeAt(n.length - 1) !== i && (n += String.fromCharCode(i));
                    const o = Ee(n, r), c = new DataView(o.buffer);
                    e.assignView(this, c, t, !1, s);
                }
            });
        }
    }), rn({
        defineValueOf: () => ({
            value() {
                return er(this, !1);
            }
        })
    });
    const Qn = BigInt(Number.MAX_SAFE_INTEGER), tr = BigInt(Number.MIN_SAFE_INTEGER);
    function er(t, n) {
        const r = {
            error: n ? "return" : "throw"
        }, s = Ie(r), i = new Map, o = function(t) {
            const c = "function" == typeof t ? e.Struct : t?.constructor?.[Vt];
            if (void 0 === c) {
                if (n) {
                    if ("bigint" == typeof t && tr <= t && t <= Qn) return Number(t);
                    if (t instanceof Error) return {
                        error: t.message
                    };
                }
                return t;
            }
            let a = i.get(t);
            if (void 0 === a) {
                let n;
                switch (c) {
                  case e.Struct:
                    n = t[jt](r), a = t.constructor[Ut] & S.IsTuple ? [] : {};
                    break;

                  case e.Union:
                    n = t[jt](r), a = {};
                    break;

                  case e.Array:
                  case e.Vector:
                  case e.Slice:
                    n = t[jt](), a = [];
                    break;

                  case e.Pointer:
                    try {
                        a = t["*"];
                    } catch (t) {
                        a = Symbol.for("inaccessible");
                    }
                    break;

                  case e.Enum:
                    a = s((() => String(t)));
                    break;

                  case e.Opaque:
                    a = {};
                    break;

                  default:
                    a = s((() => t.$));
                }
                if (a = o(a), i.set(t, a), n) for (const [t, e] of n) a[t] = o(e);
            }
            return a;
        };
        return o(t);
    }
    rn({
        defineToJSON: () => ({
            value() {
                return er(this, !0);
            }
        })
    }), rn({
        defineMemberType(t, e) {
            const {slot: n} = t;
            return Gn(n, {
                get(t) {
                    const e = this[It][t];
                    return e?.constructor;
                },
                set: un
            });
        }
    }), rn({
        defineTypedArray(t) {
            const e = this, n = this.getTypedArray(t);
            return We({
                get() {
                    const t = this.dataView, e = t.byteLength / n.BYTES_PER_ELEMENT;
                    return new n(t.buffer, t.byteOffset, e);
                },
                set(r, s) {
                    if (r?.[Symbol.toStringTag] !== n.name) throw new cn(n.name, r);
                    const i = new DataView(r.buffer, r.byteOffset, r.byteLength);
                    e.assignView(this, i, t, !0, s);
                }
            });
        }
    }), rn({
        defineMemberUint(t) {
            let e = this.getAccessor;
            return this.runtimeSafety && (e = this.addRuntimeCheck(e)), e = this.addIntConversion(e), 
            this.defineMemberUsing(t, e);
        }
    }), rn({
        defineMemberUndefined: t => ({
            get: function() {},
            set: un
        })
    }), rn({
        defineMemberUnsupported(t) {
            const e = function() {
                throw new Unsupported;
            };
            return {
                get: e,
                set: e
            };
        }
    }), rn({
        defineMemberVoid(t, e) {
            const {bitOffset: n} = t;
            return {
                get() {},
                set: void 0 !== n ? function(e) {
                    if (void 0 !== e) throw new NotUndefined(t);
                } : function(e, n) {
                    if (void 0 !== n) throw new NotUndefined(t);
                    if (e < 0 || e >= this.length) throw new OutOfBound(t, e);
                }
            };
        }
    }), rn({
        defineStructure(t) {
            const {type: e, byteSize: n} = t, r = this[`define${f[e]}`], s = [], i = {}, o = {
                dataView: this.defineDataView(t),
                base64: this.defineBase64(t),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [Gt]: {
                    value: null
                },
                [Qt]: Ae(i),
                [Lt]: Ae(s),
                [he]: this.defineCopier(n)
            }, c = t.constructor = r.call(this, t, o);
            for (const [t, e] of Object.entries(o)) {
                const n = e?.set;
                n && !i[t] && "$" !== t && (i[t] = n, s.push(t));
            }
            return Se(c.prototype, o), c;
        },
        finalizeStructure(t) {
            const {name: n, type: r, constructor: s, align: i, byteSize: o, flags: c, signature: a, static: {members: l, template: u}} = t, h = [], d = {
                name: Ae(n),
                toJSON: this.defineToJSON(),
                valueOf: this.defineValueOf(),
                [oe]: Ae(a),
                [Ht]: Ae(this),
                [Jt]: Ae(i),
                [Zt]: Ae(o),
                [Vt]: Ae(r),
                [Ut]: Ae(c),
                [Bt]: Ae(h),
                [te]: Ae(this.getTypedArray(t)),
                [Symbol.iterator]: this.defineStructIterator(),
                [jt]: this.defineStructEntries(),
                [Bt]: Ae(h)
            }, g = {
                [Symbol.toStringTag]: Ae(n)
            };
            if (l) for (const t of l) {
                const {name: n, slot: r, flags: s} = t;
                if (t.structure.type === e.Function) {
                    let e = u[It][r];
                    s & Y && (e[ce] = !0), d[n] = Ae(e), e.name || ve(e, "name", Ae(n));
                    const [i, o] = /^(get|set)\s+([\s\S]+)/.exec(n)?.slice(1) ?? [], c = "get" === i ? 0 : 1;
                    if (i && e.length === c) {
                        d[o] ||= {};
                        d[o][i] = e;
                    }
                    if (t.flags & G) {
                        const t = function(...t) {
                            try {
                                return e(this, ...t);
                            } catch (t) {
                                throw t[ae]?.(1), t;
                            }
                        };
                        if (Se(t, {
                            name: Ae(n),
                            length: Ae(e.length - 1)
                        }), g[n] = Ae(t), i && t.length === c) {
                            (g[o] ||= {})[i] = t;
                        }
                    }
                } else d[n] = this.defineMember(t), h.push(n);
            }
            d[It] = h.length > 0 && Ae(u[It]);
            const p = this[`finalize${f[r]}`];
            !1 !== p?.call(this, t, d, g) && (Se(s.prototype, g), Se(s, d));
        },
        createConstructor(t, n = {}) {
            const {type: r, byteSize: s, align: i, flags: o, instance: {members: c, template: a}} = t, {onCastError: l} = n;
            let u;
            if (a?.[It]) {
                const t = c.filter((t => t.flags & q));
                t.length > 0 && (u = t.map((t => t.slot)));
            }
            const f = new ObjectCache, h = this, d = function(n, c = {}) {
                const {allocator: g} = c, y = this instanceof d;
                let b, m;
                if (y) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if (b = this, o & p && (b[It] = {}), de in b) b[ge](n, g), m = b[At]; else {
                        const t = r !== e.Pointer ? g : null;
                        b[At] = m = h.allocateMemory(s, i, t);
                    }
                } else {
                    if (be in d && (b = d[be].call(this, n, c), !1 !== b)) return b;
                    if (m = h.extractView(t, n, l), b = f.find(m)) return b;
                    b = Object.create(d.prototype), de in b ? h.assignView(b, m, t, !1, !1) : b[At] = m, 
                    o & p && (b[It] = {});
                }
                if (u) for (const t of u) b[It][t] = a[It][t];
                return b[pe]?.(), y && (de in b || b[ge](n, g)), ye in b && (b = b[ye]()), f.save(m, b);
            };
            return ve(d, Wt, Ae(f)), d;
        },
        createApplier(t) {
            const {instance: {template: e}} = t;
            return function(n, r) {
                const s = Object.keys(n), i = this[Lt], o = this[Qt];
                for (const e of s) if (!(e in o)) throw new NoProperty(t, e);
                let c = 0, a = 0, l = 0, u = 0;
                for (const t of i) {
                    const e = o[t];
                    e.special ? t in n && u++ : (c++, t in n ? a++ : e.required && l++);
                }
                if (0 !== l && 0 === u) {
                    const e = i.filter((t => o[t].required && !(t in n)));
                    throw new MissingInitializers(t, e);
                }
                if (u + a > s.length) for (const t of i) t in n && (s.includes(t) || s.push(t));
                a < c && 0 === u && e && e[At] && this[he](e);
                for (const t of s) {
                    o[t].call(this, n[t], r);
                }
                return s.length;
            };
        },
        getTypedArray(t) {
            const {type: n, instance: r} = t;
            if (void 0 !== n && r) {
                const [t] = r.members;
                switch (n) {
                  case e.Enum:
                  case e.ErrorSet:
                  case e.Primitive:
                    {
                        const {byteSize: e, type: n} = t;
                        return globalThis[(e > 4 && n !== R.Float ? "Big" : "") + (n === R.Float ? "Float" : n === R.Int ? "Int" : "Uint") + 8 * e + "Array"];
                    }

                  case e.Array:
                  case e.Slice:
                  case e.Vector:
                    return this.getTypedArray(t.structure);
                }
            }
        }
    }), rn({
        defineArgStruct(t, e) {
            const {flags: n, byteSize: r, align: s, length: i, instance: {members: o}} = t, c = this, a = o.slice(1), l = function(t, e) {
                const o = this instanceof l;
                let u, f;
                if (o ? (u = this, f = c.allocateMemory(r, s)) : (u = Object.create(l.prototype), 
                f = t), u[At] = f, n & p && (u[It] = {}), !o) return u;
                {
                    let r;
                    if (n & _ && t.length === i + 1 && (r = t.pop()), t.length !== i) throw new ArgumentCountMismatch(i, t.length);
                    n & D && (u[ye] = null), c.copyArguments(u, t, a, r, e);
                }
            };
            for (const t of o) e[t.name] = this.defineMember(t);
            const u = e.retval.set;
            return e.length = Ae(a.length), e[ue] = n & d && this.defineVivificatorStruct(t), 
            e[fe] = n & g && this.defineVisitorArgStruct(o), e[me] = Ae((function(t) {
                u.call(this, t, this[se]);
            })), e[Symbol.iterator] = this.defineArgIterator?.(a), l;
        },
        finalizeArgStruct(t, e) {
            const {flags: n} = t;
            e[ee] = Ae(!!(n & P));
        }
    }), rn({
        defineFinalizerArray: ({get: t, set: e}) => ({
            value() {
                const n = new Proxy(this, nr);
                return Se(this, {
                    [Rt]: {
                        value: n
                    },
                    get: {
                        value: t.bind(this)
                    },
                    set: e && {
                        value: e.bind(this)
                    }
                }), n;
            }
        }),
        defineVivificatorArray(t) {
            const {instance: {members: [e]}} = t, {byteSize: n, structure: r} = e, s = this;
            return {
                value: function(t) {
                    const {constructor: e} = r, i = this[At], o = i.byteOffset + n * t, c = s.obtainView(i.buffer, o, n);
                    return this[It][t] = e.call(xt, c);
                }
            };
        }
    });
    const nr = {
        get(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? t.get(n) : e === zt ? t : t[e];
        },
        set(t, e, n) {
            const r = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== r || r == e ? t.set(r, n) : t[e] = n, !0;
        },
        deleteProperty(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e && (delete t[e], !0);
        },
        has(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 !== n || n == e ? n >= 0 && n < t.length : t[e];
        },
        ownKeys(t) {
            const e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(`${n}`);
            return e.push("length", Rt), e;
        },
        getOwnPropertyDescriptor(t, e) {
            const n = "symbol" == typeof e ? 0 : 0 | e;
            return 0 === n && n != e ? Object.getOwnPropertyDescriptor(t, e) : n >= 0 && n < t.length ? {
                value: t.get(n),
                enumerable: !0,
                writable: !0,
                configurable: !0
            } : void 0;
        }
    };
    rn({
        defineArray(t, e) {
            const {length: n, instance: {members: [r]}, flags: s} = t, i = this.createApplier(t), o = this.defineMember(r), {set: c} = o, a = this.createConstructor(t), l = function(e, r) {
                if (Ne(e, a)) this[he](e), s & g && this[fe]("copy", tt.Vivificate, e); else if ("string" == typeof e && s & m && (e = {
                    string: e
                }), e?.[Symbol.iterator]) {
                    if ((e = Te(e)).length !== n) throw new ArrayLengthMismatch(t, this, e);
                    let s = 0;
                    for (const t of e) c.call(this, s++, t, r);
                } else if (e && "object" == typeof e) {
                    if (0 === i.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            };
            return e.$ = {
                get: Je,
                set: l
            }, e.length = Ae(n), e.entries = e[jt] = this.defineArrayEntries(), s & w && (e.typedArray = this.defineTypedArray(t), 
            s & m && (e.string = this.defineString(t)), s & v && (e.clampedArray = this.defineClampedArray(t))), 
            e[Symbol.iterator] = this.defineArrayIterator(), e[ge] = Ae(l), e[ye] = this.defineFinalizerArray(o), 
            e[ue] = s & d && this.defineVivificatorArray(t), e[fe] = s & g && this.defineVisitorArray(), 
            a;
        },
        finalizeArray(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = Ae(r.structure.constructor), e[Ct] = n & b && this.defineSentinel(t);
        }
    }), rn({
        defineEnum(t, e) {
            const {instance: {members: [n]}} = t, r = this.defineMember(n), {get: s, set: i} = r, {get: o} = this.defineMember(n, !1), c = this.createApplier(t), a = [ "string", "number", "tagged union" ], l = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, a, e);
                }
            });
            return e.$ = r, e.toString = Ae(Ge), e[Symbol.toPrimitive] = {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return this.$[Et];

                      default:
                        return o.call(this);
                    }
                }
            }, e[ge] = Ae((function(e) {
                if (e && "object" == typeof e) {
                    if (0 === c.call(this, e)) throw new InvalidInitializer(t, a, e);
                } else void 0 !== e && i.call(this, e);
            })), l;
        },
        finalizeEnum(t, e) {
            const {flags: n, constructor: r, instance: {members: [s]}, static: {members: i, template: o}} = t, c = o[It], {get: a, set: l} = this.defineMember(s, !1), u = {};
            for (const {name: t, flags: n, slot: r} of i) if (n & J) {
                const n = c[r];
                ve(n, Et, Ae(t));
                const s = a.call(n);
                e[t] = {
                    value: n,
                    writable: !1
                }, u[s] = n;
            }
            e[be] = {
                value(t) {
                    if ("string" == typeof t) return r[t];
                    if ("number" == typeof t || "bigint" == typeof t) {
                        let e = u[t];
                        if (!e && n & M) {
                            e = new r(void 0), l.call(e, t);
                            const n = `${t}`;
                            ve(e, Et, Ae(n)), ve(r, n, Ae(e)), u[t] = e;
                        }
                        return e;
                    }
                    return t instanceof r ? t : t?.[kt] instanceof r && t[kt];
                }
            }, e[te] = Ae(this.getTypedArray(t));
        },
        transformDescriptorEnum(t, e) {
            const {type: n, structure: r} = e;
            if (n === R.Object) return t;
            const s = function(t) {
                const {constructor: e} = r, n = e(t);
                if (!n) throw new EnumExpected(r, t);
                return n;
            }, {get: i, set: o} = t;
            return {
                get: 0 === i.length ? function() {
                    const t = i.call(this);
                    return s(t);
                } : function(t) {
                    const e = i.call(this, t);
                    return s(e);
                },
                set: 1 === o.length ? function(t) {
                    t = s(t)[Symbol.toPrimitive](), o.call(this, t);
                } : function(t, e) {
                    const n = s(e);
                    o.call(this, t, n[Symbol.toPrimitive]());
                }
            };
        }
    }), rn({
        init() {
            this.ZigError = null, this.globalItemsByIndex = {}, this.globalErrorSet = null;
        },
        defineErrorSet(t, n) {
            const {instance: {members: [r]}, byteSize: s, flags: i} = t;
            if (!this.ZigError) {
                this.ZigError = class Error extends ZigErrorBase {};
                const t = {
                    type: e.ErrorSet,
                    flags: F,
                    byteSize: s,
                    name: "anyerror",
                    instance: {
                        members: [ r ]
                    },
                    static: {
                        members: [],
                        template: {
                            SLOTS: {}
                        }
                    }
                }, n = this.defineStructure(t);
                this.finalizeStructure(t), this.globalErrorSet = n;
            }
            if (this.globalErrorSet && i & F) return this.globalErrorSet;
            const o = this.defineMember(r), {set: c} = o, a = [ "string", "number" ], l = this.createApplier(t), u = this.createConstructor(t, {
                onCastError(t, e) {
                    throw new InvalidInitializer(t, a, e);
                }
            });
            return n.$ = o, n[ge] = Ae((function(e) {
                if (e instanceof u[Ot]) c.call(this, e); else if (e && "object" == typeof e && !gn(e)) {
                    if (0 === l.call(this, e)) throw new InvalidInitializer(t, a, e);
                } else void 0 !== e && c.call(this, e);
            })), u;
        },
        finalizeErrorSet(t, e) {
            const {constructor: n, flags: r, instance: {members: [s]}, static: {members: i, template: o}} = t;
            if (this.globalErrorSet && r & F) return !1;
            const c = o?.[It] ?? {}, a = r & F ? this.globalItemsByIndex : {}, {get: l} = this.defineMember(s, !1);
            for (const {name: t, slot: n} of i) {
                const r = c[n], s = l.call(r);
                let i = this.globalItemsByIndex[s];
                const o = !!i;
                i || (i = new this.ZigError(t, s));
                const u = Ae(i);
                e[t] = u;
                const f = `${i}`;
                e[f] = u, a[s] = i, o || (Se(this.globalErrorSet, {
                    [t]: u,
                    [f]: u
                }), this.globalErrorSet[Bt].push(t), this.globalItemsByIndex[s] = i);
            }
            e[be] = {
                value: t => "number" == typeof t ? a[t] : "string" == typeof t ? n[t] : t instanceof n[Ot] ? a[Number(t)] : gn(t) ? n[`Error: ${t.error}`] : t instanceof Error && n[`${t}`]
            }, e[Ot] = Ae(this.ZigError);
        },
        transformDescriptorErrorSet(t, e) {
            const {type: n, structure: r} = e;
            if (n === R.Object) return t;
            const s = t => {
                const {constructor: e, flags: n} = r, s = e(t);
                if (!s) {
                    if (n & F && "number" == typeof t) {
                        const e = new this.ZigError(`Unknown error: ${t}`, t);
                        return this.globalItemsByIndex[t] = e, ve(this.globalErrorSet, `${e}`, Ae(e)), e;
                    }
                    throw t instanceof Error ? new NotInErrorSet(r) : new ErrorExpected(r, t);
                }
                return s;
            }, {get: i, set: o} = t;
            return {
                get: 0 === i.length ? function() {
                    const t = i.call(this);
                    return s(t);
                } : function(t) {
                    const e = i.call(this, t);
                    return s(e);
                },
                set: 1 === o.length ? function(t) {
                    const e = s(t);
                    t = Number(e), o.call(this, t);
                } : function(t, e) {
                    const n = s(e);
                    e = Number(n), o.call(this, t, e);
                }
            };
        }
    });
    class ZigErrorBase extends Error {
        constructor(t, e) {
            super(function(t) {
                let e = t.replace(/_/g, " ");
                try {
                    e = e.replace(/(\p{Uppercase}+)(\p{Lowercase}*)/gu, ((t, e, n) => 1 === e.length ? ` ${e.toLocaleLowerCase()}${n}` : n ? t : ` ${e}`)).trimStart();
                } catch (t) {}
                return e.charAt(0).toLocaleUpperCase() + e.substring(1);
            }(t)), this.number = e, this.stack = void 0;
        }
        [Symbol.toPrimitive](t) {
            switch (t) {
              case "string":
              case "default":
                return Error.prototype.toString.call(this, t);

              default:
                return this.number;
            }
        }
        toJSON() {
            return {
                error: this.message
            };
        }
    }
    function rr(t, e) {
        return Le(t?.constructor?.child, e) && t["*"];
    }
    function sr(t, e, n) {
        if (n & U) {
            if (t?.constructor?.child?.child === e.child && t["*"]) return !0;
            if (n & O && rr(t, e.child)) return !0;
        }
        return !1;
    }
    rn({
        defineErrorUnion(t, e) {
            const {instance: {members: [n, r]}, flags: s} = t, {get: i, set: o} = this.defineMember(n), {get: c, set: a} = this.defineMember(r), {get: l, set: u} = this.defineMember(r, !1), f = n.type === R.Void, h = r.structure.constructor, p = function() {
                this[le](), this[fe]?.("clear");
            }, y = this.createApplier(t), b = function(t, e) {
                if (Ne(t, v)) this[he](t), s & g && (l.call(this) || this[fe]("copy", 0, t)); else if (t instanceof h[Ot] && h(t)) a.call(this, t), 
                p.call(this); else if (void 0 !== t || f) try {
                    o.call(this, t, e), u.call(this, 0);
                } catch (e) {
                    if (t instanceof Error) {
                        const e = h(t) ?? h.Unexpected;
                        if (!e) throw new NotInErrorSet(r.structure);
                        a.call(this, e), p.call(this);
                    } else if (gn(t)) a.call(this, t), p.call(this); else {
                        if (!t || "object" != typeof t) throw e;
                        if (0 === y.call(this, t)) throw e;
                    }
                }
            }, {bitOffset: m, byteSize: w} = n, v = this.createConstructor(t);
            return e.$ = {
                get: function() {
                    if (l.call(this)) throw c.call(this);
                    return i.call(this);
                },
                set: b
            }, e[ge] = Ae(b), e[ue] = s & d && this.defineVivificatorStruct(t), e[le] = this.defineResetter(m / 8, w), 
            e[fe] = s & g && this.defineVisitorErrorUnion(n, l), v;
        }
    }), rn({
        defineFunction(t, n) {
            const {instance: {members: [r], template: s}, static: {template: i}} = t, o = new ObjectCache, {structure: {constructor: c}} = r, a = this, l = function(n) {
                const r = this instanceof l;
                let u, f;
                if (r) {
                    if (0 === arguments.length) throw new NoInitializer(t);
                    if ("function" != typeof n) throw new cn("function", n);
                    if (c[Vt] === e.VariadicStruct || !i) throw new Unsupported;
                    u = a.getFunctionThunk(n, i);
                } else {
                    if (this !== Ht) throw new NoCastingToFunction;
                    u = n;
                }
                if (f = o.find(u)) return f;
                const h = c.prototype.length, d = r ? a.createInboundCaller(n, c) : a.createOutboundCaller(s, c);
                return Se(d, {
                    length: Ae(h),
                    name: Ae(r ? n.name : "")
                }), Object.setPrototypeOf(d, l.prototype), d[At] = u, o.save(u, d), d;
            };
            return Object.setPrototypeOf(l.prototype, Function.prototype), n.valueOf = n.toJSON = Ae(qe), 
            l;
        },
        finalizeFunction(t, e, n) {
            n[Symbol.toStringTag] = void 0;
        }
    }), rn({
        defineOpaque(t, e) {
            const {purpose: n} = t, r = () => {
                throw new AccessingOpaque(t);
            }, s = this.createConstructor(t);
            return e.$ = {
                get: r,
                set: r
            }, e[Symbol.iterator] = n === o && this.defineZigIterator(), e[Symbol.toPrimitive] = {
                value(e) {
                    const {name: n} = t;
                    return `[opaque ${n}]`;
                }
            }, e[ge] = Ae((() => {
                throw new CreatingOpaque(t);
            })), s;
        }
    }), rn({
        defineOptional(t, e) {
            const {instance: {members: [n, r]}, flags: s} = t, {get: i, set: o} = this.defineMember(n), {get: c, set: a} = this.defineMember(r), l = n.type === R.Void, u = function(t, e) {
                Ne(t, f) ? (this[he](t), s & g && c.call(this) && this[fe]("copy", tt.Vivificate, t)) : null === t ? (a.call(this, 0), 
                this[le]?.(), this[fe]?.("clear")) : (void 0 !== t || l) && (o.call(this, t, e), 
                s & E ? a.call(this, 1) : s & g && (c.call(this) || a.call(this, 13)));
            }, f = t.constructor = this.createConstructor(t), {bitOffset: h, byteSize: p} = n;
            return e.$ = {
                get: function() {
                    return c.call(this) ? i.call(this) : (this[fe]?.("clear"), null);
                },
                set: u
            }, e[ge] = Ae(u), e[le] = s & E && this.defineResetter(h / 8, p), e[ue] = s & d && this.defineVivificatorStruct(t), 
            e[fe] = s & g && this.defineVisitorOptional(n, c), f;
        }
    }), rn({
        definePointer(t, n) {
            const {flags: r, byteSize: s, instance: {members: [i]}} = t, {structure: o} = i, {type: c, flags: a, byteSize: l = 1} = o, u = r & V ? s / 2 : s, {get: f, set: d} = this.defineMember({
                type: R.Uint,
                bitOffset: 0,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    byteSize: u
                }
            }), {get: g, set: p} = r & V ? this.defineMember({
                type: R.Uint,
                bitOffset: 8 * u,
                bitSize: 8 * u,
                byteSize: u,
                structure: {
                    flags: y,
                    byteSize: u
                }
            }) : {}, b = function(t, n = !0, s = !0) {
                if (n || this[At][Mt]) {
                    if (!s) return this[It][0] = void 0;
                    {
                        const n = E.child, s = f.call(this), i = r & V ? g.call(this) : c === e.Slice && a & $ ? x.findSentinel(s, n[Ct].bytes) + 1 : 1;
                        if (s !== this[Pt] || i !== this[Dt]) {
                            const e = x.findMemory(t, s, i, n[Zt]), o = e ? n.call(Ht, e) : null;
                            return this[It][0] = o, this[Pt] = s, this[Dt] = i, r & V && (this[Ft] = null), 
                            o;
                        }
                    }
                }
                return this[It][0];
            }, m = function(t) {
                d.call(this, t), this[Pt] = t;
            }, w = a & $ ? 1 : 0, v = r & V || a & $ ? function(t) {
                p?.call?.(this, t - w), this[Dt] = t;
            } : null, S = function() {
                const t = this[$t] ?? this, e = !t[It][0], n = b.call(t, null, e);
                if (!n) {
                    if (r & B) return null;
                    throw new NullPointer;
                }
                return r & k ? or(n) : n;
            }, A = a & h ? function() {
                return S.call(this).$;
            } : S, I = r & k ? un : function(t) {
                return S.call(this).$ = t;
            }, x = this, M = function(n, s) {
                const i = o.constructor;
                if (rr(n, i)) {
                    if (!(r & k) && n.constructor.const) throw new ConstantConstraint(t, n);
                    n = n[It][0];
                } else if (r & U) sr(n, i, r) && (n = i(n[It][0][At])); else if (c === e.Slice && a & j && n) if (n.constructor[Vt] === e.Pointer) n = n[Tt]?.[At]; else if (n[At]) n = n[At]; else if (n?.buffer instanceof ArrayBuffer && !(n instanceof Uint8Array || n instanceof DataView)) {
                    const {byteOffset: t, byteLength: e} = n;
                    void 0 !== t && void 0 !== e && (n = new DataView(n.buffer, t, e));
                }
                if (n instanceof i) {
                    const e = n[Gt];
                    if (e) {
                        if (!(r & k)) throw new ReadOnlyTarget(t);
                        n = e;
                    }
                } else if (Ne(n, i)) n = i.call(Ht, n[At]); else if (r & O && r & U && n instanceof i.child) n = i(n[At]); else if (function(t, e) {
                    const n = t?.[Symbol.toStringTag];
                    if (n) {
                        const r = e[te];
                        if (r) switch (n) {
                          case r.name:
                          case "DataView":
                            return !0;

                          case "ArrayBuffer":
                            return r === Uint8Array || r === Int8Array;

                          case "Uint8ClampedArray":
                            return r === Uint8Array;
                        }
                        if (e.child && void 0 !== je(t, e.child)) return !0;
                    }
                    return !1;
                }(n, i)) {
                    n = i(x.extractView(o, n));
                } else if (null == n || n[At]) {
                    if (!(void 0 === n || r & B && null === n)) throw new InvalidPointerTarget(t, n);
                } else {
                    if (r & O && r & U && "object" == typeof n && !n[Symbol.iterator]) {
                        let t = !0;
                        const e = i.prototype[Qt];
                        for (const r of Object.keys(n)) {
                            const n = e[r];
                            if (n?.special) {
                                t = !1;
                                break;
                            }
                        }
                        t && (n = [ n ]);
                    }
                    if (te in i && n?.buffer && n[Symbol.iterator]) throw new InvalidPointerTarget(t, n);
                    n = new i(n, {
                        allocator: s
                    });
                }
                const l = n?.[At]?.[Mt];
                if (-1 === l?.address) throw new PreviouslyFreed(n);
                this[Tt] = n;
            }, E = this.createConstructor(t);
            return n["*"] = {
                get: A,
                set: I
            }, n.$ = {
                get: Je,
                set: M
            }, n.length = {
                get: function() {
                    const t = S.call(this);
                    return t ? t.length : 0;
                },
                set: function(t) {
                    t |= 0;
                    const e = S.call(this);
                    if (!e) {
                        if (0 !== t) throw new InvalidSliceLength(t, 0);
                        return;
                    }
                    if (e.length === t) return;
                    const n = e[At], s = n[Mt];
                    let i;
                    if (!s) if (r & V) this[Ft] ||= e.length, i = this[Ft]; else {
                        i = (n.buffer.byteLength - n.byteOffset) / l | 0;
                    }
                    if (t < 0 || t > i) throw new InvalidSliceLength(t, i);
                    const c = t * l, a = s ? x.obtainZigView(s.address, c) : x.obtainView(n.buffer, n.byteOffset, c), u = o.constructor;
                    this[It][0] = u.call(Ht, a), v?.call?.(this, t);
                }
            }, n.slice = c === e.Slice && {
                value(t, e) {
                    const n = this[Tt].slice(t, e);
                    return new E(n);
                }
            }, n.subarray = c === e.Slice && {
                value(t, e, n) {
                    const r = this[Tt].subarray(t, e, n);
                    return new E(r);
                }
            }, n[Symbol.toPrimitive] = c === e.Primitive && {
                value(t) {
                    return this[Tt][Symbol.toPrimitive](t);
                }
            }, n[ge] = Ae(M), n[ye] = {
                value() {
                    const t = c !== e.Pointer ? cr : {};
                    let n;
                    c === e.Function ? (n = function() {}, n[At] = this[At], n[It] = this[It], Object.setPrototypeOf(n, E.prototype)) : n = this;
                    const r = new Proxy(n, t);
                    return Object.defineProperty(n, Rt, {
                        value: r
                    }), r;
                }
            }, n[Tt] = {
                get: S,
                set: function(t) {
                    if (void 0 === t) return;
                    const e = this[$t] ?? this;
                    if (t) {
                        const n = t[At][Mt];
                        if (n) {
                            const {address: e, js: r} = n;
                            m.call(this, e), v?.call?.(this, t.length), r && (t[At][Mt] = void 0);
                        } else if (e[At][Mt]) throw new ZigMemoryTargetRequired;
                    } else e[At][Mt] && (m.call(this, 0), v?.call?.(this, 0));
                    e[It][0] = t ?? null, r & V && (e[Ft] = null);
                }
            }, n[ae] = Ae(b), n[Nt] = {
                set: m
            }, n[_t] = {
                set: v
            }, n[fe] = this.defineVisitor(), n[Pt] = Ae(0), n[Dt] = Ae(0), n[Ft] = r & V && Ae(null), 
            n.dataView = n.base64 = void 0, E;
        },
        finalizePointer(t, n) {
            const {flags: r, constructor: s, instance: {members: [i]}} = t, {structure: o} = i, {type: c, constructor: a} = o;
            n.child = a ? Ae(a) : {
                get: () => o.constructor
            }, n.const = Ae(!!(r & k)), n[be] = {
                value(n, i) {
                    if (this === Ht || this === xt || n instanceof s) return !1;
                    if (rr(n, a)) return new s(a(n["*"]), i);
                    if (sr(n, a, r)) return new s(n);
                    if (c === e.Slice) return new s(a(n), i);
                    throw new NoCastingToPointer(t);
                }
            };
        }
    });
    const ir = new WeakMap;
    function or(t) {
        let e = ir.get(t);
        if (!e) {
            const n = t[$t];
            e = n ? new Proxy(n, ar) : new Proxy(t, lr), ir.set(t, e);
        }
        return e;
    }
    const cr = {
        get(t, e) {
            if (e === $t) return t;
            if (e in t) return t[e];
            return t[Tt][e];
        },
        set(t, e, n) {
            if (e in t) t[e] = n; else {
                t[Tt][e] = n;
            }
            return !0;
        },
        deleteProperty(t, e) {
            if (e in t) delete t[e]; else {
                delete t[Tt][e];
            }
            return !0;
        },
        has(t, e) {
            if (e in t) return !0;
            return e in t[Tt];
        },
        apply: (t, e, n) => t["*"].apply(e, n)
    }, ar = {
        ...cr,
        set(t, e, n) {
            if (e in t) un(); else {
                t[Tt][e] = n;
            }
            return !0;
        }
    }, lr = {
        get(t, e) {
            if (e === Gt) return t;
            {
                const n = t[e];
                return n?.[At] ? or(n) : n;
            }
        },
        set(t, e, n) {
            un();
        }
    };
    function ur() {
        return this[_t];
    }
    function fr(t, e) {
        return (t |= 0) < 0 ? (t = e + t) < 0 && (t = 0) : t > e && (t = e), t;
    }
    function hr() {
        throw new InaccessiblePointer;
    }
    function dr() {
        const t = {
            get: hr,
            set: hr
        };
        Se(this[$t], {
            "*": t,
            $: t,
            [$t]: t,
            [Tt]: t
        });
    }
    rn({
        definePrimitive(t, e) {
            const {instance: {members: [n]}} = t, r = this.createApplier(t), {get: s, set: i} = this.defineMember(n), o = function(e) {
                if (Ne(e, c)) this[he](e); else if (e && "object" == typeof e) {
                    if (0 === r.call(this, e)) {
                        const r = xe(n);
                        throw new InvalidInitializer(t, r, e);
                    }
                } else void 0 !== e && i.call(this, e);
            }, c = this.createConstructor(t);
            return e.$ = {
                get: s,
                set: o
            }, e[ge] = Ae(o), e[Symbol.toPrimitive] = Ae(s), c;
        },
        finalizePrimitive(t, e) {
            const {instance: {members: [n]}} = t;
            e[qt] = Ae(n.bitSize), e[Xt] = Ae(n.type);
        }
    }), rn({
        defineSlice(t, e) {
            const {align: n, flags: r, byteSize: s, name: i, instance: {members: [o]}} = t, {byteSize: c, structure: a} = o, l = this, u = function(t, e, r) {
                t || (t = l.allocateMemory(e * c, n, r)), this[At] = t, this[_t] = e;
            }, f = function(e, n) {
                if (n !== this[_t]) throw new ArrayLengthMismatch(t, this, e);
            }, h = this.defineMember(o), {set: p} = h, y = this.createApplier(t), b = function(e, n) {
                if (Ne(e, w)) this[At] ? f.call(this, e, e.length) : u.call(this, null, e.length, n), 
                this[he](e), r & g && this[fe]("copy", tt.Vivificate, e); else if ("string" == typeof e && r & C) b.call(this, {
                    string: e
                }, n); else if (e?.[Symbol.iterator]) {
                    e = Te(e), this[At] ? f.call(this, e, e.length) : u.call(this, null, e.length, n);
                    let t = 0;
                    for (const r of e) w[Ct]?.validateValue(r, t, e.length), p.call(this, t++, r, n);
                } else if ("number" == typeof e) {
                    if (!(!this[At] && e >= 0 && isFinite(e))) throw new InvalidArrayInitializer(t, e, !this[At]);
                    u.call(this, null, e, n);
                } else if (e && "object" == typeof e) {
                    if (0 === y.call(this, e, n)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, m = function(t, e) {
                const n = this[_t], r = this[At];
                t = void 0 === t ? 0 : fr(t, n), e = void 0 === e ? n : fr(e, n);
                const s = t * c, i = e * c - s;
                return l.obtainView(r.buffer, r.byteOffset + s, i);
            }, w = this.createConstructor(t);
            return e.$ = {
                get: Je,
                set: b
            }, e.length = {
                get: ur
            }, r & z && (e.typedArray = this.defineTypedArray(t), r & C && (e.string = this.defineString(t)), 
            r & T && (e.clampedArray = this.defineClampedArray(t))), e.entries = e[jt] = this.defineArrayEntries(), 
            e.subarray = {
                value(t, e) {
                    const n = m.call(this, t, e);
                    return w(n);
                }
            }, e.slice = {
                value(t, e, r = {}) {
                    const {zig: s = !1} = r, i = m.call(this, t, e), o = l.allocateMemory(i.byteLength, n, s), c = w(o);
                    return c[he]({
                        [At]: i
                    }), c;
                }
            }, e[Symbol.iterator] = this.defineArrayIterator(), e[de] = Ae(u), e[he] = this.defineCopier(s, !0), 
            e[ge] = Ae(b), e[ye] = this.defineFinalizerArray(h), e[ue] = r & d && this.defineVivificatorArray(t), 
            e[fe] = r & g && this.defineVisitorArray(), w;
        },
        finalizeSlice(t, e) {
            const {flags: n, instance: {members: [r]}} = t;
            e.child = Ae(r.structure.constructor), e[Ct] = n & $ && this.defineSentinel(t);
        }
    }), rn({
        defineVivificatorStruct(t) {
            const {instance: {members: e}} = t, n = {};
            for (const t of e.filter((t => t.type === R.Object))) n[t.slot] = t;
            const r = this;
            return {
                value(t) {
                    const e = n[t], {bitOffset: s, byteSize: i, structure: {constructor: o}} = e, c = this[At], a = c.byteOffset + (s >> 3);
                    let l = i;
                    if (void 0 === l) {
                        if (7 & s) throw new NotOnByteBoundary(e);
                        l = e.bitSize >> 3;
                    }
                    const u = r.obtainView(c.buffer, a, l);
                    return this[It][t] = o.call(xt, u);
                }
            };
        }
    }), rn({
        defineStruct(t, e) {
            const {purpose: n, flags: r, length: s, instance: {members: c}} = t, a = c.find((t => t.flags & H)), l = a && this.defineMember(a), u = this.createApplier(t), f = function(e, n) {
                if (Ne(e, h)) this[he](e), r & g && this[fe]("copy", 0, e); else if (e && "object" == typeof e) u.call(this, e, n); else if ("number" != typeof e && "bigint" != typeof e || !l) {
                    if (void 0 !== e) throw new InvalidInitializer(t, "object", e);
                } else l.set.call(this, e);
            }, h = this.createConstructor(t), p = e[Qt].value, y = e[Lt].value, b = [];
            for (const t of c.filter((t => !!t.name))) {
                const {name: n, flags: r} = t, {set: s} = e[n] = this.defineMember(t);
                s && (r & Z && (s.required = !0), p[n] = s, y.push(n)), b.push(n);
            }
            return e.$ = {
                get: qe,
                set: f
            }, e.length = Ae(s), e.entries = r & S.IsTuple && this.defineVectorEntries(), e[Symbol.toPrimitive] = l && {
                value(t) {
                    return "string" === t ? Object.prototype.toString.call(this) : l.get.call(this);
                }
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : r & S.IsTuple ? this.defineVectorIterator() : this.defineStructIterator(), 
            e[ge] = Ae(f), e[ue] = r & d && this.defineVivificatorStruct(t), e[fe] = r & g && this.defineVisitorStruct(c), 
            e[jt] = r & S.IsTuple ? this.defineVectorEntries() : this.defineStructEntries(), 
            e[Bt] = Ae(b), n === i && (e.alloc = this.defineAlloc(), e.free = this.defineFree(), 
            e.dupe = this.defineDupe()), h;
        }
    }), rn({
        defineUnion(t, e) {
            const {purpose: n, flags: r, instance: {members: s}} = t, i = !!(r & A), c = i ? s.slice(0, -1) : s, a = i ? s[s.length - 1] : null, {get: l, set: u} = this.defineMember(a), {get: f} = this.defineMember(a, !1), h = r & I ? function() {
                return l.call(this)[Et];
            } : function() {
                const t = l.call(this);
                return c[t].name;
            }, p = r & I ? function(t) {
                const {constructor: e} = a.structure;
                u.call(this, e[t]);
            } : function(t) {
                const e = c.findIndex((e => e.name === t));
                u.call(this, e);
            }, y = this.createApplier(t), b = function(e, n) {
                if (Ne(e, m)) this[he](e), r & g && this[fe]("copy", tt.Vivificate, e); else if (e && "object" == typeof e) {
                    let r = 0;
                    for (const t of M) t in e && r++;
                    if (r > 1) throw new MultipleUnionInitializers(t);
                    if (0 === y.call(this, e, n)) throw new MissingUnionInitializer(t, e, i);
                } else if (void 0 !== e) throw new InvalidInitializer(t, "object with a single property", e);
            }, m = this.createConstructor(t), w = {}, v = e[Qt].value, S = e[Lt].value, M = [];
            for (const n of c) {
                const {name: s} = n, {get: o, set: c} = this.defineMember(n), a = i ? function() {
                    const e = h.call(this);
                    if (s !== e) {
                        if (r & I) return null;
                        throw new InactiveUnionProperty(t, s, e);
                    }
                    return this[fe]?.("clear"), o.call(this);
                } : o, l = i && c ? function(e) {
                    const n = h.call(this);
                    if (s !== n) throw new InactiveUnionProperty(t, s, n);
                    c.call(this, e);
                } : c, u = i && c ? function(t) {
                    p.call(this, s), c.call(this, t), this[fe]?.("clear");
                } : c;
                e[s] = {
                    get: a,
                    set: l
                }, v[s] = u, w[s] = o, S.push(s), M.push(s);
            }
            e.$ = {
                get: function() {
                    return this;
                },
                set: b
            }, e[Symbol.iterator] = n === o ? this.defineZigIterator() : this.defineUnionIterator(), 
            e[Symbol.toPrimitive] = r & I && {
                value(t) {
                    switch (t) {
                      case "string":
                      case "default":
                        return h.call(this);

                      default:
                        return f.call(this);
                    }
                }
            };
            const {comptime: E} = this;
            return e[pe] = r & x && {
                value() {
                    return E || this[fe](dr), this[fe] = He, this;
                }
            }, e[ge] = Ae(b), e[kt] = r & I && {
                get: l,
                set: u
            }, e[ue] = r & d && this.defineVivificatorStruct(t), e[fe] = r & g && this.defineVisitorUnion(c, r & I ? f : null), 
            e[jt] = this.defineUnionEntries(), e[Bt] = r & I ? {
                get() {
                    return [ h.call(this) ];
                }
            } : Ae(M), e[Kt] = Ae(w), m;
        },
        finalizeUnion(t, e) {
            const {flags: n, instance: {members: r}} = t;
            n & I && (e.tag = Ae(r[r.length - 1].structure.constructor));
        }
    }), rn({
        defineVariadicStruct(t, e) {
            const {byteSize: n, align: r, flags: s, length: i, instance: {members: o}} = t, c = this, a = o.slice(1);
            for (const t of o) e[t.name] = this.defineMember(t);
            const l = e.retval.set, u = function(t) {
                this[At] = c.allocateMemory(8 * t, 4), this.length = t, this.littleEndian = c.littleEndian;
            };
            return Se(u, {
                [Jt]: {
                    value: 4
                }
            }), Se(u.prototype, {
                set: Ae((function(t, e, n, r, s) {
                    const i = this[At], o = c.littleEndian;
                    i.setUint16(8 * t, e, o), i.setUint16(8 * t + 2, n, o), i.setUint16(8 * t + 4, r, o), 
                    i.setUint8(8 * t + 6, s == R.Float), i.setUint8(8 * t + 7, s == R.Int || s == R.Float);
                }))
            }), e[ue] = s & d && this.defineVivificatorStruct(t), e[fe] = this.defineVisitorVariadicStruct(o), 
            e[me] = Ae((function(t) {
                l.call(this, t, this[se]);
            })), function(t) {
                if (t.length < i) throw new ArgumentCountMismatch(i, t.length, !0);
                let e = n, s = r;
                const o = t.slice(i), l = {};
                for (const [t, n] of o.entries()) {
                    const r = n?.[At], o = n?.constructor?.[Jt];
                    if (!r || !o) {
                        throw an(new InvalidVariadicArgument, i + t);
                    }
                    o > s && (s = o);
                    e = (l[t] = e + (o - 1) & ~(o - 1)) + r.byteLength;
                }
                const f = new u(t.length), h = c.allocateMemory(e, s);
                h[Jt] = s, this[At] = h, this[It] = {}, c.copyArguments(this, t, a);
                let d = -1;
                for (const [t, {bitOffset: e, bitSize: n, type: r, slot: s, structure: {align: i}}] of a.entries()) f.set(t, e / 8, n, i, r), 
                s > d && (d = s);
                for (const [t, e] of o.entries()) {
                    const n = d + t + 1, {byteLength: r} = e[At], s = l[t], o = c.obtainView(h.buffer, s, r), a = this[It][n] = e.constructor.call(xt, o), u = e.constructor[qt] ?? 8 * r, g = e.constructor[Jt], p = e.constructor[Xt];
                    a.$ = e, f.set(i + t, s, u, g, p);
                }
                this[Yt] = f;
            };
        },
        finalizeVariadicStruct(t, e) {
            const {flags: n} = t;
            e[ee] = Ae(!!(n & P)), e[Jt] = Ae(void 0);
        }
    }), rn({
        defineVector(t, e) {
            const {flags: n, length: r, instance: {members: [s]}} = t, i = this.createApplier(t), o = function(e) {
                if (Ne(e, c)) this[he](e), n & g && this[fe]("copy", tt.Vivificate, e); else if (e?.[Symbol.iterator]) {
                    let n = e.length;
                    if ("number" != typeof n && (n = (e = [ ...e ]).length), n !== r) throw new ArrayLengthMismatch(t, this, e);
                    let s = 0;
                    for (const t of e) this[s++] = t;
                } else if (e && "object" == typeof e) {
                    if (0 === i.call(this, e)) throw new InvalidArrayInitializer(t, e);
                } else if (void 0 !== e) throw new InvalidArrayInitializer(t, e);
            }, c = this.createConstructor(t, {
                initializer: o
            }), {bitSize: a} = s;
            for (let t = 0, i = 0; t < r; t++, i += a) e[t] = n & g ? this.defineMember({
                ...s,
                slot: t
            }) : this.defineMember({
                ...s,
                bitOffset: i
            });
            return e.$ = {
                get: qe,
                set: o
            }, e.length = Ae(r), n & L && (e.typedArray = this.defineTypedArray(t), n & N && (e.clampedArray = this.defineClampedArray(t))), 
            e.entries = e[jt] = this.defineVectorEntries(), e[Symbol.iterator] = this.defineVectorIterator(), 
            e[ge] = Ae(o), e[ue] = n & d && this.defineVivificatorArray(t), e[fe] = n & g && this.defineVisitorArray(), 
            c;
        },
        finalizeVector(t, e) {
            const {instance: {members: [n]}} = t;
            e.child = Ae(n.structure.constructor);
        }
    });
    const gr = {
        read: BigInt(dt.fd_read),
        write: BigInt(dt.fd_write),
        readdir: BigInt(dt.fd_readdir)
    };
    function pr(t, e, n, r) {
        let s, i = this[It][t];
        if (!i) {
            if (n & tt.IgnoreUncreated) return;
            i = this[ue](t);
        }
        r && (s = r[It][t], !s) || i[fe](e, n, s);
    }
    rn({
        pathAccess(t, e, n, r, s, i) {
            const o = De(s, gr), c = {
                ...De(e, ht),
                accessCheck: !0
            };
            let a;
            return hn(i, lt, (() => (a = this.obtainStreamLocation(t, n, r), this.triggerEvent("open", {
                ...a,
                rights: o,
                flags: c
            }, lt))), (t => {
                if (!1 === t) return lt;
                try {
                    let e;
                    o.read ? e = this.convertReader(t) : o.write ? e = this.convertWriter(t) : o.readdir && (e = this.convertDirectory(t));
                    for (const t of Object.keys(o)) if (!_e(e, t)) return nt;
                } catch {
                    return nt;
                }
            }));
        },
        exports: {
            pathAccess: {
                async: !0
            }
        }
    }), rn({
        defineVisitor: () => ({
            value(t, e, n) {
                let r;
                r = "string" == typeof t ? yr[t] : t, r.call(this, e, n);
            }
        })
    });
    const yr = {
        copy(t, e) {
            const n = e[It][0];
            if (this[At][Mt] && n && !n[At][Mt]) throw new ZigMemoryTargetRequired;
            this[It][0] = n;
        },
        clear(t) {
            t & tt.IsInactive && (this[It][0] = void 0);
        },
        reset() {
            this[It][0] = void 0, this[Pt] = void 0;
        }
    };
    return rn({
        defineVisitorArgStruct(t) {
            const e = [];
            let n;
            for (const [r, {slot: s, structure: i}] of t.entries()) i.flags & g && (0 === r ? n = s : e.push(s));
            return {
                value(t, r, s) {
                    if (!(r & tt.IgnoreArguments) && e.length > 0) for (const n of e) pr.call(this, n, t, r | tt.IsImmutable, s);
                    r & tt.IgnoreRetval || void 0 === n || pr.call(this, n, t, r, s);
                }
            };
        }
    }), rn({
        defineVisitorArray: () => ({
            value(t, e, n) {
                for (let r = 0, s = this.length; r < s; r++) pr.call(this, r, t, e, n);
            }
        })
    }), rn({
        defineVisitorErrorUnion(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, s) {
                    e.call(this) && (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || pr.call(this, n, t, r, s);
                }
            };
        }
    }), rn({
        defineVisitorOptional(t, e) {
            const {slot: n} = t;
            return {
                value(t, r, s) {
                    e.call(this) || (r |= tt.IsInactive), r & tt.IsInactive && r & tt.IgnoreInactive || pr.call(this, n, t, r, s);
                }
            };
        }
    }), rn({
        defineVisitorStruct(t) {
            const e = t.filter((t => t.structure?.flags & g)).map((t => t.slot));
            return {
                value(t, n, r) {
                    for (const s of e) pr.call(this, s, t, n, r);
                }
            };
        }
    }), rn({
        defineVisitorUnion(t, e) {
            const n = [];
            for (const [e, {slot: r, structure: s}] of t.entries()) s?.flags & g && n.push({
                index: e,
                slot: r
            });
            return {
                value(t, r, s) {
                    const i = e?.call(this);
                    for (const {index: e, slot: o} of n) {
                        let n = r;
                        e !== i && (n |= tt.IsInactive), n & tt.IsInactive && n & tt.IgnoreInactive || pr.call(this, o, t, n, s);
                    }
                }
            };
        }
    }), rn({
        defineVisitorVariadicStruct(t) {
            const e = t[0], n = e.structure.flags & g ? e.slot : void 0;
            return {
                value(t, e, r) {
                    if (!(e & tt.IgnoreArguments)) for (const [s, i] of Object.entries(this[It])) s !== n && fe in i && pr.call(this, s, t, e | tt.IsImmutable, r);
                    e & tt.IgnoreRetval || void 0 === n || pr.call(this, n, t, e, r);
                }
            };
        }
    }), t.createEnvironment = function() {
        try {
            return new (sn());
        } catch (t) {
            throw console.error(t), t;
        }
    }, t;
}({}))
